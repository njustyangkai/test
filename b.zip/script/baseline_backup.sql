create database if not exists backup DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
commit;

use backup ;
drop table if exists version_info;
CREATE TABLE version_info ( 
	version      varchar(200) NULL,
	sql_version    varchar(12) NOT NULL
);

insert into version_info values (null, '000000000000'); 


-- ----------------------------
-- Table structure for backup_record
-- ----------------------------
DROP TABLE IF EXISTS backup_record;
CREATE TABLE backup_record (
  id varchar(48) NOT NULL DEFAULT '' COMMENT '备份记录id',
  mode tinyint(4) DEFAULT NULL COMMENT '备份方式：1手动 2自动',
  status tinyint(4) DEFAULT NULL COMMENT '备份状态，1：成功 2：失败 3：进行中',
  progress tinyint(4) DEFAULT NULL COMMENT '备份进度',
  user_id varchar(48) DEFAULT NULL COMMENT '用户id',
  user_name varchar(100) DEFAULT NULL COMMENT '用户名称',
  file_name varchar(100) DEFAULT NULL COMMENT '备份文件名称',
  file_size double DEFAULT NULL COMMENT '文件大小',
  start_time datetime DEFAULT NULL COMMENT '备份开始时间',
  end_time datetime DEFAULT NULL COMMENT '备份结束时间',
  detail text COMMENT '详细信息',
  PRIMARY KEY (id)
);

-- ----------------------------
-- Table structure for backup_strategy
-- ----------------------------
DROP TABLE IF EXISTS backup_strategy;
CREATE TABLE backup_strategy (
  backup_auto tinyint(4) DEFAULT NULL COMMENT '是否开启自动备份 0=关闭 1=开启',
  backup_period tinyint(4) DEFAULT NULL COMMENT '备份周期 1=天 2=周 3=月',
  backup_day tinyint(4) DEFAULT NULL COMMENT '按天备份，无意义；按周备份，表示周几；按月备份，表示某天',
  backup_time varchar(20) DEFAULT NULL COMMENT '备份时间 03:00',
  backup_path varchar(1000) DEFAULT NULL COMMENT '备份文件路径',
  auto_clear_mode tinyint(4) DEFAULT NULL COMMENT '自动清除备份方式0=按备份文件占用大小方式 1=按备份文件保存天数',
  auto_clear_value int(11) DEFAULT NULL COMMENT '自动清除的策略值，备份文件总大小或者保存的天数，0表示不清除',
  auto_clear_threshold tinyint(4) DEFAULT NULL COMMENT '自动清除设置的阈值，当clearMode=0时有效',
  updated datetime DEFAULT NULL COMMENT '最近一次更新时间'
);
INSERT INTO backup_strategy VALUES ('0', '3', '1', '03:00', '/home/Data/vdirector-backup', '0', '0', '0', null);

-- ----------------------------
-- Table structure for restore_record
-- ----------------------------
DROP TABLE IF EXISTS restore_record;
CREATE TABLE restore_record (
  id varchar(48) NOT NULL COMMENT '备份恢复记录id',
  status tinyint(4) DEFAULT NULL COMMENT '备份恢复状态，1：成功 2：失败 3：进行中',
  progress tinyint(4) DEFAULT NULL COMMENT '备份恢复进度',
  user_id varchar(48) DEFAULT NULL COMMENT '用户id',
  user_name varchar(100) DEFAULT NULL COMMENT '用户名称',
  file_name varchar(100) DEFAULT NULL COMMENT '备份恢复文件名称',
  file_size double DEFAULT NULL COMMENT '文件大小',
  start_time datetime DEFAULT NULL COMMENT '备份恢复开始时间',
  end_time datetime DEFAULT NULL COMMENT '备份恢复结束时间',
  detail text COMMENT '详细信息',
  PRIMARY KEY (id)
);
