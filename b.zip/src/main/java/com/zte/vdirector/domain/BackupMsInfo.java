package com.zte.vdirector.domain;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupDbInfo   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 上午10:55:22 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 上午10:55:22  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class BackupMsInfo
{
    private String serviceName;
    
    private String homeDir;
    
    private String dbName;
    
    private String ignoreTables;
    
    private boolean enabled = true;

    /**
     * @return the serviceName
     */
    public String getServiceName()
    {
        return serviceName;
    }

    /**
     * @param serviceName the serviceName to set
     */
    public void setServiceName(String serviceName)
    {
        this.serviceName = serviceName;
    }

    /**
     * @return the homeDir
     */
    public String getHomeDir()
    {
        return homeDir;
    }

    /**
     * @param homeDir the homeDir to set
     */
    public void setHomeDir(String homeDir)
    {
        this.homeDir = homeDir;
    }

    /**
     * @return the dbName
     */
    public String getDbName()
    {
        return dbName;
    }

    /**
     * @param dbName the dbName to set
     */
    public void setDbName(String dbName)
    {
        this.dbName = dbName;
    }

    /**
     * @return the ignoreTables
     */
    public String[] getIgnoreTables()
    {
        if (ignoreTables == null || StringUtils.isBlank(ignoreTables.trim()))
        {
            return new String[]{};
        }
        return StringUtils.splitByWholeSeparator(ignoreTables.trim(), " ");
    }

    /**
     * @param ignoreTables the ignoreTables to set
     */
    public void setIgnoreTables(String ignoreTables)
    {
        this.ignoreTables = ignoreTables;
    }

    /**
     * @return the enabled
     */
    public boolean isEnabled()
    {
        return enabled;
    }

    /**
     * @param enabled the enabled to set
     */
    public void setEnabled(boolean enabled)
    {
        this.enabled = enabled;
    }
}
