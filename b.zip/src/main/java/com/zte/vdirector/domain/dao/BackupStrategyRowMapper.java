/**
 * 
 */
package com.zte.vdirector.domain.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.zte.vdirector.domain.BackupStrategy;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupStrategyRowMapper   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午2:50:59 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午2:50:59  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class BackupStrategyRowMapper implements RowMapper<BackupStrategy>
{

    @Override
    public BackupStrategy mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        BackupStrategy backupStrategy = new BackupStrategy();
        backupStrategy.setBackupAuto(rs.getBoolean("backup_auto"));
        backupStrategy.setBackupPeriod(rs.getInt("backup_period"));
        backupStrategy.setBackupDay(rs.getInt("backup_day"));
        backupStrategy.setBackupTime(rs.getString("backup_time"));
        backupStrategy.setBackupPath(rs.getString("backup_path"));
        backupStrategy.setClearMode(rs.getInt("auto_clear_mode"));
        backupStrategy.setClearValue(rs.getInt("auto_clear_value"));
        backupStrategy.setClearThreshold(rs.getInt("auto_clear_threshold"));
        if (rs.getTimestamp("updated") != null)
        {
            backupStrategy.setUpdated(new Date(rs.getTimestamp("updated").getTime()));
        }
        return backupStrategy;
    }

}
