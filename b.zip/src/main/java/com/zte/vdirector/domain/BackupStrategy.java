/**
 * 
 */
package com.zte.vdirector.domain;

import java.util.Date;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupStrategy   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午2:40:58 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午2:40:58  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class BackupStrategy
{
    /**
     * 是否开启自动备份 0=关闭 1=开启
     */
    private boolean isBackupAuto;
    
    /**
     * 备份周期 1=天 2=周 3=月
     */
    private int backupPeriod;
    
    /**
     * 按天备份，无意义；按周备份，表示周几；按月备份，表示某天
     */
    private int backupDay;
    
    /**
     * 备份时间 03:00
     */
    private String backupTime;
    
    /**
     * 备份文件目录
     */
    private String backupPath;
    
    /**
     * 自动清除备份方式0=按备份文件占用大小方式  1=按备份文件保存天数
     */
    private int clearMode;
    
    /**
     * 自动清除的策略值，备份文件总大小或者保存的天数，0表示不清除
     */
    private int clearValue;
    
    /**
     * 自动清除设置的阈值，当clearMode=0时有效
     */
    private int clearThreshold;
    
    /**
     * 最近一次更新时间
     */
    private Date updated;
    
    private boolean isHasFile;

    /**
     * @return the isBackupAuto
     */
    public boolean isBackupAuto()
    {
        return isBackupAuto;
    }

    /**
     * @param isBackupAuto the isBackupAuto to set
     */
    public void setBackupAuto(boolean isBackupAuto)
    {
        this.isBackupAuto = isBackupAuto;
    }

    /**
     * @return the backupPeriod
     */
    public int getBackupPeriod()
    {
        return backupPeriod;
    }

    /**
     * @param backupPeriod the backupPeriod to set
     */
    public void setBackupPeriod(int backupPeriod)
    {
        this.backupPeriod = backupPeriod;
    }

    /**
     * @return the backupDay
     */
    public int getBackupDay()
    {
        return backupDay;
    }

    /**
     * @param backupDay the backupDay to set
     */
    public void setBackupDay(int backupDay)
    {
        this.backupDay = backupDay;
    }

    /**
     * @return the backupTime
     */
    public String getBackupTime()
    {
        return backupTime;
    }

    /**
     * @param backupTime the backupTime to set
     */
    public void setBackupTime(String backupTime)
    {
        this.backupTime = backupTime;
    }

    /**
     * @return the backupPath
     */
    public String getBackupPath()
    {
        return backupPath;
    }

    /**
     * @param backupPath the backupPath to set
     */
    public void setBackupPath(String backupPath)
    {
        this.backupPath = backupPath;
    }

    /**
     * @return the clearMode
     */
    public int getClearMode()
    {
        return clearMode;
    }

    /**
     * @param clearMode the clearMode to set
     */
    public void setClearMode(int clearMode)
    {
        this.clearMode = clearMode;
    }

    /**
     * @return the clearValue
     */
    public int getClearValue()
    {
        return clearValue;
    }

    /**
     * @param clearValue the clearValue to set
     */
    public void setClearValue(int clearValue)
    {
        this.clearValue = clearValue;
    }

    /**
     * @return the clearThreshold
     */
    public int getClearThreshold()
    {
        return clearThreshold;
    }

    /**
     * @param clearThreshold the clearThreshold to set
     */
    public void setClearThreshold(int clearThreshold)
    {
        this.clearThreshold = clearThreshold;
    }

    /**
     * @return the updated
     */
    public Date getUpdated()
    {
        return updated;
    }

    /**
     * @param updated the updated to set
     */
    public void setUpdated(Date updated)
    {
        this.updated = updated;
    }

    /**
     * @return the isHasFile
     */
    public boolean isHasFile()
    {
        return isHasFile;
    }

    /**
     * @param isHasFile the isHasFile to set
     */
    public void setHasFile(boolean isHasFile)
    {
        this.isHasFile = isHasFile;
    }

}
