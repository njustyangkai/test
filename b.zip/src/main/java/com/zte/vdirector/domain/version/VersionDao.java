package com.zte.vdirector.domain.version;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：backup  
 * </p>  
 * <p>   
 * 类名称：VersionDao   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年12月6日 下午2:40:43 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年12月6日 下午2:40:43  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Repository
public class VersionDao
{
    @Resource
    private JdbcTemplate jdbcTemplate;

    public Map<String, Object> getVersionInfo()
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select version,sql_version from version_info");
        List<Map<String, Object>> mapList = jdbcTemplate.queryForList(sql.toString());

        if (mapList != null && mapList.size() > 0)
        {
            return mapList.get(0);
        }
        return null;
    }

    public void updateVersion(String sqlVersion)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("update version_info set sql_version = ?");
        jdbcTemplate.update(sql.toString(), sqlVersion);
    }
}
