/**
 * 
 */
package com.zte.vdirector.domain.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.zte.vdirector.domain.BackupRecord;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupRecordRowMapper   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午2:50:59 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午2:50:59  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class BackupRecordRowMapper implements RowMapper<BackupRecord>
{

    @Override
    public BackupRecord mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        BackupRecord backupRecord = new BackupRecord();
        backupRecord.setId(rs.getString("id"));
        backupRecord.setMode(rs.getInt("mode"));
        backupRecord.setStatus(rs.getInt("status"));
        backupRecord.setProgress(rs.getInt("progress"));
        backupRecord.setUserId(rs.getString("user_id"));
        backupRecord.setUserName(rs.getString("user_name"));
        backupRecord.setFileName(rs.getString("file_name"));
        backupRecord.setFileSize(rs.getDouble("file_size"));
        if (rs.getTimestamp("start_time") != null)
        {
            backupRecord.setStartTime(new Date(rs.getTimestamp("start_time").getTime()));
        }
        if (rs.getTimestamp("end_time") != null)
        {
            backupRecord.setEndTime(new Date(rs.getTimestamp("end_time").getTime()));
        }
        backupRecord.setDetail(rs.getString("detail"));
        return backupRecord;
    }

}
