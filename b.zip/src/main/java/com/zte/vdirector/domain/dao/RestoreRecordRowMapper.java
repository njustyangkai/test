/**
 * 
 */
package com.zte.vdirector.domain.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.zte.vdirector.domain.RestoreRecord;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：RestoreRecordRowMapper   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午2:50:59 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午2:50:59  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class RestoreRecordRowMapper implements RowMapper<RestoreRecord>
{

    @Override
    public RestoreRecord mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        RestoreRecord restoreRecord = new RestoreRecord();
        restoreRecord.setId(rs.getString("id"));
        restoreRecord.setStatus(rs.getInt("status"));
        restoreRecord.setProgress(rs.getInt("progress"));
        restoreRecord.setUserId(rs.getString("user_id"));
        restoreRecord.setUserName(rs.getString("user_name"));
        restoreRecord.setFileName(rs.getString("file_name"));
        restoreRecord.setFileSize(rs.getDouble("file_size"));
        if (rs.getTimestamp("start_time") != null)
        {
            restoreRecord.setStartTime(new Date(rs.getTimestamp("start_time").getTime()));
        }
        if (rs.getTimestamp("end_time") != null)
        {
            restoreRecord.setEndTime(new Date(rs.getTimestamp("end_time").getTime()));
        }
        restoreRecord.setDetail(rs.getString("detail"));
        return restoreRecord;
    }

}
