/**
 * 
 */
package com.zte.vdirector.domain.dao;

import java.io.File;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.zte.vdirector.domain.BackupStrategy;
import com.zte.vdirector.frame.exception.BackupException;
import com.zte.vdirector.frame.utils.BackupUtils;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupStrategyDao   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午3:02:13 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午3:02:13  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Repository
public class BackupStrategyDao
{
    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 查询策略
     * @return
     */
    public BackupStrategy queryBackupStrategy()
    {
        String sql = "select * from backup_strategy";
        List<BackupStrategy> backupStrategies = jdbcTemplate.query(sql, new BackupStrategyRowMapper());
        if (backupStrategies.size() > 0)
        {
            BackupStrategy backupStrategy = backupStrategies.get(0);
            
            if (StringUtils.isNotBlank(backupStrategy.getBackupPath()))
            {
                File file = new File(backupStrategy.getBackupPath());
                if (file.exists())
                {
                    long size = BackupUtils.getDirSize(file);
                    if (size > 0)
                    {
                        backupStrategy.setHasFile(true);
                    }
                }
            }
            return backupStrategy;
        }
        throw new BackupException("Failed to get backup strategy from db!");
    }

    /**
     * 更新策略
     * @param backupStrategy
     * @return BackupStrategy
     */
    public BackupStrategy updateBackupStrategy(BackupStrategy backupStrategy)
    {
        String sql = "update backup_strategy set backup_auto = ?, backup_period = ?, backup_day = ?, backup_time = ?, backup_path = ?, "
                + "auto_clear_mode = ?, auto_clear_value = ?, auto_clear_threshold = ?, updated = ?";
        int backupAuto = 0;
        if (backupStrategy.isBackupAuto())
        {
            backupAuto = 1;
        }

        jdbcTemplate.update(sql, backupAuto, backupStrategy.getBackupPeriod(), backupStrategy.getBackupDay(),
                backupStrategy.getBackupTime(), backupStrategy.getBackupPath(), backupStrategy.getClearMode(),
                backupStrategy.getClearValue(), backupStrategy.getClearThreshold(), new Date());
        return backupStrategy;
    }
}
