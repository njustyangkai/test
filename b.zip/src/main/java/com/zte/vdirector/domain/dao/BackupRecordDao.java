/**
 * 
 */
package com.zte.vdirector.domain.dao;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.zte.vdirector.domain.BackupRecord;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupRecordDao   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午3:02:13 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午3:02:13  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Repository
public class BackupRecordDao
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 查询备份列表
     * @return
     */
    public List<BackupRecord> queryBackupRecords()
    {
        String sql = "select * from backup_record order by start_time desc";
        return jdbcTemplate.query(sql, new BackupRecordRowMapper());
    }
    
    /**
     * 查询备份信息
     * @return
     */
    public BackupRecord queryBackupRecord(String id)
    {
        try
        {
            String sql = "select * from backup_record where id = ?";
            return jdbcTemplate.queryForObject(sql, new BackupRecordRowMapper(), id);
        }
        catch (Exception e)
        {
            logger.error("queryBackupRecord Exception: " + e.getMessage());
            return null;
        }
    }

    /**
     * 判断是否有进行中的备份任务 
     */
    public boolean isProcessing()
    {
        String sql = "select * from backup_record where status = 3";
        List<BackupRecord> records = jdbcTemplate.query(sql, new BackupRecordRowMapper());
        if (null != records && !records.isEmpty())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * 新增备份记录
     * @param backupRecord
     * @return 
     */
    public BackupRecord addBackupRecord(BackupRecord backupRecord)
    {
        String sql = "insert into backup_record "
                + "(id, mode, status, user_id, user_name, start_time) values(?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, backupRecord.getId(), backupRecord.getMode(), backupRecord.getStatus(),
                backupRecord.getUserId(), backupRecord.getUserName(), backupRecord.getStartTime());
        return backupRecord;
    }

    /**
     * 编辑备份记录
     * @param backupRecord
     * @return
     */
    public BackupRecord updateBackupRecord(BackupRecord backupRecord)
    {
        String sql = "update backup_record set status = ?, progress = ?, file_name = ?, file_size = ?, end_time = ?, detail = ? where id = ?";
        jdbcTemplate.update(sql, backupRecord.getStatus(), backupRecord.getProgress(), backupRecord.getFileName(),
                backupRecord.getFileSize(), backupRecord.getEndTime(), backupRecord.getDetail(), backupRecord.getId());
        return backupRecord;
    }

    /**
     * 删除备份记录
     * @param id
     * @return
     */
    public void deleteBackupRecord(String id)
    {
        String sql = "delete from backup_record where id = ?";
        jdbcTemplate.update(sql, id);
    }
    
    /**
     * 根据备份文件删除备份记录
     * @param id
     * @return
     */
    public void deleteBackupRecordByFile(String fileName)
    {
        String sql = "delete from backup_record where file_name = ?";
        jdbcTemplate.update(sql, fileName);
    }
    
    /**
     * 终止正在备份的任务
     * @param backupStaus detail
     * @return
     */
    public void finishProcessingBackupRecord(int backupStaus, String detail)
    {
        String sql = "update backup_record set status = ?, progress = ?, end_time = ?, detail = ? where status = 3";
        jdbcTemplate.update(sql, backupStaus, 100, new Date(), detail);
    }
}
