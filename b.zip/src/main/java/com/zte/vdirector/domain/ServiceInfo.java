/**
 * 
 */
package com.zte.vdirector.domain;

import java.util.Date;
import java.util.List;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：ServiceInfo   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年11月22日 下午1:58:49 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年11月22日 下午1:58:49  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class ServiceInfo
{
    private String serviceName;
    
    private String version;
    
    private String url;
    
    private String protocol;
    
    private String visualRange;
    
    private String status;
    
    private List<ServiceNode> nodes;
    
    
    /**
     * @return the serviceName
     */
    public String getServiceName()
    {
        return serviceName;
    }

    /**
     * @param serviceName the serviceName to set
     */
    public void setServiceName(String serviceName)
    {
        this.serviceName = serviceName;
    }

    /**
     * @return the version
     */
    public String getVersion()
    {
        return version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(String version)
    {
        this.version = version;
    }

    /**
     * @return the url
     */
    public String getUrl()
    {
        return url;
    }

    /**
     * @param url the url to set
     */
    public void setUrl(String url)
    {
        this.url = url;
    }

    /**
     * @return the protocol
     */
    public String getProtocol()
    {
        return protocol;
    }

    /**
     * @param protocol the protocol to set
     */
    public void setProtocol(String protocol)
    {
        this.protocol = protocol;
    }

    /**
     * @return the visualRange
     */
    public String getVisualRange()
    {
        return visualRange;
    }

    /**
     * @param visualRange the visualRange to set
     */
    public void setVisualRange(String visualRange)
    {
        this.visualRange = visualRange;
    }

    /**
     * @return the status
     */
    public String getStatus()
    {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status)
    {
        this.status = status;
    }

    /**
     * @return the nodes
     */
    public List<ServiceNode> getNodes()
    {
        return nodes;
    }

    /**
     * @param nodes the nodes to set
     */
    public void setNodes(List<ServiceNode> nodes)
    {
        this.nodes = nodes;
    }

    /**
     * 
     * <p>  
     * 版权所有：中兴通讯股份有限公司   
     * </p>  
     * <p>  
     * 项目名称：Backup  
     * </p>  
     * <p>   
     * 类名称：ServiceNode   
     * </p>  
     * <p>  
     * 类描述：   
     * </p>  
     * <p>  
     * 创建人：10125326王明涛 
     * </p>  
     * <p>  
     * 创建时间：2016年11月22日 下午2:04:36 
     * </p>  
     * <p>    
     * 修改人：10125326  
     * </p>  
     * <p>  
     * 修改时间：2016年11月22日 下午2:04:36  
     * </p>  
     * <p>   
     * 修改备注： 
     * </p>    
     * @version 1.0   
     *
     */
    public class ServiceNode
    {
        private String ip;
        
        private String port;
        
        private String ttl;
        
        private String nodeId;
        
        private Date expiration;
        
        private Date created_at;
        
        private Date updated_at;

        /**
         * @return the ip
         */
        public String getIp()
        {
            return ip;
        }

        /**
         * @param ip the ip to set
         */
        public void setIp(String ip)
        {
            this.ip = ip;
        }

        /**
         * @return the port
         */
        public String getPort()
        {
            return port;
        }

        /**
         * @param port the port to set
         */
        public void setPort(String port)
        {
            this.port = port;
        }

        /**
         * @return the ttl
         */
        public String getTtl()
        {
            return ttl;
        }

        /**
         * @param ttl the ttl to set
         */
        public void setTtl(String ttl)
        {
            this.ttl = ttl;
        }

        /**
         * @return the nodeId
         */
        public String getNodeId()
        {
            return nodeId;
        }

        /**
         * @param nodeId the nodeId to set
         */
        public void setNodeId(String nodeId)
        {
            this.nodeId = nodeId;
        }

        /**
         * @return the expiration
         */
        public Date getExpiration()
        {
            return expiration;
        }

        /**
         * @param expiration the expiration to set
         */
        public void setExpiration(Date expiration)
        {
            this.expiration = expiration;
        }

        /**
         * @return the created_at
         */
        public Date getCreated_at()
        {
            return created_at;
        }

        /**
         * @param created_at the created_at to set
         */
        public void setCreated_at(Date created_at)
        {
            this.created_at = created_at;
        }

        /**
         * @return the updated_at
         */
        public Date getUpdated_at()
        {
            return updated_at;
        }

        /**
         * @param updated_at the updated_at to set
         */
        public void setUpdated_at(Date updated_at)
        {
            this.updated_at = updated_at;
        }
        
    }
}
