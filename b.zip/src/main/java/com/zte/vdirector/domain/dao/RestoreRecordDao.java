/**
 * 
 */
package com.zte.vdirector.domain.dao;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.zte.vdirector.domain.RestoreRecord;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：RestoreRecordDao   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午3:02:13 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午3:02:13  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Repository
public class RestoreRecordDao
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 查询恢复列表记录
     * @return
     */
    public List<RestoreRecord> queryRestoreRecords()
    {
        String sql = "select * from restore_record order by start_time desc";
        return jdbcTemplate.query(sql, new RestoreRecordRowMapper());
    }

    /**
     * 查询单条恢复记录
     * @return
     */
    public RestoreRecord queryRestoreRecord(String id)
    {
        try
        {
            String sql = "select * from restore_record where id = ?";
            return jdbcTemplate.queryForObject(sql, new RestoreRecordRowMapper(), id);
        }
        catch (Exception e)
        {
            logger.error("queryRestoreRecord Exception: " + e.getMessage());
            return null;
        }
    }

    /**
     * 判断是否有进行中的恢复任务 
     */
    public boolean isProcessing()
    {
        String sql = "select * from restore_record where status = 3";
        List<RestoreRecord> records = jdbcTemplate.query(sql, new RestoreRecordRowMapper());
        if (null != records && !records.isEmpty())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * 新增恢复记录
     * @param restoreRecord
     * @return 
     */
    public RestoreRecord addRestoreRecord(RestoreRecord restoreRecord)
    {
        String sql = "insert into restore_record "
                + "(id, status, user_id, user_name, file_name, file_size, start_time) values(?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, restoreRecord.getId(), restoreRecord.getStatus(), restoreRecord.getUserId(),
                restoreRecord.getUserName(), restoreRecord.getFileName(), restoreRecord.getFileSize(),
                restoreRecord.getStartTime());
        return restoreRecord;
    }

    /**
     * 编辑备份恢复记录
     * @param restoreRecord
     * @return
     */
    public RestoreRecord updateRestoreRecord(RestoreRecord restoreRecord)
    {
        String sql = "update restore_record set status = ?, progress = ?, end_time = ?, detail = ? where id = ?";
        jdbcTemplate.update(sql, restoreRecord.getStatus(), restoreRecord.getProgress(), restoreRecord.getEndTime(),
                restoreRecord.getDetail(), restoreRecord.getId());
        return restoreRecord;
    }

    /**
     * 删除备份恢复记录
     * @param id
     * @return
     */
    public void deleteRestoreRecord(String id)
    {
        String sql = "delete from restore_record where id = ?";
        jdbcTemplate.update(sql, id);
    }
    
    /**
     * 终止正在恢复的任务
     * @param restoreStaus detail
     * @return
     */
    public void finishProcessingRestoreRecord(int restoreStaus, String detail)
    {
        String sql = "update restore_record set status = ?, progress = ? , end_time = ?, detail = ? where status = 3";
        jdbcTemplate.update(sql, restoreStaus, 100, new Date(), detail);
    }
}
