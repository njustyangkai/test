/**
 * 
 */
package com.zte.vdirector.scheduler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.matchers.GroupMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.zte.vdirector.frame.exception.BackupException;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：SchedulerManager   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月12日 下午12:40:39 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月12日 下午12:40:39  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Component
public class SchedulerManager
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private SchedulerFactoryBean schedulerFactoryBean;

    /**
     * 调度JOB
     * @param <T>
     * @param jobName
     * @param jobGroup
     * @param cronExpression
     * @throws SchedulerException
     */
    @SuppressWarnings("unchecked")
    public <T> void scheduleJob(String jobName, String jobGroup, String cronExpression, Class<T> clazz)
    {
        logger.info("SchedulerManager.scheduleJob(" + jobName + ", " + jobGroup + ", " + cronExpression + ")");
        
        try
        {
          //获取调度器
            Scheduler scheduler = schedulerFactoryBean.getScheduler();
            //根据名称和组获取key
            TriggerKey triggerKey = TriggerKey.triggerKey(jobName, jobGroup);
            //获取CronTrigger触发器
            CronTrigger trigger = (CronTrigger) scheduler.getTrigger(triggerKey);

            // 表达式调度构建器
            CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(cronExpression);
            if (null == trigger)
            {
                logger.info("SchedulerManager.scheduleJob--------->Create new trigger");
                //如果触发器不存在，则新创建一个
                //首先构造一个jobDetail
                JobDetail jobDetail = JobBuilder.newJob((Class<? extends Job>) clazz).withIdentity(jobName, jobGroup).build();
                // 按新的cronExpression表达式构建一个新的trigger
                trigger = TriggerBuilder.newTrigger().withIdentity(triggerKey).withSchedule(scheduleBuilder).build();
                // 执行调度任务
                scheduler.scheduleJob(jobDetail, trigger);
            }
            else
            {
                if (!StringUtils.equals(trigger.getCronExpression(), cronExpression))
                {
                    logger.info("SchedulerManager.scheduleJob--------->Get old trigger");
                    trigger = trigger.getTriggerBuilder().withIdentity(triggerKey).withSchedule(scheduleBuilder).startNow().build();
                    // 按新的trigger重新设置job执行
                    scheduler.rescheduleJob(triggerKey, trigger);
                }
                else
                {
                    logger.info("SchedulerManager.scheduleJob--------->cronExpression no change");
                }
            }
        }
        catch (SchedulerException e)
        {
            logger.error("SchedulerManager.scheduleJob(String jobName, String jobGroup, String cronExpression) SchedulerException", e);
            throw new BackupException(e);
        }
        logger.info("SchedulerManager.scheduleJob End");
    }

    /**
     * 调度JOB
     * @param <T>
     * @param jobName
     * @param cronExpression
     * @throws SchedulerException
     */
    public <T> void scheduleJob(String jobName, String cronExpression, Class<T> clazz)
    {
        scheduleJob(jobName, Scheduler.DEFAULT_GROUP, cronExpression, clazz);
    }

    /**
     * 删除任务
     * @param jobName
     * @param jobGroup
     * @throws SchedulerException
     */
    public void removeJob(String jobName, String jobGroup)
    {
        logger.info("SchedulerManager.removeJob(" + jobName + ", " + jobGroup + ")");
        try
        {
            JobKey jobKey = JobKey.jobKey(jobName, jobGroup);
            schedulerFactoryBean.getScheduler().deleteJob(jobKey);
        }
        catch (SchedulerException e)
        {
            logger.error("SchedulerManager.removeJob(String jobName, String jobGroup) SchedulerException", e);
            throw new BackupException(e);
        }
        logger.info("SchedulerManager.removeJob End");
    }

    /**
     * 删除任务
     * @param jobName
     * @throws SchedulerException
     */
    public void removeJob(String jobName)
    {
        removeJob(jobName, Scheduler.DEFAULT_GROUP);
    }

    /**
     * 触发任务立即执行
     * @param jobName
     * @param jobGroup
     * @param params
     * @throws SchedulerException
     */
    public void triggerJob(String jobName, String jobGroup, Map<Object, Object> params)
    {
        logger.info("SchedulerManager.triggerJob(" + jobName + ", " + jobGroup + ", " + JSON.toJSONString(params) + ")");

        try
        {
            Scheduler scheduler = schedulerFactoryBean.getScheduler();

            JobKey jobKey = JobKey.jobKey(jobName, jobGroup);
            if (params == null || params.size() == 0)
            {
                scheduler.triggerJob(jobKey);
            }
            else
            {
                JobDataMap jobDataMap = new JobDataMap(params);
                scheduler.triggerJob(jobKey, jobDataMap);
            }
        }
        catch (SchedulerException e)
        {
            logger.error("SchedulerManager.triggerJob(String jobName, String jobGroup, Map<Object, Object> params) SchedulerException", e);
            throw new BackupException(e);
        }
        logger.info("SchedulerManager.triggerJob End");
    }

    /**
     * 获取当前执行的任务
     * @return
     * @throws SchedulerException
     */
    public List<JobExecutionContext> getExecutionJobsContext()
    {
        try
        {
            Scheduler scheduler = schedulerFactoryBean.getScheduler();
            return scheduler.getCurrentlyExecutingJobs();
        }
        catch (SchedulerException e)
        {
            logger.error("SchedulerManager.getExecutionJobsContext() SchedulerException", e);
            throw new BackupException(e);
        }
    }

    /**
     * 获取当前所有任务的Trigger
     * @return
     * @throws SchedulerException
     */
    public List<Trigger> getJobTriggers()
    {
        try
        {
            List<Trigger> triggers = new ArrayList<Trigger>();
            Scheduler scheduler = schedulerFactoryBean.getScheduler();

            for (String groupName : scheduler.getJobGroupNames())
            {
                Set<JobKey> jobKeys = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName));
                for (JobKey jobKey : jobKeys)
                {
                    triggers.addAll(scheduler.getTriggersOfJob(jobKey));
                }
            }
            return triggers;
        }
        catch (SchedulerException e)
        {
            logger.error("SchedulerManager.getJobTriggers() SchedulerException", e);
            throw new BackupException(e);
        }
        
    }
}
