/**
 * 
 */
package com.zte.vdirector.scheduler.job;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zte.vdirector.frame.utils.SpringUtil;
import com.zte.vdirector.service.BackupService;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：GetServiceInfoJob   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年11月22日 下午2:31:13 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年11月22日 下午2:31:13  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class GetServiceInfoJob implements Job
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException
    {
        logger.info("The GetServiceInfo job begin");
        BackupService backupService = SpringUtil.getBean(BackupService.class);
        backupService.processServiceInfo();
        logger.info("The GetServiceInfo job end");
    }

}
