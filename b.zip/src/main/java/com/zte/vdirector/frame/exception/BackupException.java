package com.zte.vdirector.frame.exception;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupException   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午3:11:58 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午3:11:58  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class BackupException extends RuntimeException
{

    /**
     * 
     */
    private static final long serialVersionUID = -4083622768264995952L;

    public BackupException()
    {
        super();
        // TODO Auto-generated constructor stub
    }

    public BackupException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
    {
        super(message, cause, enableSuppression, writableStackTrace);
        // TODO Auto-generated constructor stub
    }

    public BackupException(String message, Throwable cause)
    {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public BackupException(String message)
    {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public BackupException(Throwable cause)
    {
        super(cause);
        // TODO Auto-generated constructor stub
    }

    
}
