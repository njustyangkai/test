package com.zte.vdirector.frame.init;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.zte.vdirector.domain.BackupStrategy;
import com.zte.vdirector.frame.constants.BackupConstants;
import com.zte.vdirector.frame.utils.BackupUtils;
import com.zte.vdirector.scheduler.SchedulerManager;
import com.zte.vdirector.scheduler.job.BackupJob;
import com.zte.vdirector.scheduler.job.ClearJob;
import com.zte.vdirector.service.BackupService;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupTaskInitializer   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月19日 上午8:37:03 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月19日 上午8:37:03  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Component
public class BackupTaskInitializer implements CommandLineRunner
{
    @Autowired
    private BackupService backupService;
    
    @Autowired
    private SchedulerManager schedulerManager;
    
    @Autowired
    private Environment environment;
    
    //系统启动时启动定时任务
    @Override
    public void run(String... arg0) throws Exception
    {
        //查询备份策略
        BackupStrategy backupStrategy = backupService.queryBackupStrategy();
        if (backupStrategy.isBackupAuto())
        {
            //获取cron表达式
            String cronExpression = BackupUtils.getCronExpression(backupStrategy);
            schedulerManager.scheduleJob(BackupConstants.DEFAULT_BACKUP_JOB_NAME, cronExpression, BackupJob.class);
        }
        
        //启动自动清除任务
        String clearJobCronExpression = environment.getProperty(BackupConstants.BACKUP_AUTO_CLEAR_CRON_EXPRESSION);
        if (StringUtils.isBlank(clearJobCronExpression))
        {
            clearJobCronExpression = "0 0 0/1 * * ? ";
        }
        schedulerManager.scheduleJob(BackupConstants.DEFAULT_CLEAR_JOB_NAME, clearJobCronExpression, ClearJob.class);
    }

}
