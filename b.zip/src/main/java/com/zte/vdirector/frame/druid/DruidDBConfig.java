/**
 * 
 */
package com.zte.vdirector.frame.druid;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alibaba.druid.pool.DruidDataSource;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：DruidDBConfig   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年11月16日 上午10:17:21 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年11月16日 上午10:17:21  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Configuration
public class DruidDBConfig
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${spring.datasource.url}")
    private String dbUrl;

    @Value("${spring.datasource.username}")
    private String username;

    @Value("${spring.datasource.password}")
    private String password;

    @Value("${spring.datasource.driverClassName}")
    private String driverClassName;

    @Bean
    //声明其为Bean实例  
    public DataSource dataSource()
    {
        DruidDataSource datasource = new DruidDataSource();

        datasource.setUrl(dbUrl);
        datasource.setUsername(username);
        datasource.setPassword(password);
        datasource.setDriverClassName(driverClassName);
        
        Connection conn = null;
        try
        {
            Class.forName(driverClassName);
            conn = DriverManager.getConnection(dbUrl, username, password);
            logger.trace("Test Connection Success, dbUrl = " + dbUrl);
            return datasource;
        }
        catch (ClassNotFoundException e)
        {
            logger.error("Test Connection ClassNotFoundException, dbUrl = " + dbUrl, e);
        }
        catch (SQLException e)
        {
            logger.error("Test Connection SQLException, dbUrl = " + dbUrl, e);
        }
        catch (Exception e)
        {
            logger.error("Test Connection Exception, dbUrl = " + dbUrl, e);
        }
        finally
        {
            if (conn != null)
            {
                try
                {
                    conn.close();
                }
                catch (Exception e)
                {
                    logger.error("Connection Close Exception", e);
                }
            }
        }
        
        datasource.setUrl("jdbc:mysql://localhost:3306/backup");
        return datasource;
    }
}
