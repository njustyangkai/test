package com.zte.vdirector.frame.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.zte.vdirector.frame.constants.BackupConstants.BackupStatus;
import com.zte.vdirector.service.BackupService;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：RunningTaskInitializer   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月19日 上午8:37:03 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月19日 上午8:37:03  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Component
public class RunningTaskInitializer implements CommandLineRunner
{
    @Autowired
    private BackupService backupService;
    
    //将系统中正在进行的备份和恢复任务结束
    @Override
    public void run(String... arg0) throws Exception
    {
        backupService.finishProcessingBackupRecord(BackupStatus.FAIL, "System Interrupt");
        backupService.finishProcessingRestoreRecord(BackupStatus.FAIL, "System Interrupt");
    }

}
