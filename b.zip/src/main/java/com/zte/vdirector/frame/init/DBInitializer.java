package com.zte.vdirector.frame.init;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.SQLExec;
import org.apache.tools.ant.types.EnumeratedAttribute;
import org.apache.tools.ant.types.FileSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.zte.vdirector.service.VersionService;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：backup  
 * </p>  
 * <p>   
 * 类名称：DBInitializer   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年8月2日 上午8:22:00 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年8月2日 上午8:22:00  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Component
public class DBInitializer implements CommandLineRunner
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private Environment env;

    @Resource
    private VersionService versionService;

    @Override
    public void run(String... arg0) throws Exception
    {
        try
        {
            // 获取\WEB-INF\classes\sql下全部升级脚本
            File file = new File(this.getClass().getResource("/sql").getPath());
            File[] allSQLFiles = file.listFiles();

            // 待执行升级脚本列表
            List<File> toExecuteSQLFiles = new ArrayList<File>();

            // 读取数据库中记录的当前版本号
            Map<String, Object> versionMap = versionService.getVersionInfo();
            String currentVersion = versionMap.get("sql_version").toString();

            // 最大版本号，初始化为当前版本号。
            String maxVersion = currentVersion;

            // 遍历升级脚本列表，筛选出需要执行的。
            if (null != allSQLFiles && allSQLFiles.length > 0)
            {
                for (int i = 0; i < allSQLFiles.length; i++)
                {
                    String style = allSQLFiles[i].getName().substring(allSQLFiles[i].getName().lastIndexOf("."));
                    if (!".sql".equals(style))
                    {
                        continue;
                    }

                    String sqlVersionTmp = allSQLFiles[i].getName().substring(0, 12);

                    // 大于当前版本的都加入待执行列表
                    if (Long.parseLong(sqlVersionTmp) > Long.parseLong(currentVersion))
                    {
                        toExecuteSQLFiles.add(allSQLFiles[i]);

                        // 同时判断该版本号是否最大，因为最终记录到数据库的版本号是最大的那个。
                        if (Long.parseLong(sqlVersionTmp) > Long.parseLong(maxVersion))
                        {
                            maxVersion = sqlVersionTmp;
                        }
                    }
                }
            }

            if (toExecuteSQLFiles.size() > 0)
            {
                SQLExec sqlExec = new SQLExec();

                //设置数据库参数
                String driver = env.getProperty("spring.datasource.driverClassName", String.class);
                String url = env.getProperty("spring.datasource.url", String.class);
                String userId = env.getProperty("spring.datasource.username", String.class);
                String password = env.getProperty("spring.datasource.password", String.class);

                sqlExec.setDriver(driver);
                sqlExec.setUrl(url);
                sqlExec.setUserid(userId);
                sqlExec.setEncoding("utf-8");
                sqlExec.setPassword(password);
                //有出错的语句该如何处理     
                sqlExec.setOnerror((SQLExec.OnError) (EnumeratedAttribute.getInstance(SQLExec.OnError.class, "abort")));
                //设置是否输出 
                sqlExec.setPrint(true);
                //输出到文件 sql.out 中；不设置该属性，默认输出到控制台     
                sqlExec.setOutput(new File(this.getClass().getResource("/sql").getPath() + "/sql.out"));

                //要执行的脚本
                FileSet set = new FileSet();
                set.setProject(new Project());
                set.setDir(new File(this.getClass().getResource("/sql").getPath()));

                String[] sqlNames = new String[allSQLFiles.length];
                for (int i = 0; i < toExecuteSQLFiles.size(); i++)
                {
                    if (toExecuteSQLFiles.get(i).isFile())
                    {
                        sqlNames[i] = toExecuteSQLFiles.get(i).getName();
                    }
                }

                set.appendIncludes(sqlNames);

                sqlExec.addFileset(set);
                // 要指定这个属性，不然会出错     
                sqlExec.setProject(new Project());
                sqlExec.execute();

                versionService.updateVersion(maxVersion);
            }
        }
        catch (Exception e)
        {
            logger.error("Database upgrade failed.", e);
        }
    }
}
