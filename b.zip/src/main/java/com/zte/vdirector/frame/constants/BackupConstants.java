/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年7月28日      下午6:53:54
 */
package com.zte.vdirector.frame.constants;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupConstants   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月18日 下午6:14:38 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月18日 下午6:14:38  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */

public interface BackupConstants
{
    int SUCCESS_CODE_200 = 200;
    int CREATED_CODE_201 = 201;
    int ACCEPTED_CODE_202 = 202;
    int DELETE_CODE_204 = 204;
    int SERVER_ERROR_CODE_500 = 500;
    int CONFLICT_CODE_409 = 409;
    int NOT_ACCEPTABLE_406 = 406;
    int NOT_FOUND_404 = 404;
    int BAD_REQUEST_400 = 400;
    
    public static final String DEFAULT_BACKUP_JOB_NAME = "default_backup_job";

    public static final String DEFAULT_CLEAR_JOB_NAME = "default_clear_job";
    
    public static final String INPUT_INSTALL_DIR = "INPUT_INSTALL_DIR";
    
    public static final String BACKUP_AUTO_CLEAR_CRON_EXPRESSION = "backup.auto.clear.cronexpression";
    
    public static final String BACKUP_DOWNLOAD_FILE_KEEPTIME = "backup.downlode.file.keeptime";
    
    public static final String DOWNLOAD_DIR = "download";
    
    public static final String RESTORE_DIR = "restore";

    /**
     * 
     * <p>  
     * 版权所有：中兴通讯股份有限公司   
     * </p>  
     * <p>  
     * 项目名称：Backup  
     * </p>  
     * <p>   
     * 类名称：BackupPeriod   
     * </p>  
     * <p>  
     * 类描述：   
     * </p>  
     * <p>  
     * 创建人：10125326王明涛 
     * </p>  
     * <p>  
     * 创建时间：2016年9月18日 下午5:07:30 
     * </p>  
     * <p>    
     * 修改人：10125326  
     * </p>  
     * <p>  
     * 修改时间：2016年9月18日 下午5:07:30  
     * </p>  
     * <p>   
     * 修改备注： 
     * </p>    
     * @version 1.0   
     *
     */
    interface BackupPeriod
    {
        public static final int DAY = 1;

        public static final int WEEK = 2;

        public static final int MONTH = 3;
    }

    /**
     * 
     * <p>  
     * 版权所有：中兴通讯股份有限公司   
     * </p>  
     * <p>  
     * 项目名称：Backup  
     * </p>  
     * <p>   
     * 类名称：BackupMode   
     * </p>  
     * <p>  
     * 类描述：   备份方式 
     * </p>  
     * <p>  
     * 创建人：10125326王明涛 
     * </p>  
     * <p>  
     * 创建时间：2016年9月19日 下午12:44:53 
     * </p>  
     * <p>    
     * 修改人：10125326  
     * </p>  
     * <p>  
     * 修改时间：2016年9月19日 下午12:44:53  
     * </p>  
     * <p>   
     * 修改备注： 
     * </p>    
     * @version 1.0   
     *
     */
    interface BackupMode
    {
        /**
         * 手动方式
         */
        public static final int MANUAL = 1;

        /**
         * 自动方式
         */
        public static final int AUTO = 2;
    }

    /**
     * 
     * <p>  
     * 版权所有：中兴通讯股份有限公司   
     * </p>  
     * <p>  
     * 项目名称：Backup  
     * </p>  
     * <p>   
     * 类名称：BackupStatus   
     * </p>  
     * <p>  
     * 类描述：   
     * </p>  
     * <p>  
     * 创建人：10125326王明涛 
     * </p>  
     * <p>  
     * 创建时间：2016年9月19日 下午12:57:26 
     * </p>  
     * <p>    
     * 修改人：10125326  
     * </p>  
     * <p>  
     * 修改时间：2016年9月19日 下午12:57:26  
     * </p>  
     * <p>   
     * 修改备注： 
     * </p>    
     * @version 1.0   
     *
     */
    interface BackupStatus
    {
        /**
         * 成功
         */
        public static final int SUCCESS = 1;

        /**
         * 失败
         */
        public static final int FAIL = 2;

        /**
         * 进行中
         */
        public static final int PROCESSING = 3;
    }

    /**
     * 
     * <p>  
     * 版权所有：中兴通讯股份有限公司   
     * </p>  
     * <p>  
     * 项目名称：Backup  
     * </p>  
     * <p>   
     * 类名称：ClearMode   
     * </p>  
     * <p>  
     * 类描述：   
     * </p>  
     * <p>  
     * 创建人：10125326王明涛 
     * </p>  
     * <p>  
     * 创建时间：2016年9月20日 下午7:08:16 
     * </p>  
     * <p>    
     * 修改人：10125326  
     * </p>  
     * <p>  
     * 修改时间：2016年9月20日 下午7:08:16  
     * </p>  
     * <p>   
     * 修改备注： 
     * </p>    
     * @version 1.0   
     *
     */
    interface ClearMode
    {
        /**
         * 按备份文件占用大小方式
         */
        public static final int SIZE = 0;

        /**
         * 按备份文件保存天数
         */
        public static final int DATE = 1;
    }

    /**
     * 
     * <p>  
     * 版权所有：中兴通讯股份有限公司   
     * </p>  
     * <p>  
     * 项目名称：Backup  
     * </p>  
     * <p>   
     * 类名称：ParamKey   
     * </p>  
     * <p>  
     * 类描述：   
     * </p>  
     * <p>  
     * 创建人：10125326王明涛 
     * </p>  
     * <p>  
     * 创建时间：2016年9月21日 上午10:45:47 
     * </p>  
     * <p>    
     * 修改人：10125326  
     * </p>  
     * <p>  
     * 修改时间：2016年9月21日 上午10:45:47  
     * </p>  
     * <p>   
     * 修改备注： 
     * </p>    
     * @version 1.0   
     *
     */
    interface ParamKey
    {
        String COMMON_URI = "uri";

        String COMMON_REQUESTBODY = "requestBody";
    }
}
