/**
 * 
 */
package com.zte.vdirector.frame.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.zte.vdirector.domain.BackupStrategy;
import com.zte.vdirector.frame.constants.BackupConstants.BackupPeriod;
import com.zte.vdirector.frame.exception.BackupException;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupUtils   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月18日 上午9:17:42 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月18日 上午9:17:42  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class BackupUtils
{
    private static Logger logger = LoggerFactory.getLogger(BackupUtils.class);

    public static long getDirSize(File file)
    {
        //判断文件是否存在     
        if (file.exists())
        {
            //如果是目录则递归计算其内容的总大小    
            if (file.isDirectory())
            {
                File[] children = file.listFiles();
                long size = 0;
                for (File f : children)
                {
                    size += getDirSize(f);
                }
                return size;
            }
            else
            {
                //如果是文件则直接返回其大小,以“兆”为单位   
                long size = file.length();
                return size;
            }
        }
        else
        {
            logger.info("The directory or file is not exist, please check it");
            return 0;
        }
    }

    /**
     * 获取cron表达式
     * @param backupStrategy
     * @return
     */
    public static String getCronExpression(BackupStrategy backupStrategy)
    {
        String cronExpression = "";
        if (backupStrategy.isBackupAuto())
        {
            //备份时间，类似于05:25
            String backupTime = backupStrategy.getBackupTime();
            String[] backupTimeArry = StringUtils.split(backupTime, ":");
            String backupHour = backupTimeTrim(backupTimeArry[0]);
            String backupMinute = backupTimeTrim(backupTimeArry[1]);

            //按天备份
            if (backupStrategy.getBackupPeriod() == BackupPeriod.DAY)
            {
                //每日0点：0 0 0 * * ?
                cronExpression = "0 " + backupMinute + " " + backupHour + " * * ?";
            }
            else if (backupStrategy.getBackupPeriod() == BackupPeriod.MONTH)
            {
                //每月1日0点： 0 0 0 1 * ?
                cronExpression = "0 " + backupMinute + " " + backupHour + " "
                        + String.valueOf(backupStrategy.getBackupDay()) + " * ?";
            }
            else if (backupStrategy.getBackupPeriod() == BackupPeriod.WEEK)
            {
                //0 0 0 ? * 2 每周一0点 (注:1=SUN,2=MON,3=TUE,4=WED,5=THU,6=FRI,7=SAT)
                cronExpression = "0 " + backupMinute + " " + backupHour + " ? * " + (backupStrategy.getBackupDay() + 1)
                        % 7;
            }
        }
        return cronExpression;
    }

    /**
     * 去除小时和分之前的0
     * @param str
     * @return
     */
    private static String backupTimeTrim(String str)
    {
        if (StringUtils.startsWith(str, "0"))
        {
            return StringUtils.substringAfter(str, "0");
        }
        return str;
    }

    public static void main2(String[] args)
    {
        System.out.println(getDirSize(new File("F:\\ISO")));
    }

    /**
     * 删除目录
     * @param dir
     */
    public static void deleteDir(File dir)
    {
        if (dir.isDirectory())
        {
            File[] files = dir.listFiles();
            for (File file : files)
            {
                deleteDir(file);
            }
        }
        dir.delete();
    }
    
    /**
     * 创建目录
     * @param path
     * @return
     */
    public static File createDir(String path)
    {
        File dir = new File(path);
        if (!dir.exists())
        {
            dir.mkdirs();
        }
        return dir;
    }
    
    /**
     * 将multipartFile转换为file
     * @param multipartFile
     * @param file
     * @return
     */
    public static void transferMultipartFile2File(MultipartFile multipartFile, File file)
    {
        try
        {
            FileUtils.copyInputStreamToFile(multipartFile.getInputStream(), file);
        }
        catch (IOException e)
        {
            logger.error("convertMultipartFile2File IOException", e);
            throw new BackupException(e);
        }  
        catch (Exception e)
        {
            logger.error("convertMultipartFile2File Exception", e);
            throw new BackupException(e);
        }
    }
}
