package com.zte.vdirector.frame.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.async.DeferredResult;

import com.google.common.base.Predicates;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：SwaggerConfig   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月28日 上午9:14:13 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月28日 上午9:14:13  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig
{
	@SuppressWarnings("unchecked")
	@Bean
	public Docket backupApi()
	{
		Docket docket = new Docket(DocumentationType.SWAGGER_2).groupName("backup")
				.genericModelSubstitutes(DeferredResult.class).useDefaultResponseMessages(false).forCodeGeneration(true)
				.pathMapping("/")// base，最终调用接口后会和paths拼接在一起
				.select().paths(Predicates.or(PathSelectors.regex("/.*")))// 过滤的接口
				.build().apiInfo(testBackupInfo());
		return docket;
	}

	private ApiInfo testBackupInfo()
	{
		Contact contact = new Contact("vDirector2.0", "http://www.zte.com.cn", "wang.mingtao5@zte.com.cn");
		ApiInfo apiInfo = new ApiInfo(
				"vDirector2.0 Backup Service API Document",		// 大标题
				"API DOC",	// 小标题
				"0.1",			// 版本
				"http://www.zte.com.cn", 
				contact,	// 作者
				"vDirector2.0",	// 链接显示文字
				"http://www.zte.com.cn"//	网站链接
		);
		return apiInfo;
	}
}
