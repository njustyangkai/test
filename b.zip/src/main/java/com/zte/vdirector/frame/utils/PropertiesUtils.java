/**
 * 
 */
package com.zte.vdirector.frame.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：PropertiesUtils   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年11月24日 下午3:35:04 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年11月24日 下午3:35:04  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class PropertiesUtils
{
    private static Logger logger = LoggerFactory.getLogger(PropertiesUtils.class);

    /**
     * 读取properties文件
     * @param filename
     * @return
     */
    public static Properties readPropertiesFile(String filename)
    {
        Properties properties = new Properties();
        InputStream inputStream = null;
        try
        {
            inputStream = new FileInputStream(filename);
            properties.load(inputStream);
        }
        catch (IOException e)
        {
            logger.error("readPropertiesFile IOException", e);
        }
        catch (Exception e)
        {
            logger.error("readPropertiesFile Exception", e);
        }
        finally
        {
            if (inputStream != null)
            {
                try
                {
                    inputStream.close();
                }
                catch (IOException e)
                {
                    logger.error("readPropertiesFile: InputStream close Exception", e);
                }
            }
        }
        return properties;
    }

    /**
     * 将properties内容写入文件
     * @param filename
     * @param properties
     */
    public static void writePropertiesFile(String filename, Properties properties)
    {
        OutputStream outputStream = null;
        try
        {
            outputStream = new FileOutputStream(filename);
            properties.store(outputStream, "author: backup@vdirector");
        }
        catch (IOException e)
        {
            logger.error("writePropertiesFile IOException", e);
        }
        catch (Exception e)
        {
            logger.error("writePropertiesFile Exception", e);
        }
        finally
        {
            if (outputStream != null)
            {
                try
                {
                    outputStream.close();
                }
                catch (IOException e)
                {
                    logger.error("writePropertiesFile: OutputStream close Exception", e);
                }
            }
        }
    }
}
