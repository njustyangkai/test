/**
 * 2010-4-20
 */
package com.zte.vdirector.frame.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zte.vdirector.frame.exception.BackupException;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：TarUtils   
 * </p>  
 * <p>  
 * 类描述：   TAR工具
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月16日 下午1:57:04 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月16日 下午1:57:04  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class TarUtils
{
    private static Logger logger = LoggerFactory.getLogger(TarUtils.class);

    private static final String BASE_DIR = "";

    // 符号"/"用来作为目录标识判断符
    private static final String PATH = "/";
    private static final int BUFFER = 1024;

    private static final String EXT = ".tar";

    /**
     * 归档
     * 
     * @param srcPath
     * @param destPath
     * @throws Exception
     */
    public static void archive(String srcPath, String destPath, boolean isHasRoot)
    {

        File srcFile = new File(srcPath);

        archive(srcFile, destPath, isHasRoot);

    }

    /**
     * 压缩文件
     * @param srcFile
     * @param tarArchiveOutputStream
     * @param isHasRoot
     */
    public static void archive(List<File> srcFiles, File destFile, boolean isHasRoot)
    {
        TarArchiveOutputStream taos = null;
        try
        {
            taos = new TarArchiveOutputStream(new FileOutputStream(destFile));
            for (File srcFile : srcFiles)
            {
                archive(srcFile, taos, BASE_DIR, isHasRoot);
            }
            taos.flush();
        }
        catch (FileNotFoundException e)
        {
            logger.error("TarUtils.archive(List<File> srcFiles, File destFile, boolean isHasRoot) FileNotFoundException", e);
            throw new BackupException(e);
        }
        catch (IOException e)
        {
            logger.error("TarUtils.archive(List<File> srcFiles, File destFile, boolean isHasRoot) IOException", e);
            throw new BackupException(e);
        }
        catch (Exception e)
        {
            logger.error("TarUtils.archive(List<File> srcFiles, File destFile, boolean isHasRoot) Exception", e);
            throw new BackupException(e);
        }
        finally
        {
            try
            {
                if (taos != null)
                {
                    taos.close();
                }
            }
            catch (IOException e)
            {
                logger.error("TarArchiveOutputStream close IOException", e);
            }
        }
    }
    
    /**
     * 归档
     * 
     * @param srcFile
     *            源路径
     * @param destPath
     *            目标路径
     * @throws Exception
     */
    public static void archive(File srcFile, File destFile, boolean isHasRoot)
    {
        TarArchiveOutputStream taos = null;
        try
        {
            taos = new TarArchiveOutputStream(new FileOutputStream(destFile));
            archive(srcFile, taos, BASE_DIR, isHasRoot);
            taos.flush();
        }
        catch (FileNotFoundException e)
        {
            logger.error("TarUtils.archive(File srcFile, File destFile, boolean isHasRoot) FileNotFoundException", e);
            throw new BackupException(e);
        }
        catch (IOException e)
        {
            logger.error("TarUtils.archive(File srcFile, File destFile, boolean isHasRoot) IOException", e);
            throw new BackupException(e);
        }
        catch (Exception e)
        {
            logger.error("TarUtils.archive(File srcFile, File destFile, boolean isHasRoot) Exception", e);
            throw new BackupException(e);
        }
        finally
        {
            try
            {
                if (taos != null)
                {
                    taos.close();
                }
            }
            catch (IOException e)
            {
                logger.error("TarArchiveOutputStream close IOException", e);
            }
        }
    }

    /**
     * 归档
     * 
     * @param srcFile
     * @throws Exception
     */
    public static void archive(File srcFile, boolean isHasRoot)
    {
        String name = srcFile.getName();
        String basePath = srcFile.getParent();
        String destPath = basePath + name + EXT;
        archive(srcFile, destPath, isHasRoot);
    }

    /**
     * 归档文件
     * 
     * @param srcFile
     * @param destPath
     * @throws Exception
     */
    public static void archive(File srcFile, String destPath, boolean isHasRoot)
    {
        archive(srcFile, new File(destPath), isHasRoot);
    }

    /**
     * 归档
     * 
     * @param srcPath
     * @throws Exception
     */
    public static void archive(String srcPath, boolean isHasRoot)
    {
        File srcFile = new File(srcPath);

        archive(srcFile, isHasRoot);
    }

    /**
     * 归档
     * 
     * @param srcFile
     *            源路径
     * @param taos
     *            TarArchiveOutputStream
     * @param basePath
     *            归档包内相对路径
     * @throws Exception
     */
    private static void archive(File srcFile, TarArchiveOutputStream taos, String basePath, boolean isHasRoot)
    {
        if (srcFile.isDirectory())
        {
            archiveDir(srcFile, taos, basePath, isHasRoot);
        }
        else
        {
            archiveFile(srcFile, taos, basePath, isHasRoot);
        }
    }

    /**
     * 目录归档
     * 
     * @param dir
     * @param taos
     *            TarArchiveOutputStream
     * @param basePath
     * @throws Exception
     */
    private static void archiveDir(File dir, TarArchiveOutputStream taos, String basePath, boolean isHasRoot)
    {
        File[] files = dir.listFiles();

        if (files.length < 1)
        {
            TarArchiveEntry entry = null;
            if (isHasRoot)
            {
                entry = new TarArchiveEntry(basePath + dir.getName() + PATH);
            }
            else
            {
                entry = new TarArchiveEntry(StringUtils.substringAfter(basePath, PATH) + dir.getName() + PATH);
            }

            try
            {
                taos.putArchiveEntry(entry);
            }
            catch (IOException e)
            {
                logger.error("TarArchiveOutputStream putArchiveEntry IOException", e);
                throw new BackupException(e);
            }
            catch (Exception e)
            {
                logger.error(
                        "TarUtils.archiveDir(File dir, TarArchiveOutputStream taos, String basePath, boolean isHasRoot) Exception",
                        e);
                throw new BackupException(e);
            }
            finally
            {
                if (taos != null)
                {
                    try
                    {
                        taos.closeArchiveEntry();
                    }
                    catch (IOException e)
                    {
                        logger.error("TarArchiveOutputStream closeArchiveEntry IOException", e);
                    }
                }
            }
        }

        for (File file : files)
        {
            // 递归归档
            archive(file, taos, basePath + dir.getName() + PATH, isHasRoot);
        }
    }

    /**
     * 数据归档
     * 
     * @param data
     *            待归档数据
     * @param path
     *            归档数据的当前路径
     * @param name
     *            归档文件名
     * @param taos
     *            TarArchiveOutputStream
     * @throws Exception
     */
    private static void archiveFile(File file, TarArchiveOutputStream taos, String dir, boolean isHasRoot)
    {
        TarArchiveEntry entry = null;
        BufferedInputStream bis = null;
        try
        {
            if (isHasRoot)
            {
                entry = new TarArchiveEntry(dir + file.getName());
            }
            else
            {
                entry = new TarArchiveEntry(StringUtils.substringAfter(dir, PATH) + file.getName());
            }
            entry.setSize(file.length());

            taos.putArchiveEntry(entry);
            bis = new BufferedInputStream(new FileInputStream(file));
            int count;
            byte data[] = new byte[BUFFER];
            while ((count = bis.read(data, 0, BUFFER)) != -1)
            {
                taos.write(data, 0, count);
            }
        }
        catch (FileNotFoundException e)
        {
            logger.error(
                    "TarUtils.archiveFile(File file, TarArchiveOutputStream taos, String dir, boolean isHasRoot) FileNotFoundException",
                    e);
            throw new BackupException(e);
        }
        catch (IOException e)
        {
            logger.error(
                    "TarUtils.archiveFile(File file, TarArchiveOutputStream taos, String dir, boolean isHasRoot) IOException",
                    e);
            throw new BackupException(e);
        }
        catch (Exception e)
        {
            logger.error(
                    "TarUtils.archiveFile(File file, TarArchiveOutputStream taos, String dir, boolean isHasRoot) Exception",
                    e);
            throw new BackupException(e);
        }
        finally
        {
            try
            {
                if (bis != null)
                {
                    bis.close();
                }
            }
            catch (IOException e)
            {
                logger.error("BufferedInputStream Close IOException", e);
            }

            try
            {
                if (taos != null)
                {
                    taos.closeArchiveEntry();
                }
            }
            catch (IOException e)
            {
                logger.error("TarArchiveOutputStream closeArchiveEntry IOException", e);
            }
        }
    }

    /**
     * 解归档
     * 
     * @param srcFile
     * @throws Exception
     */
    public static void deArchive(File srcFile)
    {
        String basePath = srcFile.getParent();
        deArchive(srcFile, basePath);
    }

    /**
     * 解归档
     * 
     * @param srcFile
     * @param destFile
     * @throws Exception
     */
    public static void deArchive(File srcFile, File destFile)
    {
        TarArchiveInputStream tais = null;
        try
        {
            tais = new TarArchiveInputStream(new FileInputStream(srcFile));
            deArchive(destFile, tais);
        }
        catch (FileNotFoundException e)
        {
            logger.error("TarUtils.deArchiveFile(File srcFile, File destFile) FileNotFoundException", e);
            throw new BackupException(e);
        }
        catch (Exception e)
        {
            logger.error("TarUtils.deArchiveFile(File srcFile, File destFile) Exception", e);
            throw new BackupException(e);
        }
        finally
        {
            if (tais != null)
            {
                try
                {
                    tais.close();
                }
                catch (IOException e)
                {
                    logger.error(
                            "TarUtils.deArchiveFile(File srcFile, File destFile) TarArchiveInputStream close IOException",
                            e);
                }
            }
        }

    }

    /**
     * 解归档
     * 
     * @param srcFile
     * @param destPath
     * @throws Exception
     */
    public static void deArchive(File srcFile, String destPath)
    {
        deArchive(srcFile, new File(destPath));
    }

    /**
     * 文件 解归档
     * 
     * @param destFile
     *            目标文件
     * @param tais
     *            ZipInputStream
     * @throws Exception
     */
    private static void deArchive(File destFile, TarArchiveInputStream tais)
    {
        TarArchiveEntry entry = null;
        try
        {
            while ((entry = tais.getNextTarEntry()) != null)
            {
                // 文件
                String dir = destFile.getPath() + File.separator + entry.getName();
                File dirFile = new File(dir);

                // 文件检查
                fileProber(dirFile);

                if (entry.isDirectory())
                {
                    dirFile.mkdirs();
                }
                else
                {
                    deArchiveFile(dirFile, tais);
                }
            }
        }
        catch (IOException e)
        {
            logger.error("TarUtils.deArchiveFile(File destFile, TarArchiveInputStream tais) IOException", e);
            throw new BackupException(e);
        }
        catch (Exception e)
        {
            logger.error("TarUtils.deArchiveFile(File destFile, TarArchiveInputStream tais) Exception", e);
            throw new BackupException(e);
        }
    }

    /**
     * 文件 解归档
     * 
     * @param srcPath
     *            源文件路径
     * 
     * @throws Exception
     */
    public static void deArchive(String srcPath)
    {
        File srcFile = new File(srcPath);

        deArchive(srcFile);
    }

    /**
     * 文件 解归档
     * 
     * @param srcPath
     *            源文件路径
     * @param destPath
     *            目标文件路径
     * @throws Exception
     */
    public static void deArchive(String srcPath, String destPath)
    {

        File srcFile = new File(srcPath);
        deArchive(srcFile, destPath);
    }

    /**
     * 文件解归档
     * 
     * @param destFile
     *            目标文件
     * @param tais
     *            TarArchiveInputStream
     * @throws Exception
     */
    private static void deArchiveFile(File destFile, TarArchiveInputStream tais)
    {
        BufferedOutputStream bos = null;
        try
        {
            bos = new BufferedOutputStream(new FileOutputStream(destFile));
            int count;
            byte data[] = new byte[BUFFER];
            while ((count = tais.read(data, 0, BUFFER)) != -1)
            {
                bos.write(data, 0, count);
            }
        }
        catch (FileNotFoundException e)
        {
            logger.error("TarUtils.deArchiveFile(File destFile, TarArchiveInputStream tais) FileNotFoundException", e);
            throw new BackupException(e);
        }
        catch (IOException e)
        {
            logger.error("TarUtils.deArchiveFile(File destFile, TarArchiveInputStream tais) IOException", e);
            throw new BackupException(e);
        }
        catch (Exception e)
        {
            logger.error("TarUtils.deArchiveFile(File destFile, TarArchiveInputStream tais) Exception", e);
            throw new BackupException(e);
        }
        finally
        {
            if (bos != null)
            {
                try
                {
                    bos.close();
                }
                catch (IOException e)
                {
                    logger.error(
                            "TarUtils.deArchiveFile(File destFile, TarArchiveInputStream tais) BufferedOutputStream close IOException",
                            e);
                }
            }
        }

    }

    /**
     * 文件探针
     * 
     * <pre>
     * 当父目录不存在时，创建目录！
     * </pre>
     * 
     * @param dirFile
     */
    private static void fileProber(File dirFile)
    {
        File parentFile = dirFile.getParentFile();
        if (parentFile != null && !parentFile.exists())
        {
            // 递归寻找上级目录
            fileProber(parentFile);

            parentFile.mkdir();
        }

    }

    public static void main1(String[] args) throws Exception
    {
        //        File sF = new File("D:\\develop\\SVN_ROOT\\backup\\build\\libs");
        //        File dF = new File("D:\\develop\\SVN_ROOT\\backup\\build\\aa.tar");
        //        archive(sF, dF, false);
        File dF = new File("D:\\develop\\SVN_ROOT\\backup\\build\\libs\\20160919200100.tar");
        //deArchive(dF, "20160919200100");
        System.out.println(dF.getParentFile());
        System.out.println(new File("F:\\ISO").length());
    }
}
