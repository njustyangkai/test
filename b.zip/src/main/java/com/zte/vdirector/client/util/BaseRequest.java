package com.zte.vdirector.client.util;

import java.util.Calendar;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：BaseRequest   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年7月30日 下午2:34:04 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年7月30日 下午2:34:04  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class BaseRequest
{
    Logger logger = LoggerFactory.getLogger(this.getClass());
    private RestfulClient orgRestfulClient;
 
    @Resource
    public void setOrgRestfulClient(RestfulClient orgRestfulClient)
    {
        this.orgRestfulClient = orgRestfulClient;
    }

    protected RestfulRsp patch(Object bean, Map<String, String> headers, MediaType mediaType, String url)
            throws Exception
    {
        return request(bean, headers, HttpMethod.PATCH, mediaType, url);
    }

    protected RestfulRsp post(Object bean, Map<String, String> headers, MediaType mediaType, String url)
            throws Exception
    {
        return request(bean, headers, HttpMethod.POST, mediaType, url);
    }

    protected RestfulRsp get(Object bean, Map<String, String> headers, MediaType mediaType, String url)
            throws Exception
    {
        return request(bean, headers, HttpMethod.GET, mediaType, url);
    }

    protected RestfulRsp put(Object bean, Map<String, String> headers, MediaType mediaType, String url)
            throws Exception
    {
        return request(bean, headers, HttpMethod.PUT, mediaType, url);
    }

    protected RestfulRsp delete(Object bean, Map<String, String> headers, MediaType mediaType, String url)
            throws Exception
    {
        return request(bean, headers, HttpMethod.DELETE, mediaType, url);
    }

    protected RestfulRsp head(Object bean, Map<String, String> headers, MediaType mediaType, String url)
            throws Exception
    {
        return request(bean, headers, HttpMethod.HEAD, mediaType, url);
    }

    protected RestfulRsp request(Object bean, Map<String, String> headers, HttpMethod method, MediaType mediaType, String url) throws Exception
    {
        Calendar starttime = Calendar.getInstance();
        RestfulReq in = new RestfulReq();

        if (bean != null && !bean.toString().trim().equals(""))
        {
            if (bean instanceof String)
            {
                in.setRequestBody(bean.toString());
            }
            else if (bean instanceof byte[] || bean instanceof Byte[])
            {
                in.setRequestBody(bean);
            }
            else
            {
                in.setRequestBody(JSON.toJSONString(bean));
            }
        }

        if (mediaType != null)
        {
            in.setType(mediaType);
        }
        in.setUrl(url);
        in.setHeaders(headers);

        RestfulRsp out;
        switch (method)
        {
            case GET:
                out = orgRestfulClient.get(in);
                break;
            case POST:
                out = orgRestfulClient.post(in);
                break;
            case PUT:
                out = orgRestfulClient.put(in);
                break;
            case DELETE:
                out = orgRestfulClient.delete(in);
                break;
            case HEAD:
                out = orgRestfulClient.head(in);
                break;
            case PATCH:
                out = orgRestfulClient.patch(in);
                break;
            default:
                out = new RestfulRsp();
                out.setStatusCode(500);
                out.setStatusName("system error");
                break;
        }
        Calendar endtime = Calendar.getInstance();
        logger.info("Resquest INFO : [ " + method.toString() + " ] [ " + url + " ] [ " + JSON.toJSONString(in) + " ]");
        logger.info("Response INFO : [ " + JSON.toJSONString(out) + " ]");
        logger.info("Consume " + (endtime.getTime().getTime() - starttime.getTime().getTime()) + "ms");
        return out;
    }
}
