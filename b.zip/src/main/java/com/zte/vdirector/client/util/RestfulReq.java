package com.zte.vdirector.client.util;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.MediaType;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：RestfulReq   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年7月30日 下午2:56:00 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年7月30日 下午2:56:00  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class RestfulReq
{
    /**
     * URL
     */
    private String url;

    /**
     * 请求body
     */
    private Object requestBody;

    /**
     * 请求header
     */
    private Map<String, String> headers = new HashMap<String, String>();

    private MediaType type = new MediaType("application", "json", Charset.forName("UTF-8"));

    /**
     * @return String
     */
    public String getUrl()
    {
        return url;
    }

    /**
     * @param url url
     */
    public void setUrl(String url)
    {
        this.url = url;
    }

    /**
     * @return Object
     */
    public Object getRequestBody()
    {
        return requestBody;
    }

    /**
     * @param requestBody requestBody
     */
    public void setRequestBody(Object requestBody)
    {
        this.requestBody = requestBody;
    }

    /**
     * @return Map<String, String>
     */
    public Map<String, String> getHeaders()
    {
        return headers;
    }

    /**
     * @param headers headers
     */
    public void setHeaders(Map<String, String> headers)
    {
        this.headers = headers;
    }

    /**
     * @return MediaType
     */
    public MediaType getType()
    {
        return type;
    }

    /**
     * @param type type
     */
    public void setType(MediaType type)
    {
        this.type = type;
    }
}
