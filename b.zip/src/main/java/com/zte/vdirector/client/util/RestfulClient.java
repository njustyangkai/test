package com.zte.vdirector.client.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.ResourceHttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.UnknownHttpStatusCodeException;

/**
 * 
 * 版权所有：中兴通讯股份有限公司   
 * 项目名称：RestClient   
 * 类名称：RosRestClient   
 * 类描述：   
 * 创建人：10079153   
 * 创建时间：2014年4月14日 上午11:36:08   
 * 修改人：10079153  
 * 修改时间：2014年4月14日 上午11:36:08   
 * 修改备注：   
 * @version 1.0   
 *
 */
@Service("orgRestfulClient")
public class RestfulClient
{
    private static RestTemplate restTemplate;

    /**
     * @param in rest请求入参
     * @return rest请求出参
     */
    public RestfulRsp get(RestfulReq in)
    {
        return sendRestRequest(in, HttpMethod.GET);
    }

    /**
     * @param in rest请求入参
     * @return rest请求出参
     */
    public RestfulRsp post(RestfulReq in)
    {
        return sendRestRequest(in, HttpMethod.POST);
    }

    /**
     * @param in rest请求入参
     * @return rest请求出参
     */
    public RestfulRsp patch(RestfulReq in)
    {
        return sendRestRequest(in, HttpMethod.PATCH);
    }

    /**
     * @param in rest请求入参
     * @return rest请求出参
     */
    public RestfulRsp put(RestfulReq in)
    {
        return sendRestRequest(in, HttpMethod.PUT);
    }

    /**
     * @param in rest请求入参
     * @return rest请求出参
     */
    public RestfulRsp delete(RestfulReq in)
    {
        return sendRestRequest(in, HttpMethod.DELETE);
    }

    /**
     * @param in rest请求入参
     * @return rest请求出参
     */
    public RestfulRsp head(RestfulReq in)
    {
        return sendRestRequest(in, HttpMethod.HEAD);
    }

    /**
     * 初始化
     * @param maxPerRoute 每个主机的最大并行链接数
     * @param maxTotal 客户端总并行链接最大数
     * @param connectTimeout 连接超时时间
     * @param readTimeout 传输超时时间
     */
    public static void init(int maxPerRoute, int maxTotal, int connectTimeout, int readTimeout)
    {
        DefaultHttpClient httpClient = new DefaultHttpClient(maxPerRoute, maxTotal);
        HttpComponentsClientHttpRequestFactory httpClientFactory = new HttpComponentsClientHttpRequestFactory(
                httpClient);
        httpClientFactory.setConnectTimeout(connectTimeout);
        httpClientFactory.setReadTimeout(readTimeout);

        ByteArrayHttpMessageConverter byteConverter = new ByteArrayHttpMessageConverter();
        ResourceHttpMessageConverter resourceConverter = new ResourceHttpMessageConverter();
        StringHttpMessageConverter httpConverter = new StringHttpMessageConverter();
        List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
        messageConverters.add(byteConverter);
        messageConverters.add(resourceConverter);
        messageConverters.add(httpConverter);
        restTemplate = new RestTemplate(httpClientFactory);
        restTemplate.setMessageConverters(messageConverters);
    }

    /**
     * @param in rest请求入参
     * @param method
     * @return rest请求出参
     */
    private RestfulRsp sendRestRequest(RestfulReq in, HttpMethod method)
    {
        RestfulRsp out = new RestfulRsp();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(in.getType());
        headers.add("accept", "application/json");
        Map<String, String> headersmap = in.getHeaders();
        if (headersmap != null && !headersmap.isEmpty())
        {
            for (String key : headersmap.keySet())
            {
                headers.add(key, headersmap.get(key));
            }
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        HttpEntity<?> request = new HttpEntity(in.getRequestBody(), headers);

        try
        {
            if (restTemplate == null)
            {
                RestfulClient.init(20, 100, 30000, 120000);
            }
            ResponseEntity<?> httpResponse = restTemplate.exchange(in.getUrl(), method, request, String.class);
            out.setStatusCode(httpResponse.getStatusCode().value());
            out.setStatusName(httpResponse.getStatusCode().name());
            if (httpResponse.getBody() != null)
            {
                out.setResponseBody(httpResponse.getBody().toString());
            }
            out.setHeaders(httpResponse.getHeaders());
            return out;
        }
        catch (UnknownHttpStatusCodeException e)
        {
            out.setStatusCode(e.getRawStatusCode());
            out.setStatusName(e.getMessage());
            out.setResponseBody(e.getMessage());
            return out;
        }
        catch (HttpStatusCodeException e)
        {
            out.setStatusCode(e.getStatusCode().value());
            out.setStatusName(e.getStatusCode().name());
            String responseBodyStr = e.getResponseBodyAsString();
            if (StringUtils.contains(responseBodyStr, "<h1>") && StringUtils.contains(responseBodyStr, "</h1>"))
            {
                out.setResponseBody(StringUtils.substringBetween(responseBodyStr, "<h1>", "</h1>"));
            }
            else
            {
                out.setResponseBody(e.getResponseBodyAsString());
            }
            return out;
        }
        catch (Exception e)
        {
            out.setStatusCode(500);
            out.setStatusName(e.getMessage());
            out.setResponseBody(e.getMessage());
            return out;
        }
    }
}
