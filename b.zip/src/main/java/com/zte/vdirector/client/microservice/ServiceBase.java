package com.zte.vdirector.client.microservice;

import org.springframework.stereotype.Service;

import com.zte.vdirector.client.util.BaseRequest;
import com.zte.vdirector.client.util.MsbUtil;
import com.zte.vdirector.client.util.RestfulRsp;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：ServiceBase   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年11月24日 下午8:07:06 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年11月24日 下午8:07:06  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Service
public class ServiceBase extends BaseRequest
{

    public RestfulRsp post(Object object, String urlpath) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.post(object, null, null, url);
    }

    public RestfulRsp put(Object object, String urlpath) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.put(object, null, null, url);
    }

    public RestfulRsp get(String urlpath) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.get(null, null, null, url);
    }

    public RestfulRsp delete(String urlpath) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.delete(null, null, null, url);
    }

}
