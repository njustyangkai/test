/**
 * 
 */
package com.zte.vdirector.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.fastjson.JSON;
import com.zte.vdirector.client.microservice.MsbAPI;
import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.BackupMsInfo;
import com.zte.vdirector.domain.BackupMsInfos;
import com.zte.vdirector.domain.BackupRecord;
import com.zte.vdirector.domain.BackupStrategy;
import com.zte.vdirector.domain.RestoreRecord;
import com.zte.vdirector.domain.ServiceInfo;
import com.zte.vdirector.domain.ServiceInfo.ServiceNode;
import com.zte.vdirector.domain.dao.BackupRecordDao;
import com.zte.vdirector.domain.dao.BackupStrategyDao;
import com.zte.vdirector.domain.dao.RestoreRecordDao;
import com.zte.vdirector.frame.constants.BackupConstants;
import com.zte.vdirector.frame.constants.BackupConstants.BackupStatus;
import com.zte.vdirector.frame.constants.BackupConstants.ClearMode;
import com.zte.vdirector.frame.exception.BackupException;
import com.zte.vdirector.frame.utils.BackupUtils;
import com.zte.vdirector.frame.utils.PropertiesUtils;
import com.zte.vdirector.frame.utils.TarUtils;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupService   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午3:48:01 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午3:48:01  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Service
public class BackupService
{
    private Logger logger = LoggerFactory.getLogger(BackupService.class);

    private static final String DEFAULT_BACKUP_DIR = "/home/Data/vdirector-backup";

    private static final String DEFAULT_MYSQL_INSTALL_DIR = "/home/ztecms";

    private static final String FILE_KEY_SQL = "sql";

    private static final String FILE_KEY_PROPERTIES = "properties";
    
    private static final String FILE_KEY_CONF = "conf";
    
    private static final String LOG_CONFIG_FILE_NAME = "log-config.conf";

    @Autowired
    private Environment environment;

    @Autowired
    private DataSource dataSource;

    @Autowired
    private BackupMsInfos backupMsInfos;

    @Autowired
    private BackupStrategyDao backupStrategyDao;

    @Autowired
    private BackupRecordDao backupRecordDao;

    @Autowired
    private RestoreRecordDao restoreRecordDao;

    @Autowired
    private MsbAPI msbAPI;

    @Autowired
    private ServiceBase serviceBase;

    /**
     * 查询策略
     * @return
     */
    public BackupStrategy queryBackupStrategy()
    {
        return backupStrategyDao.queryBackupStrategy();
    }

    /**
     * 更新策略
     * @param backupStrategy
     */
    public BackupStrategy updateBackupStrategy(BackupStrategy backupStrategy)
    {
        return backupStrategyDao.updateBackupStrategy(backupStrategy);
    }

    /**
     * 查询备份列表
     * @return
     */
    public List<BackupRecord> queryBackupRecords()
    {
        return backupRecordDao.queryBackupRecords();
    }

    /**
     * 查询备份列表
     * @return
     */
    public Map<String, BackupRecord> queryBackupRecordsMap()
    {
        Map<String, BackupRecord> backupRecordsMap = new HashMap<String, BackupRecord>();

        List<BackupRecord> backupRecords = queryBackupRecords();
        if (backupRecords != null && backupRecords.size() > 0)
        {
            for (BackupRecord backupRecord : backupRecords)
            {
                backupRecordsMap.put(backupRecord.getId(), backupRecord);
            }
        }
        return backupRecordsMap;
    }

    /**
     * 查询备份信息
     * @return
     */
    public BackupRecord queryBackupRecord(String id)
    {
        return backupRecordDao.queryBackupRecord(id);
    }

    /**
     * 判断是否有进行中的备份任务 
     */
    public boolean isBackupProcessing()
    {
        return backupRecordDao.isProcessing();
    }

    /**
     * 新增备份记录
     * @param backupRecord
     * @return 
     */
    public BackupRecord addBackupRecord(BackupRecord backupRecord)
    {
        return backupRecordDao.addBackupRecord(backupRecord);
    }

    /**
     * 编辑备份记录
     * @param backupRecord
     * @return
     */
    public BackupRecord updateBackupRecord(BackupRecord backupRecord)
    {
        return backupRecordDao.updateBackupRecord(backupRecord);
    }

    /**
     * 终止正在备份的任务
     * @param backupStaus detail
     * @return
     */
    public void finishProcessingBackupRecord(int backupStaus, String detail)
    {
        backupRecordDao.finishProcessingBackupRecord(backupStaus, detail);
    }

    /**
     * 删除备份记录
     * @param id
     * @return
     */
    public void deleteBackupRecord(String id, String filePath)
    {
        backupRecordDao.deleteBackupRecord(id);
        File file = new File(filePath);
        if (file.exists())
        {
            file.delete();
        }
    }

    /**
     * 根据备份文件删除备份记录
     * @param id
     * @return
     */
    public void deleteBackupRecordByFile(String fileName)
    {
        backupRecordDao.deleteBackupRecordByFile(fileName);
    }

    /**
     * 查询恢复列表记录
     * @return
     */
    public List<RestoreRecord> queryRestoreRecords()
    {
        return restoreRecordDao.queryRestoreRecords();
    }

    /**
     * 查询恢复详情
     */
    public RestoreRecord queryRestoreRecord(String id)
    {
        return restoreRecordDao.queryRestoreRecord(id);
    }

    /**
     * 判断是否有进行中的恢复任务 
     */
    public boolean isRestoreProcessing()
    {
        return restoreRecordDao.isProcessing();
    }

    /**
     * 新增恢复记录
     * @param restoreRecord
     * @return 
     */
    public RestoreRecord addRestoreRecord(RestoreRecord restoreRecord)
    {
        return restoreRecordDao.addRestoreRecord(restoreRecord);
    }

    /**
     * 编辑备份恢复记录
     * @param restoreRecord
     * @return
     */
    public RestoreRecord updateRestoreRecord(RestoreRecord restoreRecord)
    {
        return restoreRecordDao.updateRestoreRecord(restoreRecord);
    }

    /**
     * 终止正在恢复的任务
     * @param restoreStaus detail
     * @return
     */
    public void finishProcessingRestoreRecord(int restoreStaus, String detail)
    {
        restoreRecordDao.finishProcessingRestoreRecord(restoreStaus, detail);
    }

    /**
     * 删除备份恢复记录
     * @param id
     * @return
     */
    public void deleteRestoreRecord(String id)
    {
        restoreRecordDao.deleteRestoreRecord(id);
    }

    /**
     * 备份
     */
    public void backup(BackupRecord newBackupRecord)
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        //获取备份的临时目录
        String backupRelativePath = simpleDateFormat.format(newBackupRecord.getStartTime());
        //新增一条备份记录
        addBackupRecord(newBackupRecord);

        //备份策略
        BackupStrategy backupStrategy = queryBackupStrategy();
        //获取配置的文件路径
        String backupPath = backupStrategy.getBackupPath();
        //创建临时备份文件目录
        File backupPathDir = createTempBackupDir(backupPath, backupRelativePath);

        List<BackupMsInfo> backupMsInfoList = backupMsInfos.getBackupMsInfos();

        try
        {
            if (backupMsInfoList != null && backupMsInfoList.size() > 0)
            {
                //备份数据库
                String sqlFileName = backupRelativePath + ".sql";
                backupMysqlDb(backupMsInfoList, backupPathDir.getPath(), sqlFileName);

                //备份配置文件
                //backupConfigurationFile(backupMsInfoList, backupPathDir.getPath());
                
                //备份日志配置信息
                backupLogConfiguration(backupPathDir.getPath());
                
                //打tar包
                tarBackupFile(backupPathDir.getPath(), backupPathDir.getPath() + ".tar");

                BackupRecord backupRecord = getFinishBackupRecord(newBackupRecord, BackupStatus.SUCCESS, "");
                File tarFile = new File(backupPathDir.getPath() + ".tar");
                backupRecord.setFileName(backupRelativePath + ".tar");

                BigDecimal bigDecimal = new BigDecimal(tarFile.length() / 1024);
                backupRecord.setFileSize(bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue());
                updateBackupRecord(backupRecord);
            }
            else
            {
                logger.info("The backup information of microservice is empty");
            }
        }
        catch (Exception e)
        {
            BackupRecord backupRecord = getFinishBackupRecord(newBackupRecord, BackupStatus.FAIL, "Backup Failed: "
                    + e.getMessage());
            updateBackupRecord(backupRecord);
            throw new BackupException(e);
        }
        finally
        {
            try
            {
                if (backupPathDir.exists())
                {
                    BackupUtils.deleteDir(backupPathDir);
                }
            }
            catch (Exception e)
            {
                logger.error("Delete backup directory Exception", e);
            }
        }
    }

    /**
     * 新增一条备份记录
     * @param id
     * @param backupDate
     * @param mode
     * @return
     */
    public BackupRecord getBackupRecord(String id, Date backupDate, int mode)
    {
        BackupRecord backupRecord = new BackupRecord();
        backupRecord.setId(id);
        backupRecord.setMode(mode);
        backupRecord.setStartTime(backupDate);
        backupRecord.setStatus(BackupStatus.PROCESSING);
        return backupRecord;
    }

    /**
     * 失败记录
     * @param backupRecord
     * @return
     */
    public BackupRecord getFinishBackupRecord(BackupRecord backupRecord, int status, String detail)
    {
        backupRecord.setStatus(status);
        backupRecord.setEndTime(new Date());
        backupRecord.setProgress(100);
        backupRecord.setDetail(detail);
        return backupRecord;
    }

    /**
     * 恢复记录
     * @param id
     * @param restoreDate
     * @param mode
     * @return
     */
    public RestoreRecord getRestoreRecord(String id, Date restoreDate, String userName, String fileName, double fileSize)
    {
        RestoreRecord restoreRecord = new RestoreRecord();
        restoreRecord.setId(id);
        restoreRecord.setUserName(userName);
        restoreRecord.setStartTime(restoreDate);
        restoreRecord.setStatus(BackupStatus.PROCESSING);
        restoreRecord.setFileName(fileName);
        restoreRecord.setFileSize(fileSize);
        return restoreRecord;
    }

    /**
     * 恢复结束记录
     * @param restoreRecord
     * @return
     */
    public RestoreRecord getFinishRestoreRecord(RestoreRecord restoreRecord, int status, String detail)
    {
        restoreRecord.setStatus(status);
        restoreRecord.setEndTime(new Date());
        restoreRecord.setProgress(100);
        restoreRecord.setDetail(detail);
        return restoreRecord;
    }

    /**
     * 创建临时文件目录
     * @param backupPath
     * @return 
     */
    private File createTempBackupDir(String backupPath, String backupRelativePath)
    {
        if (StringUtils.isBlank(backupPath))
        {
            //如果配置的备份路径为空，则检查配置文件中是否有路径，若配置文件中也没有配置，则使用DEFAULT_BACKUP_DIR
            if (StringUtils.isNotBlank(environment.getProperty("backup.default.dir")))
            {
                backupPath = environment.getProperty("backup.default.dir");
            }
            else
            {
                backupPath = DEFAULT_BACKUP_DIR;
            }
        }

        File backupPathDir = new File(backupPath + File.separator + backupRelativePath);
        if (!backupPathDir.exists())
        {
            backupPathDir.mkdirs();
        }
        return backupPathDir;
    }

    /**
     * 将备份文件打成tar
     * @param srcFilePah
     * @param destFilePath
     * @return
     */
    private boolean tarBackupFile(String srcFilePah, String destFilePath)
    {
        try
        {
            //打tar包
            TarUtils.archive(srcFilePah, destFilePath, false);
        }
        catch (Exception e)
        {
            logger.info("Archive tar package Exception", e);
            throw new BackupException(e);
        }

        return true;
    }

    /**
     * 备份配置文件
     * @param backupMsInfos
     * @param backupPath
     * @return
     */
    public boolean backupConfigurationFile(List<BackupMsInfo> backupMsInfos, String backupPath)
    {
        //配置文件路径
        File backupPathFile = new File(backupPath);
        if (!backupPathFile.exists())
        {
            //如果路径不存在，则重建
            backupPathFile.mkdirs();
        }
        return backupConfigurationFileUseFileCopy(backupMsInfos, backupPath);
        //        String backupCommand = getBackupConfigurationFileCommand(backupMsInfos, backupPath);
        //
        //        if (StringUtils.isBlank(backupCommand))
        //        {
        //            logger.info("The command of backup configuration file is blank, configurationFileBackupPath = "
        //                    + backupPath);
        //            return true;
        //        }
        //        else
        //        {
        //            return execBackupCommand(backupCommand, backupPath, "Configuration_File");
        //        }
    }

    /**
     * 
     * @param backupMsInfos
     * @param backupPath
     * @return
     */
    public boolean backupConfigurationFileUseFileCopy(List<BackupMsInfo> backupMsInfos, String backupPath)
    {
        for (BackupMsInfo backupMsInfo : backupMsInfos)
        {
            //通过配置文件路径构造拷贝命令
            if (backupMsInfo.isEnabled())
            {
                String configurationFilePath = getMicroServiceHomeDir(backupMsInfo) + File.separator
                        + backupMsInfo.getServiceName() + ".properties";
                File configurationFile = new File(configurationFilePath);
                if (configurationFile.exists())
                {
                    try
                    {
                        Files.copy(Paths.get(configurationFilePath),
                                Paths.get(backupPath + File.separator + backupMsInfo.getServiceName() + ".properties"),
                                StandardCopyOption.REPLACE_EXISTING);
                    }
                    catch (IOException e)
                    {
                        logger.info("Copy configurationFile IOException, the configurationFilePath is "
                                + configurationFilePath, e);
                    }
                }
                else
                {
                    logger.info("The configuration file of " + backupMsInfo.getServiceName()
                            + " is not exists, please check configurationFilePath [" + configurationFilePath + "]");
                }
            }
        }
        return true;
    }

    /**
     * 
     * @param backupMsInfo
     * @return
     */
    public String getMicroServiceHomeDir(BackupMsInfo backupMsInfo)
    {
        String homeDir = backupMsInfo.getHomeDir();
        if (StringUtils.isBlank(homeDir))
        {
            homeDir = environment.getProperty(BackupConstants.INPUT_INSTALL_DIR) + File.separator + "zte"
                    + File.separator + backupMsInfo.getServiceName();
        }
        return homeDir;
    }

    /**
     * 获取配置备份文件路径的命令
     * @param backupMsInfos
     * @param configurationFileBackupPath
     * @return
     */
    public String getBackupConfigurationFileCommand(List<BackupMsInfo> backupMsInfos, String configurationFileBackupPath)
    {
        StringBuffer backupCommand = new StringBuffer("");
        for (BackupMsInfo backupMsInfo : backupMsInfos)
        {
            //通过配置文件路径构造拷贝命令
            if (backupMsInfo.isEnabled())
            {
                String configurationFilePath = getMicroServiceHomeDir(backupMsInfo) + File.separator
                        + backupMsInfo.getServiceName() + ".properties";
                File configurationFile = new File(configurationFilePath);
                if (configurationFile.exists())
                {
                    backupCommand.append(configurationFilePath).append(" ");
                }
                else
                {
                    logger.info("The configuration file of " + backupMsInfo.getServiceName()
                            + " is not exists, please check configurationFilePath [" + configurationFilePath + "]");
                }
            }
        }
        if (backupCommand.length() == 0)
        {
            //没有需要备份的配置文件
            return backupCommand.toString();
        }
        return "cp -f " + backupCommand.append(configurationFileBackupPath).toString();
    }

    /**
     * 执行命令
     * @param backupCommand
     * @param streamGobblerName
     * @param streamGobblerType
     * @return
     */
    private boolean execBackupCommand(String[] backupCommand, String streamGobblerName, String streamGobblerType)
    {
        Process ps = null;
        BufferedReader br = null;
        try
        {
            logger.info("Command = " + JSON.toJSONString(backupCommand));
            //执行命令
            if (backupCommand.length == 1)
            {
                ps = Runtime.getRuntime().exec(backupCommand[0]);
            }
            else
            {
                ps = Runtime.getRuntime().exec(backupCommand);
            }

            BackupDumpStreamGobbler errorGobbler = new BackupDumpStreamGobbler(ps.getErrorStream(), "ERROR",
                    streamGobblerName, streamGobblerType);
            BackupDumpStreamGobbler infoGobbler = new BackupDumpStreamGobbler(ps.getInputStream(), "OUTPUT",
                    streamGobblerName, streamGobblerType);
            errorGobbler.start();
            infoGobbler.start();

            int status = ps.waitFor();
            if (status == 0)
            {
                return true;
            }
            else
            {
                logger.info("Command execute failed, the process status is " + status);
                throw new BackupException("Runtime execute backup command failed, the flag is " + status);
            }
        }
        catch (Exception e)
        {
            logger.error("Command execute Exception", e);
            throw new BackupException(e);
        }
        finally
        {
            if (br != null)
            {
                try
                {
                    br.close();
                }
                catch (IOException e1)
                {
                    logger.error("Close BufferedReader IOException", e1);
                }
            }
            if (null != ps)
            {
                ps.destroy();
            }
        }
    }

    /**
     * 执行命令
     * @param commands
     * @param streamGobblerName
     * @param streamGobblerType
     * @return
     */
    public boolean execCommandByProcessBuilder(List<String> commands, String streamGobblerName, String streamGobblerType)
    {
        Process ps = null;
        BufferedReader br = null;
        try
        {
            logger.info("Command = " + JSON.toJSONString(commands));
            //执行命令
            ps = new ProcessBuilder(commands).start();

            BackupDumpStreamGobbler errorGobbler = new BackupDumpStreamGobbler(ps.getErrorStream(), "ERROR",
                    streamGobblerName, streamGobblerType);
            BackupDumpStreamGobbler infoGobbler = new BackupDumpStreamGobbler(ps.getInputStream(), "OUTPUT",
                    streamGobblerName, streamGobblerType);
            errorGobbler.start();
            infoGobbler.start();

            int status = ps.waitFor();
            if (status == 0)
            {
                return true;
            }
            else
            {
                logger.info("Command execute failed, the process status is " + status);
                throw new BackupException("ProcessBuilder execute command failed, the flag is " + status);
            }
        }
        catch (Exception e)
        {
            logger.error("Command execute Exception", e);
            throw new BackupException(e);
        }
        finally
        {
            if (br != null)
            {
                try
                {
                    br.close();
                }
                catch (IOException e1)
                {
                    logger.error("Close BufferedReader IOException", e1);
                }
            }
            if (null != ps)
            {
                ps.destroy();
            }
        }
    }

    /**
     * 
     * @param backupMsInfos
     * @param backupPath
     * @param backupFileName
     * @return
     */
    private boolean backupMysqlDb(List<BackupMsInfo> backupMsInfos, String backupPath, String backupFileName)
    {
        String backupCommand = getBackupMysqlDbCommand(backupMsInfos, backupPath, backupFileName);
        if (StringUtils.isBlank(backupCommand))
        {
            logger.info("The command of backup mysql DB is blank, backupPath = " + backupPath);
            return true;
        }
        return execBackupCommand(new String[] { backupCommand }, backupFileName, "Mysql_DB_Backup");
    }

    /**
     * 获取mysql命令前缀，command为mysql或者mysqldump
     * @return
     */
    private StringBuffer getMysqlDbCommandPrefix(String command)
    {
        String datasourceUrl = ((DruidDataSource) dataSource).getUrl(); //environment.getProperty("spring.datasource.url");
        //mysql的ip
        String mysqlHostIp = StringUtils.substringBetween(datasourceUrl, "jdbc:mysql://", ":");
        //mysql port
        String mysqlPort = StringUtils.substringBetween(datasourceUrl, mysqlHostIp + ":", "/");
        //mysql用户名
        String mysqlUserName = environment.getProperty("spring.datasource.username");
        //mysql密码
        String mysqlPassword = environment.getProperty("spring.datasource.password");

        //获取mysql的安装目录
        String mysqlHome = environment.getProperty("backup.mysql.home.dir");
        StringBuffer backupCommand = null;

        if (StringUtils.isBlank(mysqlHome))
        {
            //如果安装目录为空，则用系统默认的mysqdump mysql命令
            String installHome = DEFAULT_MYSQL_INSTALL_DIR;
            mysqlHome = installHome + File.separator + "mysql";
        }

        //指定mysqldump命令
        backupCommand = new StringBuffer(mysqlHome).append(File.separator).append("bin").append(File.separator)
                .append(command);

        backupCommand.append(" --host=").append(mysqlHostIp).append(" --port=").append(mysqlPort).append(" --user=")
                .append(mysqlUserName).append(" --password=").append(mysqlPassword);

        if (StringUtils.isNotBlank(environment.getProperty("backup.mysql.socket")))
        {
            backupCommand.append(" --socket=").append(environment.getProperty("backup.mysql.socket"));
        }
        backupCommand.append(" --default-character-set=utf8 ");
        return backupCommand;
    }

    /**
     * 获取备份数据库的命令
     * @param backupMsInfo
     * @param backupPath
     * @return
     */
    private String getBackupMysqlDbCommand(List<BackupMsInfo> backupMsInfos, String backupPath, String backupFileName)
    {
        StringBuffer backupCommand = getMysqlDbCommandPrefix("mysqldump");

        StringBuffer dbNameBuffer = new StringBuffer("");
        StringBuffer ignoreTablesBuffer = new StringBuffer("");
        for (BackupMsInfo backupMsInfo : backupMsInfos)
        {
            String dbName = backupMsInfo.getDbName();
            if (backupMsInfo.isEnabled() && StringUtils.isNotBlank(dbName))
            {
                //备份的数据库
                dbNameBuffer.append(dbName).append(" ");

                String[] ignoreTables = backupMsInfo.getIgnoreTables();

                if (ignoreTables != null && ignoreTables.length > 0)
                {
                    //增加不备份的表
                    for (String table : ignoreTables)
                    {
                        ignoreTablesBuffer.append(" --ignore-table ").append(dbName).append(".").append(table);
                    }
                }
            }
        }

        if (StringUtils.isBlank(dbNameBuffer))
        {
            logger.info("No DB to backup, please check the configurations of microservice in backup.properties");
            return "";
        }

        backupCommand.append(" --databases ").append(dbNameBuffer).append(ignoreTablesBuffer);
        backupCommand.append(" --complete-insert ").append(" --skip-extended-insert ").append(" --replace ");
        //输出文件
        backupCommand.append(" --result-file=").append(backupPath).append(File.separator).append(backupFileName);
        return backupCommand.toString();
    }

    /**
     * 备份恢复
     * @param backupFile
     */
    public void restore(RestoreRecord restoreRecord, File backupFile)
    {
        File restoreTempDirFile = backupFile.getParentFile();

        try
        {
            //解压文件
            TarUtils.deArchive(backupFile, restoreTempDirFile);

            //获取待恢复的备份文件
            Map<String, Map<String, File>> fileMap = getRestoreFiles(restoreTempDirFile);

            //恢复备份的配置文件
            //restoreConfigurationFile(backupMsInfos.getBackupMsInfos(), fileMap.get(FILE_KEY_PROPERTIES));

            //恢复数据库数据
            restoreMysqlDb(fileMap.get(FILE_KEY_SQL));
            
            //恢复log配置信息
            restoreLogConfiguration(fileMap.get(FILE_KEY_CONF));

            restoreRecord = getFinishRestoreRecord(restoreRecord, BackupStatus.SUCCESS, "");
            updateRestoreRecord(restoreRecord);

            //Thread.sleep(3 * 1000);
            //启动各个微服务
            //restartMicroService();
        }
        catch (Exception e)
        {
            logger.error("Restore Exception", e);
            restoreRecord = getFinishRestoreRecord(restoreRecord, BackupStatus.FAIL,
                    "Restore Failed: " + e.getMessage());
            updateRestoreRecord(restoreRecord);
            throw new BackupException(e);
        }
        finally
        {
            try
            {
                if (restoreTempDirFile.exists())
                {
                    //删除临时目录
                    BackupUtils.deleteDir(restoreTempDirFile);
                }
            }
            catch (Exception e1)
            {
                logger.error("Delete restore temp directory Exception", e1);
            }
        }
    }

    /**
     * 重启微服务
     * @return
     */
    public void restartMicroService()
    {
        String installHome = environment.getProperty(BackupConstants.INPUT_INSTALL_DIR);
        String shellFilePath = installHome + File.separator + "zte" + File.separator + "script";
        String startShellFilePath = shellFilePath + File.separator + "run.sh";
        //String stopShellFilePath = shellFilePath + File.separator + "stop.sh";

        //停止微服务
        //execBackupCommand(new String[]{stopShellFilePath}, "stop.sh", "MicroService_Stop");
        //启动微服务
        execBackupCommand(new String[] { startShellFilePath }, "run.sh", "MicroService_Start");
    }

    /**
     * 恢复备份的配置文件
     * @param backupMsInfos
     * @param configurationFileMap
     * @return
     */
    @SuppressWarnings("unused")
    private boolean restoreConfigurationFile(List<BackupMsInfo> backupMsInfos, Map<String, File> configurationFileMap)
    {
        if (backupMsInfos != null && backupMsInfos.size() > 0)
        {
            //记录失败的文件信息
            List<String> failedFiles = new ArrayList<String>();

            for (BackupMsInfo backupMsInfo : backupMsInfos)
            {
                //配置文件名称
                String configurationFileName = backupMsInfo.getServiceName() + ".properties";
                if (configurationFileMap.containsKey(configurationFileName))
                {
                    try
                    {
                        File restoreFile = configurationFileMap.get(configurationFileName);
                        //将配置文件拷贝到微服务的安装目录
                        Files.copy(Paths.get(restoreFile.getPath()), Paths.get(getMicroServiceHomeDir(backupMsInfo)
                                + File.separator + configurationFileName), StandardCopyOption.REPLACE_EXISTING);
                    }
                    catch (IOException e)
                    {
                        failedFiles.add(configurationFileName);
                        logger.info("Restore configurationFile IOException, the configurationFile is "
                                + configurationFileName, e);
                    }
                }
            }

            if (failedFiles.size() > 0)
            {
                throw new BackupException("Restore configurationFile Exception, the file names are " + failedFiles);
            }
        }
        else
        {
            logger.info("The backup information of microservice is empty, no need to restore!");
        }
        return true;
    }

    /**
     * 获取待恢复的备份文件
     * @param restoreTempDirFile
     * @return
     */
    private Map<String, Map<String, File>> getRestoreFiles(File restoreTempDirFile)
    {
        File[] files = restoreTempDirFile.listFiles();
        Map<String, Map<String, File>> fileMap = new HashMap<String, Map<String, File>>();

        //数据库脚本文件
        Map<String, File> sqlFileMap = new HashMap<String, File>();
        //配置文件
        Map<String, File> propertiesFileMap = new HashMap<String, File>();
        //配置文件
        Map<String, File> confFileMap = new HashMap<String, File>();
        
        for (File file : files)
        {
            if (file.isFile())
            {
                String fileName = file.getName();
                if (StringUtils.endsWithIgnoreCase(fileName, ".sql"))
                {
                    //sql文件
                    sqlFileMap.put(fileName, file);
                }
                else if (StringUtils.endsWithIgnoreCase(fileName, ".properties"))
                {
                    //properties文件
                    propertiesFileMap.put(fileName, file);
                }
                else if (StringUtils.endsWithIgnoreCase(fileName, ".conf"))
                {
                    //conf文件
                    confFileMap.put(fileName, file);
                }
            }
        }
        //if (sqlFileMap.size() == 0 && configurationFileMap.size() == 0)
        if (sqlFileMap.size() == 0)
        {
            throw new BackupException("The format of file is incorrect, please check it!");
        }
        fileMap.put(FILE_KEY_SQL, sqlFileMap);
        fileMap.put(FILE_KEY_PROPERTIES, propertiesFileMap);
        fileMap.put(FILE_KEY_CONF, confFileMap);
        return fileMap;
    }

    /**
     * 恢复数据库
     * @param filePath
     * @return
     */
    private boolean restoreMysqlDb(String filePath)
    {
        StringBuffer restoreCommand = getMysqlDbCommandPrefix("mysql").append(" < ").append(filePath);
        return execBackupCommand(new String[] { "/bin/sh", "-c", restoreCommand.toString() }, filePath,
                "Mysql_DB_Restore");
    }

    /**
     * 恢复数据库
     * @param sqlFileMap
     * @return
     */
    private boolean restoreMysqlDb(Map<String, File> sqlFileMap)
    {
        //记录失败的文件信息
        List<String> failedFiles = new ArrayList<String>();

        for (File file : sqlFileMap.values())
        {
            try
            {
                //恢复数据库文件
                restoreMysqlDb(file.getPath());
            }
            catch (Exception e)
            {
                failedFiles.add(file.getName());
                logger.error("Restore Mysql Db Exception, file name is " + file.getName(), e);
            }
        }

        if (failedFiles.size() > 0)
        {
            throw new BackupException("Restore Mysql Db Exception, the file names are " + failedFiles);
        }
        return true;
    }

    /**
     * 根据策略清除备份文件
     */
    public void clear()
    {
        BackupStrategy backupStrategy = queryBackupStrategy();
        //自动清除备份方式 
        int clearMode = backupStrategy.getClearMode();
        if (clearMode == ClearMode.SIZE)
        {
            //0=按备份文件占用大小方式
            clearBySize(backupStrategy);
        }
        else if (clearMode == ClearMode.DATE)
        {
            //1=按备份文件保存天数
            clearByDate(backupStrategy);
        }

    }

    /**
     * 根据配置的文件大小清除
     * @param backupStrategy
     */
    private void clearBySize(BackupStrategy backupStrategy)
    {
        int clearValue = backupStrategy.getClearValue();
        if (clearValue > 0)
        {
            //备份文件路径
            File backupFileDir = new File(backupStrategy.getBackupPath());
            if (!backupFileDir.exists())
            {
                logger.info("The backup file path is not exist, the path is " + backupStrategy.getBackupPath());
                return;
            }
            //配置文件总大小
            long backupFileSize = BackupUtils.getDirSize(backupFileDir);
            //策略配置的文件大小
            long backupFileConfigSize = clearValue * 1024 * 1024 * 1024L;
            if (backupFileConfigSize < backupFileSize)
            {
                long exceedSize = backupFileSize - backupFileConfigSize;

                //当前备份文件总大小大于配置的值，则需要删除文件
                File[] backupFiles = backupFileDir.listFiles();

                //按名称升序排列
                Arrays.sort(backupFiles, new Comparator<File>()
                {
                    public int compare(File file1, File file2)
                    {
                        return file1.compareTo(file2);
                    }
                });

                //记录删除的文件
                List<File> deleteFiles = new ArrayList<File>();
                long deleteSize = 0L;

                //找出需要删除的文件
                for (File backupFile : backupFiles)
                {
                    deleteFiles.add(backupFile);
                    //将待删除的文件大小相加
                    if (backupFile.isDirectory())
                    {
                        //如果是目录，则递归计算目录大小
                        deleteSize = deleteSize + BackupUtils.getDirSize(backupFile);
                    }
                    else
                    {
                        deleteSize = deleteSize + backupFile.length();
                    }
                    //判断待删除的文件总大小与 超过配置的大小比较，如果大于，则不需要再删除了
                    if (deleteSize > exceedSize)
                    {
                        break;
                    }
                }

                //删除文件
                deleteFiles(deleteFiles);
            }
        }
        else
        {
            logger.info("The total backup file size is less than zero, it means no limit, no need to delete file!");
        }
    }

    /**
     * 根据配置的文件大小清除
     * @param backupStrategy
     */
    private void clearByDate(BackupStrategy backupStrategy)
    {
        //配置文件保留天数
        int backupFileSaveDays = backupStrategy.getClearValue();
        if (backupFileSaveDays > 0)
        {
            //备份文件路径
            File backupFileDir = new File(backupStrategy.getBackupPath());
            if (!backupFileDir.exists())
            {
                logger.info("The backup file path is not exist, the path is " + backupStrategy.getBackupPath());
                return;
            }

            //找出保留的最早的时间点，如果文件时间小于这个时间点，则删除
            long diffMillis = System.currentTimeMillis() - backupFileSaveDays * 24 * 60 * 60 * 1000L;

            //当前备份文件总大小大于配置的值，则需要删除文件
            File[] backupFiles = backupFileDir.listFiles();

            //记录删除的文件
            List<File> deleteFiles = new ArrayList<File>();

            //找出需要删除的文件
            for (File backupFile : backupFiles)
            {
                if (backupFile.lastModified() < diffMillis)
                {
                    deleteFiles.add(backupFile);
                }
            }

            //删除文件
            deleteFiles(deleteFiles);
        }
        else
        {
            logger.info("The backup file keep time is less than zero, it means no limit, no need to delete file!");
        }
    }

    /**
     * 删除多个文件
     * @param files
     */
    private void deleteFiles(List<File> files)
    {
        //删除文件
        for (File deleteFile : files)
        {
            if (deleteFile.isDirectory())
            {
                //如果是目录，则递归删除
                BackupUtils.deleteDir(deleteFile);
            }
            else
            {
                //删除文件
                deleteFile.delete();
                //删除对应的备份记录
                deleteBackupRecordByFile(deleteFile.getName());
            }
        }
    }

    /**
     * 处理微服务部署信息
     */
    public void processServiceInfo()
    {
        Map<String, String> deployNodeInfos = new HashMap<String, String>();

        List<ServiceInfo> serviceInfos = getServiceInfoFromMSB();
        for (ServiceInfo serviceInfo : serviceInfos)
        {
            List<ServiceNode> serviceNodes = serviceInfo.getNodes();

            for (ServiceNode serviceNode : serviceNodes)
            {
                String serviceNodeIp = serviceNode.getIp();
                if (deployNodeInfos.containsKey(serviceNodeIp))
                {
                    String serviceNameStr = deployNodeInfos.get(serviceNodeIp);
                    deployNodeInfos.put(serviceNodeIp, serviceNameStr + serviceInfo.getServiceName() + ";");
                }
                else
                {
                    deployNodeInfos.put(serviceNodeIp, serviceInfo.getServiceName() + ";");
                }
            }
        }
    }

    /**
     * 从msb获取服务信息
     * @return
     */
    private List<ServiceInfo> getServiceInfoFromMSB()
    {
        String msbIp = environment.getProperty("msb.address");
        String msbPort = environment.getProperty("msb.port");

        String msbUrl = "http://" + msbIp + ":" + msbPort + "/api/microservices/v1/services";
        logger.trace("processServiceInfo get service info from MSB: msbUrl = " + msbUrl);
        try
        {
            RestfulRsp response = msbAPI.getServiceInfo(msbUrl);
            int retCode = response.getStatusCode();
            if (retCode >= 200 && retCode < 300)
            {
                String respBody = response.getResponseBody();
                return JSON.parseArray(respBody, ServiceInfo.class);
            }
            else
            {
                logger.trace("processServiceInfo get service info from MSB failed, returnCode = :" + retCode);
            }
        }
        catch (Exception e)
        {
            logger.error("getServiceInfoFromMSB Exception", e);
        }
        return new ArrayList<ServiceInfo>();
    }

    /**
     * 备份日志配置
     * @param backupPathDir
     * @throws Exception 
     */
    private void backupLogConfiguration(String backupPathDir) throws Exception
    {
        try
        {
            //获取日志配置
            Properties properties = getLogConfiguration();
            //将日志配置写入文件
            PropertiesUtils.writePropertiesFile(backupPathDir + "/" + LOG_CONFIG_FILE_NAME, properties);
        }
        catch (Exception e)
        {
            logger.error("backupLogConfiguration: Backup Log Configurations Exception", e);
            throw new Exception("Backup Log Configurations Exception", e);
        }
    }

    /**
     * 获取log微服务的配置信息
     * @return
     * @throws Exception
     */
    private Properties getLogConfiguration() throws Exception
    {
        Properties properties = new Properties();

        String logBackupUriStr = environment.getProperty("backup.log.uri");
        if (StringUtils.isNotBlank(logBackupUriStr))
        {
            logger.trace("getLogConfiguration: logBackupUriStr = " + logBackupUriStr);
            String[] logBackupUriArray = StringUtils.splitByWholeSeparator(logBackupUriStr.trim(), " ");

            //遍历uri，分别获取各个url中的配置信息
            for (String logBackupUri : logBackupUriArray)
            {
                String logUri = "api/v1.0/LOG/" + logBackupUri;
                //调用log微服务的接口去获取配置信息
                logger.trace("getLogConfiguration: begin to get log configuration, logUri = " + logUri);
                RestfulRsp configuration = serviceBase.get(logUri);
                if (configuration.getStatusCode() >= 200 && configuration.getStatusCode() < 300)
                {
                    String respBody = configuration.getResponseBody();
                    logger.trace("getLogConfiguration: The log configuration from " + logUri + " is " + respBody);
                    properties.setProperty(logBackupUri, respBody);
                }
                else
                {
                    //调用接口异常
                    logger.error("getLogConfiguration: get log configuration from " + logUri
                            + " failed, error info is " + JSON.toJSONString(configuration));
                    throw new Exception("getLogConfiguration: get log configuration from " + logUri
                            + " failed, error code is " + configuration.getStatusCode());
                }
            }
        }

        return properties;
    }

    /**
     * 恢复日志配置信息
     * @param confFileMap
     * @throws Exception 
     */
    private void restoreLogConfiguration(Map<String, File> confFileMap) throws Exception
    {
        if (confFileMap.containsKey(LOG_CONFIG_FILE_NAME))
        {
            try
            {
                //日志的配置信息文件
                File logConfigFile = confFileMap.get(LOG_CONFIG_FILE_NAME);
                //将配置信息转换成properties
                Properties logConfigProperties = PropertiesUtils.readPropertiesFile(logConfigFile.getPath());
                restoreLogConfigurationRest(logConfigProperties);
            }
            catch (Exception e)
            {
                logger.error("restoreLogConfiguration Exception", e);
                throw new Exception("Restore Log Configurations Exception", e);
            }
        }
        else
        {
            logger.error("restoreLogConfiguration: The log configuration file is not in restore tar package!");
        }
    }
    
    /**
     * 恢复日志配置信息
     * @param logConfigProperties
     * @throws Exception
     */
    private void restoreLogConfigurationRest(Properties logConfigProperties) throws Exception
    {
        //遍历文件，根据配置信息去修改各个配置信息
        for (Object key : logConfigProperties.keySet())
        {
            String logConfigUri = String.valueOf(key);
            String logConfigValue = logConfigProperties.getProperty(logConfigUri);
            logger.trace("restoreLogConfigurationRest: log configuration properties [" + logConfigUri + "=" + logConfigValue);
            
            String logUri = "api/v1.0/LOG/" + logConfigUri;
            
            //调用log微服务的接口去设置配置信息
            logger.trace("restoreLogConfigurationRest: begin to get log configuration, logUri = " + logUri);
            RestfulRsp configuration = serviceBase.put(logConfigValue, logUri);
            
            if (configuration.getStatusCode() >= 200 && configuration.getStatusCode() < 300)
            {
                String respBody = configuration.getResponseBody();
                logger.trace("restoreLogConfigurationRest: Set log configuration to " + logUri + " is success, responseBody is " + respBody);
            }
            else
            {
                //调用接口异常
                logger.error("restoreLogConfigurationRest: set log configuration to " + logUri
                        + " failed, error info is " + JSON.toJSONString(configuration));
                throw new Exception("restoreLogConfigurationRest: set log configuration to " + logUri
                        + " failed, error code is " + configuration.getStatusCode());
            }
        }
    }
    
    /**
     * 
     * <p>  
     * 版权所有：中兴通讯股份有限公司   
     * </p>  
     * <p>  
     * 项目名称：Backup  
     * </p>  
     * <p>   
     * 类名称：BackupDumpStreamGobbler   
     * </p>  
     * <p>  
     * 类描述：   
     * </p>  
     * <p>  
     * 创建人：10125326王明涛 
     * </p>  
     * <p>  
     * 创建时间：2016年9月15日 上午11:17:33 
     * </p>  
     * <p>    
     * 修改人：10125326  
     * </p>  
     * <p>  
     * 修改时间：2016年9月15日 上午11:17:33  
     * </p>  
     * <p>   
     * 修改备注： 
     * </p>    
     * @version 1.0   
     *
     */
    class BackupDumpStreamGobbler extends Thread
    {
        private Logger logger = LoggerFactory.getLogger(BackupDumpStreamGobbler.class);

        /**
         * The is.
         */
        InputStream is;

        /** 
         * The type. 
         */
        String type;

        /** 
         * The name.
         */
        String name;

        /**
         * 操作类型，mysqldb，configurationfile
         */
        String operType;

        /**
         * Instantiates a new stream gobbler.
         * 
         * @param is the is
         * @param type the type
         */
        BackupDumpStreamGobbler(InputStream is, String type, String name, String operType)
        {
            this.is = is;
            this.type = type;
            this.name = name;
            this.operType = operType;
        }

        /**
         * Run.
         * 
         * @version
         */
        @Override
        public void run()
        {
            try
            {
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String line = null;
                logger.info("BackupDumpStreamGobbler: > operType > " + operType + " > name > " + name + " > " + type
                        + " > ");
                while ((line = br.readLine()) != null)
                {
                    logger.error(line);
                }
                logger.info("BackupDumpStreamGobbler end: > operType > " + operType + " > name > " + name + " > "
                        + type + " > " + line);
            }
            catch (IOException e)
            {
                logger.error("BackupDumpStreamGobbler Thread Running IOException > operType" + " > operType > "
                        + " > name > " + name + " > " + type, e);
            }
        }
    }
}
