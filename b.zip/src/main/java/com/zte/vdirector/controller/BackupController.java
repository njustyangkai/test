/**
 * 
 */
package com.zte.vdirector.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.quartz.CronTrigger;
import org.quartz.Trigger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.zte.vdirector.domain.BackupMsInfo;
import com.zte.vdirector.domain.BackupMsInfos;
import com.zte.vdirector.domain.BackupRecord;
import com.zte.vdirector.domain.BackupStrategy;
import com.zte.vdirector.domain.RestoreRecord;
import com.zte.vdirector.frame.constants.BackupConstants;
import com.zte.vdirector.frame.constants.BackupConstants.BackupMode;
import com.zte.vdirector.frame.constants.BackupConstants.BackupStatus;
import com.zte.vdirector.frame.response.CommonResponse;
import com.zte.vdirector.frame.utils.BackupUtils;
import com.zte.vdirector.frame.utils.TarUtils;
import com.zte.vdirector.scheduler.SchedulerManager;
import com.zte.vdirector.scheduler.job.BackupJob;
import com.zte.vdirector.service.BackupService;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：BackupController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326   
 * </p>  
 * <p>  
 * 创建时间：2016年7月28日 下午3:30:01 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年7月28日 下午3:30:01  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@RestController
@EnableAutoConfiguration
@RequestMapping
public class BackupController extends CommonController
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private BackupMsInfos backupMsInfos;

    @Autowired
    private SchedulerManager schedulerManager;

    @Autowired
    private BackupService backupService;

    @RequestMapping("/job/{id}")
    public String testJob(@PathVariable int id)
    {
        long startTime = System.currentTimeMillis();
        for (BackupMsInfo backupMsInfo : backupMsInfos.getBackupMsInfos())
        {
            System.out.println("##############################");
            System.out.println(backupMsInfo.getDbName());
            System.out.println(backupMsInfo.getServiceName());
            System.out.println(backupService.getMicroServiceHomeDir(backupMsInfo));
            System.out.println(backupMsInfo.getIgnoreTables().toString());
        }

        if (id == 0)
        {
            schedulerManager.removeJob(BackupConstants.DEFAULT_BACKUP_JOB_NAME);
        }
        else
        {
            schedulerManager.scheduleJob(BackupConstants.DEFAULT_BACKUP_JOB_NAME, "0/" + id + " * * * * ?",
                    BackupJob.class);
        }
        logger.info("testJob consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return "success";
    }

    /**
     * 查询job详情
     * @return
     */
    @RequestMapping("/jobs")
    public List<Map<String, String>> showJobInfo()
    {
        long startTime = System.currentTimeMillis();
        List<Map<String, String>> jobInfos = new ArrayList<Map<String, String>>();
        List<Trigger> triggers = schedulerManager.getJobTriggers();
        for (Trigger trigger : triggers)
        {
            Map<String, String> jobInfo = new HashMap<String, String>();
            jobInfo.put("Key", trigger.getKey().getName());
            jobInfo.put("Group", trigger.getKey().getGroup());
            jobInfo.put("NextFireTime", trigger.getNextFireTime().toString());
            jobInfo.put("PreviousFireTime", String.valueOf(trigger.getPreviousFireTime()));
            jobInfo.put("CronExpression", ((CronTrigger) trigger).getCronExpression());
            jobInfos.add(jobInfo);
        }
        logger.info("showJobInfo consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return jobInfos;
    }

    /**
     * 查询策略详情
     * @return
     */
    @RequestMapping("/strategy")
    public @ResponseBody CommonResponse queryStrategy(HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        BackupStrategy backupStrategy = backupService.queryBackupStrategy();
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setData(backupStrategy);
        logger.info("queryStrategy consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 修改策略
     * @param backupStrategy
     * @return
     */
    @RequestMapping(value = "/strategy", method = RequestMethod.PUT)
    public @ResponseBody CommonResponse updateStrategy(@RequestBody BackupStrategy backupStrategy, HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        String i18nKey = "backup.strategy.set";
        request.setAttribute("i18n_key", i18nKey);
        if (backupStrategy.isBackupAuto())
        {
            //获取cron表达式
            String cronExpression = BackupUtils.getCronExpression(backupStrategy);
            schedulerManager.scheduleJob(BackupConstants.DEFAULT_BACKUP_JOB_NAME, cronExpression, BackupJob.class);
        }
        super.rptOptLog(i18nKey, null, null, request, response, BackupConstants.SUCCESS_CODE_200);
        CommonResponse commonResponse = new CommonResponse();
        backupService.updateBackupStrategy(backupStrategy);
        commonResponse.setData(backupStrategy);
        logger.info("updateStrategy consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 查询备份记录列表
     * @return
     */
    @RequestMapping("/backups")
    public @ResponseBody CommonResponse queryBackupRecords(HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        List<BackupRecord> backupRecords = backupService.queryBackupRecords();
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setData(backupRecords);
        logger.info("queryBackupRecords consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 查询备份记录详情
     * @return
     */
    @RequestMapping("/backups/{id}")
    public @ResponseBody CommonResponse queryBackupRecord(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        BackupRecord backupRecord = backupService.queryBackupRecord(id);
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setData(backupRecord);
        logger.info("queryBackupRecord consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 备份
     * @return
     */
    @RequestMapping(value = "/backups", method = RequestMethod.POST)
    public @ResponseBody CommonResponse backup(HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        String i18nKey = "backup.action.manual";
        request.setAttribute("i18n_key", i18nKey);
        if (backupService.isBackupProcessing())
        {
            super.rptOptLog(i18nKey, "System is backuping!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, "System is backuping!");
        }

        if (backupService.isRestoreProcessing())
        {
            super.rptOptLog(i18nKey, "System is restoring!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, "System is restoring!");
        }

        CommonResponse commonResponse = new CommonResponse();
        //获取一条备份记录
        BackupRecord backupRecord = backupService.getBackupRecord(UUID.randomUUID().toString(), new Date(),
                BackupMode.MANUAL);

        backupRecord.setUserName(request.getHeader("operateUser"));

        //备份
        ServiceThread backupThread = new ServiceThread(1, backupRecord, null, null);
        backupThread.setName("1-" + backupRecord.getId());
        backupThread.start();
        super.rptOptLog(i18nKey, null, null, request, response, BackupConstants.SUCCESS_CODE_200);
        commonResponse.setData(backupRecord);
        logger.info("backup consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 取消备份
     */
    @SuppressWarnings("deprecation")
    @RequestMapping(value = "/backups/{id}/cancel", method = RequestMethod.DELETE)
    public @ResponseBody CommonResponse cancelBackup(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        String i18nKey = "backup.action.cancel";
        request.setAttribute("i18n_key", i18nKey);
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            Map<Thread, StackTraceElement[]> threadMap = Thread.getAllStackTraces();
            for (Thread t : threadMap.keySet())
            {
                if (StringUtils.equals(t.getName(), "1-" + id))
                {
                    t.stop();
                }
            }
            super.rptOptLog(i18nKey, id, null, request, response, BackupConstants.SUCCESS_CODE_200);
        }
        catch (Exception e)
        {
            super.rptOptLog(i18nKey, id, null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            logger.error("Cancel backup failed.", e);
        }
        logger.info("cancelBackup consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 备份记录删除
     * @return
     */
    @RequestMapping(value = "/backups/{id}", method = RequestMethod.DELETE)
    public @ResponseBody CommonResponse deleteBackupFile(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        String i18nKey = "backup.record.clear";
        request.setAttribute("i18n_key", i18nKey);
        
        BackupStrategy backupStrategy = backupService.queryBackupStrategy();
        deleteBackupRecord(id, backupStrategy.getBackupPath());
        super.rptOptLog(i18nKey, id, null, request, response, BackupConstants.SUCCESS_CODE_200);
        logger.info("deleteBackupFile consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return new CommonResponse();
    }

    /**
     * 删除备份记录
     * @param id
     * @param backupPath
     */
    private void deleteBackupRecord(String id, String backupPath)
    {
        BackupRecord backupRecord = backupService.queryBackupRecord(id);
        if (backupRecord != null)
        {
            //删除记录
            backupService.deleteBackupRecord(id, backupPath + File.separator + backupRecord.getFileName());
        }
    }

    /**
     * 备份记录批量删除
     * @return
     */
    @RequestMapping(value = "/backups/delete", method = RequestMethod.POST)
    public @ResponseBody CommonResponse deleteBackupFiles(@RequestBody String body, HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        String i18nKey = "backup.record.clear";
        request.setAttribute("i18n_key", i18nKey);
        
        List<String> ids = JSON.parseArray(body, String.class);
        if (ids != null && ids.size() > 0)
        {
            BackupStrategy backupStrategy = backupService.queryBackupStrategy();
            for (String id : ids)
            {
                deleteBackupRecord(id, backupStrategy.getBackupPath());
                super.rptOptLog(i18nKey, id, null, request, response, BackupConstants.SUCCESS_CODE_200);
            }
        }
        logger.info("deleteBackupFiles consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return new CommonResponse();
    }

    /**
     * 备份文件下载
     * @param id
     * @param response
     * @return
     */
    @RequestMapping(value = "/backups/file/{id}", method = RequestMethod.GET)
    public @ResponseBody Object backupFileDownload(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        String i18nKey = "backup.file.download";
        request.setAttribute("i18n_key", i18nKey);
        
        CommonResponse commonResponse = new CommonResponse();
        //检查备份记录是否存在
        BackupRecord backupRecord = backupService.queryBackupRecord(id);
        if (backupRecord == null)
        {
            super.rptOptLog(i18nKey, "The backup record is not exist!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            commonResponse = new CommonResponse(false, "The backup record is not exist, please check it!");
            return commonResponse;
        }

        //检查备份的文件是否存在
        BackupStrategy backupStrategy = backupService.queryBackupStrategy();
        File backupFile = new File(backupStrategy.getBackupPath(), backupRecord.getFileName());
        if (!backupFile.exists())
        {
            super.rptOptLog(i18nKey, "The backup file is not exist!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            commonResponse = new CommonResponse(false, "The backup file is not exist!");
            return commonResponse;
        }

        InputStream inputStream = null;
        OutputStream outputStream = null;
        try
        {
            inputStream = new FileInputStream(backupFile);
            int read = 0;
            byte[] bytes = new byte[4096];

            // 设置Header一定要在response.getOutputStream()前，否则不生效。
            response.setHeader("Content-Disposition", "attachment; filename=" + backupRecord.getFileName());
            outputStream = response.getOutputStream();
            while ((read = inputStream.read(bytes)) != -1)
            {
                outputStream.write(bytes, 0, read);
            }
            outputStream.flush();
            super.rptOptLog(i18nKey, backupRecord.getFileName(), null, request, response, BackupConstants.SUCCESS_CODE_200);
        }
        catch (FileNotFoundException e)
        {
            logger.error("Download backup file FileNotFoundException", e);
            commonResponse = new CommonResponse(false, e.getMessage());
            super.rptOptLog(i18nKey, backupRecord.getFileName(), null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
        }
        catch (IOException e)
        {
            logger.error("Download backup file IOException", e);
            commonResponse = new CommonResponse(false, e.getMessage());
            super.rptOptLog(i18nKey, backupRecord.getFileName(), null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
        }
        catch (Exception e)
        {
            logger.error("Download backup file Exception", e);
            commonResponse = new CommonResponse(false, e.getMessage());
            super.rptOptLog(i18nKey, backupRecord.getFileName(), null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
        }
        finally
        {
            if (inputStream != null)
            {
                try
                {
                    inputStream.close();
                }
                catch (IOException e)
                {
                    logger.error("InputStream close IOException", e);
                }
            }
            if (outputStream != null)
            {
                try
                {
                    outputStream.close();
                }
                catch (IOException e)
                {
                    logger.error("OutputStream close IOException", e);
                }
            }
        }
        logger.info("backupFileDownload consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 备份文件下载
     * @param id
     * @param response
     * @return
     */
    @RequestMapping(value = "/backups/file", method = RequestMethod.GET)
    public @ResponseBody Object backupFileBatchDownload(HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        String i18nKey = "backup.file.download.batch";
        request.setAttribute("i18n_key", i18nKey);
        
        CommonResponse commonResponse = new CommonResponse();
        String idsString = request.getParameter("ids");
        String[] ids = new String[] {};
        if (StringUtils.isNotBlank(idsString))
        {
            ids = StringUtils.split(idsString, ",");
        }
        if (ids != null && ids.length > 0)
        {
            InputStream inputStream = null;
            OutputStream outputStream = null;
            File downLoadFile = null;
            try
            {
                //查询备份策略
                BackupStrategy backupStrategy = backupService.queryBackupStrategy();
                //查询备份记录列表
                Map<String, BackupRecord> backupRecordMap = backupService.queryBackupRecordsMap();

                //备份文件
                downLoadFile = new File("batch-" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())
                        + ".tar");
                if (!downLoadFile.exists())
                {
                    downLoadFile.createNewFile();
                }

                List<File> srcFiles = new ArrayList<File>();
                for (String id : ids)
                {
                    id = id.trim();
                    if (backupRecordMap.containsKey(id))
                    {
                        BackupRecord backupRecord = backupRecordMap.get(id);
                        File backupFile = new File(backupStrategy.getBackupPath(), backupRecord.getFileName());
                        if (!backupFile.exists())
                        {
                            logger.info("The backup file of " + id + " is not exist");
                            continue;
                        }
                        srcFiles.add(backupFile);
                    }
                    else
                    {
                        logger.info("The backup record of " + id + " is not exist");
                    }
                }

                TarUtils.archive(srcFiles, downLoadFile, false);

                inputStream = new FileInputStream(downLoadFile);
                int read = 0;
                byte[] bytes = new byte[4096];

                // 设置Header一定要在response.getOutputStream()前，否则不生效。
                response.setHeader("Content-Disposition", "attachment; filename=" + downLoadFile.getName());
                outputStream = response.getOutputStream();
                while ((read = inputStream.read(bytes)) != -1)
                {
                    outputStream.write(bytes, 0, read);
                }
                outputStream.flush();
                super.rptOptLog(i18nKey, downLoadFile.getName(), null, request, response, BackupConstants.SUCCESS_CODE_200);
            }
            catch (FileNotFoundException e)
            {
                logger.error("Download backup file FileNotFoundException", e);
                commonResponse = new CommonResponse(false, e.getMessage());
                super.rptOptLog(i18nKey, null, null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            }
            catch (IOException e)
            {
                logger.error("Download backup file IOException", e);
                commonResponse = new CommonResponse(false, e.getMessage());
                super.rptOptLog(i18nKey, null, null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            }
            catch (Exception e)
            {
                logger.error("Download backup file Exception", e);
                commonResponse = new CommonResponse(false, e.getMessage());
                super.rptOptLog(i18nKey, null, null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            }
            finally
            {
                if (inputStream != null)
                {
                    try
                    {
                        inputStream.close();
                    }
                    catch (IOException e)
                    {
                        logger.error("InputStream close IOException", e);
                    }
                }
                if (outputStream != null)
                {
                    try
                    {
                        outputStream.close();
                    }
                    catch (IOException e)
                    {
                        logger.error("OutputStream close IOException", e);
                    }
                }
                if (downLoadFile.exists())
                {
                    downLoadFile.delete();
                }
            }
        }
        else
        {
            commonResponse = new CommonResponse(false, "The ids are null");
        }
        logger.info("backupFileBatchDownload consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    class ServiceThread extends Thread
    {
        private BackupRecord backupRecord;
        private RestoreRecord restoreRecord;
        private File restoreTarFile;

        /**
         *  1-备份；2-恢复
         */
        private int operateType;

        public ServiceThread(int operateType, BackupRecord backupRecord, RestoreRecord restoreRecord,
                File restoreTarFile)
        {
            this.backupRecord = backupRecord;
            this.restoreRecord = restoreRecord;
            this.restoreTarFile = restoreTarFile;
            this.operateType = operateType;
        }

        @Override
        public void run()
        {
            try
            {
                // 备份
                if (operateType == 1)
                {
                    backupService.backup(backupRecord);
                }
                else
                {
                    backupService.restore(restoreRecord, restoreTarFile);
                }
            }
            catch (Exception e)
            {
                logger.error(operateType == 1 ? "Backup Failed." : "Restore Failed.", e);
            }
        }
    }

    /**
     * 恢复
     */
    @RequestMapping(value = "/restore", method = RequestMethod.POST)
    public @ResponseBody CommonResponse restore(@RequestParam("file") MultipartFile multipartFile,
            HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        
        String i18nKey = "backup.action.restore";
        request.setAttribute("i18n_key", i18nKey);
        
        if (multipartFile == null)
        {
            super.rptOptLog(i18nKey, "Cannot read the backup file!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, "Cannot read the backup file!");
        }

        if (backupService.isBackupProcessing())
        {
            super.rptOptLog(i18nKey, "System is backuping!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, "System is backuping!");
        }

        if (backupService.isRestoreProcessing())
        {
            super.rptOptLog(i18nKey, "System is restoring!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, "System is restoring!");
        }

        CommonResponse commonResponse = new CommonResponse();

        Date restoreDate = new Date();
        BigDecimal bigDecimal = new BigDecimal(multipartFile.getSize() / 1024);
        //恢复文件大小
        double fileSize = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue();

        RestoreRecord restoreRecord = backupService.getRestoreRecord(UUID.randomUUID().toString(), restoreDate, "",
                multipartFile.getOriginalFilename(), fileSize);
        restoreRecord.setUserName(request.getHeader("operateUser"));
        backupService.addRestoreRecord(restoreRecord);

        try
        {
            File restoreTempDir = createRestoreTempDir(restoreDate);

            //将multipartFile转为tar文件
            File restoreTarFile = new File(restoreTempDir.getPath(), multipartFile.getOriginalFilename());
            BackupUtils.transferMultipartFile2File(multipartFile, restoreTarFile);
            //恢复
            ServiceThread restoreThread = new ServiceThread(2, null, restoreRecord, restoreTarFile);
            restoreThread.setName("2-" + restoreRecord.getId());
            restoreThread.start();
            commonResponse.setData(restoreRecord);
            super.rptOptLog(i18nKey, multipartFile.getOriginalFilename(), null, request, response, BackupConstants.SUCCESS_CODE_200);
        }
        catch (Exception e)
        {
            logger.error("Restore Exception", e);
            restoreRecord = backupService.getFinishRestoreRecord(restoreRecord, BackupStatus.FAIL, "Restore Failed: "
                    + e.getMessage());
            backupService.updateRestoreRecord(restoreRecord);
            commonResponse = new CommonResponse(false, "Restore Failed: " + e.getMessage());
            super.rptOptLog(i18nKey, multipartFile.getOriginalFilename(), null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
        }
        logger.info("restore consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 恢复
     */
    @RequestMapping(value = "/restore/{id}", method = RequestMethod.POST)
    public @ResponseBody CommonResponse restoreByRecordId(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        
        String i18nKey = "backup.action.restore";
        request.setAttribute("i18n_key", i18nKey);
        
        if (backupService.isBackupProcessing())
        {
            super.rptOptLog(i18nKey, "System is backuping!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, "System is backuping!");
        }

        if (backupService.isRestoreProcessing())
        {
            super.rptOptLog(i18nKey, "System is restoring!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, "System is restoring!");
        }

        CommonResponse commonResponse = new CommonResponse();

        //检查备份记录是否存在
        BackupRecord backupRecord = backupService.queryBackupRecord(id);
        if (backupRecord == null)
        {
            super.rptOptLog(i18nKey, "The backup record is not exist!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            commonResponse = new CommonResponse(false, "The backup record is not exist, please check it!");
            return commonResponse;
        }

        //检查备份的文件是否存在
        BackupStrategy backupStrategy = backupService.queryBackupStrategy();
        File backupFile = new File(backupStrategy.getBackupPath(), backupRecord.getFileName());
        if (!backupFile.exists())
        {
            super.rptOptLog(i18nKey, "The backup file is not exist!", null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
            commonResponse = new CommonResponse(false, "The backup file is not exist, couldn't restore!");
            return commonResponse;
        }

        Date restoreDate = new Date();
        RestoreRecord restoreRecord = backupService.getRestoreRecord(UUID.randomUUID().toString(), restoreDate, "",
                backupRecord.getFileName(), backupRecord.getFileSize());
        restoreRecord.setUserName(request.getHeader("operateUser"));
        backupService.addRestoreRecord(restoreRecord);
        commonResponse.setData(restoreRecord);
        try
        {
            File restoreTempDir = createRestoreTempDir(restoreDate);

            //将multipartFile转为tar文件
            File restoreTarFile = new File(restoreTempDir.getPath(), backupRecord.getFileName());
            Files.copy(Paths.get(backupFile.getPath()), Paths.get(restoreTarFile.getPath()),
                    StandardCopyOption.REPLACE_EXISTING);
            //恢复
            ServiceThread restoreThread = new ServiceThread(2, null, restoreRecord, restoreTarFile);
            restoreThread.setName("2-" + restoreRecord.getId());
            restoreThread.start();
            super.rptOptLog(i18nKey, backupRecord.getFileName(), null, request, response, BackupConstants.SUCCESS_CODE_200);
        }
        catch (Exception e)
        {
            logger.error("Restore Exception", e);
            restoreRecord = backupService.getFinishRestoreRecord(restoreRecord, BackupStatus.FAIL, "Restore Failed: "
                    + e.getMessage());
            backupService.updateRestoreRecord(restoreRecord);
            super.rptOptLog(i18nKey, backupRecord.getFileName(), null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
        }
        logger.info("restoreByRecordId consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 查询恢复详情
     */
    @RequestMapping(value = "/restore/{id}", method = RequestMethod.GET)
    public @ResponseBody CommonResponse queryRestoreRecord(@PathVariable String id)
    {
        long startTime = System.currentTimeMillis();
        
        CommonResponse commonResponse = new CommonResponse();
        RestoreRecord restoreRecord = backupService.queryRestoreRecord(id);
        commonResponse.setData(restoreRecord);
        logger.info("queryRestoreRecord consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }
    
    /**
     * 查询恢复记录列表
     */
    @RequestMapping(value = "/restore", method = RequestMethod.GET)
    public @ResponseBody CommonResponse queryRestoreRecords()
    {
        long startTime = System.currentTimeMillis();
        
        CommonResponse commonResponse = new CommonResponse();
        List<RestoreRecord> restoreRecords = backupService.queryRestoreRecords();
        commonResponse.setData(restoreRecords);
        logger.info("queryRestoreRecords consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 创建恢复的临时目录
     * @param restoreDate
     * @return
     */
    private File createRestoreTempDir(Date restoreDate)
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String restoreTempDirPath = simpleDateFormat.format(restoreDate);
        return BackupUtils.createDir(restoreTempDirPath);
    }

    /**
     * 取消恢复
     */
    @SuppressWarnings("deprecation")
    @RequestMapping(value = "/restore/{id}/cancel", method = RequestMethod.DELETE)
    public @ResponseBody CommonResponse cancelRestore(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        long startTime = System.currentTimeMillis();
        
        String i18nKey = "backup.action.restore.cancel";
        request.setAttribute("i18n_key", i18nKey);
        
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            Map<Thread, StackTraceElement[]> threadMap = Thread.getAllStackTraces();
            for (Thread t : threadMap.keySet())
            {
                if (StringUtils.equals(t.getName(), "2-" + id))
                {
                    t.stop();
                }
            }
            super.rptOptLog(i18nKey, id, null, request, response, BackupConstants.SUCCESS_CODE_200);
        }
        catch (Exception e)
        {
            logger.error("Cancel restore failed.", e);
            super.rptOptLog(i18nKey, id, null, request, response, BackupConstants.SERVER_ERROR_CODE_500);
        }
        logger.info("cancelRestore consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return commonResponse;
    }

    /**
     * 测试重启服务
     * @return
     */
    @RequestMapping(value = "/restart", method = RequestMethod.POST)
    public @ResponseBody CommonResponse restart()
    {
        long startTime = System.currentTimeMillis();
        backupService.restartMicroService();
        logger.info("restart service consume: " + (System.currentTimeMillis() - startTime) + "ms");
        return new CommonResponse();
    }
}
