/**
 * 
 */
package com.zte.vdirector.controller;

import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zte.vdirector.frame.utils.SpringUtil;
import com.zte.vdirector.logm.service.LogReporterService;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：CommonController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326   
 * </p>  
 * <p>  
 * 创建时间：2016年7月28日 下午3:30:49 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年7月28日 下午3:30:49  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class CommonController
{
    public Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    protected SpringUtil springUtil;

    @Resource
    private LogReporterService logReporterService;

    /**
     * 记录成功操作日志
     * @param summaryKey 操作KEY
     * @param additionalKey 详情KEY（可选）
     * @param args 详情中需要的参数（可选）
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @param httpStatus HTTP状态码，根据这个标准的HTTP状态标识该操作的成功与否
     */
    protected void rptOptLog(String summaryKey, String additionalKey, Object[] args, HttpServletRequest request,
            HttpServletResponse response, int httpStatus)
    {
        StringBuilder logSummary = new StringBuilder();
        StringBuilder additionalInfo = new StringBuilder();

        String summaryEN = springUtil.getMessage(summaryKey, null, Locale.US);
        String summaryCN = springUtil.getMessage(summaryKey, null, Locale.CHINA);
        logSummary.append(summaryEN).append('|').append(summaryCN);

        if (StringUtils.isNotBlank(additionalKey))
        {
//            String additionalEN = springUtil.getMessage(additionalKey, args, Locale.US);
//            String additionalCN = springUtil.getMessage(additionalKey, args, Locale.CHINA);
            additionalInfo.append(additionalKey);
        }

        // 由于记录日志的接口从HttpServletResponse中的状态判断结果，
        // 而我们系统判断操作成功与否部分微服务通过CommonResponse对象的success字段true、false实现的
        // 这里传递参数的时候，由各个子类指定状态码，记录完日志后，为保证不影响业务流程，恢复HttpServletResponse原有的状态。
        int originalStatus = response.getStatus();
        response.setStatus(httpStatus);
        logReporterService.rptOptLog(logSummary.toString(), additionalInfo.toString(), request, response);
        response.setStatus(originalStatus);
    }
}
