drop table if exists version_info;
CREATE TABLE version_info ( 
	version      varchar(200) NULL,
	sql_version    varchar(12) NOT NULL
);

insert into version_info values (null, '000000000000'); 
-- ----------------------------
-- Table structure for backup_record
-- ----------------------------
DROP TABLE IF EXISTS backup_record;
CREATE TABLE backup_record (
  id varchar(48) NOT NULL DEFAULT '',
  mode tinyint(4) DEFAULT NULL,
  status tinyint(4) DEFAULT NULL,
  progress tinyint(4) DEFAULT NULL,
  user_id varchar(48) DEFAULT NULL,
  user_name varchar(100) DEFAULT NULL,
  file_name varchar(100) DEFAULT NULL,
  file_size double DEFAULT NULL,
  start_time datetime DEFAULT NULL,
  end_time datetime DEFAULT NULL,
  detail text,
  PRIMARY KEY (id)
);

-- ----------------------------
-- Table structure for backup_strategy
-- ----------------------------
DROP TABLE IF EXISTS backup_strategy;
CREATE TABLE backup_strategy (
  backup_auto tinyint(4) DEFAULT NULL,
  backup_period tinyint(4) DEFAULT NULL,
  backup_day tinyint(4) DEFAULT NULL,
  backup_time varchar(20) DEFAULT NULL,
  backup_path varchar(1000) DEFAULT NULL,
  auto_clear_mode tinyint(4) DEFAULT NULL,
  auto_clear_value int(11) DEFAULT NULL,
  auto_clear_threshold tinyint(4) DEFAULT NULL,
  updated datetime DEFAULT NULL
);
INSERT INTO backup_strategy VALUES ('0', '3', '1', '03:00', '/home/Data/vdirector-backup', '0', '0', '0', null);

-- ----------------------------
-- Table structure for restore_record
-- ----------------------------
DROP TABLE IF EXISTS restore_record;
CREATE TABLE restore_record (
  id varchar(48) NOT NULL,
  status tinyint(4) DEFAULT NULL,
  progress tinyint(4) DEFAULT NULL,
  user_id varchar(48) DEFAULT NULL,
  user_name varchar(100) DEFAULT NULL,
  file_name varchar(100) DEFAULT NULL,
  file_size double DEFAULT NULL,
  start_time datetime DEFAULT NULL,
  end_time datetime DEFAULT NULL,
  detail text,
  PRIMARY KEY (id)
);


