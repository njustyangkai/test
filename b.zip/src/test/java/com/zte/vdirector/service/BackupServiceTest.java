/**
 * 
 */
package com.zte.vdirector.service;

//import static org.junit.Assert.assertTrue;

//import java.util.List;

import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import com.zte.vdirector.domain.user.User;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：BackupServiceTest   
 * </p>  
 * <p>  
 * 类描述： Junit测试类  
 * </p>  
 * <p>  
 * 创建人：10155603  --梁尔镇 
 * </p>  
 * <p>  
 * 创建时间：2016年7月29日 上午11:10:38 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年7月29日 上午11:10:38  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class BackupServiceTest
{
    @Test
    public void testListBackupRecord()
    {

    }

    @Test
    public void testBackup()
    {

    }

    @Test
    public void testRestore()
    {

    }

    @Test
    public void testUpdateStrategy()
    {

    }

    @Test
    public void testQueryStrategy()
    {

    }
}
