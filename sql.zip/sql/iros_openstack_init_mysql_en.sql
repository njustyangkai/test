use nova;
DELETE FROM instance_type_extra_specs;
DELETE FROM instance_types;

INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m1.small', 1, 1024, 1, 0, NULL, '1', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m1.medium', 2, 2048, 1, 0, NULL, '2', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m1.large', 3, 4096, 1, 0, NULL, '3', 1, 0, 0, 0, 1, 0);


INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('discardedXXXm2.tiny', 4, 1024, 2, 0, NULL, '4', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m2.small', 5, 2048, 2, 0, NULL, '5', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m2.medium', 6, 4096, 2, 0, NULL, '6', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('discardedXXXm2.large', 7,6144, 2, 0, NULL, '7', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m2.xlarge', 8, 8192, 2, 0, NULL, '8', 1, 0, 0, 0, 1, 0);


INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('discardedXXXm3.tiny', 9, 2048, 4, 0, NULL, '9', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m3.small', 10, 4096, 4, 0, NULL, '10', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('discardedXXXm3.medium', 11, 6144, 4, 0, NULL, '11', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m3.large', 12, 8192, 4, 0, NULL, '12', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('discardedXXXm3.xlarge', 13, 12288, 4, 0, NULL, '13', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m3.xxlarge', 14, 16384, 4, 0, NULL, '14', 1, 0, 0, 0, 1, 0);


INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('discardedXXXm4.tiny', 15, 4096, 8, 0, NULL, '15', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m4.small', 16, 6144, 8, 0, NULL, '16', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('discardedXXXm4.medium', 17, 8192, 8, 0, NULL, '17', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m4.large', 18, 12288, 8, 0, NULL, '18', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('discardedXXXm4.xlarge', 19, 16384, 8, 0, NULL, '19', 1, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('m4.xxlarge', 20, 32768, 8, 0, NULL, '20', 1, 0, 0, 0, 1, 0);

INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('VFW001', 21 , 1024, 1, 0, NULL, '21', 0, 0, 0, 0, 1, 0);
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('VFW002', 22, 2048, 2, 0, NULL, '22', 1, 0, 0, 0, 1, 0);


use neutron;
drop table if exists om_lb_vminfo;
drop table if exists nsfocus_vnidsmipmaps;
drop table if exists nsfocus_vdasmipmaps;
drop table if exists nsfocus_vwafmipmaps;
drop table if exists nsfocus_vsashmipmaps;
create table om_lb_vminfo 
( 
	pool_id        			varchar(64) 		 null,		
	vm_id        			varchar(64) 		 null,		
	vm_type        			varchar(10) 		 null,		
	port_id        			varchar(64) 		 null,	
	port_mac        		varchar(64) 		 null,	
	manage_ip        		varchar(64) 		 null,	
    primary key(vm_id)
);
create table nsfocus_vnidsmipmaps 
( 
	tenant_id        		varchar(255) 		 null,		
	vm_id        			varchar(64) 		not null,		
	port_id        			varchar(64) 		 null,		
	manage_ip        		varchar(64) 		 null,	
    primary key(vm_id)
);
create table nsfocus_vdasmipmaps 
( 
	tenant_id        		varchar(255) 		 null,		
	vm_id        			varchar(64) 		not null,		
	port_id        			varchar(64) 		 null,		
	manage_ip        		varchar(64) 		 null,	
    primary key(vm_id)
);
create table nsfocus_vwafmipmaps 
( 
	tenant_id        		varchar(255) 		 null,		
	vm_id        			varchar(64) 		not null,		
	port_id        			varchar(64) 		 null,		
	manage_ip        		varchar(64) 		 null,	
    primary key(vm_id)
);
create table nsfocus_vsashmipmaps 
( 
	tenant_id        		varchar(255) 		 null,		
	vm_id        			varchar(64) 		not null,		
	port_id        			varchar(64) 		 null,		
	manage_ip        		varchar(64) 		 null,	
    primary key(vm_id)
);