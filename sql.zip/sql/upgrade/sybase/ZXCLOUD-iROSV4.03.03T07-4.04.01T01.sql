use zxinsys
go

delete from portal_sysparam where param_name ='versionnumber'
go
insert into portal_sysparam(param_name,param_value, description) values('versionnumber', 'ZXCLOUD-iROSV4.04.01', '版本号')
go
