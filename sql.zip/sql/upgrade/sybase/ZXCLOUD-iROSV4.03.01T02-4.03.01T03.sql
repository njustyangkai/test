-- 08_relation.sql
-- 创建资源关联库
use master
go
setuser 'dbo'
go
if not exists (select 1 from master.dbo.sysdevices where name = 'irosrelation')
begin
   disk init
   name='irosrelation',
   physname='/home/sybase/data/irosrelation.dat',
   size='512M',
   dsync=false
end
go

if not exists (select 1 from master.dbo.sysdevices where name = 'irosrelation_log')
begin
   disk init
   name='irosrelation_log',
   physname='/home/sybase/data/irosrelation_log.dat',
   size='512M',
   dsync=false
end
go

if not exists (select 1 from master.dbo.sysdatabases where name = 'irosrelation')
begin
   create database irosrelation on irosrelation='512M' log on irosrelation_log='512M'
end
go

use master
go

exec sp_dboption irosrelation,'trunc log on chkpt',true
go
exec sp_dboption irosrelation,'select into/bulkcopy/pllsort',true
go

use irosrelation
go
-- 云主机与用户的关联关系表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_instance' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_instance
go

create table om_relation_instance (
	res_id				varchar(64) 	not null,	-- 云主机id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power
	extra				text			null,
	primary key (res_id)
)
go


-- 网络与用户的关联关系表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_network' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_network
go

create table om_relation_network (
	res_id				varchar(64) 	not null,	-- 网络id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power
	extra				text			null,
	primary key (res_id)
)
go

-- 子网与用户的关联关系表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_subnet' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_subnet
go

create table om_relation_subnet (
	res_id				varchar(64) 	not null,	-- 子网id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power
	extra				text			null,
	primary key (res_id)
)
go

-- 镜像与用户的关联关系表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_image' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_image
go
create table om_relation_image (
	res_id				varchar(64) 	not null,	-- 镜像id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power
	extra				text			null,
	primary key (res_id)
)
go

-- 云硬盘与用户的关联关系表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_volume' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_volume
go
create table om_relation_volume (
	res_id				varchar(64) 	not null,	-- 云硬盘id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power
	extra				text			null,
	primary key (res_id)
)
go

-- 租户信息表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_tenant' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_tenant
go
create table om_relation_tenant(
  id 					varchar(64)		not null,		-- 租户id
  name 					varchar(64)		not null,		-- 租户名称
  extra 				text,							-- 扩展信息
  description 			text,							-- 描述信息
  enabled 				int				default null,	-- 是否可用,
  dc_id					varchar(64) 	not null,		-- dc id
  dc_type				int				not null,		-- dc类型，3是vmware，4是power
  primary key (id)
)
go

-- 用户信息表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_user' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_user
go
create table om_relation_user (
  id					varchar(64) 	not null,		-- 用户id
  name 					varchar(255)	not null,		-- 用户名称
  extra 				text,							-- 扩展信息
  password 				varchar(128) 	default null,	-- 密码
  enabled 				int		 		default null,	-- 是否可用
  is_admin				int				default 0		not null,		-- 是否管理员 0表示普通用户 1表示管理员
  email					varchar(100) 	default null,	-- 邮箱
  dc_id					varchar(64) 	not null,		-- dc id
  dc_type				int				not null,		-- dc类型，3是vmware，4是power
  primary key (id)
)
go

-- 用户租户关联信息表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_assignment' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_assignment
go
create table om_relation_assignment (
  user_id					varchar(64) 	not null,		-- 用户id
  tenant_id 				varchar(64)		not null		-- 租户id
)
go

-- 配额相关
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_quota_class' and u.name = 'dbo' and o.type = 'U')
    drop table om_quota_class
go
CREATE TABLE om_quota_class (
	id						varchar(64)					not null,	-- id
	create_date				datetime					not null,	-- 创建时间
	update_date				datetime					not null,	-- 更新时间
	name					varchar(100)				not null,	-- 配额类名
	resource_id				varchar(64)					not null,	-- 配额id
	resource				varchar(100)				not null,	-- 配额名称
	resource_type			varchar(50)					null,		-- 资源所属的大类
	hard_limit				numeric						not null,	-- 上限
	deleted					numeric						not null,	-- 是否删除
	delete_date				datetime					null,		-- 删除时间
	dc_type					int							not null,	-- dc类型，3是vmware，4是power，用来标示该类型特有的配额，如果为-1，标示公共的
	primary key(id)
)
go

-- 初始化数据，根据需要补充
insert into om_quota_class (id, create_date, update_date, name, resource,resource_id, hard_limit, deleted, delete_date, resource_type, dc_type)
values('1', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '云主机(台)', 'nova_instances', 50, 0, null, '计算', -1)
go
insert into om_quota_class (id, create_date, update_date, name, resource,resource_id, hard_limit, deleted, delete_date, resource_type, dc_type)
values('2', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'CPU(核)', 'nova_cores', 50, 0, null, '计算', -1)
go
insert into om_quota_class (id, create_date, update_date, name, resource,resource_id, hard_limit, deleted, delete_date, resource_type, dc_type)
values('3', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '内存(MB)', 'nova_ram', 51200, 0, null, '计算', -1)
go
insert into om_quota_class (id, create_date, update_date, name, resource,resource_id, hard_limit, deleted, delete_date, resource_type, dc_type)
values('4', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '网络(个)', 'neutron_networks', 50, 0, null, '网络', -1)
go
insert into om_quota_class (id, create_date, update_date, name, resource,resource_id, hard_limit, deleted, delete_date, resource_type, dc_type)
values('5', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '云硬盘(个)', 'cinder_volumes', 50, 0, null, '云硬盘', 4)
go
insert into om_quota_class (id, create_date, update_date, name, resource,resource_id, hard_limit, deleted, delete_date, resource_type, dc_type)
values('6', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '云硬盘总大小(GB)', 'cinder_gigabytes', 100, 0, null, '云硬盘', 4)
go


if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_quotas' and u.name = 'dbo' and o.type = 'U')
    drop table om_quotas
go
CREATE TABLE om_quotas (
	id						varchar(64)				not null, 	-- id
	create_date				datetime				not null, 	-- 创建时间
	update_date				datetime				not null, 	-- 更新时间
	dc_id					varchar(64)				not null, 	-- dc_id
	dc_type					int						not null,	-- dc类型，3是vmware，4是power，
	tenant_id				varchar(64)				not null, 	-- 租户id
	resource_id				varchar(64)				not null,	-- 配额id
	resource				varchar(100)			not null,	-- 配额名称
	resource_type			varchar(50)				null,     	-- 资源所属的大类
	in_use					numeric					default 0	not null, 	-- 已使用
	hard_limit				numeric					not null, 	-- 上限
	PRIMARY KEY(id)
)
go

-- vmware规格信息表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'vmware_flavors' and u.name = 'dbo' and o.type = 'U')
    drop table vmware_flavors
go
create table vmware_flavors (
	name			varchar(255)		not null,
	id				varchar(64)			not null,
	memory_mb		int					not null,
	vcpus			int					not null,
	root_gb			int					default null,
	disabled		int					default 0		not null,
	is_public		int					default 0		not null,
	dc_id			varchar(64) 		not null,		-- dc id
	dc_type			int					not null,		-- dc类型,目前只是3，vmware
	deleted			int					default 0		not null,
	primary key (id)
)
go



-- 06_irosmeasure.sql
use irosmeasure
go

if exists (select 1 from  sysobjects where id = object_id('ros_ptypedef') and type = 'U')
   drop table ros_ptypedef
go

/*==============================================================*/
/* Table: ros_ptypedef                                          */
/*==============================================================*/
create table ros_ptypedef (
   res_type             varchar(100)                   not null,	-- 资源类型:nova
   poid                 varchar(20)                    not null,	-- 类型编号:1010001
   poname               varchar(128)                   not null,	-- 类型名称:CPU性能/内存性能/磁盘性能/网卡性能
   tablename            varchar(32)                    not null,	-- 对应的表名 data_vm_cpu/data_vm_mem/data_vm_disk/data_vm_nic
   bvisible             tinyint                        not null,	-- 界面是否可见:1可见/0不可见 
   isrealtime           tinyint                        not null,	-- 是否实时统计(保留字段)默认0
   extrastr             varchar(255)                   null,		-- 扩展字段:可存放json,便于扩展
   constraint PK_ROS_PTYPEDEF primary key (res_type, poid)
)
go

if exists (select 1 from  sysobjects where id = object_id('ros_pitemdef') and type = 'U')
   drop table ros_pitemdef
go

/*==============================================================*/
/* Table: ros_pitemdef                                          */
/*==============================================================*/
create table ros_pitemdef (
   dc_type              integer                        not null,
   poid                 varchar(20)                    not null,	-- 类型编号:1010001
   pitemid              integer                        not null,	-- 指标编号:1/2
   pitemname            varchar(128)                   not null,	-- 指标名称:CPU利用率/内存利用率
   pitemfield           varchar(128)                    not null,	-- 指标项:cpu_util/memory.usage
   pitemutil            varchar(32)                    not null,	-- 指标项单位:%/MB/
   datatype             tinyint                        not null,	-- 指标值数据类型:1 int/2 float
   bvisible             tinyint                        not null,	-- 界面是否可见:1可见/0不可见 
   extrastr             varchar(256)                   null,		-- 扩展字段:可存放json,便于扩展
   constraint PK_ROS_PITEMDEF primary key (poid, pitemid)
)
go

if exists (select 1 from  sysobjects where id = object_id('ros_data_lasttime') and type = 'U')
   drop table ros_data_lasttime
go
create table ros_data_lasttime (
   dc_id                varchar(100)                   not null,
   poid                 varchar(20)                    not null,
   pitemid              integer                        not null,
   lasttime             datetime                       null,
   primary key (dc_id, poid, pitemid)
)
go
-- iecs
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100821', '虚拟机CPU性能', 'data_vm_cpu', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100824', '虚拟机磁盘性能', 'data_vm_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100826', '虚拟机网卡性能', 'data_vm_nic', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100801', '物理机CPU性能', 'data_host_cpu', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100802', '物理机内存性能', 'data_host_mem', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100803', '物理机磁盘性能', 'data_host_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100806', '物理机网卡性能', 'data_host_nic', 1, 0)

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100821', 2, '虚拟机CPU使用率', '', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 2, '虚拟机磁盘读取速率', '', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 6, '虚拟机磁盘写入速率', '', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 2, '虚拟机网络出口带宽', '', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 6, '虚拟机网络入口带宽', '', 'B/s', 2, 1)

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100801', 2, '物理机CPU使用率', '', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100802', 2, '物理机内存使用情况', '', 'MB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100803', 2, '物理机磁盘已使用大小', '', 'GB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 30, '物理机端口流出速率', '', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 26, '物理机端口流入速率', '', 'B/s', 2, 1)

-- openstack
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010001', '虚拟机CPU性能', 'data_vm_cpu', 1, 0)
-- insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010002', '虚拟机内存性能', 'data_vm_mem', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010003', '虚拟机磁盘性能', 'data_vm_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010004', '虚拟机网卡性能', 'data_vm_nic', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010005', '物理机CPU性能', 'data_host_cpu', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010006', '物理机内存性能', 'data_host_mem', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010007', '物理机磁盘性能', 'data_host_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010008', '物理机网卡性能', 'data_host_nic', 1, 0)

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010001', 1, '虚拟机CPU使用率', 'cpu_util', '%', 2, 1)
-- insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010002', 1, '虚拟机内存使用情况', 'memory.usage', 'MB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 1, '虚拟机磁盘读取速率', 'disk.read.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 2, '虚拟机磁盘写入速率', 'disk.write.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 3, '虚拟机磁盘大小', 'disk.total.size', 'GB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 1, '虚拟机网络出口带宽', 'network.outgoing.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 2, '虚拟机网络入口带宽', 'network.incoming.bytes.rate', 'B/s', 2, 1)

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010005', 1, '物理机CPU使用率', 'compute.node.cpu.percent', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010006', 1, '物理机内存使用情况', 'compute.node.memory.used', 'MB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 1, '物理机磁盘读取速率', 'compute.node.disk.read.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 2, '物理机磁盘写入速率', 'compute.node.disk.write.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 3, '物理机磁盘大小', 'compute.node.disk.total', 'GB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 4, '物理机磁盘已使用大小', 'compute.node.disk.used', 'GB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 1, '物理机网络出口带宽', 'compute.node.network.outgoing.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 2, '物理机网络入口带宽', 'compute.node.network.incoming.bytes.rate', 'B/s', 2, 1)

-- vmware
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020001', '虚拟机CPU性能', 'data_vm_cpu', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020002', '虚拟机内存性能', 'data_vm_mem', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020003', '虚拟机磁盘性能', 'data_vm_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020004', '虚拟机网卡性能', 'data_vm_nic', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020005', '物理机CPU性能', 'data_host_cpu', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020006', '物理机内存性能', 'data_host_mem', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020007', '物理机磁盘性能', 'data_host_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020008', '物理机网卡性能', 'data_host_nic', 1, 0)

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020001', 1, '虚拟机CPU使用率', '2', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020002', 1, '虚拟机内存使用率', '24', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 1, '虚拟机磁盘读取', '130', 'MB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 2, '虚拟机磁盘写入', '131', 'MB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 1, '虚拟机网络出口带宽', '149', 'KB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 2, '虚拟机网络入口带宽', '148', 'KB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020005', 1, '物理机CPU使用率', '2', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020006', 1, '物理机内存使用情况', '24', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 1, '物理机磁盘读取速率', '130', 'MB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 2, '物理机磁盘写入速率', '131', 'MB', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 1, '物理机网络出口带宽', '149', 'KB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 2, '物理机网络入口带宽', '148', 'KB/s', 2, 1)
go




-- 02_iros.sql
use zxinsys
go
-- 不按ID合并菜单
update portal_sysparam set param_value = '0' where param_name = 'IsJoinMenuByID'
go

delete from oper_funcgrp2 where funcgrpid =10 and servicekey='uniportal'
delete from oper_function where funcgrpid=10 and servicekey='uniportal'
delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =10
go
exec proc_res_op_paratype 0 ,2, 105, ''		    -- 去除【日志管理】操作日志统计类型
go

exec proc_res_op_function 0, 1, 1396, 139606,'操作日志'
go
exec proc_res_op_function 0, 1, 1396, 139612,'安全日志'
go
exec proc_res_op_function 0, 1, 1396, 139613,'日志备份配置'
go


delete from portal_sysparam where param_name = 'BAK_TASK_DAY'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('BAK_TASK_DAY','1','管理数据备份天','平台系统配置','备份的天，当备份周期为日时，请输入1-7中任一数字，1代表星期一，7代表星期日，当大于7则认为周日备份；当备份周期为月，请输入1-31中任一数字,1代表1号，31代表31号',
             1,31,1,'1',1,
             '','','','','')
go


use iros
go

if exists(select 1 from sysobjects where id = object_id('t_domain'))
    drop table t_domain
go

if exists(select 1 from sysobjects where id = object_id('t_domain_operator'))
    drop table t_domain_operator
go

if exists(select 1 from sysobjects where id = object_id('t_dc_operator'))
    drop table t_dc_operator
go

if exists(select 1 from sysobjects where id = object_id('om_tenant'))
    drop table om_tenant
go

if exists(select 1 from sysobjects where id = object_id('om_tenant_admin_rel'))
    drop table om_tenant_admin_rel
go

if exists(select 1 from sysobjects where id = object_id('om_tenant_dc_rel'))
    drop table om_tenant_dc_rel
go



if not exists(select 1 from syscolumns where (syscolumns.name = 'vmware_datacenter') and (syscolumns.id IN (select id from sysobjects where name = 't_dc')) )
begin
  exec('alter table t_dc add vmware_datacenter varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'power_domainid') and (syscolumns.id IN (select id from sysobjects where name = 't_dc')) )
begin
  exec('alter table t_dc add power_domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'power_projectname') and (syscolumns.id IN (select id from sysobjects where name = 't_dc')) )
begin
  exec('alter table t_dc add power_projectname varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'power_ip') and (syscolumns.id IN (select id from sysobjects where name = 't_dc')) )
begin
  exec('alter table t_dc add power_ip varchar(64) null')
end

if exists(select 1 from syscolumns where (syscolumns.name = 'state') and (syscolumns.id IN (select id from sysobjects where name = 'om_user_info')) )
begin
  exec('sp_rename ''om_user_info.state'', ''status'', ''column''')
end

if exists(select 1 from syscolumns where (syscolumns.name = 'tree_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_base_tree')) )
begin
  exec('sp_rename ''om_base_tree.tree_id'', ''id'', ''column''')
end

if exists(select 1 from syscolumns where (syscolumns.name = 'tree_name') and (syscolumns.id IN (select id from sysobjects where name = 'om_base_tree')) )
begin
  exec('sp_rename ''om_base_tree.tree_name'', ''name'', ''column''')
end

if exists(select 1 from syscolumns where (syscolumns.name = 'tree_desc') and (syscolumns.id IN (select id from sysobjects where name = 'om_base_tree')) )
begin
  exec('sp_rename ''om_base_tree.tree_desc'', ''description'', ''column''')
end

go
