use zxinsys
go
delete from oper_virtual_grpdef where v_opergrpid=6141 and servicekey='uniportal'
go

-- 创建菜单
exec proc_res_op_function 0, 1, 1396, 139641,'应用管理'
go

-- 新增 应用管理员 角色
proc_res_op_grpscript2 0, 1, 109, '应用管理员', '应用管理员'
go

-- 给角色 应用管理员 增加权限
proc_res_op_grpdef 0, 1, 109, 1396, 139641
go

-- 创建操作员组
proc_res_op_v_grpscript 0, 1, 6141, '应用管理员组'
go

-- 给操作组赋予新的角色
proc_res_op_v_grpdef 0, 1, 6141, 109
go

-- 给初始化用户super所在的组赋予新增角色
proc_res_op_v_grpdef 0,1,1000,109
go
proc_res_op_v_grpdef 0,1,1001,109
go


use iros
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.04T03' where name = 'iROS'
go

delete from om_base_service where id = 15
go
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (15, '应用服务', 'switch_isware', '','通过iROS界面可以链接到iSWare首页，进行应用管理。',',1,2,')
go

-- 增加功能控制配置项
delete from om_control_function where id = 'isware_switch_control'
go
delete from om_control_function where id = 'isware_path'
go
insert into om_control_function values ('isware_switch_control','iSWare融合开关', '0')
go
insert into om_control_function values ('isware_path','iSWare地址', 'http://127.0.0.1:8101/uniportal/frame/login.action?directTurnToHome=false&userName=super&password=Zte@12345')
go

-- 新增历史记录表
if exists(select 1 from sysobjects where id = object_id('om_history_records'))
    drop table om_history_records
go
create table om_history_records 
( 
	dc_id						varchar(64) 	NOT NULL, 
	instance_id					varchar(100) 	NOT NULL,  
	oper_type					int 		    NOT NULL,  
	created						varchar(64) 	NULL,
	status						int     		NULL,
	detail						text 			NULL
)
go



