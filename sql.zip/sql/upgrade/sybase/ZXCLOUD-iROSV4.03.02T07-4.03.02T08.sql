use zxinsys
go

proc_res_op_grpscript2 0, 1, 102, '资源管理' 
go
proc_res_op_grpscript2 0, 1, 103, '组织管理' 
go

proc_res_op_v_grpscript 0, 1, 6102, '资源管理员组'
go
proc_res_op_v_grpscript 0, 1, 6103, '组织管理员组'
go


proc_res_op_v_grpdef 0,2,1000,101
go
proc_res_op_v_grpdef 0,2,1001,101
go

proc_res_op_v_grpdef 0, 2, 6101, 101
go

proc_res_op_v_grpscript 0, 2, 6101, '域管理员组'
go

proc_res_op_grpdef 0, 2, 101, 1,  10001
go         
proc_res_op_grpdef 0, 2, 101, 1,  10003
go         
proc_res_op_grpdef 0, 2, 101, 1,  10006 
go        
proc_res_op_grpdef 0, 2, 101, 1,  10007
go         
proc_res_op_grpdef 0, 2, 101, 3,  12001 
go        
proc_res_op_grpdef 0, 2, 101, 3,  12002 
go        
proc_res_op_grpdef 0, 2, 101, 3,  12003   
go      
proc_res_op_grpdef 0, 2, 101, 3,  12007 
go        
proc_res_op_grpdef 0, 2, 101, 3,  12008 
go        
proc_res_op_grpdef 0, 2, 101, 3,  12010 
go        
proc_res_op_grpdef 0, 2, 101, 4,  13001 
go        
proc_res_op_grpdef 0, 2, 101, 4,  13003  
go       
proc_res_op_grpdef 0, 2, 101, 4,  13005  
go         
proc_res_op_grpdef 0, 2, 101, 4,  13007  
go         
proc_res_op_grpdef 0, 2, 101, 4,  13008  
go         
proc_res_op_grpdef 0, 2, 101, 4,  13009  
go         
proc_res_op_grpdef 0, 2, 101, 4,  13011  
go         
proc_res_op_grpdef 0, 2, 101, 4,  13014  
go         
proc_res_op_grpdef 0, 2, 101, 4,  13016  
go         
proc_res_op_grpdef 0, 2, 101, 4,  13017  
go         
proc_res_op_grpdef 0, 2, 101, 4,  13020  
go         
proc_res_op_grpdef 0, 2, 101, 10, 15001  
go         
proc_res_op_grpdef 0, 2, 101, 10, 15005  
go         
proc_res_op_grpdef 0, 2, 101, 10, 15007  
go         
proc_res_op_grpdef 0, 2, 101, 11, 18005  
go         
proc_res_op_grpdef 0, 2, 101, 11, 18102  
go         
proc_res_op_grpdef 0, 2, 101, 1396, 139601  
go   

proc_res_op_grpscript2 0, 2, 101, '域管理' 
go


