use iros
go
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.04T02' where name = 'iROS'
go