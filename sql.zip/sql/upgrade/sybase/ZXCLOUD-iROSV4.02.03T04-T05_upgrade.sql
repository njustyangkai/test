use iros
go

if not exists(select 1 from sysobjects where id = object_id('om_cidr'))
begin
	exec('create table om_cidr ( 
            vdcid						varchar(100)				NULL,	-- vdcid
            cidr						varchar(100)				NOT NULL,	-- �����ַ
            vlan						varchar(10)					NULL,		-- vlan id
            PRIMARY KEY(cidr)
        )')
end
go
