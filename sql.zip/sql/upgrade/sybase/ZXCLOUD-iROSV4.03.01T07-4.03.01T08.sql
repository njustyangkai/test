use zxinsys
go
-- 隐藏左视图
update portal_sysparam set param_value = '2' where param_name = 'IS_NEED_HEADER_LEFT'
go

delete from portal_sysparam where param_name = 'idcim_switch_control'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_switch_control','0','IDCIM融合控制开关','iROS','IDCIM融合控制开关',
             4,1000,1,'0-关闭, 1-开启',1,
             '','','','','')
go
     
delete from portal_sysparam where param_name = 'idcim_restful_url'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_restful_url','http://127.0.0.1:21180','IDCIM Restful 普通请求URL','iROS','IDCIM Restful 普通请求URL',
             2,1000,0,'',1,
             '','','','','')
go