use iros
go
if exists(select 1 from sysobjects where id = object_id('vlantag_ip_rel'))
    drop table vlantag_ip_rel
go

use irosrelation
go

if exists(select 1 from syscolumns where (syscolumns.name = 'zone_id') and (syscolumns.id IN (select id from sysobjects where name = 't_vm')) )
begin
  exec('ALTER TABLE t_vm MODIFY COLUMN zone_id  varchar(100) NULL')
end
go
if exists(select 1 from syscolumns where (syscolumns.name = 'aggregate_id') and (syscolumns.id IN (select id from sysobjects where name = 't_vm')) )
begin
  exec('ALTER TABLE t_vm MODIFY COLUMN aggregate_id  varchar(100) NULL')
end
go
if exists(select 1 from syscolumns where (syscolumns.name = 'host_id') and (syscolumns.id IN (select id from sysobjects where name = 't_vm')) )
begin
  exec('ALTER TABLE t_vm MODIFY COLUMN host_id  varchar(100) NULL')
end
go

use zxinmeasure
go

if exists (select * from sysobjects where id = object_id('dbo.p_dynamic_create_table'))
    drop procedure dbo.p_dynamic_create_table
go

create procedure p_dynamic_create_table(@vname   varchar(50))
as
begin
	   declare @i int
	   declare @dd varchar(4)
	   declare @tabname varchar(50)
	   declare @sql varchar(4000)
 
	   set @i=24
	   
	   while @i>=1
	   begin
	        set @dd=right('0'+cast(@i as varchar),2)
			set @tabname=@vname+@dd
			if not exists (select 1 from  sysobjects where id=object_id(@tabname) and type='U')
			BEGIN
				set @sql='create table '+@tabname+
								 '(starttime            datetime not null,'+
								 'endtime               datetime null,'+
								 'resourcetype          varchar(255) not null,'+
								 'resourceid            varchar(200) not null,'+
								 'param1                varchar(200) null,'+
								 'param2                varchar(200) null,'+
								 'statcode1             float null)'
				execute (@sql)
				
				set @sql='create index idx_starttime_'+@tabname+' on '+@tabname+'(starttime)'
				execute (@sql)
				set @sql='create index idx_resourceid_'+@tabname+' on '+@tabname+'(resourceid)'
				execute (@sql)
				set @sql='create index idx_param1_'+@tabname+' on '+@tabname+'(param1)'
				execute (@sql)
				set @sql='create index idx_param2_'+@tabname+' on '+@tabname+'(param2)'
				execute (@sql)
			END  
	   		set @i=@i-1
	   end
end
go


delete from ros_pitemdef where poid = '100826'
go
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 30, '虚拟机网络出口带宽', '', 'KB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 26, '虚拟机网络入口带宽', '', 'KB/s', 2, 1)
go

delete from ros_ommp_rel where poid in ( '100826', '100822')
go
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100822', 2, 2072, 100722)
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100826', 30, 2072, 100726)
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100826', 26, 2072, 100727)
go
