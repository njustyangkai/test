use zxinsys
go
proc_res_op_grpdef 0, 2, 103, 3,  12001      
go     
proc_res_op_grpdef 0, 2, 103, 3,  12002      
go     
proc_res_op_grpdef 0, 2, 103, 3,  12003      
go     
proc_res_op_grpdef 0, 2, 103, 3,  12007      
go     
proc_res_op_grpdef 0, 2, 103, 3,  12008      
go     
proc_res_op_grpdef 0, 2, 103, 3,  12010      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13001      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13003      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13005      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13007      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13008      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13009      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13011      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13014      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13016      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13017      
go     
proc_res_op_grpdef 0, 2, 103, 4,  13020      
go     
proc_res_op_grpdef 0, 2, 103, 11, 18005        
go
proc_res_op_grpdef 0, 2, 103, 1396, 139604
go
use iros
go
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.03T02' where name = 'iROS'
go
if exists(select 1 from sysobjects where id = object_id('om_base_service'))
    drop table om_base_service
go
create table om_base_service
(
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64) NOT NULL,
	rel_id      varchar(500) NOT NULL,
	description  varchar(500) NULL,
	dc_type 	varchar(500) NULL,
	primary key (id)
)
go
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (1, 'VPN', 'switch_vpn', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (2, '负载均衡', 'switch_lb', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (3, '防火墙', 'switch_firewall', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (4, 'DCI', 'switch_dci', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (5, '安全组', 'switch_sg', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (6, '基础虚拟化功能', 'switch_base', '','',',1,2,3,4,5,6,7,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (7, '业务自动编排', 'switch_adt', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (8, '业务环境', 'switch_service', '7','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (9, '增量备份', 'switch_backup_add', '6','',',2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (10, '全量备份', 'switch_backup_all', '6','',',2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (11, '端口流统计', 'switch_flow', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (13, '备份', 'switch_dpmbackup', '6','',',1,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (14, '机架租赁', 'switch_rackrent', '','提供机架整体对外出租的功能，同时提供高质量带宽宽带，互联网IP的接入，方便企业的接入。',',1,2,3,4,5,6,7,')
go
use zxinalarm
go
exec proc_alm_code_new 1,1000001,'主机离线告警',1,13,1,22537
exec proc_alm_code_new 1,1000002,'虚拟机关闭告警',1,13,1,22537
exec proc_alm_code_new 1,1000003,'VMC数据库异常',1,13,1,22537
exec proc_alm_code_new 1,1000004,'存储库状态异常',1,13,1,22537
exec proc_alm_code_new 1,1000005,'存储库使用率超过阈值',1,13,1,22537
exec proc_alm_code_new 1,1000008,'虚机崩溃告警',8,13,1,22537
exec proc_alm_code_new 1,1000009,'虚机重启告警',8,13,1,22537
exec proc_alm_code_new 1,1000014,'存储库代理状态异常',1,13,1,22537
exec proc_alm_code_new 1,1000016,'存储库单元可访问异常',1,13,1,22537
exec proc_alm_code_new 1,1000017,'主机访问存储库目录异常',1,13,1,22537
exec proc_alm_code_new 1,1000018,'主机网络异常',1,13,1,22537
exec proc_alm_code_new 1,1000020,'虚拟机故障切换资源',1,13,1,22537
exec proc_alm_code_new 1,1000021,'光纤告警',1,13,1,22537
exec proc_alm_code_new 1,1000025,'日志空间超限',1,13,1,22537
exec proc_alm_code_new 1,1000026,'MCE硬件异常',1,13,1,22537
exec proc_alm_code_new 1,1000000,'VMC异常',1,13,1,22537
exec proc_alm_code_new 1,1000100,'DRS批量迁移失败', 8,13,1,22537
exec proc_alm_code_new 1,1000041,'主机磁盘异常', 1,13,1,22537
go
exec proc_alm_reason_new 1,1000001,'主机离线告警',22537 
exec proc_alm_reason_new 1,1000002,'虚拟机关闭告警',22537 
exec proc_alm_reason_new 1,1000003,'VMC数据库异常',22537 
exec proc_alm_reason_new 1,1000004,'存储库状态异常',22537 
exec proc_alm_reason_new 1,1000005,'存储库使用率超过阈值',22537 
exec proc_alm_reason_new 1,1000008,'虚机崩溃告警',22537 
exec proc_alm_reason_new 1,1000009,'虚机重启告警',22537 
exec proc_alm_reason_new 1,1000014,'存储库代理状态异常',22537 
exec proc_alm_reason_new 1,1000016,'存储库单元可访问异常',22537 
exec proc_alm_reason_new 1,1000017,'主机访问存储库目录异常',22537 
exec proc_alm_reason_new 1,1000018,'主机网络异常',22537 
exec proc_alm_reason_new 1,1000020,'虚拟机故障切换资源',22537 
exec proc_alm_reason_new 1,1000021,'光纤告警',22537 
exec proc_alm_reason_new 1,1000025,'日志空间超限',22537 
exec proc_alm_reason_new 1,1000026,'MCE硬件异常',22537 
exec proc_alm_reason_new 1,1000000,'VMC异常',22537 
exec proc_alm_reason_new 1,1000100,'DRS批量迁移失败',22537 
exec proc_alm_reason_new 1,1000041,'主机磁盘异常',22537
go
use opslog
go
if exists (select * from sysobjects where id = object_id('dbo.p_create_operlog'))
    drop procedure dbo.p_create_operlog
go
create procedure p_create_operlog
as
begin
	   declare @i int
	   declare @mmdd varchar(4)
	   declare @tabname varchar(20)
	   declare @sql varchar(1000) 
 
	   set @i=24
	   
	   while @i>=1
	   begin 
	      
			set @mmdd=right('0'+cast(@i as varchar(2)),2) 
	                
			begin 		   
	      
			set @tabname='oper_log'+@mmdd         
			set @sql='if exists(select 1 from sysobjects where name = '''+@tabname+''') '+
			           ' drop table '+@tabname
			  execute (@sql)
			  
			  set @sql='create table '+@tabname+
		             '(id					numeric				not null,'+
					 'domainid				varchar(100)		null,'+
					 'dcid					varchar(64)			null,'+
					 'orgid					varchar(64)			null,'+
					 'vdcid					varchar(64)			null,'+
	        	     'servicekey			varchar(10)			not null,'+
	        	     'code					int					not null,'+	
	        	     'taskid				varchar(50)			null,'+        	    
					 'targettype			varchar(20)			null,'+
					 'targetid				varchar(64)			null,'+
	        	     'targetname			varchar(256)			null,'+
	        	     'description			varchar(256)		null,'+
	        	     'details				text        		null,'+
	        	     'status				int					not null,'+
	        	     'starttime				datetime			not null,'+
	        	     'endtime				datetime			null,'+
	        	     'operid				varchar(64)			null,'+
	        	     'opername				varchar(64)			null,'+
					 'operip				varchar(100)		null,'+
	        	     'extra					varchar(1000)		null)'
		
			execute (@sql)
		
		       
			   set @sql='create index idx_operlog_targetid_'+@mmdd+' on '+@tabname+'(targetid, dcid)'
			   execute (@sql)
			   set @sql='create index idx_operlog_starttime_'+@mmdd+' on '+@tabname+'(starttime)'
			   execute (@sql)
			   set @sql='create index idx_operlog_endtime_'+@mmdd+' on '+@tabname+'(endtime)'
			   execute (@sql)
			end
 
	   	set @i=@i-1
	   end
end
go
