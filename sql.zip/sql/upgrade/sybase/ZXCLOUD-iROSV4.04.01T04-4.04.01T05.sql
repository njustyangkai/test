use iros
go
if exists(select 1 from sysobjects where id = object_id('iros_version_info'))
    drop table iros_version_info
go
CREATE TABLE iros_version_info ( 
	name						varchar(100) 	NOT NULL,-- 名称
	version				        varchar(200) 	NULL,-- 版本
	extra						varchar(500) 	NULL
)
go
insert into iros_version_info (name, version, extra) values('iROS', 'ZXCLOUD-iROSV4.04.01T05', '')
go
insert into iros_version_info (name, version, extra) values('OMMP', 'ZXCLOUD-OMMPV6.01.13', '')
go
