use iros
go
if exists(select 1 from sysobjects where id = object_id('om_base_service'))
    drop table om_base_service
go
create table om_base_service
(
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64) NOT NULL,
	rel_id      varchar(500) NOT NULL,
	description  varchar(500) NULL,
	dc_type 	varchar(500) NULL,
	primary key (id)
)
go

insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (1, 'VPN', 'switch_vpn', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (2, '负载均衡', 'switch_lb', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (3, '防火墙', 'switch_firewall', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (4, 'DCI', 'switch_dci', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (5, '安全组', 'switch_sg', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (6, '基础虚拟化功能', 'switch_base', '','',',1,2,3,4,5,6,7,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (7, '业务自动编排', 'switch_adt', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (8, '业务环境', 'switch_service', '7','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (9, '增量备份', 'switch_backup_add', '6','',',2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (10, '全量备份', 'switch_backup_all', '6','',',2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (11, '端口流统计', 'switch_flow', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (12, '云桌面', 'switch_irai', '6','',',1,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (13, '备份', 'switch_dpmbackup', '6','',',1,')
go

if exists(select 1 from sysobjects where id = object_id('om_ip_rel'))
    drop table om_ip_rel
go
create table om_ip_rel 
( 
	id							varchar(64) 	NOT NULL,
	internet_ip				    varchar(100) 	NULL,
    float_ip	                varchar(100) 	NULL,
    extnet_id	                varchar(100) 	NULL,
	subnet_id	                varchar(100) 	NULL,
	dc_id						varchar(100) 	NULL,
    vdc_id                      numeric		    NULL,
    tenant_id				    varchar(100) 	NULL, 	
	vm_id	                    varchar(100) 	NULL,
	extra						varchar(500) 	NULL
)
go