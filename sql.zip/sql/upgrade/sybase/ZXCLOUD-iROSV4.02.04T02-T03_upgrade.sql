use master
go

--sp_configure 'number of devices',30 
--go

--irosmeasure--
disk init name='irosmeasure',physname='/home/sybase/data/irosmeasure.dat',size='102400M',dsync=false
go
disk init name='irosmeasure_log',physname='/home/sybase/data/irosmeasure_log.dat',size='102400M',dsync=false
go
create database irosmeasure on irosmeasure = '102400M' log on irosmeasure_log='102400M'
go


dump tran irosmeasure with no_log
go
exec sp_dboption 'irosmeasure','trunc. log',true
go
exec sp_dboption 'irosmeasure', 'ddl', true
go
exec sp_dboption 'irosmeasure', 'null', false
go
exec sp_dboption 'irosmeasure', 'select into', true
checkpoint
go 



use irosmeasure
go

if not exists(select 1 from sysobjects where id = object_id('ros_ptypedef'))
begin
	exec('create table ros_ptypedef (
	   res_type             varchar(100)                   not null,	-- ��Դ����:nova
	   poid                 varchar(20)                    not null,	-- ���ͱ��:1010001
	   poname               varchar(128)                   not null,	-- ��������:CPU����/�ڴ�����/��������/��������
	   tablename            varchar(32)                    not null,	-- ��Ӧ�ı��� data_vm_cpu/data_vm_mem/data_vm_disk/data_vm_nic
	   bvisible             tinyint                        not null,	-- �����Ƿ�ɼ�:1�ɼ�/0���ɼ� 
	   isrealtime           tinyint                        not null,	-- �Ƿ�ʵʱͳ��(�����ֶ�)Ĭ��0
	   extrastr             varchar(255)                   null,		-- ��չ�ֶ�:�ɴ��json,������չ
	   constraint PK_ROS_PTYPEDEF primary key (res_type, poid)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('ros_pitemdef'))
begin
	exec('create table ros_pitemdef (
	   poid                 varchar(20)                    not null,	-- ���ͱ��:1010001
	   pitemid              integer                        not null,	-- ָ����:1/2
	   pitemname            varchar(128)                   not null,	-- ָ������:CPU������/�ڴ�������
	   pitemfield           varchar(128)                    not null,	-- ָ����:cpu_util/memory.usage
	   pitemutil            varchar(32)                    not null,	-- ָ���λ:%/MB/
	   datatype             tinyint                        not null,	-- ָ��ֵ��������:1 int/2 float
	   bvisible             tinyint                        not null,	-- �����Ƿ�ɼ�:1�ɼ�/0���ɼ� 
	   lasttime             datetime                       null,		-- ���һ�θ���ʱ��
	   extrastr             varchar(256)                   null,		-- ��չ�ֶ�:�ɴ��json,������չ
	   constraint PK_ROS_PITEMDEF primary key (poid, pitemid)
	)')
end
go


if exists (select * from sysobjects where id = object_id('dbo.p_create_table'))
    drop procedure dbo.p_create_table
go

create procedure p_create_table(@vname   varchar(50))
as
begin
	/**
	*  create   measure(24) table  
	*  E.g exec p_create_view 'data_vm_cpu' 
	*  
	* @param  @vname  table name
	* @author lb 
	* @create date 2014-12
	* @mod date 
	*/        
	   declare @i int
	   declare @dd varchar(4)
	   declare @tabname varchar(20)
	   declare @sql varchar(3000)
 
	   set @i=24
	   
	   while @i>=1
	   begin
	     
	      
	        set @dd=right('0'+cast(@i as varchar),2)
	      	  
		 
			set @tabname=@vname+@dd
			set @sql='if exists(select 1 from sysobjects where name = '''+@tabname+''') '+
			' drop table '+@tabname
			execute (@sql)
			  
			set @sql='create table '+@tabname+
		                     '(time            datetime not null,'+
						     'res_type         varchar(100) null,'+
							 'dc_id            varchar(100) null,'+
						     'res_id           varchar(100) not null,'+
						     'moc_id           varchar(100) null,'+
							 'pitemid          integer null,'+
							 'usage_value      float null)'
		
						     
			execute (@sql)
			  
			
			set @sql='create index idx_time_'+@tabname+' on '+@tabname+'(time)'
			execute (@sql)
			set @sql='create index idx_res_id_'+@tabname+' on '+@tabname+'(res_id)'
			execute (@sql)	
			set @sql='create index idx_moc_id_'+@tabname+' on '+@tabname+'(moc_id)'
			execute (@sql)				
			  
	   		set @i=@i-1
	   end
end
go
------create table end ------
 

------------init data start -------
exec p_create_table 'data_vm_cpu' 
exec p_create_table 'data_vm_mem' 
exec p_create_table 'data_vm_disk' 
exec p_create_table 'data_vm_nic' 
exec p_create_table 'data_host_cpu' 
exec p_create_table 'data_host_mem' 
exec p_create_table 'data_host_disk' 
exec p_create_table 'data_host_nic' 
go

insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010001', '�����CPU����', 'data_vm_cpu', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010002', '������ڴ�����', 'data_vm_mem', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010003', '�������������', 'data_vm_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010004', '�������������', 'data_vm_nic', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010005', '������CPU����', 'data_host_cpu', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010006', '�������ڴ�����', 'data_host_mem', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010007', '��������������', 'data_host_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010008', '��������������', 'data_host_nic', 1, 0)
go

insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010001', 1, '�����CPUʹ����', 'cpu_util', '%', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010002', 1, '������ڴ�ʹ�����', 'memory.usage', 'MB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 1, '��������̶�ȡ����', 'disk.read.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 2, '���������д������', 'disk.write.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 3, '��������̴�С', 'disk.total.size', 'GB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010004', 1, '�����������ڴ���', 'network.outgoing.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010004', 2, '�����������ڴ���', 'network.incoming.bytes.rate', 'B/s', 2, 1)

insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010005', 1, '������CPUʹ����', 'compute.node.cpu.percent', '%', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010006', 1, '�������ڴ�ʹ�����', 'compute.node.memory.used', 'MB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 1, '���������̶�ȡ����', 'compute.node.disk.read.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 2, '����������д������', 'compute.node.disk.write.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 3, '���������̴�С', 'compute.node.disk.total', 'GB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 4, '������������ʹ�ô�С', 'compute.node.disk.used', 'GB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010008', 1, '������������ڴ���', 'compute.node.network.outgoing.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010008', 2, '������������ڴ���', 'compute.node.network.incoming.bytes.rate', 'B/s', 2, 1)
go


use zxinsys
go

exec proc_res_op_function 0, 1, 1396, 139611,'����ͳ��'
go
delete from portal_sysparam where param_name = 'volume_upper_limit'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('volume_upper_limit','500','��Ӳ�̴�С����(GB)','iROS','��Ӳ�̴�С����(GB)',
             2,100,0,' ',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'iros_management_address'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_management_address','127.0.0.1','iROS��������ַ','iROS','iROS��������ַ,�澯SNMP������ַ,�·���opencos',
             2,100,1,' ',1,
             '','','','','')
go


-- �����µĽ�ɫ��
-- proc_res_op_grpscript2 ��ƷID���޸ı�ʶ(add-1,del-2)����ɫ��ʶ����ɫ����
proc_res_op_grpscript2 0, 1, 201, '����Ա��ɫ' 
go
proc_res_op_grpscript2 0, 1, 202, '����Ա��ɫ' 
go
proc_res_op_grpscript2 0, 1, 203, 'ά��Ա��ɫ' 
go
proc_res_op_grpscript2 0, 1, 204, '���Ա��ɫ' 
go
proc_res_op_grpscript2 0, 1, 205, '�Զ����ɫ' 
go


--�������ӵĽ�ɫ������Ӧ��Ȩ�ޣ�
--����Ա��ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 201, 1,  10001
go         
proc_res_op_grpdef 0, 1, 201, 1,  10003
go         
proc_res_op_grpdef 0, 1, 201, 1,  10006 
go        
proc_res_op_grpdef 0, 1, 201, 1,  10007
go         
proc_res_op_grpdef 0, 1, 201, 3,  12001 
go        
proc_res_op_grpdef 0, 1, 201, 3,  12002 
go        
proc_res_op_grpdef 0, 1, 201, 3,  12003   
go      
proc_res_op_grpdef 0, 1, 201, 3,  12007 
go        
proc_res_op_grpdef 0, 1, 201, 3,  12008 
go        
proc_res_op_grpdef 0, 1, 201, 3,  12010 
go        
proc_res_op_grpdef 0, 1, 201, 4,  13001 
go        
proc_res_op_grpdef 0, 1, 201, 4,  13003  
go       
proc_res_op_grpdef 0, 1, 201, 4,  13005  
go         
proc_res_op_grpdef 0, 1, 201, 4,  13007  
go         
proc_res_op_grpdef 0, 1, 201, 4,  13008  
go         
proc_res_op_grpdef 0, 1, 201, 4,  13009  
go         
proc_res_op_grpdef 0, 1, 201, 4,  13011  
go         
proc_res_op_grpdef 0, 1, 201, 4,  13014  
go         
proc_res_op_grpdef 0, 1, 201, 4,  13016  
go         
proc_res_op_grpdef 0, 1, 201, 4,  13017  
go         
proc_res_op_grpdef 0, 1, 201, 4,  13020  
go         
proc_res_op_grpdef 0, 1, 201, 10, 15001  
go         
proc_res_op_grpdef 0, 1, 201, 10, 15005  
go         
proc_res_op_grpdef 0, 1, 201, 10, 15007  
go         
proc_res_op_grpdef 0, 1, 201, 11, 18005  
go         
proc_res_op_grpdef 0, 1, 201, 11, 18102  
go         
proc_res_op_grpdef 0, 1, 201, 1396, 139601  
go   
proc_res_op_grpdef 0, 1, 201, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139603  
go   
proc_res_op_grpdef 0, 1, 201, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139605  
go   
proc_res_op_grpdef 0, 1, 201, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139607  
go   
proc_res_op_grpdef 0, 1, 201, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139609  
go   
proc_res_op_grpdef 0, 1, 201, 1396, 139610     
go

--����Ա��ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 202, 1,  10001
go         
proc_res_op_grpdef 0, 1, 202, 1,  10003
go         
proc_res_op_grpdef 0, 1, 202, 1,  10006 
go        
proc_res_op_grpdef 0, 1, 202, 1,  10007
go         
proc_res_op_grpdef 0, 1, 202, 3,  12001 
go        
proc_res_op_grpdef 0, 1, 202, 3,  12002 
go        
proc_res_op_grpdef 0, 1, 202, 3,  12003   
go      
proc_res_op_grpdef 0, 1, 202, 3,  12007 
go        
proc_res_op_grpdef 0, 1, 202, 3,  12008 
go        
proc_res_op_grpdef 0, 1, 202, 3,  12010 
go        
proc_res_op_grpdef 0, 1, 202, 4,  13001 
go        
proc_res_op_grpdef 0, 1, 202, 4,  13003  
go       
proc_res_op_grpdef 0, 1, 202, 4,  13005  
go         
proc_res_op_grpdef 0, 1, 202, 4,  13007  
go         
proc_res_op_grpdef 0, 1, 202, 4,  13008  
go         
proc_res_op_grpdef 0, 1, 202, 4,  13009  
go         
proc_res_op_grpdef 0, 1, 202, 4,  13011  
go         
proc_res_op_grpdef 0, 1, 202, 4,  13014  
go         
proc_res_op_grpdef 0, 1, 202, 4,  13016  
go         
proc_res_op_grpdef 0, 1, 202, 4,  13017  
go         
proc_res_op_grpdef 0, 1, 202, 4,  13020  
go         
proc_res_op_grpdef 0, 1, 202, 10, 15001  
go         
proc_res_op_grpdef 0, 1, 202, 10, 15005  
go         
proc_res_op_grpdef 0, 1, 202, 10, 15007  
go         
proc_res_op_grpdef 0, 1, 202, 11, 18005  
go         
proc_res_op_grpdef 0, 1, 202, 11, 18102  
go         
proc_res_op_grpdef 0, 1, 202, 1396, 139601  
go   
proc_res_op_grpdef 0, 1, 202, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139603  
go   
proc_res_op_grpdef 0, 1, 202, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139605  
go   
proc_res_op_grpdef 0, 1, 202, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139607  
go   
proc_res_op_grpdef 0, 1, 202, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139609  
go   
proc_res_op_grpdef 0, 1, 202, 1396, 139610     
go

--ά��Ա��ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 203, 1,  10001
go         
proc_res_op_grpdef 0, 1, 203, 1,  10003
go         
proc_res_op_grpdef 0, 1, 203, 1,  10006 
go        
proc_res_op_grpdef 0, 1, 203, 1,  10007
go         
proc_res_op_grpdef 0, 1, 203, 3,  12001 
go        
proc_res_op_grpdef 0, 1, 203, 3,  12002 
go        
proc_res_op_grpdef 0, 1, 203, 3,  12003   
go      
proc_res_op_grpdef 0, 1, 203, 3,  12007 
go        
proc_res_op_grpdef 0, 1, 203, 3,  12008 
go        
proc_res_op_grpdef 0, 1, 203, 3,  12010 
go        
proc_res_op_grpdef 0, 1, 203, 4,  13001 
go        
proc_res_op_grpdef 0, 1, 203, 4,  13003  
go       
proc_res_op_grpdef 0, 1, 203, 4,  13005  
go         
proc_res_op_grpdef 0, 1, 203, 4,  13007  
go         
proc_res_op_grpdef 0, 1, 203, 4,  13008  
go         
proc_res_op_grpdef 0, 1, 203, 4,  13009  
go         
proc_res_op_grpdef 0, 1, 203, 4,  13011  
go         
proc_res_op_grpdef 0, 1, 203, 4,  13014  
go         
proc_res_op_grpdef 0, 1, 203, 4,  13016  
go         
proc_res_op_grpdef 0, 1, 203, 4,  13017  
go         
proc_res_op_grpdef 0, 1, 203, 4,  13020  
go         
proc_res_op_grpdef 0, 1, 203, 10, 15001  
go         
proc_res_op_grpdef 0, 1, 203, 10, 15005  
go         
proc_res_op_grpdef 0, 1, 203, 10, 15007  
go         
proc_res_op_grpdef 0, 1, 203, 11, 18005  
go         
proc_res_op_grpdef 0, 1, 203, 11, 18102  
go         

--���Ա��ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 204, 1,  10001
go         
proc_res_op_grpdef 0, 1, 204, 1,  10003
go         
proc_res_op_grpdef 0, 1, 204, 1,  10006 
go        
proc_res_op_grpdef 0, 1, 204, 1,  10007
go         
proc_res_op_grpdef 0, 1, 204, 3,  12001 
go        
proc_res_op_grpdef 0, 1, 204, 3,  12002 
go        
proc_res_op_grpdef 0, 1, 204, 3,  12003   
go      
proc_res_op_grpdef 0, 1, 204, 3,  12007 
go        
proc_res_op_grpdef 0, 1, 204, 3,  12008 
go        
proc_res_op_grpdef 0, 1, 204, 3,  12010 
go        
proc_res_op_grpdef 0, 1, 204, 4,  13001 
go        
proc_res_op_grpdef 0, 1, 204, 4,  13003  
go       
proc_res_op_grpdef 0, 1, 204, 4,  13005  
go         
proc_res_op_grpdef 0, 1, 204, 4,  13007  
go         
proc_res_op_grpdef 0, 1, 204, 4,  13008  
go         
proc_res_op_grpdef 0, 1, 204, 4,  13009  
go         
proc_res_op_grpdef 0, 1, 204, 4,  13011  
go         
proc_res_op_grpdef 0, 1, 204, 4,  13014  
go         
proc_res_op_grpdef 0, 1, 204, 4,  13016  
go         
proc_res_op_grpdef 0, 1, 204, 4,  13017  
go         
proc_res_op_grpdef 0, 1, 204, 4,  13020  
go         
proc_res_op_grpdef 0, 1, 204, 10, 15001  
go         
proc_res_op_grpdef 0, 1, 204, 10, 15005  
go         
proc_res_op_grpdef 0, 1, 204, 10, 15007  
go         
proc_res_op_grpdef 0, 1, 204, 11, 18005  
go         
proc_res_op_grpdef 0, 1, 204, 11, 18102  
go         
proc_res_op_grpdef 0, 1, 204, 1396, 139601  
go   
proc_res_op_grpdef 0, 1, 204, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139603  
go   
proc_res_op_grpdef 0, 1, 204, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139605  
go   
proc_res_op_grpdef 0, 1, 204, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139607  
go   
proc_res_op_grpdef 0, 1, 204, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139609  
go   
proc_res_op_grpdef 0, 1, 204, 1396, 139610     
go

--�Զ����ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 205, 1,  10001
go         
proc_res_op_grpdef 0, 1, 205, 1,  10003
go         
proc_res_op_grpdef 0, 1, 205, 1,  10006 
go        
proc_res_op_grpdef 0, 1, 205, 1,  10007
go         
proc_res_op_grpdef 0, 1, 205, 3,  12001 
go        
proc_res_op_grpdef 0, 1, 205, 3,  12002 
go        
proc_res_op_grpdef 0, 1, 205, 3,  12003   
go      
proc_res_op_grpdef 0, 1, 205, 3,  12007 
go        
proc_res_op_grpdef 0, 1, 205, 3,  12008 
go        
proc_res_op_grpdef 0, 1, 205, 3,  12010 
go        
proc_res_op_grpdef 0, 1, 205, 4,  13001 
go        
proc_res_op_grpdef 0, 1, 205, 4,  13003  
go       
proc_res_op_grpdef 0, 1, 205, 4,  13005  
go         
proc_res_op_grpdef 0, 1, 205, 4,  13007  
go         
proc_res_op_grpdef 0, 1, 205, 4,  13008  
go         
proc_res_op_grpdef 0, 1, 205, 4,  13009  
go         
proc_res_op_grpdef 0, 1, 205, 4,  13011  
go         
proc_res_op_grpdef 0, 1, 205, 4,  13014  
go         
proc_res_op_grpdef 0, 1, 205, 4,  13016  
go         
proc_res_op_grpdef 0, 1, 205, 4,  13017  
go         
proc_res_op_grpdef 0, 1, 205, 4,  13020  
go         
proc_res_op_grpdef 0, 1, 205, 10, 15001  
go         
proc_res_op_grpdef 0, 1, 205, 10, 15005  
go         
proc_res_op_grpdef 0, 1, 205, 10, 15007  
go         
proc_res_op_grpdef 0, 1, 205, 11, 18005  
go         
proc_res_op_grpdef 0, 1, 205, 11, 18102  
go         
proc_res_op_grpdef 0, 1, 205, 1396, 139601  
go   
proc_res_op_grpdef 0, 1, 205, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139603  
go   
proc_res_op_grpdef 0, 1, 205, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139605  
go   
proc_res_op_grpdef 0, 1, 205, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139607  
go   
proc_res_op_grpdef 0, 1, 205, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139609  
go   
proc_res_op_grpdef 0, 1, 205, 1396, 139610     
go

if exists (select * from sysobjects where id = object_id('proc_rcs_updateRole'))
     
     update portal_sysparam set param_value='1'  where param_name='RCS'

     exec proc_rcs_updateRolego
go

use iros
go
--��opencos֪ͨ iROS snmp������Ϣ
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.2.0','opencos_snmpTrapCommunity')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.3.0','opencos_snmpTrapVersion')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.2.1.3','opencos_trapIpaddressPort')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.4.2.1.1','heartbeatNotification')
go
