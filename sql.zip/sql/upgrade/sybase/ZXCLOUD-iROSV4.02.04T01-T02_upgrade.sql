use zxinsys
go

delete from zxinsys..portal_sysparam where param_name ='versionnumber'
go
insert into zxinsys..portal_sysparam(param_name,param_value, description) values('versionnumber', 'ZXCLOUD-iROSV4.02.04', '�汾��')
go

exec proc_res_op_function 0, 1, 1396, 139609,'ʵʱ�澯'
go
exec proc_res_op_function 0, 1, 1396, 139610,'��ʷ�澯'
go

--OMMP���������־�� 3961~3970 
exec proc_res_op_paratype 0, 1, 3961, '�ƹ���'
go

delete from oper_funcgrp2 where funcgrpid = 4
insert into oper_funcgrp2 values (4, '4', 'Ȩ�޹���', 'uniportal', 0)

delete from oper_function where funcdescription in ('����Ա����','��ɫ��Ϣ','����Ϣ','��ȫ�ȼ�','��ȫ��������','����Ա��Ϣ�༭','��ɫ��Ϣ�༭','����Ϣ�༭','��ȫ�ȼ��༭','��ȫ�������ñ༭','����ɾ����Դ')
insert into oper_function values (4, 13001, '1301' , '����Ա����'  ,       0, 'uniportal')
insert into oper_function values (4, 13003, '1303' , '��ɫ��Ϣ'    ,       0, 'uniportal')
insert into oper_function values (4, 13005, '1305' , '����Ϣ'      ,       0, 'uniportal')
insert into oper_function values (4, 13007, '1307' , '��ȫ�ȼ�'     ,      0, 'uniportal')
insert into oper_function values (4, 13008, '1308' , '��ȫ��������'  ,      0, 'uniportal') 
insert into oper_function values (4, 13009, '1309' , '����Ա��Ϣ�༭'  ,      0, 'uniportal')
insert into oper_function values (4, 13011, '1311' , '��ɫ��Ϣ�༭'  ,      0, 'uniportal')
insert into oper_function values (4, 13014, '1314' , '����Ϣ�༭'  ,       0, 'uniportal') 
insert into oper_function values (4, 13016, '1316' , '��ȫ�ȼ��༭'  ,       0, 'uniportal') 
insert into oper_function values (4, 13017, '1317' , '��ȫ�������ñ༭'  ,       0, 'uniportal')
insert into oper_function values (4, 13020, '1320' , '����ɾ����Դ'  ,       0, 'uniportal') 
go

delete from oper_grpdef where funcgrpid=4 and opergrpid=1000  and servicekey='uniportal'
insert into oper_grpdef select 1000,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4 
delete from oper_grpdef where funcgrpid=4 and opergrpid=1001  and servicekey='uniportal'
insert into oper_grpdef select 1001,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4 
go



use iros
go

if not exists(select 1 from sysobjects where id = object_id('alarming'))
begin
	exec('create table alarming(
		globalid      	numeric(10,0)    not   null,              -- ȫ�ֱ�ʶ���澯ģ�����ɣ�ȫ��Ψһ 
		localid         varchar(100)     not   null,              -- �ֲ���ʶ���澯Դ����
		objid           varchar(200)     null,                    -- �澯�����ʶ  ȫ�ָ澯 objid objtype objname Ϊ��
		objtype         varchar(200)     null,                    -- �澯��������
		objname         varchar(200)     null,                    -- �澯��������
		sourceid        varchar(200)     not   null,              -- �澯Դ��ʶ
		sourcetype      varchar(200)     not   null,              -- �澯Դ����	
		sourcename      varchar(200)     not   null,              -- �澯Դ����	
		code		    varchar(100) 	 not   null,              -- �澯��
		almlevel	    int			     not   null,              -- �澯����
		content         varchar(1500)    null,                    -- ������Ϣ
		createtime		varchar(100)     not   null,              -- �澯����ʱ��
		cleartime	    varchar(100)     null,                    -- �澯�ָ�ʱ��
		cleartype	    int	             null,                    -- �澯�ָ���ʽ��1-�����ָ�,2-�ֹ��ָ�,3-�Զ��ָ� RCS�澯δ��
		objip     	    varchar(200)     null,                    -- �澯����ip	RCS�澯δ��
		confirmtime     varchar(100)     null,                    -- ȷ��ʱ��RCS�澯δ��
		confirmuser     varchar(200)     null,                    -- ȷ���û�RCS�澯δ��
		confirmtype     int		         null,                    -- ȷ��״̬��(0-δȷ�� 1-��ȷ��)RCS�澯δ��
		confirminfo     varchar(200)     null,                    -- ȷ����ϢRCS�澯δ��
		keeptime         int             null,                    -- ����ʱ��,��λ����RCS�澯δ��	
		constraint PK_ALARM primary key (globalid)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('alarm_his'))
begin
	exec('create table alarm_his(
		globalid      	numeric(10,0)    not   null,              -- ȫ�ֱ�ʶ���澯ģ�����ɣ�ȫ��Ψһ 
		localid         varchar(100)     not   null,              -- �ֲ���ʶ���澯Դ����
		objid           varchar(200)     null,                    -- �澯�����ʶ  ȫ�ָ澯 objid objtype objname Ϊ��
		objtype         varchar(200)     null,                    -- �澯��������
		objname         varchar(200)     null,                    -- �澯��������
		sourceid        varchar(200)     not   null,              -- �澯Դ��ʶ
		sourcetype      varchar(200)     not   null,              -- �澯Դ����	
		sourcename      varchar(200)     not   null,              -- �澯Դ����	
		code		    varchar(100) 	 not   null,              -- �澯��
		almlevel	    int			     not   null,              -- �澯����
		content         varchar(1500)    null,                    -- ������Ϣ
		createtime		varchar(100)     not   null,              -- �澯����ʱ��
		cleartime	    varchar(100)     null,                    -- �澯�ָ�ʱ��
		cleartype	    int	             null,                    -- �澯�ָ���ʽ��1-�����ָ�,2-�ֹ��ָ�,3-�Զ��ָ� RCS�澯δ��
		objip     	    varchar(200)     null,                    -- �澯����ip	RCS�澯δ��
		confirmtime     varchar(100)     null,                    -- ȷ��ʱ��RCS�澯δ��
		confirmuser     varchar(200)     null,                    -- ȷ���û�RCS�澯δ��
		confirmtype     int		         null,                    -- ȷ��״̬��(0-δȷ�� 1-��ȷ��)RCS�澯δ��
		confirminfo     varchar(200)     null,                    -- ȷ����ϢRCS�澯δ��
		keeptime         int             null,                    -- ����ʱ��,��λ����RCS�澯δ��	
		constraint PK_ALARM_HIS primary key (globalid)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('alarm_code'))
begin
	exec('create table alarm_code(  
		code              varchar(100)            not    null,      -- �澯/֪ͨ��
		description       varchar(254)            not    null,      -- ����
		almlevel          int                     not    null,      -- ����(1-�����澯,2-��Ҫ�澯,3-��Ҫ�澯,4-����澯,8-һ��֪ͨ,9-��Ҫ֪ͨ)
		isshow            int                     not    null,      -- �Ƿ���ʾ(1-��ʾ,0-����ʾ,)
		solution		   varchar(400)           null,             -- ��������
	   constraint PK_ALARM_CODE primary key (code)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('alarm_config'))
begin
	exec('create table alarm_config( 
		name          varchar(100)                   not null,     
		value         varchar(100)                   not null,      
		constraint PK_ALARM_CONFIG primary key (name)
	)')
end
go

insert into alarm_config(name, value) values('alarm_globalid', '1') --�澯ȫ�����к�
go
insert into alarm_config(name, value) values('realalarm_maxcount', '1000')--�����������澯
go
insert into alarm_code(code, description, almlevel, isshow) values('46112', '������񲻿���',1,1)
go
insert into alarm_code(code, description, almlevel, isshow) values('46114', '�����ڴ����',1,1)
go
insert into alarm_code(code, description, almlevel, isshow) values('46176', '�����״̬�쳣',4,1)
go

-- alarmoid
if exists(select 1 from sysobjects where id = object_id('alarm_oid'))
    drop table alarm_oid
go
create table alarm_oid( 
    name            varchar(100)                   not null,     
    oid             varchar(100)                   not null,      
    constraint PK_ALARM_OID primary key (name)
)
go

insert into alarm_oid(oid, name) values('1.3.6.1.6.3.1.1.4.1.0','alarmType')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.1','alarmReport')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.2','alarmRestore')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.3','alarmEventTime')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.2','sendNotificationId')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.4','lastSendNotificationId')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.3','systemDN')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.11','alarmCode')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.2','alarmManagedObjectInstance')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.4','alarmEventType')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.5','alarmProbableCause')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.6','alarmPerceivedSeverity')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.7','alarmSpecificProblem')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.8','alarmAdditionalText')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.12','alarmNetype')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.9','alarmIndex')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.1','alarmId')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.14','alarmCodeName')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.15','alarmManagedObjectInstanceName')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.16','alarmSystemType')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.17','alarmNeIP')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.18','alarmACK')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.19','cleiCode')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.20','timeZoneID')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.21','timeZoneOffset')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.22','dSTSaving')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.23','aid')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.24','id')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.26','alarmMocObjectInstatance')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.10','alarmComment')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.25','alarmOtherInfo')
go


use opslog
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log01')) )
begin
  exec('alter table oper_log01 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log02')) )
begin
  exec('alter table oper_log02 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log03')) )
begin
  exec('alter table oper_log03 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log04')) )
begin
  exec('alter table oper_log04 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log05')) )
begin
  exec('alter table oper_log05 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log06')) )
begin
  exec('alter table oper_log06 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log07')) )
begin
  exec('alter table oper_log07 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log08')) )
begin
  exec('alter table oper_log08 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log09')) )
begin
  exec('alter table oper_log09 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log10')) )
begin
  exec('alter table oper_log10 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log11')) )
begin
  exec('alter table oper_log11 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log12')) )
begin
  exec('alter table oper_log12 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log13')) )
begin
  exec('alter table oper_log13 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log14')) )
begin
  exec('alter table oper_log14 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log15')) )
begin
  exec('alter table oper_log15 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log16')) )
begin
  exec('alter table oper_log16 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log17')) )
begin
  exec('alter table oper_log17 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log18')) )
begin
  exec('alter table oper_log18 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log19')) )
begin
  exec('alter table oper_log19 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log20')) )
begin
  exec('alter table oper_log20 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log21')) )
begin
  exec('alter table oper_log21 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log22')) )
begin
  exec('alter table oper_log22 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log23')) )
begin
  exec('alter table oper_log23 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log24')) )
begin
  exec('alter table oper_log24 add domainid varchar(100) null')
end
go
