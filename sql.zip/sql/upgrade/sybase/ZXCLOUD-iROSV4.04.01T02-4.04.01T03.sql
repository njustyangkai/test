use iros
go

update om_order_process set description='适用于云主机、云桌面、防火墙、负载均衡资源的申请审批流程' where process_id=2
go

delete from om_res_order_process_rel where res_type = 5 and process_id = 2
go
insert into om_res_order_process_rel (res_type, process_id) values(5, 2)
go

-- 增加物理设备
if exists (select 1 from sysobjects where id = object_id('sp_web_add_phymachineinfo'))
   drop procedure sp_web_add_phymachineinfo
go
create procedure sp_web_add_phymachineinfo
(
  @v_i_entid            varchar(100), 
  @v_i_devicemospecid   varchar(100), 
  --@v_i_areaid           varchar(200), 
  @v_i_fixedassetnum    varchar(200),
  @v_i_systemnum        varchar(200), 
  @v_i_productmnum      varchar(200), 
  @v_i_purchasedate     date,        
  @v_i_assurancetime    int,          
  @v_i_assurancedesc    varchar(200), 
  @v_i_location         varchar(200), 
  @v_i_locationdesc     varchar(50) , 
  @v_i_upframenum       varchar(50) , 
  @v_i_roundframenum    varchar(50) , 
  @v_i_slotnum          varchar(50) , 
  @v_i_ipmiip           varchar(100), 
  @v_i_ipmiuser         varchar(50) , 
  @v_i_ipmipwd          varchar(50) , 
  @v_i_status           int         , 
  @v_i_operid           varchar(50) ,   
  @v_i_entname          varchar(200),           
  @v_i_ommpid           varchar(200)     
)  
as
  declare  @v_entid               varchar(100)
  declare  @v_devicemospecid      varchar(100)
  declare  @v_opertime            date
  declare  @v_deviceid            varchar(200)  
  declare  @v_devicename          varchar(200)   
  declare  @v_phstatus            int          
begin  
  select  @v_entid = ltrim(rtrim(@v_i_entid))	
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_opertime = getdate()
  select  @v_phstatus = 7
  

  select @v_deviceid = deviceid from om_device_info where devicemospecid = @v_i_devicemospecid
  if @@rowcount = 0
  begin
    select 3001
    return
  end 
  select @v_devicename = dataname from common_dict_item where dataid = @v_deviceid
  if @@rowcount = 0
  begin
    select 3006
    return
  end 
   
  if exists(select 1 from om_phydevice_info where entid = @v_entid)
  begin
    select 3001
    return
  end  

  if exists(select 1 from om_phydevice_info where entname = @v_i_entname and status <>9)
  begin
    select 3001
    return
  end

  if exists(select 1 from om_phydevice_info where fixedassetnum = @v_i_fixedassetnum and status <>9)
  begin
    select 3003
    return
  end

  if exists(select 1 from om_phydevice_info where systemnum = @v_i_systemnum and status <>9)
  begin
    select 3004
    return
  end
  
    if exists(select 1 from om_phydevice_info where productmnum = @v_i_productmnum and status <>9)
  begin
    select 3005
    return
  end

  begin tran
  	insert into om_phydevice_info (entid, entname,devicemospecid ,deviceid ,fixedassetnum ,systemnum ,productmnum ,purchasedate ,
                       assurancetime ,assurancedesc ,location ,locationdesc ,upframenum ,roundframenum ,
                      slotnum ,ipmiip ,ipmiuser ,ipmipwd ,status ,phstatus ,operid , opertime)
  	       values(@v_entid ,@v_i_entname,@v_devicemospecid,@v_deviceid, @v_i_fixedassetnum ,@v_i_systemnum ,@v_i_productmnum,@v_i_purchasedate, 
                  @v_i_assurancetime ,@v_i_assurancedesc  ,@v_i_location ,@v_i_locationdesc ,@v_i_upframenum ,@v_i_roundframenum ,
                  @v_i_slotnum ,@v_i_ipmiip ,@v_i_ipmiuser ,@v_i_ipmipwd ,@v_i_status, @v_phstatus ,@v_i_operid,@v_opertime)
    if @@error<>0
    begin
      rollback tran
      select 1001
      return
    end
    
  commit tran

  begin
  	update om_device_info set specidnum = specidnum + 1  where devicemospecid = @v_devicemospecid
  	if @@error<>0
	  begin
	    select 1001
	    return
	  end	 	
  end	 

  select  1
  return
end
go