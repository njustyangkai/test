use zxinsys
go

delete from portal_sysparam where param_name ='versionnumber'
go
insert into portal_sysparam(param_name,param_value, description) values('versionnumber', 'ZXCLOUD-iROSV4.03.03', '版本号')
go

delete from portal_sysparam where param_name = 'log_collect_upper_limit'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('log_collect_upper_limit','300','日志一键收集文件个数上限(个)','iROS','日志一键收集文件个数上限(个)',
             2,300,0,' ',1,
             '','','','','')
go
			 
exec proc_res_op_function 0, 1, 1396, 139624,'日志收集'
go

exec proc_add_res_definition 'PH_DEVICE', 'iROS物理设备', 'ROOT', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_iros_phdevice', '', null
go

exec proc_add_res_definition 'PH_MACHINE', '物理机', 'PH_COMPANY', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_phmachine', '', null
go


use iros
go
delete from om_order_process where process_id =2
go
insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(2, '云资源申请审批流程', '适用于云主机、防火墙、负载均衡资源的申请审批流程', 2, 0, 0)
go

delete from om_res_order_process_rel
go
insert into om_res_order_process_rel (res_type, process_id) values(1, 2)
insert into om_res_order_process_rel (res_type, process_id) values(3, 2)
insert into om_res_order_process_rel (res_type, process_id) values(4, 2)
go


if exists(select 1 from sysobjects where name = 'om_server' and type = 'U')
begin
  exec('sp_rename om_server, om_order_res_rel')
end

if exists(select 1 from sysobjects where name = 'om_order_res_rel' and type = 'U')
	if not exists(select 1 from syscolumns where (syscolumns.name = 'res_type') and (syscolumns.id IN (select id from sysobjects where name = 'om_order_res_rel')) )
	begin
		exec('alter table om_order_res_rel add res_type tinyint default 1 not null')
	end


delete from om_base_service
go
insert into om_base_service values (1, 'VPN', 'switch_vpn', '6')
insert into om_base_service values (2, '负载均衡', 'switch_lb', '6')
insert into om_base_service values (3, '防火墙', 'switch_firewall', '6')
insert into om_base_service values (4, 'DCI', 'switch_dci', '6')
insert into om_base_service values (5, '安全组', 'switch_sg', '6')
insert into om_base_service values (6, '基础虚拟化功能', 'switch_base', '')
insert into om_base_service values (7, '业务自动编排', 'switch_adt', '6')
insert into om_base_service values (8, '业务环境', 'switch_service', '6,7')
insert into om_base_service values (9, '增量备份', 'switch_backup_add', '6')
insert into om_base_service values (10, '全量备份', 'switch_backup_all', '6')
insert into om_base_service values (11, '端口流统计', 'switch_flow', '6')
go

delete from common_dict_item where dataid in ('800105', '800106', '800107')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800105','Windows2003','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800106','Windows2008','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800107','Windows2012','7','os-1')
go

delete from ent_iros_phdevice
go
insert into ent_iros_phdevice (entid,entname,entrid,parentrid,parententid) values ('101','iROS物理设备','PH_DEVICE','ROOT','ROOT')
go
