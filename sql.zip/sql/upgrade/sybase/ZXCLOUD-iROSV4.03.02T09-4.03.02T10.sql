use iros
go

delete from os_name_config where os_id in ('36', '37', '38', '39', '40', '41')
go
insert into os_name_config(os_id, os_type, os_name) values('36','Windows','Microsoft Windows 8(32)')
go
insert into os_name_config(os_id, os_type, os_name) values('37','Windows','Microsoft Windows 8(64)')
go
insert into os_name_config(os_id, os_type, os_name) values('38','Windows','Microsoft Windows Server 2012,Essentials Edition(64)')
go
insert into os_name_config(os_id, os_type, os_name) values('39','Windows','Microsoft Windows Server 2012,Datacenter Edition(64)')
go
insert into os_name_config(os_id, os_type, os_name) values('40','Windows','Microsoft Windows Server 2012,Standard Edition(64)')
go
insert into os_name_config(os_id, os_type, os_name) values('41','Windows','Microsoft Windows Server 2012,Foundation Edition(64)')
go

if exists(select 1 from sysobjects where id = object_id('om_a10_vlantag'))
    drop table om_a10_vlantag
go
CREATE TABLE om_a10_vlantag (
    vlan_tag                int        				not null,
	status   	            tinyint    default 0 	not null,
	a10_vm_uuid          	varchar(64)				not null,
	network_id              varchar(64)        		null,
	a10_port_id             varchar(64)        		null,  
	vnetid           		varchar(64)      		null,    
    vip_list             	text                	null,
    primary key (vlan_tag) 
)
go

IF EXISTS (SELECT id FROM sysobjects WHERE type='P' AND name='p_insert_vlantag')
DROP PROCEDURE p_insert_vlantag

go
CREATE PROCEDURE p_insert_vlantag
        @vmUuid VARCHAR(50)
AS
BEGIN
DECLARE 
        @i INTEGER,        --循环变量
        @sql  VARCHAR(16300),
        @vsql  VARCHAR(16300),
        @dsql  VARCHAR(200)
SELECT @i = 4094
WHILE @i>= 0 
BEGIN 
IF (@i%235 = 0)
BEGIN
SELECT @vsql = @sql 
EXECUTE (@vsql)
SELECT @sql=''
END
SELECT @sql = @sql + 'insert into om_a10_vlantag (vlan_tag,a10_vm_uuid) values (' + cast( @i as varchar) + ','''+@vmUuid+''')'
SELECT @i = @i - 1
END
SELECT @dsql = 'delete from om_a10_vlantag where vlan_tag = 1'
EXECUTE (@dsql)
END

go

if exists(select 1 from sysobjects where id = object_id('om_a10_dvsport'))
    drop table om_a10_dvsport
go
CREATE TABLE om_a10_dvsport (
	a10_vm_uuid			   varchar(64)      null,
    device_id              varchar(64)      null,
	port_id   	           varchar(64)    	null
)
go


if exists(select 1 from sysobjects where id = object_id('om_a10_tenant'))
    drop table om_a10_tenant
go
CREATE TABLE om_a10_tenant (
    tenant_id              varchar(64)      null,
	dc_id   	           varchar(64)    	null,
	a10_vm_uuid			   varchar(64)      null
)
go

if not exists(select 1 from syscolumns where (syscolumns.name = 'status') and (syscolumns.id IN (select id from sysobjects where name = 'om_ade_instance')) )
begin
  exec('alter table om_ade_instance add status tinyint null')
  exec('update om_ade_instance set status = 1')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'update_time') and (syscolumns.id IN (select id from sysobjects where name = 'om_ade_instance')) )
begin
  exec('alter table om_ade_instance add update_time datetime null')
end
