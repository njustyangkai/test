use zxinsys
go

delete from zxinsys..portal_sysparam where param_name ='versionnumber'
go
insert into zxinsys..portal_sysparam(param_name,param_value, description) values('versionnumber', 'ZXCLOUD-iROSV4.03.02', '版本号')
go

use iros
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'extra') and (syscolumns.id IN (select id from sysobjects where name = 'om_service_config')) )
begin
  exec('alter table om_service_config add extra text null')
end


if not exists(select 1 from sysobjects where id = object_id('om_dci'))
begin
	exec('create table om_dci
	(
	   dci_id        	int NOT NULL,
		dci_name        varchar(255) NOT NULL,
		vdc_id        	int NOT NULL,	
		export_rt       varchar(100)  NOT NULL,
		import_rt       varchar(100)  NOT NULL,
		rd              varchar(100)  NOT NULL,
		vni        	    varchar(100)  NOT NULL,
		primary key (dci_id)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('om_dci_sub'))
begin
	exec('create table om_dci_sub
	(
	   dci_id        	int NOT NULL,	
		dc_id         	varchar(100)  NOT NULL,
		tenant_id       varchar(100)  NOT NULL,
		net_id        	varchar(100)  NOT NULL,	
		sub_id        	varchar(100)  NOT NULL,
        sub_ipmask      varchar(100)  NOT NULL			
	)')
end
go

if exists(select 1 from sysobjects where id = object_id('om_base_service'))
    drop table om_base_service
go
create table om_base_service
(
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64) NOT NULL,
	rel_id      varchar(500) NOT NULL,
	primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_service_directory'))
    drop table om_service_directory
go
create table om_service_directory
(
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64)  NULL,
	dc_id      varchar(100) NOT NULL,
	template_id  int  NULL,
	vdc_id   	numeric  NULL,
	type        tinyint NOT NULL,
	parent_id      int  NULL,
	is_use        tinyint NOT NULL,
	is_publish      tinyint NOT NULL,
	extra        text  NULL,
	primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_service_rel'))
    drop table om_service_rel
go
create table om_service_rel
(
	id        	int NOT NULL,
	rel_id      int NOT NULL,
	dc_id  varchar(100) NOT NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_ade_template'))
    drop table om_ade_template
go
create table om_ade_template
(
	id                     int         not null,   
   name                   varchar(100)         not null,  
   type                   tinyint         not null,  
   description                   text         null,       
   status                 tinyint    default 0 not null,   
   dc_id	              varchar(100)         not null,   
   tenant_id              varchar(100)         not null,   
   delete_flag			  tinyint    default 0 not null,   
   creator_id             numeric         		NOT NULL,       
   create_time            datetime             null,      
   delete_time            datetime             null,       
   update_time            datetime             null,      
   extra				  text         null,      
   primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_ade_instance'))
    drop table om_ade_instance
go
create table om_ade_instance
(
	id								int 	NOT NULL,  
	name							varchar(100) 	NOT NULL,  
    description							text 	NULL,		
	vdc_id							numeric	NOT NULL,  
	dc_id							varchar(100)	NULL,  
	template_id						varchar(100)	NOT NULL,  
	stack_id						varchar(100)	NULL,  
	delete_flag			  			tinyint    default 0 not null,  
	create_time            			datetime        NOT NULL,  
	delete_time            			datetime        null,       
	creator_id						numeric	NOT NULL,  
	extra							text	NULL,   
    PRIMARY KEY(id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_ade_traffic_steering'))
    drop table om_ade_traffic_steering
go
create table om_ade_traffic_steering
(
	instance_id						int 	NOT NULL,  
	classfier						varchar(100) 	NOT NULL,  
	portChain						varchar(100) 	NOT NULL  
)
go

if exists(select 1 from sysobjects where id = object_id('vlantag_ip_rel'))
    drop table vlantag_ip_rel
go
CREATE TABLE vlantag_ip_rel ( 
	id					varchar(64) 	NOT NULL,   -- ID
	vlantag     int not NULL, -- vlan Tag
	ip       	  varchar(50) NULL,
	isused       	tinyint not NULL, -- 标志，0-未使用 1-已使用
	dc_id					varchar(100) 	NOT NULL,
	network_id    varchar(100) 	NULL,
	PRIMARY KEY(id)
)
go

delete from alarm_oid where name ='currentAlarmTable'
go
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3','currentAlarmTable')
go

use zxinsys
go
update portal_sysparam set param_value = '0' where param_name = 'compute_threshold'
go

delete from portal_sysparam where param_name = 'idcim_switch_control'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_switch_control','0','IDCIM融合控制开关','iROS','IDCIM融合控制开关',
             4,1000,1,'0-关闭, 1-开启',1,
             '','','','','')
go
     
delete from portal_sysparam where param_name = 'idcim_restful_url'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_restful_url','http://127.0.0.1:21180','IDCIM Restful 普通请求URL','iROS','IDCIM Restful 普通请求URL',
             2,1000,0,'',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'ade_path'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('ade_path','','ADE接口地址','iROS','ADE接口地址',
             2,1000,0,'',1,
             '','','','','')
go

proc_res_op_grpdef 0, 1, 102, 1396, 139615
go
proc_res_op_grpdef 0, 1, 104, 1396, 139616
go

exec proc_res_op_function 0, 2, 1396, 139615,'模板管理'
go
exec proc_res_op_function 0, 2, 1396, 139616,'实例化管理'
go

use iros
go

--iROS使用OMMP告警模型后，清理不用的表
if(exists(select 1 from sysobjects where name='alarming'))
  drop table alarming
go

if(exists(select 1 from sysobjects where name='alarm_his'))
  drop table alarm_his
go

if(exists(select 1 from sysobjects where name='alarm_code'))
  drop table alarm_code
go

if(exists(select 1 from sysobjects where name='alarm_config'))
  drop table alarm_config
go

use zxinalarm
go

--清理不用的告警码
exec proc_alm_code_new 2,10001,'nova-cert服务异常',1,13,1,22537
exec proc_alm_code_new 2,10002,'nova-consoleauth服务异常',1,13,1,22537
exec proc_alm_code_new 2,10003,'nova-scheduler服务异常',1,13,1,22537
exec proc_alm_code_new 2,10004,'nova-conductor服务异常',1,13,1,22537
exec proc_alm_code_new 2,10005,'nova-compute服务异常',1,13,1,22537
go
exec proc_alm_code_new 2,20001,'neutron-loadbalancer-agent代理服务异常',1,13,1,22537
exec proc_alm_code_new 2,20002,'neutron-openvswitch-agent代理服务异常',1,13,1,22537
exec proc_alm_code_new 2,20003,'neutron-dhcp-agent代理服务异常',1,13,1,22537
exec proc_alm_code_new 2,20004,'neutron-l3-agent代理服务异常',1,13,1,22537
exec proc_alm_code_new 2,20005,'neutron-dhcp-agent代理服务异常',1,13,1,22537
go
exec proc_alm_code_new 2,30001,'cinder-scheduler服务异常',1,13,1,22537
exec proc_alm_code_new 2,30002,'cinder-volume服务异常',1,13,1,22537
exec proc_alm_code_new 2,30003,'cinder-backup服务异常',1,13,1,22537
go

--清理不用的告警原因
exec proc_alm_reason_new 2,10001,'nova-cert服务异常',22537
exec proc_alm_reason_new 2,10002,'nova-consoleauth服务异常',22537
exec proc_alm_reason_new 2,10003,'nova-scheduler服务异常',22537
exec proc_alm_reason_new 2,10004,'nova-conductor服务异常',22537
exec proc_alm_reason_new 2,10005,'nova-compute服务异常',22537
go
exec proc_alm_reason_new 2,20001,'neutron-loadbalancer-agent代理服务异常',22537
exec proc_alm_reason_new 2,20002,'neutron-openvswitch-agent代理服务异常',22537
exec proc_alm_reason_new 2,20003,'neutron-dhcp-agent代理服务异常',22537
exec proc_alm_reason_new 2,20004,'neutron-l3-agent代理服务异常',22537
go
exec proc_alm_reason_new 2,30001,'cinder-scheduler服务异常',22537
exec proc_alm_reason_new 2,30002,'cinder-volume服务异常',22537
exec proc_alm_reason_new 2,30003,'cinder-backup服务异常',22537
go

--因为此次升级涉及到服务目录功能的增加，所以升级之后，请将管理端系统中已经存在dc，操作一次编辑，不需要改任务数据，点击确定即可。后台会自动去生成相应的服务目录数据
--另外，升级之后，租户的所有功能将包装成服务，默认第一次生成是未发布不显示状态，如需改成发布状态，请在资源管理，点击dc节点，右侧服务目录Tab页里，将需要发布的服务发布出去