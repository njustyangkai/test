use zxinsys
go

exec proc_res_op_function 0, 1, 1396, 139606,'��־����'
go
exec proc_res_op_function 0, 1, 1396, 139607,'���ݹ���'
go
exec proc_res_op_function 0, 1, 1396, 139608,'�澯��ַ����'
go

delete from portal_sysparam where param_name = 'remote_syn_user'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_syn_user','','4Aͬ���û���Ϣ���õ�ַ','iROS','4Aͬ���û���Ϣ���õ�ַ',
             2,100,0,' ',1,
             '','','','','')
go
delete from portal_sysparam where param_name = 'iros_backup_shell_path'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_backup_shell_path','/home/iros/db_bak','����shell�ű�����·��','iROS','����shell�ű�����·��',
             2,100,0,'/home/iros/db_bak',1,
             '','','','','')
go

use iros
go

--RCS �澯iROS snmp ת����ַ
if(exists(select 1 from sysobjects where name='alarm_snmp_address'))
  drop table alarm_snmp_address
go
create table alarm_snmp_address (
   name             varchar(200)    not null,   
   port              int            not null,   
   ip               varchar(50)     not null,   
   community        varchar(200)    not null,
   type             varchar(50)     not null,      --south ���� north ����
   constraint PK_ALARM_SNMP_ADDRESS primary key (name)
)
go
