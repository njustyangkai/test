use iros
go
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.02T01' where name = 'iROS'
go

use zxinsys
go

delete from portal_sysparam where param_name = 'is_support_irai_desktop'
go
delete from portal_sysparam where param_name ='versionnumber'
go
insert into portal_sysparam(param_name,param_value, paramgroup,description) values('versionnumber', 'OMMPV6.01.13','平台系统配置', '版本信息')
go

