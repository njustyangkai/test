use zxinalarm
go
ALTER TABLE alarming MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm01 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm02 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm03 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm04 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm05 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm06 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm07 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm08 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm09 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm10 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm11 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE alarm12 MODIFY COLUMN reserve1 varchar(255)
go

ALTER TABLE inform01 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform02 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform03 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform04 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform05 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform06 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform07 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform08 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform09 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform10 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform11 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE inform12 MODIFY COLUMN reserve1 varchar(255)
go

ALTER TABLE impinform01 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform02 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform03 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform04 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform05 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform06 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform07 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform08 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform09 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform10 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform11 MODIFY COLUMN reserve1 varchar(255)
ALTER TABLE impinform12 MODIFY COLUMN reserve1 varchar(255)
go

use zxinsys
go

proc_res_op_grpdef 0, 1, 105, 11, 18102
go

exec proc_res_op_function 0, 1, 1396, 139629,'服务监控'
go

exec proc_res_op_function 0, 1, 1396, 139630,'租期统计'
go

exec zxinsys..proc_add_res_definition 'PH_DEVICE', 'iROS 物理设备', 'ROOT', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_iros_phdevice', '', null
exec zxinsys..proc_add_res_definition 'IROS_VDC', '租户', 'PH_DEVICE', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_iros_irosvdc', '', null
exec zxinsys..proc_add_res_definition 'PH_COMPANY', '厂商', 'IROS_VDC', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_phcompany', '', null
exec zxinsys..proc_add_res_definition 'PH_MACHINE', '物理机', 'PH_COMPANY', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_phmachine', '', null
go

exec proc_res_op_funcgrp2 0, 1, 1, '性能统计'
go
exec proc_res_op_function 0, 1, 1, 10001,'数据查询'
go
exec proc_res_op_function 0, 1, 1, 10003,'数据分析'
go
exec proc_res_op_function 0, 1, 1, 10006,'门限告警阀值设置'
go
exec proc_res_op_function 0, 1, 1, 10007,'数据保存配置'
go

delete from portal_sysparam where param_name = 'download_image_default_path'
go
delete from portal_sysparam where param_name = 'uSmartOS_restful_url'
go
delete from portal_sysparam where param_name = 'corePoolSize'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('corePoolSize','100','核心池大小','iROS','核心池大小',
             2,1000,0,'',0,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'keepAliveTime'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('keepAliveTime','3','空闲线程保留时长','iROS','空闲线程保留时长，单位：秒',
             2,100,0,'',0,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'keepMonths'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('keepMonths','6','性能数据保留时长','iROS','性能数据保留时长，单位：月',
             2,100,0,'',1,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'maximumPoolSize'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('maximumPoolSize','200','线程池最大线程数','iROS','线程池最大线程数',
             2,100,0,'',0,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'workQueueSize'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('workQueueSize','200','工作队列最大线程数','iROS','工作队列最大线程数',
             2,100,0,'',0,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'bandwidthUtilizationKeepMonths'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('bandwidthUtilizationKeepMonths','6','带宽利用率统计数据保留时长','iROS','带宽利用率统计数据保留时长，单位：月',
             2,100,0,'',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'iros_overdue_res_email_tip_days'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_overdue_res_email_tip_days','7','资源超期提醒提前天数','iROS','资源超期提醒提前天数，单位：天',
             2,100,0,'',1,
             '','','','','')
go
             
delete from portal_sysparam where param_name = 'iros_overdue_res_close'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('iros_overdue_res_close', '0', '资源超期后是否关闭资源', 'iROS', '资源超期后是否关闭资源', 
			4, null, null, '1-关闭, 0-不关闭', 1, 
			'', '', '', '', '')
go


use iros
go

if not exists(select 1 from syscolumns where (syscolumns.name = 'deliver_time') and (syscolumns.id IN (select id from sysobjects where name = 'om_service_rel')) )
begin
  exec('alter table om_order_res_rel add deliver_time datetime null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'expire_time') and (syscolumns.id IN (select id from sysobjects where name = 'om_service_rel')) )
begin
  exec('alter table om_order_res_rel add expire_time datetime null')
end


if exists(select 1 from sysobjects where id = object_id('om_instance_backup'))
    drop table om_instance_backup
go
CREATE TABLE om_instance_backup (
    id                              int  identity,
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
    parent_id						int     NULL,
	instance_uuid				    varchar(255)	NOT NULL,
	instance_name				    varchar(255)	NULL,
	backup_type 				    tinyint	NOT NULL, 
	root_disk_file			  		varchar(255) NULL, 
	data_disk_file            		varchar(1000) NULL,
	memory_file            		    varchar(255) NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
	description						text  		NULL,
	related_id						int(11)     NULL,
	current		 				    tinyint	 	NULL, 
    PRIMARY KEY(id)
)with identity_gap=1
go

if exists(select 1 from sysobjects where id = object_id('om_backup_task'))
    drop table om_backup_task
go
CREATE TABLE om_backup_task (   
	id                              int  identity,
	backup_id						int 	NOT NULL,
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
	instance_uuid				    varchar(255)   NOT NULL,
	instance_name				    varchar(255)   NULL,
    backup_type 				    tinyint	NOT NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
	process						    int NOT NULL, 
	sync	        			    tinyint	NOT NULL, 
	extra							text	NULL,
	PRIMARY KEY(id,backup_id)
)with identity_gap=1
go

if exists(select 1 from sysobjects where id = object_id('om_net_vdc_rel'))
	drop table om_net_vdc_rel
go
create table om_net_vdc_rel
(
	networkid varchar(100) not null,
	vdcid numeric not null,
	dcid varchar(100) not null,
	projectid varchar(100) not null
)
go

use zxinmeasure
go

drop table if exists ros_port_info
go
create table ros_port_info (
  resource_id varchar(128) NOT NULL,
  tenant_id varchar(64) NOT NULL,
  port_id varchar(64) NOT NULL,
  mac varchar(64) NOT NULL,
  bandwidth int NOT NULL
)
go

drop table if exists ros_bandwidth_utilization
go
create table ros_bandwidth_utilization (
  dc_id VARCHAR (64) NOT NULL,
  resource_id varchar(128) NOT NULL,
  tenant_id varchar(64) NOT NULL,
  mac varchar(64) NOT NULL,
  starttime varchar(64) NOT NULL,
  utilization float NOT NULL
)
go


