﻿use master
go

--sp_configure 'number of devices',30 
--go

--irosmeasure--
disk init name='irosmeasure',physname='/home/sybase/data/irosmeasure.dat',size='102400M',dsync=false
go
disk init name='irosmeasure_log',physname='/home/sybase/data/irosmeasure_log.dat',size='102400M',dsync=false
go
create database irosmeasure on irosmeasure = '102400M' log on irosmeasure_log='102400M'
go


dump tran irosmeasure with no_log
go
exec sp_dboption 'irosmeasure','trunc. log',true
go
exec sp_dboption 'irosmeasure', 'ddl', true
go
exec sp_dboption 'irosmeasure', 'null', false
go
exec sp_dboption 'irosmeasure', 'select into', true
checkpoint
go 

use master
go
dump transaction irosmeasure with no_log
go
exec sp_dboption 'irosmeasure','trunc. log',true
go
exec sp_dboption 'irosmeasure', 'ddl', true
go
exec sp_dboption 'irosmeasure', 'null', false
go
checkpoint
go
exec sp_dboption 'irosmeasure', 'select into', true
go

use irosmeasure
go
checkpoint
go


use irosmeasure
go

if exists (select 1 from  sysobjects where id = object_id('ros_ptypedef') and type = 'U')
   drop table ros_ptypedef
go

/*==============================================================*/
/* Table: ros_ptypedef                                          */
/*==============================================================*/
create table ros_ptypedef (
   res_type             varchar(100)                   not null,	-- 资源类型:nova
   poid                 varchar(20)                    not null,	-- 类型编号:1010001
   poname               varchar(128)                   not null,	-- 类型名称:CPU性能/内存性能/磁盘性能/网卡性能
   tablename            varchar(32)                    not null,	-- 对应的表名 data_vm_cpu/data_vm_mem/data_vm_disk/data_vm_nic
   bvisible             tinyint                        not null,	-- 界面是否可见:1可见/0不可见 
   isrealtime           tinyint                        not null,	-- 是否实时统计(保留字段)默认0
   extrastr             varchar(255)                   null,		-- 扩展字段:可存放json,便于扩展
   constraint PK_ROS_PTYPEDEF primary key (res_type, poid)
)
go

if exists (select 1 from  sysobjects where id = object_id('ros_pitemdef') and type = 'U')
   drop table ros_pitemdef
go

/*==============================================================*/
/* Table: ros_pitemdef                                          */
/*==============================================================*/
create table ros_pitemdef (
   poid                 varchar(20)                    not null,	-- 类型编号:1010001
   pitemid              integer                        not null,	-- 指标编号:1/2
   pitemname            varchar(128)                   not null,	-- 指标名称:CPU利用率/内存利用率
   pitemfield           varchar(128)                    not null,	-- 指标项:cpu_util/memory.usage
   pitemutil            varchar(32)                    not null,	-- 指标项单位:%/MB/
   datatype             tinyint                        not null,	-- 指标值数据类型:1 int/2 float
   bvisible             tinyint                        not null,	-- 界面是否可见:1可见/0不可见 
   lasttime             datetime                       null,		-- 最后一次更新时间
   extrastr             varchar(256)                   null,		-- 扩展字段:可存放json,便于扩展
   constraint PK_ROS_PITEMDEF primary key (poid, pitemid)
)
go


if exists (select * from sysobjects where id = object_id('dbo.p_create_table'))
    drop procedure dbo.p_create_table
go

create procedure p_create_table(@vname   varchar(50))
as
begin
	/**
	*  create   measure(24) table  
	*  E.g exec p_create_view 'data_vm_cpu' 
	*  
	* @param  @vname  table name
	* @author lb 
	* @create date 2014-12
	* @mod date 
	*/        
	   declare @i int
	   declare @dd varchar(4)
	   declare @tabname varchar(20)
	   declare @sql varchar(3000)
 
	   set @i=24
	   
	   while @i>=1
	   begin
	     
	      
	        set @dd=right('0'+cast(@i as varchar),2)
	      	  
		 
			set @tabname=@vname+@dd
			set @sql='if exists(select 1 from sysobjects where name = '''+@tabname+''') '+
			' drop table '+@tabname
			execute (@sql)
			  
			set @sql='create table '+@tabname+
		                     '(time            datetime not null,'+
						     'res_type         varchar(100) null,'+
							 'dc_id            varchar(100) null,'+
						     'res_id           varchar(100) not null,'+
						     'moc_id           varchar(100) null,'+
							 'pitemid          integer null,'+
							 'usage_value      float null)'
		
						     
			execute (@sql)
			  
			
			set @sql='create index idx_time_'+@tabname+' on '+@tabname+'(time)'
			execute (@sql)
			set @sql='create index idx_res_id_'+@tabname+' on '+@tabname+'(res_id)'
			execute (@sql)	
			set @sql='create index idx_moc_id_'+@tabname+' on '+@tabname+'(moc_id)'
			execute (@sql)				
			  
	   		set @i=@i-1
	   end
end
go
------create table end ------
 

------------init data start -------
exec p_create_table 'data_vm_cpu' 
exec p_create_table 'data_vm_mem' 
exec p_create_table 'data_vm_disk' 
exec p_create_table 'data_vm_nic' 
exec p_create_table 'data_host_cpu' 
exec p_create_table 'data_host_mem' 
exec p_create_table 'data_host_disk' 
exec p_create_table 'data_host_nic' 
go

insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010001', '虚拟机CPU性能', 'data_vm_cpu', 1, 0)
-- insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010002', '虚拟机内存性能', 'data_vm_mem', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010003', '虚拟机磁盘性能', 'data_vm_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010004', '虚拟机网卡性能', 'data_vm_nic', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010005', '物理机CPU性能', 'data_host_cpu', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010006', '物理机内存性能', 'data_host_mem', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010007', '物理机磁盘性能', 'data_host_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010008', '物理机网卡性能', 'data_host_nic', 1, 0)
go

insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010001', 1, '虚拟机CPU使用率', 'cpu_util', '%', 2, 1)
-- insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010002', 1, '虚拟机内存使用情况', 'memory.usage', 'MB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 1, '虚拟机磁盘读取速率', 'disk.read.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 2, '虚拟机磁盘写入速率', 'disk.write.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 3, '虚拟机磁盘大小', 'disk.total.size', 'GB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010004', 1, '虚拟机网络出口带宽', 'network.outgoing.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010004', 2, '虚拟机网络入口带宽', 'network.incoming.bytes.rate', 'B/s', 2, 1)

insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010005', 1, '物理机CPU使用率', 'compute.node.cpu.percent', '%', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010006', 1, '物理机内存使用情况', 'compute.node.memory.used', 'MB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 1, '物理机磁盘读取速率', 'compute.node.disk.read.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 2, '物理机磁盘写入速率', 'compute.node.disk.write.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 3, '物理机磁盘大小', 'compute.node.disk.total', 'GB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 4, '物理机磁盘已使用大小', 'compute.node.disk.used', 'GB', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010008', 1, '物理机网络出口带宽', 'compute.node.network.outgoing.bytes.rate', 'B/s', 2, 1)
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010008', 2, '物理机网络入口带宽', 'compute.node.network.incoming.bytes.rate', 'B/s', 2, 1)
go


use zxinsys
go

delete from zxinsys..portal_sysparam where param_name ='versionnumber'
go
insert into zxinsys..portal_sysparam(param_name,param_value, description) values('versionnumber', 'ZXCLOUD-iROSV4.03.01', '版本号')
go

-- 删除性能和故障两个菜单
delete from oper_funcgrp2 where funcgrpid =1 and servicekey='uniportal'
delete from oper_funcgrp2 where funcgrpid =3 and servicekey='uniportal'

delete from oper_function where funcgrpid=1 and servicekey='uniportal'
delete from oper_function where funcgrpid=3 and servicekey='uniportal'

delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =1
delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =3
go

exec proc_res_op_paratype 0 ,2, 101, ''			-- 去除【故障管理】操作日志统计类型
go
exec proc_res_op_paratype 0 ,2, 102, '' 		-- 去除【性能统计】操作日志统计类型
go
exec proc_res_op_paratype 0 ,2, 103, '' 		-- 去除【资源管理】操作日志统计类型
go

proc_res_op_grpdef 0, 1, 103, 1396, 139601  
go

exec proc_res_op_function 0, 2, 1396, 139603,''	-- 价格管理
go
exec proc_res_op_function 0, 1, 1396, 139606,'日志管理'
go
exec proc_res_op_function 0, 1, 1396, 139607,'备份管理'
go
exec proc_res_op_function 0, 1, 1396, 139608,'告警地址配置'
go
exec proc_res_op_function 0, 1, 1396, 139609,'实时告警'
go
exec proc_res_op_function 0, 1, 1396, 139610,'历史告警'
go
exec proc_res_op_function 0, 1, 1396, 139611,'性能统计'
go

exec proc_res_op_paratype 0, 1, 3961, '云管理'
go

UPDATE portal_sysparam SET description = '镜像下载缺省绝对路径(/开头,只能有-_/字母和数字),最长254个字符', check_script = '/^[/]([a-zA-Z0-9-_/]){0,254}$/' 
	WHERE param_name = 'download_image_default_path'
go
	
delete from portal_sysparam where param_name = 'remote_syn_user'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_syn_user','','4A同步用户信息调用地址','iROS','4A同步用户信息调用地址',
             2,100,0,' ',1,
             '','','','','')
go
delete from portal_sysparam where param_name = 'remote_idcim_host'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_idcim_host','','获取物理主机列表调用地址','iROS','获取物理主机列表调用地址',
             2,100,0,' ',1,
             '','','','','')
go
delete from portal_sysparam where param_name = 'iros_backup_shell_path'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_backup_shell_path','/home/iros/db_bak','备份shell脚本放置路径','iROS','备份shell脚本放置路径',
             2,100,0,'/home/iros/db_bak',0,
             '','','','','')
go

delete from portal_sysparam where param_name = 'volume_upper_limit'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('volume_upper_limit','500','云硬盘大小上限(GB)','iROS','云硬盘大小上限(GB)',
             2,100,0,' ',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'om_support_hr'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('om_support_hr', '1', '是否支持hr鉴权', 'iROS', '是否支持hr鉴权', 
			4, null, null, '1-支持,0-不支持', 1, 
			'', '', '', '', '')
go

delete from portal_sysparam where param_name = 'hr_server_url'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('hr_server_url', 'http://tech.zte.com.cn/tech/xmlrpc', 'hr鉴权url', 'iROS', 'hr鉴权url', 
			2, 100, 0, '', 0, 
			'', '', '', '', '')
go

			
			
delete from ommp_res_definition where rid = 'OPENSTACK'
go

use zxinsys
go
delete from oper_funcgrp2 where funcgrpid = 4
insert into oper_funcgrp2 values (4, '4', '权限管理', 'uniportal', 0)


delete from oper_function where funcdescription in ('操作员管理','角色信息','组信息','安全等级','安全规则设置','操作员信息编辑','角色信息编辑','组信息编辑','安全等级编辑','安全规则设置编辑','创建删除资源')
insert into oper_function values (4, 13001, '1301' , '操作员管理'  ,       0, 'uniportal')
insert into oper_function values (4, 13003, '1303' , '角色信息'    ,       0, 'uniportal')
insert into oper_function values (4, 13005, '1305' , '组信息'      ,       0, 'uniportal')
insert into oper_function values (4, 13007, '1307' , '安全等级'     ,      0, 'uniportal')
insert into oper_function values (4, 13008, '1308' , '安全规则设置'  ,      0, 'uniportal') 
insert into oper_function values (4, 13009, '1309' , '操作员信息编辑'  ,      0, 'uniportal')
insert into oper_function values (4, 13011, '1311' , '角色信息编辑'  ,      0, 'uniportal')
insert into oper_function values (4, 13014, '1314' , '组信息编辑'  ,       0, 'uniportal') 
insert into oper_function values (4, 13016, '1316' , '安全等级编辑'  ,       0, 'uniportal') 
insert into oper_function values (4, 13017, '1317' , '安全规则设置编辑'  ,       0, 'uniportal')
insert into oper_function values (4, 13020, '1320' , '创建删除资源'  ,       0, 'uniportal') 
go

delete from oper_grpdef where funcgrpid=4 and opergrpid=1000  and servicekey='uniportal'
insert into oper_grpdef select 1000,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4 
delete from oper_grpdef where funcgrpid=4 and opergrpid=1001  and servicekey='uniportal'
insert into oper_grpdef select 1001,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4 
go


-- 增加新的角色：
-- proc_res_op_grpscript2 产品ID，修改标识(add-1,del-2)，角色标识，角色名称
proc_res_op_grpscript2 0, 1, 201, '管理员角色' 
go
proc_res_op_grpscript2 0, 1, 202, '操作员角色' 
go
proc_res_op_grpscript2 0, 1, 203, '维护员角色' 
go
proc_res_op_grpscript2 0, 1, 204, '监控员角色' 
go
proc_res_op_grpscript2 0, 1, 205, '自定义角色' 
go


--给新增加的角色增加相应的权限：
--管理员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
proc_res_op_grpdef 0, 1, 201, 1,  10001
go
proc_res_op_grpdef 0, 1, 201, 1,  10003
go
proc_res_op_grpdef 0, 1, 201, 1,  10006 
go
proc_res_op_grpdef 0, 1, 201, 1,  10007
go
proc_res_op_grpdef 0, 1, 201, 3,  12001 
go
proc_res_op_grpdef 0, 1, 201, 3,  12002 
go
proc_res_op_grpdef 0, 1, 201, 3,  12003   
go
proc_res_op_grpdef 0, 1, 201, 3,  12007 
go
proc_res_op_grpdef 0, 1, 201, 3,  12008 
go
proc_res_op_grpdef 0, 1, 201, 3,  12010 
go
proc_res_op_grpdef 0, 1, 201, 4,  13001 
go
proc_res_op_grpdef 0, 1, 201, 4,  13003  
go
proc_res_op_grpdef 0, 1, 201, 4,  13005  
go
proc_res_op_grpdef 0, 1, 201, 4,  13007  
go
proc_res_op_grpdef 0, 1, 201, 4,  13008  
go
proc_res_op_grpdef 0, 1, 201, 4,  13009  
go
proc_res_op_grpdef 0, 1, 201, 4,  13011  
go
proc_res_op_grpdef 0, 1, 201, 4,  13014  
go
proc_res_op_grpdef 0, 1, 201, 4,  13016  
go
proc_res_op_grpdef 0, 1, 201, 4,  13017  
go
proc_res_op_grpdef 0, 1, 201, 4,  13020  
go
proc_res_op_grpdef 0, 1, 201, 10, 15001  
go
proc_res_op_grpdef 0, 1, 201, 10, 15005  
go
proc_res_op_grpdef 0, 1, 201, 10, 15007  
go
proc_res_op_grpdef 0, 1, 201, 11, 18005  
go
proc_res_op_grpdef 0, 1, 201, 11, 18102  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139601  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139603  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139605  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139607  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139609  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139610     
go

--操作员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
proc_res_op_grpdef 0, 1, 202, 1,  10001
go
proc_res_op_grpdef 0, 1, 202, 1,  10003
go
proc_res_op_grpdef 0, 1, 202, 1,  10006 
go
proc_res_op_grpdef 0, 1, 202, 1,  10007
go
proc_res_op_grpdef 0, 1, 202, 3,  12001 
go
proc_res_op_grpdef 0, 1, 202, 3,  12002 
go
proc_res_op_grpdef 0, 1, 202, 3,  12003   
go
proc_res_op_grpdef 0, 1, 202, 3,  12007 
go
proc_res_op_grpdef 0, 1, 202, 3,  12008 
go
proc_res_op_grpdef 0, 1, 202, 3,  12010 
go
proc_res_op_grpdef 0, 1, 202, 4,  13001 
go
proc_res_op_grpdef 0, 1, 202, 4,  13003  
go
proc_res_op_grpdef 0, 1, 202, 4,  13005  
go
proc_res_op_grpdef 0, 1, 202, 4,  13007  
go
proc_res_op_grpdef 0, 1, 202, 4,  13008  
go
proc_res_op_grpdef 0, 1, 202, 4,  13009  
go
proc_res_op_grpdef 0, 1, 202, 4,  13011  
go
proc_res_op_grpdef 0, 1, 202, 4,  13014  
go
proc_res_op_grpdef 0, 1, 202, 4,  13016  
go
proc_res_op_grpdef 0, 1, 202, 4,  13017  
go
proc_res_op_grpdef 0, 1, 202, 4,  13020  
go
proc_res_op_grpdef 0, 1, 202, 10, 15001  
go
proc_res_op_grpdef 0, 1, 202, 10, 15005  
go
proc_res_op_grpdef 0, 1, 202, 10, 15007  
go
proc_res_op_grpdef 0, 1, 202, 11, 18005  
go
proc_res_op_grpdef 0, 1, 202, 11, 18102  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139601  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139603  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139605  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139607  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139609  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139610     
go

--维护员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
proc_res_op_grpdef 0, 1, 203, 1,  10001
go
proc_res_op_grpdef 0, 1, 203, 1,  10003
go
proc_res_op_grpdef 0, 1, 203, 1,  10006 
go
proc_res_op_grpdef 0, 1, 203, 1,  10007
go
proc_res_op_grpdef 0, 1, 203, 3,  12001 
go
proc_res_op_grpdef 0, 1, 203, 3,  12002 
go
proc_res_op_grpdef 0, 1, 203, 3,  12003   
go
proc_res_op_grpdef 0, 1, 203, 3,  12007 
go
proc_res_op_grpdef 0, 1, 203, 3,  12008 
go
proc_res_op_grpdef 0, 1, 203, 3,  12010 
go
proc_res_op_grpdef 0, 1, 203, 4,  13001 
go
proc_res_op_grpdef 0, 1, 203, 4,  13003  
go
proc_res_op_grpdef 0, 1, 203, 4,  13005  
go
proc_res_op_grpdef 0, 1, 203, 4,  13007  
go
proc_res_op_grpdef 0, 1, 203, 4,  13008  
go
proc_res_op_grpdef 0, 1, 203, 4,  13009  
go
proc_res_op_grpdef 0, 1, 203, 4,  13011  
go
proc_res_op_grpdef 0, 1, 203, 4,  13014  
go
proc_res_op_grpdef 0, 1, 203, 4,  13016  
go
proc_res_op_grpdef 0, 1, 203, 4,  13017  
go
proc_res_op_grpdef 0, 1, 203, 4,  13020  
go
proc_res_op_grpdef 0, 1, 203, 10, 15001  
go
proc_res_op_grpdef 0, 1, 203, 10, 15005  
go
proc_res_op_grpdef 0, 1, 203, 10, 15007  
go
proc_res_op_grpdef 0, 1, 203, 11, 18005  
go
proc_res_op_grpdef 0, 1, 203, 11, 18102  
go

--监控员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
proc_res_op_grpdef 0, 1, 204, 1,  10001
go
proc_res_op_grpdef 0, 1, 204, 1,  10003
go
proc_res_op_grpdef 0, 1, 204, 1,  10006 
go
proc_res_op_grpdef 0, 1, 204, 1,  10007
go
proc_res_op_grpdef 0, 1, 204, 3,  12001 
go
proc_res_op_grpdef 0, 1, 204, 3,  12002 
go
proc_res_op_grpdef 0, 1, 204, 3,  12003   
go
proc_res_op_grpdef 0, 1, 204, 3,  12007 
go
proc_res_op_grpdef 0, 1, 204, 3,  12008 
go
proc_res_op_grpdef 0, 1, 204, 3,  12010 
go
proc_res_op_grpdef 0, 1, 204, 4,  13001 
go
proc_res_op_grpdef 0, 1, 204, 4,  13003  
go
proc_res_op_grpdef 0, 1, 204, 4,  13005  
go
proc_res_op_grpdef 0, 1, 204, 4,  13007  
go
proc_res_op_grpdef 0, 1, 204, 4,  13008  
go
proc_res_op_grpdef 0, 1, 204, 4,  13009  
go
proc_res_op_grpdef 0, 1, 204, 4,  13011  
go
proc_res_op_grpdef 0, 1, 204, 4,  13014  
go
proc_res_op_grpdef 0, 1, 204, 4,  13016  
go
proc_res_op_grpdef 0, 1, 204, 4,  13017  
go
proc_res_op_grpdef 0, 1, 204, 4,  13020  
go
proc_res_op_grpdef 0, 1, 204, 10, 15001  
go
proc_res_op_grpdef 0, 1, 204, 10, 15005  
go
proc_res_op_grpdef 0, 1, 204, 10, 15007  
go
proc_res_op_grpdef 0, 1, 204, 11, 18005  
go
proc_res_op_grpdef 0, 1, 204, 11, 18102  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139601  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139603  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139605  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139607  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139609  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139610     
go

--自定义角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
proc_res_op_grpdef 0, 1, 205, 1,  10001
go
proc_res_op_grpdef 0, 1, 205, 1,  10003
go
proc_res_op_grpdef 0, 1, 205, 1,  10006 
go
proc_res_op_grpdef 0, 1, 205, 1,  10007
go
proc_res_op_grpdef 0, 1, 205, 3,  12001 
go
proc_res_op_grpdef 0, 1, 205, 3,  12002 
go
proc_res_op_grpdef 0, 1, 205, 3,  12003   
go
proc_res_op_grpdef 0, 1, 205, 3,  12007 
go
proc_res_op_grpdef 0, 1, 205, 3,  12008 
go
proc_res_op_grpdef 0, 1, 205, 3,  12010 
go
proc_res_op_grpdef 0, 1, 205, 4,  13001 
go
proc_res_op_grpdef 0, 1, 205, 4,  13003  
go
proc_res_op_grpdef 0, 1, 205, 4,  13005  
go
proc_res_op_grpdef 0, 1, 205, 4,  13007  
go
proc_res_op_grpdef 0, 1, 205, 4,  13008  
go
proc_res_op_grpdef 0, 1, 205, 4,  13009  
go
proc_res_op_grpdef 0, 1, 205, 4,  13011  
go
proc_res_op_grpdef 0, 1, 205, 4,  13014  
go
proc_res_op_grpdef 0, 1, 205, 4,  13016  
go
proc_res_op_grpdef 0, 1, 205, 4,  13017  
go
proc_res_op_grpdef 0, 1, 205, 4,  13020  
go
proc_res_op_grpdef 0, 1, 205, 10, 15001  
go
proc_res_op_grpdef 0, 1, 205, 10, 15005  
go
proc_res_op_grpdef 0, 1, 205, 10, 15007  
go
proc_res_op_grpdef 0, 1, 205, 11, 18005  
go
proc_res_op_grpdef 0, 1, 205, 11, 18102  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139601  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139603  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139605  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139607  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139609  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139610     
go


if exists (select * from sysobjects where id = object_id('proc_rcs_updateRole'))
     
     update portal_sysparam set param_value='1'  where param_name='RCS'

     exec proc_rcs_updateRolego
go


use iros
go
IF EXISTS (SELECT 1 FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'v_ent_openstack' AND u.name = 'dbo' AND o.type = 'V')
BEGIN
	drop view v_ent_openstack
END
go

if not exists(select 1 from sysobjects where id = object_id('common_organization'))
begin
	exec('CREATE TABLE if not exists common_organization ( 
		id         	numeric(18,0) NOT NULL,
		parentid   	numeric(18,0) NOT NULL,
		name       	varchar(128) NOT NULL,
		description	varchar(256) NULL,
		creator    	numeric(18,0) NULL,
		createtime 	datetime NULL,
		tenantid   	numeric(18,0) NULL 
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('om_cidr'))
begin
	exec('create table om_cidr ( 
            vdcid						varchar(100)				NULL,	-- vdcid
            cidr						varchar(100)				NOT NULL,	-- 网络地址
            vlan						varchar(10)					NULL,		-- vlan id
            PRIMARY KEY(cidr)
        )')
end
go


ALTER TABLE om_vdc MODIFY tenantid varchar(64)
go
ALTER TABLE om_user_info ADD orgid varchar(64) NULL,  type int NULL,  state int NULL
go

if not exists(select 1 from sysobjects where id = object_id('om_res_template'))
begin
	exec('CREATE TABLE if not exists om_res_template
	(
	   id                   varchar(64) not null,
	   dcid                 varchar(64) not null,
	   name                 varchar(200) null,
	   flavorid            varchar(64) null,
	   imageid              varchar(64) null,
	   status               varchar(10) null,
	   description          varchar(400) null,
	   PRIMARY KEY(id)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('om_vm_info_task'))
begin
	exec('CREATE TABLE if not exists om_vm_info_task ( 
		id							varchar(64) 	NOT NULL,   -- ID
		dc_id						varchar(64) 	NULL,   -- dcID
		dc_name						varchar(100) 	NULL,   -- dc名称
		dc_type						varchar(2) 		NULL,   -- dc类型
		domain_id					varchar(64) 	NULL,   -- domain ID
		domain_name					varchar(100) 	NULL,   -- domain name
		zone_name					varchar(100) 	NULL,   -- 集群名称
		host_name					varchar(100) 	NULL,   -- 主机名称
		name						varchar(100) 	NULL,   -- 虚机名称
		created						varchar(32) 	NULL,   -- 创建时间
		user_id						varchar(100) 	NULL,   -- 用户id
		user_name					varchar(100) 	NULL,   -- 用户名称
		tenant_id					varchar(100) 	NULL,   -- 租户id
		tenant_name					varchar(100) 	NULL,   -- 租户名称
		image_id					varchar(100) 	NULL,   -- 镜像id
		image_name					varchar(100) 	NULL,   -- 镜像名称
		addresses					varchar(100) 	NULL,   -- mac地址
		flavor_id					varchar(200) 	NULL,   -- 规格id
		flavor_info					varchar(200) 	NULL,   -- 规格
		ip_info						varchar(1000) 	NULL,   -- IP
		task_state					varchar(100) 	NULL,   -- 当前任务
		power_state					varchar(2) 		NULL,   -- 电源状态
		vm_state					varchar(100) 	NULL,   -- 虚机状态
		servergroup_info			varchar(100) 	NULL,   -- 云主机组
		is_volume_attached			varchar(64) 	NULL,   
		
		PRIMARY KEY(id)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('om_dc_info_task'))
begin
	exec('CREATE TABLE if not exists om_dc_info_task ( 
		dc_id							varchar(64) 	NOT NULL,   -- ID
		dc_name							varchar(100) 	NOT NULL,   -- 名称
		dc_type							varchar(2) 		NULL,   -- dc类型
		domain_id						varchar(64) 	NULL,   -- domain ID
		domain_name						varchar(100) 	NULL,   -- domain name
		zone_count						int 	 NULL,		-- 集群数
		host_count						int 	 NULL,		-- 主机数
		vm_count						int 	 NULL,	-- 虚机数	
		cpu_used						int		 NULL,	-- cpu使用量(个)
		cpu_all							int		 NULL,		-- cpu总量(个)
		mem_used						bigint 	 NULL,   -- 内存使用量(MB)
		mem_all							bigint      NULL,   -- 内存总量(MB)
		disk_used						int	     NULL,		-- 存储使用量(GB)
		disk_all						int 	 NULL,	-- 存储总量	(GB)
		volume_count					int			NULL,	-- 云硬盘个数
		image_count						int			NULL,	-- 镜像个数
		network_count					int			NULL,	-- 网络个数
		shared_network_count			int			NULL,	-- 共享网络个数
		external_network_count			int			NULL,	-- 外部网络个数
		extra							varchar(1000)	NULL,		-- 扩展字段
		PRIMARY KEY(dc_id)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('om_host_info_task'))
begin
	exec('CREATE TABLE if not exists om_host_info_task ( 
		id							varchar(64) 	NOT NULL,   -- ID
		dc_id						varchar(64) 	NULL,   -- dcID
		dc_name						varchar(100) 	NULL,   -- dc名称
		dc_type						varchar(2) 		NULL,   -- dc类型
		zone_name					varchar(100) 	NULL,   -- 集群名称
		host_name					varchar(100) 	NULL,   -- 主机名称
		status						varchar(32) 	NULL,   -- 状态
		hypervisor_type				varchar(32)		NULL,   -- 类型
		vcpus						int		 NULL,		-- 虚拟内核（总计）
		vcpus_used					int 	 NULL,   -- 虚拟内核（已使用）
		memory_mb					bigint   NULL,   -- 内存总计
		memory_mb_used				bigint	 NULL,		-- 内存已使用
		local_gb					int 	 NULL,	-- 存储总计
		local_gb_used				int	NULL,		-- 存储已使用
		running_vms					int	NULL,		-- 云主机个数
		PRIMARY KEY(id)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('om_base_tree'))
begin
	exec('CREATE TABLE if not exists om_base_tree ( 
		tree_id						varchar(64) 	NOT NULL,   -- ID
		tree_name						varchar(100) 	NOT NULL,   -- 名称
		tree_desc						varchar(250) 	NULL,		-- 描述
		parent_id						varchar(100) 	NOT NULL,	-- 父节点	
		type							int		NOT NULL,	-- 类型（0、资源 1、组织）
		extra							varchar(500)	NULL,		-- 扩展字段
		PRIMARY KEY(tree_id)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('om_oper_res_rel'))
begin
	exec('CREATE TABLE if not exists om_oper_res_rel ( 
		rel_id						varchar(64) 	NOT NULL,   -- 关联id
		oper_id					decimal(10) 	NOT NULL,   -- 用户id（ommp的用户id）
		type						int		NOT NULL,	-- 关联节点类型（1、tree节点 2、dc节点）当关联的是tree节点，则默认为此tree节点下所有节点都关联
		resource_id					varchar(100) 	NOT NULL,	-- 关联的资源节点id
		PRIMARY KEY(rel_id)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('om_oper_org_rel'))
begin
	exec('CREATE TABLE if not exists om_oper_org_rel ( 
		rel_id						varchar(64) 	NOT NULL,   -- 关联id
		oper_id					decimal(10) 	NOT NULL,   -- 用户id（ommp的用户id）
		type						int		NOT NULL,	-- 关联节点类型（1、tree节点 2、vdc节点）当关联的是tree节点，则默认为此tree节点下所有节点都关联
		resource_id					varchar(100) 	NOT NULL,	-- 关联的资源节点id
		PRIMARY KEY(rel_id)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('om_org_res_rel'))
begin
	exec('CREATE TABLE if not exists om_org_res_rel ( 
		rel_id						varchar(64) 	NOT NULL,   -- 关联id
		org_id					varchar(100) 	NOT NULL,   -- 组织id
		type						int		NOT NULL,	-- 关联节点类型（1、domain节点 2、dc节点）当关联的是domain，则默认为此domain下所有节点都能看到
		resource_id					varchar(100) 	NOT NULL,	-- 关联的资源节点id
		PRIMARY KEY(rel_id)
	)')
end
go


--RCS 告警iROS snmp 转发地址

if not exists(select 1 from sysobjects where id = object_id('alarm_snmp_address'))
begin
	exec('create table alarm_snmp_address (
	   name             varchar(200)    not null,   
	   port              int            not null,   
	   ip               varchar(50)     not null,   
	   community        varchar(200)    not null, 
	   type             varchar(50)     not null,      --south 南向 north 北向
	   constraint PK_ALARM_SNMP_ADDRESS primary key (name)
	)')
end
go

-- 当前告警

if not exists(select 1 from sysobjects where id = object_id('alarming'))
begin
	exec('create table alarming(
	   globalid      	numeric(10,0)    not   null,              -- 全局标识，告警模块生成，全局唯一 
		localid         varchar(100)     not   null,              -- 局部标识，告警源生成
		objid           varchar(200)     null,                    -- 告警对象标识  全局告警 objid objtype objname 为空
		objtype         varchar(200)     null,                    -- 告警对象类型
		objname         varchar(200)     null,                    -- 告警对象名称
		sourceid        varchar(200)     not   null,              -- 告警源标识
		sourcetype      varchar(200)     not   null,              -- 告警源类型	
		sourcename      varchar(200)     not   null,              -- 告警源类型	
		code		    varchar(100) 	 not   null,              -- 告警码
		almlevel	    int			     not   null,              -- 告警级别
		content         varchar(1500)    null,                    -- 附加信息
		createtime		varchar(100)     not   null,              -- 告警产生时间
		cleartime	    varchar(100)     null,                    -- 告警恢复时间
		cleartype	    int	             null,                    -- 告警恢复方式：1-正常恢复,2-手工恢复,3-自动恢复 RCS告警未用
		objip     	    varchar(200)     null,                    -- 告警对象ip	RCS告警未用
		confirmtime     varchar(100)     null,                    -- 确认时间RCS告警未用
		confirmuser     varchar(200)     null,                    -- 确认用户RCS告警未用
		confirmtype     int		         null,                    -- 确认状态，(0-未确认 1-已确认)RCS告警未用
		confirminfo     varchar(200)     null,                    -- 确认信息RCS告警未用
		keeptime         int             null,                    -- 保留时间,单位分钟RCS告警未用	
		constraint PK_ALARM primary key (globalid)
	)')
end
go

--历史告警
if not exists(select 1 from sysobjects where id = object_id('alarm_his'))
begin
	exec('create table alarm_his(
	   globalid      	numeric(10,0)    not   null,              -- 全局标识，告警模块生成，全局唯一 
		localid         varchar(100)     not   null,              -- 局部标识，告警源生成
		objid           varchar(200)     null,                    -- 告警对象标识  全局告警 objid objtype objname 为空
		objtype         varchar(200)     null,                    -- 告警对象类型
		objname         varchar(200)     null,                    -- 告警对象名称
		sourceid        varchar(200)     not   null,              -- 告警源标识
		sourcetype      varchar(200)     not   null,              -- 告警源类型	
		sourcename      varchar(200)     not   null,              -- 告警源类型	
		code		    varchar(100) 	 not   null,              -- 告警码
		almlevel	    int			     not   null,              -- 告警级别
		content         varchar(1500)    null,                    -- 附加信息
		createtime		varchar(100)     not   null,              -- 告警产生时间
		cleartime	    varchar(100)     null,                    -- 告警恢复时间
		cleartype	    int	             null,                    -- 告警恢复方式：1-正常恢复,2-手工恢复,3-自动恢复 RCS告警未用
		objip     	    varchar(200)     null,                    -- 告警对象ip	RCS告警未用
		confirmtime     varchar(100)     null,                    -- 确认时间RCS告警未用
		confirmuser     varchar(200)     null,                    -- 确认用户RCS告警未用
		confirmtype     int		         null,                    -- 确认状态，(0-未确认 1-已确认)RCS告警未用
		confirminfo     varchar(200)     null,                    -- 确认信息RCS告警未用
		keeptime         int             null,                    -- 保留时间,单位分钟RCS告警未用	
		constraint PK_ALARM_HIS primary key (globalid)
	)')
end
go

--告警码表
if not exists(select 1 from sysobjects where id = object_id('alarm_code'))
begin
	exec('create table alarm_code(  
		code              varchar(100)            not    null,      -- 告警/通知码
		description       varchar(254)            not    null,      -- 描述
		almlevel          int                     not    null,      -- 级别(1-紧急告警,2-重要告警,3-次要告警,4-警告告警,8-一般通知,9-重要通知)
		isshow            int                     not    null,      -- 是否显示(1-显示,0-不显示,)
		solution		   varchar(400)           null,             -- 处理建议
	   constraint PK_ALARM_CODE primary key (code)
	)')
end
go

if not exists(select 1 from sysobjects where id = object_id('alarm_config'))
begin
	exec('create table alarm_config( 
		name          varchar(100)                   not null,     
		value         varchar(100)                   not null,      
		constraint PK_ALARM_CONFIG primary key (name)
	)')
end
go


insert into alarm_config(name, value) values('alarm_globalid', '1') --告警全局序列号
go
insert into alarm_config(name, value) values('realalarm_maxcount', '1000')--保留多少条告警
go
insert into alarm_code(code, description, almlevel, isshow) values('46112', '计算服务不可用',1,1)
go
insert into alarm_code(code, description, almlevel, isshow) values('46114', '主机内存故障',1,1)
go
insert into alarm_code(code, description, almlevel, isshow) values('46176', '虚拟机状态异常',4,1)
go

-- alarmoid
if not exists(select 1 from sysobjects where id = object_id('alarm_oid'))
begin
	exec('create table alarm_oid( 
		name            varchar(100)                   not null,     
		oid             varchar(100)                   not null,      
		constraint PK_ALARM_OID primary key (name)
	)')
end
go

insert into alarm_oid(oid, name) values('1.3.6.1.6.3.1.1.4.1.0','alarmType')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.1','alarmReport')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.2','alarmRestore')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.3','alarmEventTime')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.2','sendNotificationId')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.4','lastSendNotificationId')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.3','systemDN')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.11','alarmCode')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.2','alarmManagedObjectInstance')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.4','alarmEventType')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.5','alarmProbableCause')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.6','alarmPerceivedSeverity')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.7','alarmSpecificProblem')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.8','alarmAdditionalText')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.12','alarmNetype')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.9','alarmIndex')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.1','alarmId')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.14','alarmCodeName')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.15','alarmManagedObjectInstanceName')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.16','alarmSystemType')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.17','alarmNeIP')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.18','alarmACK')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.19','cleiCode')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.20','timeZoneID')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.21','timeZoneOffset')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.22','dSTSaving')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.23','aid')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.24','id')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.26','alarmMocObjectInstatance')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.10','alarmComment')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.25','alarmOtherInfo')
--向opencos通知 iROS snmp监听信息
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.2.0','opencos_snmpTrapCommunity')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.3.0','opencos_snmpTrapVersion')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.2.1.3','opencos_trapIpaddressPort')
--向北向网管发送心跳
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.4.2.1.1','heartbeatNotification')

go


use opslog
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log01')) )
begin
  exec('alter table oper_log01 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log02')) )
begin
  exec('alter table oper_log02 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log03')) )
begin
  exec('alter table oper_log03 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log04')) )
begin
  exec('alter table oper_log04 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log05')) )
begin
  exec('alter table oper_log05 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log06')) )
begin
  exec('alter table oper_log06 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log07')) )
begin
  exec('alter table oper_log07 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log08')) )
begin
  exec('alter table oper_log08 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log09')) )
begin
  exec('alter table oper_log09 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log10')) )
begin
  exec('alter table oper_log10 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log11')) )
begin
  exec('alter table oper_log11 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log12')) )
begin
  exec('alter table oper_log12 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log13')) )
begin
  exec('alter table oper_log13 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log14')) )
begin
  exec('alter table oper_log14 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log15')) )
begin
  exec('alter table oper_log15 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log16')) )
begin
  exec('alter table oper_log16 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log17')) )
begin
  exec('alter table oper_log17 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log18')) )
begin
  exec('alter table oper_log18 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log19')) )
begin
  exec('alter table oper_log19 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log20')) )
begin
  exec('alter table oper_log20 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log21')) )
begin
  exec('alter table oper_log21 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log22')) )
begin
  exec('alter table oper_log22 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log23')) )
begin
  exec('alter table oper_log23 add domainid varchar(100) null')
end

if not exists(select 1 from syscolumns where (syscolumns.name = 'domainid') and (syscolumns.id IN (select id from sysobjects where name = 'oper_log24')) )
begin
  exec('alter table oper_log24 add domainid varchar(100) null')
end
go