use iros
go
if exists(select 1 from sysobjects where id = object_id('om_irai_quota'))
    drop table om_irai_quota
go
CREATE TABLE om_irai_quota ( 
	id						varchar(64)				not null, 	-- id
	create_date				datetime				not null, 	-- 创建时间
	update_date				datetime				not null, 	-- 更新时间
	dc_id					varchar(64)				not null, 	-- dc_id
	dc_type					int						not null,	-- dc类型，3是vmware，4是power，
	tenant_id				varchar(64)				not null, 	-- 租户id
	vdc_id					numeric				not null,
	resource_id				varchar(64)				not null,	-- 配额id
	resource				varchar(100)			not null,	-- 配额名称
	in_use					numeric					default 0		not null, 	-- 已使用
	hard_limit				numeric					not null, 	-- 上限
	PRIMARY KEY(id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_resize_flavor_record'))
    drop table om_resize_flavor_record
go
create table om_resize_flavor_record
(
	instanceid varchar(100) NOT NULL,
	vdcid varchar(10) NOT NULL,
	dcid varchar(100) NOT NULL,
	flag int(11) NOT NULL,
	operation varchar(20) DEFAULT NULL,
	vcpus int(11) NOT NULL,
	memory bigint(20) NOT NULL,
	disk int(11) NOT NULL,
	created datetime DEFAULT NULL,
	updated datetime DEFAULT NULL
)
go


if not exists(select 1 from syscolumns where (syscolumns.name = 'description') and (syscolumns.id IN (select id from sysobjects where name = 'om_base_service')) )
begin
  exec('alter table om_base_service add  description  varchar(500) null')
end
go

if not exists(select 1 from syscolumns where (syscolumns.name = 'tag') and (syscolumns.id IN (select id from sysobjects where name = 'om_dci')) )
begin
  exec('alter table om_dci add  tag  varchar(100) null')
end
go

if not exists(select 1 from syscolumns where (syscolumns.name = 'tag_type') and (syscolumns.id IN (select id from sysobjects where name = 'om_dci')) )
begin
  exec('alter table om_dci add  tag_type  varchar(100) null')
end
go

if not exists(select 1 from syscolumns where (syscolumns.name = 'dscp') and (syscolumns.id IN (select id from sysobjects where name = 'om_dci')) )
begin
  exec('alter table om_dci add  dscp  int null')
end
go

delete from om_base_service where switch_name = 'switch_irai'
insert into om_base_service (id, name, switch_name, rel_id, description) values (12, '云桌面', 'switch_irai', '6','')
go

use zxinmeasure
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100709, '物理机磁盘每秒读次数', 'IROSHOST', 1, 'measure_hdiskreadtimesdata', 2, 1, 1)
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100710, '物理机磁盘每秒写次数', 'IROSHOST', 1, 'measure_hdiskwritetimesdata', 2, 1, 1)
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100711, '物理机磁盘IO延迟', 'IROSHOST', 1, 'measure_hdiskiodelaydata', 2, 1, 1)

insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100709, 1, '物理机磁盘每秒读次数', 'statcode1', 'measure_hdiskreadtimesdata', 3, 1)
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100710, 1, '物理机磁盘每秒写次数', 'statcode1', 'measure_hdiskwritetimesdata', 3, 1)
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100711, 1, '物理机磁盘IO延迟', 'statcode1', 'measure_hdiskiodelaydata', 3, 1)

insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100709, 1, '磁盘名称', 'param1', 0)
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100709, 2, 'DCID', 'param2', 0)
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100710, 1, '磁盘名称', 'param1', 0)
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100710, 2, 'DCID', 'param2', 0)
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100711, 1, '磁盘名称', 'param1', 0)
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100711, 2, 'DCID', 'param2', 0)
go


exec p_create_table 'measure_hdiskreadtimesdata'
exec p_create_table 'measure_hdiskwritetimesdata'
exec p_create_table 'measure_hdiskiodelaydata'
go

delete from ros_ptypedef where res_type = 'host' and poid = '100803'
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100803', '物理机磁盘使用率', 'data_host_disk', 1, 0)
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100813', '物理机磁盘性能', 'data_host_disk', 1, 0)
go

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 2, '物理机磁盘每秒读次数', '', '', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 6, '物理机磁盘每秒写次数', '', '', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 10, '物理机磁盘读取速率', '', 'KB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 14, '物理机磁盘写入速率', '', 'KB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 18, '物理机磁盘IO延迟', '', 'Ms', 2, 1)

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 2, 2071, 100709)
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 6, 2071, 100710)
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 10, 2071, 100703)
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 14, 2071, 100704)
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 18, 2071, 100711)
go

go

use zxinalarm
go
exec proc_alm_code_new 1,1000041,'主机磁盘异常', 1,13,1,22537
exec proc_alm_reason_new 1,1000041,'主机磁盘异常',22537
go

alter table alarming modify reserve1 varchar(250)
alter table alarm01 modify reserve1 varchar(250)
alter table alarm02 modify reserve1 varchar(250)
alter table alarm03 modify reserve1 varchar(250)
alter table alarm04 modify reserve1 varchar(250)
alter table alarm05 modify reserve1 varchar(250)
alter table alarm06 modify reserve1 varchar(250)
alter table alarm07 modify reserve1 varchar(250)
alter table alarm08 modify reserve1 varchar(250)
alter table alarm09 modify reserve1 varchar(250)
alter table alarm10 modify reserve1 varchar(250)
alter table alarm11 modify reserve1 varchar(250)
alter table alarm12 modify reserve1 varchar(250)
go
alter table inform01 modify reserve1 varchar(250)
alter table inform02 modify reserve1 varchar(250)
alter table inform03 modify reserve1 varchar(250)
alter table inform04 modify reserve1 varchar(250)
alter table inform05 modify reserve1 varchar(250)
alter table inform06 modify reserve1 varchar(250)
alter table inform07 modify reserve1 varchar(250)
alter table inform08 modify reserve1 varchar(250)
alter table inform09 modify reserve1 varchar(250)
alter table inform10 modify reserve1 varchar(250)
alter table inform11 modify reserve1 varchar(250)
alter table inform12 modify reserve1 varchar(250)
go
alter table impinform01 modify reserve1 varchar(250)
alter table impinform02 modify reserve1 varchar(250)
alter table impinform03 modify reserve1 varchar(250)
alter table impinform04 modify reserve1 varchar(250)
alter table impinform05 modify reserve1 varchar(250)
alter table impinform06 modify reserve1 varchar(250)
alter table impinform07 modify reserve1 varchar(250)
alter table impinform08 modify reserve1 varchar(250)
alter table impinform09 modify reserve1 varchar(250)
alter table impinform10 modify reserve1 varchar(250)
alter table impinform11 modify reserve1 varchar(250)
alter table impinform12 modify reserve1 varchar(250)
go

