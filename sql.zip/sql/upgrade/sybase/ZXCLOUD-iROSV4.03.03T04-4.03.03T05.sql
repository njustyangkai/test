use zxinsys
go
proc_res_op_grpdef 0, 2, 102, 1396, 139623
go
proc_res_op_grpdef 0, 2, 103, 1396, 139623
go
proc_res_op_grpdef 0, 2, 103, 1396, 139614
go
proc_res_op_grpdef 0, 2, 104, 1396, 139614
go
proc_res_op_grpdef 0, 2, 102, 1396, 139620
go

proc_res_op_grpdef 0, 2, 102, 1396, 139604
go
proc_res_op_grpdef 0, 2, 103, 1396, 139604
go
proc_res_op_grpdef 0, 2, 105, 1396, 139604
go

proc_res_op_function 0, 1, 1396, 139601,'云管理'
go
proc_res_op_function 0, 1, 1396, 139604,'云服务'
go
proc_res_op_function 0, 2, 1396, 139623,'初始化向导'
go
proc_res_op_function 0, 2, 1396, 139611,'性能统计'
go
proc_res_op_function 0, 2, 1396, 139614,'易云管理'
go

proc_res_op_function 0, 1, 1396, 139620,'设备监控'
go
proc_res_op_function 0, 1, 1396, 139621,'资产管理'
go
proc_res_op_function 0, 2, 1396, 139622,'数据字典'
go

delete from portal_sysparam where param_name = 'receive_vnfm_feedback_timeout'
go

delete from portal_sysparam where param_name = 'image_delete_interval'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('image_delete_interval','180','删除下载镜像任务默认比较时间','iROS','删除下载镜像任务默认比较时间，单位：分钟',
             2,100,0,'',0,
             '','','','','')
go


use zxinmeasure
go
if exists (select * from sysobjects where id = object_id('dbo.p_create_table'))
    drop procedure dbo.p_create_table
go

CREATE PROCEDURE dbo.p_create_table(@tablename varchar(50))
as
begin
	declare @currentTableName VARCHAR(128)
    declare @nextTableName VARCHAR(128)
	declare @currentmonth INT
	declare @nextmonth INT
	declare @addNum INT
	declare @vsql varchar(1000)

    SET @currentmonth=datepart(mm,getdate())  
	SET @addNum=(datepart(yy,getdate()) % 2) * 12 
    

	SET @nextmonth=@currentmonth + 1

  

	SET @currentmonth=@currentmonth + @addNum
	SET @nextmonth=@nextmonth + @addNum


    IF @nextmonth > 24
	BEGIN
       SET @nextmonth=1
    END

	SET @currentTableName=right('0'+cast(@currentmonth as varchar),2)
	SET @nextTableName=right('0'+cast(@nextmonth as varchar),2)
	
	SET @currentTableName=@tablename + @currentTableName
	SET @nextTableName=@tablename + @nextTableName
	
	if not exists (select 1 from  sysobjects where id=object_id(@currentTableName) and type='U')
	BEGIN
		SET @vsql='create table '+@currentTableName+
		                     '(starttime            datetime not null,'+
						     'endtime               datetime null,'+
							 'resourcetype          varchar(255) not null,'+
						     'resourceid            varchar(200) not null,'+
						     'param1                varchar(200) null,'+
							 'param2                varchar(200) null,'+
							 'statcode1             float null)'
		execute (@vsql)
			
		SET @vsql='create index idx_starttime_'+@currentTableName+' on '+@currentTableName+'(starttime)'
		execute (@vsql)
		SET @vsql='create index idx_resourceid_'+@currentTableName+' on '+@currentTableName+'(resourceid)'
		execute (@vsql)
		SET @vsql='create index idx_param1_'+@currentTableName+' on '+@currentTableName+'(param1)'
		execute (@vsql)
		SET @vsql='create index idx_param2_'+@currentTableName+' on '+@currentTableName+'(param2)'
		execute (@vsql)
	END
	
	if not exists (select 1 from  sysobjects where id=object_id(@nextTableName) and type='U')
	BEGIN
		SET @vsql='create table '+@nextTableName+
		                     '(starttime            datetime not null,'+
						     'endtime               datetime null,'+
							 'resourcetype          varchar(255) not null,'+
						     'resourceid            varchar(200) not null,'+
						     'param1                varchar(200) null,'+
							 'param2                varchar(200) null,'+
							 'statcode1             float null)'
		execute (@vsql)
			
		SET @vsql='create index idx_starttime_'+@nextTableName+' on '+@nextTableName+'(starttime)'
		execute (@vsql)
		SET @vsql='create index idx_resourceid_'+@nextTableName+' on '+@nextTableName+'(resourceid)'
		execute (@vsql)
		SET @vsql='create index idx_param1_'+@nextTableName+' on '+@nextTableName+'(param1)'
		execute (@vsql)
		SET @vsql='create index idx_param2_'+@nextTableName+' on '+@nextTableName+'(param2)'
		execute (@vsql)
	END
end
go


delete form ros_ptypedef where poid = '100822'
go
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100822', '虚拟机内存性能', 'data_vm_mem', 1, 0)
go

delete form ros_pitemdef where dc_type = 1
go
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100821', 2, '虚拟机CPU使用率', '', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100822', 2, '虚拟机内存使用率', '', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 2, '虚拟机磁盘读取速率', '', 'MB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 6, '虚拟机磁盘写入速率', '', 'MB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 26, '虚拟机网络出口带宽', '', 'KB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 30, '虚拟机网络入口带宽', '', 'KB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100801', 2, '物理机CPU使用率', '', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100802', 2, '物理机内存使用情况', '', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100803', 2, '物理机磁盘使用率', '', '%', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 30, '物理机端口流出速率', '', 'KB/s', 2, 1)
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 26, '物理机端口流入速率', '', 'KB/s', 2, 1)
go


