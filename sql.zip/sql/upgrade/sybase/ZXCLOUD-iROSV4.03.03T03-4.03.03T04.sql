use zxinsys
go
exec proc_add_res_definition 'IROSOWNER', '资源属主', 'ROOT', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_owner', '', null
exec proc_add_res_definition 'IROSDC', '数据中心', 'IROSOWNER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_dc', '', null
exec proc_add_res_definition 'IROSCLUSTER', '集群', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_cluster', '', null
exec proc_add_res_definition 'IROSHOST', '主机', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host', '', null
exec proc_add_res_definition 'IROSVM', '云主机', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm', '', null
exec proc_add_res_definition 'IROS_REPOS_GRP', '存储组', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp', '', null
exec proc_add_res_definition 'IROS_REPOS_GRP_MANAGE', '存储组', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_manage', '', null
exec proc_add_res_definition 'IROS_REPOS_GRP_PUB', '存储组', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_pub', '', null
exec proc_add_res_definition 'IROS_REPOS', '存储', 'IROS_REPOS_GRP', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos', '', null
exec proc_add_res_definition 'IROS_REPOS_MANAGE', '存储', 'IROS_REPOS_GRP_MANAGE', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_manage', '', null
exec proc_add_res_definition 'IROS_REPOS_PUB', '存储', 'IROS_REPOS_GRP_PUB', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_pub', '', null
exec proc_add_res_definition 'IROS_HOSTNIC', '主机网卡', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host_nic', '', null
exec proc_add_res_definition 'IROS_VMNIC', '云主机网卡', 'IROSVM', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm_nic', '', null
go

exec proc_res_op_function 0, 2, 1396, 139629,'服务监控'
go
exec proc_res_op_function 0, 1, 1396, 139630,'租期统计'
go

use iros
go
if exists(select 1 from sysobjects where id = object_id('ent_res_repos_grp'))
    drop table ent_res_repos_grp
go
create table ent_res_repos_grp(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos_grp_manage'))
    drop table ent_res_repos_grp_manage
go
create table ent_res_repos_grp_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos_grp_pub'))
    drop table ent_res_repos_grp_pub
go
create table ent_res_repos_grp_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos'))
    drop table ent_res_repos
go
create table ent_res_repos(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos_manage'))
    drop table ent_res_repos_manage
go
create table ent_res_repos_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos_pub'))
    drop table ent_res_repos_pub
go
create table ent_res_repos_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_host_nic'))
    drop table ent_res_host_nic
go
create table ent_res_host_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_vm_nic'))
    drop table ent_res_vm_nic
go
create table ent_res_vm_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('dc_ommp_restype_rel'))
    drop table dc_ommp_restype_rel
go
create table dc_ommp_restype_rel (
   dc_type           integer                   not null,
   dc_restype        varchar(50)               not null,
   ommp_restype      varchar(50)               not null, 
   primary key (dc_type, dc_restype)
)
go

-- iECS 
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP', 'IROS_REPOS_GRP')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_MANAGE', 'IROS_REPOS_GRP_MANAGE')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_PUB', 'IROS_REPOS_GRP_PUB')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS', 'IROS_REPOS')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_MANAGE', 'IROS_REPOS_MANAGE')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_PUB', 'IROS_REPOS_PUB')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMC', 'IROSDC')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VM', 'IROSVM')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'HOST', 'IROSHOST')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'POOL', 'IROSCLUSTER')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'NIC', 'IROS_HOSTNIC')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMNETCARD', 'IROS_VMNIC')
go


if not exists(select 1 from syscolumns where (syscolumns.name = 'dc_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_resource_statistic')) )
begin
  exec('alter table om_resource_statistic add dc_id varchar(100)')
end


alter table om_resource_statistic 
DROP PRIMARY KEY,
ADD PRIMARY KEY (type, resource_id, resource_name, date)
go



use zxinalarm
go

--告警系统类型
exec proc_alm_systypedic 1,22537,'iROS'

-- iECS
exec proc_alm_code_new 1,1000001,'主机离线告警',1,13,1,22537
exec proc_alm_code_new 1,1000002,'虚拟机关闭告警',1,13,1,22537
exec proc_alm_code_new 1,1000003,'VMC数据库异常',1,13,1,22537
exec proc_alm_code_new 1,1000004,'存储库状态异常',1,13,1,22537
exec proc_alm_code_new 1,1000005,'存储库使用率超过阈值',1,13,1,22537
exec proc_alm_code_new 1,1000008,'虚机崩溃告警',8,13,1,22537
exec proc_alm_code_new 1,1000009,'虚机重启告警',8,13,1,22537
exec proc_alm_code_new 1,1000014,'存储库代理状态异常',1,13,1,22537
exec proc_alm_code_new 1,1000016,'存储库单元可访问异常',1,13,1,22537
exec proc_alm_code_new 1,1000017,'主机访问存储库目录异常',1,13,1,22537
exec proc_alm_code_new 1,1000018,'主机网络异常',1,13,1,22537
exec proc_alm_code_new 1,1000020,'虚拟机故障切换资源',1,13,1,22537
exec proc_alm_code_new 1,1000021,'光纤告警',1,13,1,22537
exec proc_alm_code_new 1,1000025,'日志空间超限',1,13,1,22537
exec proc_alm_code_new 1,1000026,'MCE硬件异常',1,13,1,22537
exec proc_alm_code_new 1,1000000,'VMC异常',1,13,1,22537
exec proc_alm_code_new 1,1000100,'DRS批量迁移失败', 8,13,1,22537
go

-- iECS
exec proc_alm_reason_new 1,1000001,'主机离线告警',22537 
exec proc_alm_reason_new 1,1000002,'虚拟机关闭告警',22537 
exec proc_alm_reason_new 1,1000003,'VMC数据库异常',22537 
exec proc_alm_reason_new 1,1000004,'存储库状态异常',22537 
exec proc_alm_reason_new 1,1000005,'存储库使用率超过阈值',22537 
exec proc_alm_reason_new 1,1000008,'虚机崩溃告警',22537 
exec proc_alm_reason_new 1,1000009,'虚机重启告警',22537 
exec proc_alm_reason_new 1,1000014,'存储库代理状态异常',22537 
exec proc_alm_reason_new 1,1000016,'存储库单元可访问异常',22537 
exec proc_alm_reason_new 1,1000017,'主机访问存储库目录异常',22537 
exec proc_alm_reason_new 1,1000018,'主机网络异常',22537 
exec proc_alm_reason_new 1,1000020,'虚拟机故障切换资源',22537 
exec proc_alm_reason_new 1,1000021,'光纤告警',22537 
exec proc_alm_reason_new 1,1000025,'日志空间超限',22537 
exec proc_alm_reason_new 1,1000026,'MCE硬件异常',22537 
exec proc_alm_reason_new 1,1000000,'VMC异常',22537 
exec proc_alm_reason_new 1,1000100,'DRS批量迁移失败',22537 
go
