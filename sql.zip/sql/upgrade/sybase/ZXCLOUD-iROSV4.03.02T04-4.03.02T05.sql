﻿use irosrelation
go

-- 备份与用户的关联关系表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_volume' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_backup
go
create table om_relation_backup (
	res_id				varchar(64) 	not null,	-- 备份id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power，7是IECS
	extra				text			null,
	primary key (res_id)
)
go

-- 快照与用户的关联关系表
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 'om_relation_volume' and u.name = 'dbo' and o.type = 'U')
    drop table om_relation_snapshot
go
create table om_relation_snapshot (
	res_id				varchar(64) 	not null,	-- 快照id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power，7是IECS
	extra				text			null,
	primary key (res_id)
)
go

delete from om_quota_class where id = '7'
delete from om_quota_class where id = '8'

go

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('7', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '备份(个)', 'nova_backup', 50, 0, null, '备份', -1);
go
insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('8', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '快照(个)', 'nova_snapshot', 50, 0, null, '快照', -1);
go
