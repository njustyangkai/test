use iros
go

delete from om_control_function where id = 'drs_switch_control'
insert into om_control_function values ('drs_switch_control','DRS开关', '0')

go

delete from om_base_service where id = 9
delete from om_base_service where id = 10
insert into om_base_service values (9, '增量备份', 'switch_backup_add', '')
insert into om_base_service values (10, '全量备份', 'switch_backup_all', '')

go

if exists(select 1 from sysobjects where id = object_id('om_instance_backup'))
    drop table om_instance_backup
go
CREATE TABLE om_instance_backup (
    id                              int  identity,
    uuid	                        varchar(100) 	NOT NULL, 
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
    parent_id						int     NULL,
	instance_uuid				    varchar(255)	NOT NULL,
	instance_name				    varchar(255)	NULL,
	backup_type 				    tinyint	NOT NULL, 
	root_disk_file			  		varchar(255) NULL, 
	data_disk_file            		varchar(1000) NULL,
	memory_file            		    varchar(255) NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
    PRIMARY KEY(id,uuid)
)with identity_gap=1
go

if exists(select 1 from sysobjects where id = object_id('om_backup_task'))
    drop table om_backup_task
go
CREATE TABLE om_backup_task (   
	id                              int  identity,
	backup_id						varchar(100) 	NOT NULL,
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
	instance_uuid				    varchar(255)   NOT NULL,
	instance_name				    varchar(255)   NULL,
    backup_type 				    tinyint	NOT NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
	process						    int NOT NULL, 
	sync	        			    tinyint	NOT NULL, 
	extra							text	NULL,
	PRIMARY KEY(id,backup_id)
)with identity_gap=1
go

if exists(select 1 from sysobjects where id = object_id('om_backup_policy'))
    drop table om_backup_policy
go
CREATE TABLE om_backup_policy ( 
	uuid	                        varchar(100) 	NOT NULL, 
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
	name         				    varchar(255)	NOT NULL,
	policy       			  		varchar(255) NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	last_exec_date            	    datetime  NULL, 
	enable 				            tinyint	NOT NULL, 
	policy_type						int	NULL,   
    PRIMARY KEY(uuid)
)
go



if exists(select 1 from sysobjects where id = object_id('om_backup_policy_association'))
    drop table om_backup_policy_association
go
CREATE TABLE om_backup_policy_association(  
    instance_uuid				    varchar(255) NOT NULL,
	backup_policy_id				varchar(100) 	NOT NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_backup_quota'))
    drop table om_backup_quota
go
CREATE TABLE om_backup_quota ( 
    uuid							varchar(100) 	NOT NULL,  
	dc_id							varchar(100) 	NULL, 
    vdc_id							numeric	NOT NULL,	 
	quota						    int	default 0 not null,   
	backup_type					    tinyint	NOT NULL, 
    PRIMARY KEY(uuid)
)

go

if exists(select 1 from sysobjects where id = object_id('om_backup_path'))
    drop table om_backup_path
go
CREATE TABLE om_backup_path ( 
	uuid							varchar(100) NOT NULL, 
	dc_id							varchar(100) 	NOT NULL,   
	compute_host					varchar(255) 	NULL,
	path_type 				        tinyint	NOT NULL, 
	backup_path					    varchar(255) 	NULL,
    PRIMARY KEY(uuid)
)

go


--DRS begin
--DRS配置表
if exists(select 1 from sysobjects where id = object_id('drs_config'))
    drop table drs_config
go
create table drs_config (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  ,--资源池id
	reposstype						int					 DEFAULT  1  not null  ,--存储策略
	enable                          int                  DEFAULT  1  not null  ,--是否启动
	mode                     		int                  DEFAULT  1  null  ,	--策略模式
	autorun                     	int                         	 null  ,	--是否自动执行
	constraint PK_DRS_CONFIG_ID primary key (id)
)

go

--DRS配置详细表
if exists(select 1 from sysobjects where id = object_id('drs_config_detail'))
    drop table drs_config_detail
go
create table drs_config_detail (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  ,--资源池id
	cpuup                      		varchar(100)                     null  ,	--CPU上限
	cpudown                    		varchar(100)                     null  ,	--CPU下限
	memup                         	varchar(100)                     null  ,	--内存上限
	memdown                       	varchar(100)                     null  ,	--内存下限
	active                          int                  DEFAULT  1  not null  ,--是否有效
	starttime                      	varchar(10)                      null  ,	--开始时间
	endtime                    		varchar(10)                      null  ,	--结束时间
	constraint PK_DRS_CONFIG_DETAIL_ID primary key (id)	
)
go

--DRS调度建议表
if exists(select 1 from sysobjects where id = object_id('drs_suggest'))
    drop table drs_suggest
go
create table drs_suggest (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(255)                      not null  ,--资源池id
	operation                       int                              not null  ,--执行动作
	hostid                          varchar(255)                      null  ,	--最佳被迁主机
	hostid2                         varchar(255)                      null  ,	--最佳目标主机
	vmid                            varchar(255)                      null  ,	--最佳被迁虚机
	hostname                        varchar(255)                      null  ,	--最佳被迁主机名
	hostname2                       varchar(255)                      null  ,	--最佳目标主机名
	vmname                          varchar(255)                      null  ,	--最佳被迁虚机名
	description                     varchar(256)                     null  ,	--描述
	inserttime                      datetime                         null  ,	--产生时间
	status                          int                              null  ,	--状态
	maintainStatus                  int                              null  ,	--主机维护时，任务执行状态
	constraint PK_DRS_SUGGEST_ID primary key (id)
)
go

--DRS调度执行历史表
if exists(select 1 from sysobjects where id = object_id('drs_suggest_history'))
    drop table drs_suggest_history
go
create table drs_suggest_history (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(255)                      not null  ,--资源池id
	suggestid                       varchar(64)                      not null  ,--建议ID
	operation                       int                              not null  ,--执行动作
	hostid                          varchar(255)                      null  ,	--最佳被迁主机
	hostid2                         varchar(255)                      null  ,	--最佳目标主机
	vmid                            varchar(255)                      null  ,	--最佳被迁虚机
	hostname                        varchar(255)                      null  ,	--最佳被迁主机名
	hostname2                       varchar(255)                      null  ,	--最佳目标主机名
	vmname                          varchar(255)                      null  ,	--最佳被迁虚机名
	description                     varchar(256)                     null  ,	--描述
	inserttime                      datetime                         null  ,	--产生时间
	status                          int                              null  ,	--状态
	exetime 						datetime                         null  ,	--执行时间
	maintainStatus                  int                              null  ,	--主机维护时，任务执行状态
	taskid                          varchar(64)                      null  ,	--该任务执行时，任务对象返回的任务ID
	constraint PK_DRS_SUGGEST_HISTORY_ID primary key (id)
)
go

--DRS配置表
if exists(select 1 from sysobjects where id = object_id('drs_storage_config'))
    drop table drs_storage_config
go
create table drs_storage_config (
	poolid                          varchar(64)                      not null  ,--资源池id
	reposstype						int					 DEFAULT  1  not null  ,--存储策略
	enable                          int                  DEFAULT  1  not null  ,--是否启动
	mode                     		int                  DEFAULT  1  null  ,	--策略模式
	autorun                     	int                         	 null  ,	--是否自动执行
	maxrate                         int                              not null,  --设置的最大阈值   
	ext1                           int                               null,  --扩展1  
	ext2                           int                                null,  --扩展2
	ext3                           varchar(64)                                null,  --扩展3
	ext4                           varchar(64)                                null,  --扩展4
	constraint PK_drs_storage_config_ID primary key (poolid)
)
go

--DRS调度建议表
if exists(select 1 from sysobjects where id = object_id('drs_storage_suggest'))
    drop table drs_storage_suggest
go
create table drs_storage_suggest (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  ,--资源池id
	operation                       int                              not null  ,--执行动作
	hostid                          varchar(64)                      null  ,	--最佳被迁主机
	hostid2                         varchar(64)                      null  ,	--最佳目标主机
	vmid                            varchar(64)                      null  ,	--最佳被迁虚机
	hostname                        varchar(64)                      null  ,	--最佳被迁主机名
	hostname2                       varchar(64)                      null  ,	--最佳目标主机名
	vmname                          varchar(64)                      null  ,	--最佳被迁虚机名
	description                     varchar(256)                     null  ,	--描述
	inserttime                      datetime                         null  ,	--产生时间
	status                          int                              null  ,	--状态
	maintainStatus                  int                              null  ,	--主机维护时，任务执行状态
	constraint PK_DRS_STORAGE_SUGGEST_ID primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_compute_ipmi'))
    drop table om_compute_ipmi
go
create table om_compute_ipmi
(
    dc_id			varchar(64)		not null,
	[compute]			varchar(100)	not null,
	ip			    varchar(64)		null,
	user_name		varchar(255)	null,
	user_pwd		varchar(255)    null,
	constraint PK_OM_COMPUTE_IPMI primary key (dc_id, [compute])
)
go
--DRS end
