use iros
go

update iros_version_info set version = 'ZXCLOUD-iROSV4.04.06T01' where name = 'iROS'
go

use zxinsys
go
exec proc_res_op_function 0, 1, 1396, 139646,'高级'
go
delete from portal_sysparam where param_name = 'antivurs_sso_aes_password'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('antivurs_sso_aes_password','ZTE&nubosh#T0en','安贤单点登录AES秘钥','iROS','安贤单点登录AES秘钥',
             2,100,0,'',1,
             '','','','','')
go