use iros
go

-- ȥ��om_cidr������
declare @TABLE_NAME varchar(50)
set @TABLE_NAME='om_cidr'

while 1=1
begin

declare @PK_NAME varchar(50)
set @PK_NAME=null
declare @sql varchar(1000)
set @sql=null

select @PK_NAME=name from sysindexes where indid>0 and indid<255 and status&2048=2048 and id in
(select id from sysobjects where name=@TABLE_NAME)

if @PK_NAME is null
begin
--print ��pk name is null��
break
end
else
begin

--print ��pk name is not null��
print @PK_NAME
select @sql='alter table '+@TABLE_NAME+' drop constraint '+@PK_NAME
exec(@sql)

end
end

go 
