use iros
go
if exists(select 1 from sysobjects where id = object_id('om_cidr'))
    drop table om_cidr
go
