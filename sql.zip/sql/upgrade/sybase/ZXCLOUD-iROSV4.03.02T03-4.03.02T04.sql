use zxinsys
go

exec proc_res_op_function 0, 1, 1396, 139615,'模板管理'
go
exec proc_res_op_function 0, 1, 1396, 139616,'实例化管理'
go

update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139615 and servicekey='uniportal'
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139616 and servicekey='uniportal'
go


use iros
go

if exists(select 1 from sysobjects where id = object_id('resource_price'))
    drop table resource_price
go
CREATE TABLE resource_price (
	name        			varchar(100) 		not null,	
	groups        			int         		not null, -- 1.虚拟资源 2.物理资源 3.网络资源 4.物理机os
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance 11.iecs os 12.physical 13.network bandwidth
    unit                    varchar(50)         not null,
	sub_type                varchar(100)        null,
	price  			        numeric(20, 5) 		not null,
	description             varchar(100)        null   
)
go

insert into resource_price (name, groups, type, unit, description, price) values ('CPU价格', 1, 2, '元/核', '1核每小时价格', 0.05)
insert into resource_price (name, groups, type, unit, description, price) values ('内存价格', 1, 3, '元/GB', '1GB每小时价格', 0.05)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('AIX系统盘价格', 1, 4, '元/GB', 'AIX', 'AIX系统盘每GB每小时价格', 0.002)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Linux系统盘价格', 1, 4, '元/GB', 'Linux', 'Linux系统盘每GB每小时价格', 0.001)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Windows系统盘价格', 1, 4, '元/GB', 'Windows', 'Windows系统盘每GB每小时价格', 0.002)
insert into resource_price (name, groups, type, unit, description, price) values ('卷价格', 1, 7, '元/GB', '1GB每小时价格', 0.0006)
insert into resource_price (name, groups, type, unit, description, price) values ('私有镜像价格', 1, 8, '元/GB', '1GB每小时价格', 0.0006)
insert into resource_price (name, groups, type, unit, description, price) values ('公网IP价格', 3, 5, '元/个', '1个公网IP每小时价格', 0.01)
insert into resource_price (name, groups, type, unit, description, price) values ('路由器价格', 3, 6, '元/个', '1个路由每小时价格', 0.01)
insert into resource_price (name, groups, type, unit, description, price) values ('防火墙价格', 3, 9, '元/套', '1套每小时价格', 0.1)
insert into resource_price (name, groups, type, unit, description, price) values ('负载均衡价格', 3, 10, '元/套', '1套每小时价格', 0.1)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽价格', 3, 13, '元/Mbps', 'up',  '1Mbps上行带宽每小时价格', 0.01)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽价格', 3, 13, '元/Mbps', 'down',  '1Mbps下行带宽每小时价格', 0.01)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽无限制价格', 3, 13, '元', 'unlimit up',  '上行带宽无限制每小时价格', 0.02)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽无限制价格', 3, 13, '元',  'unlimit down', '下行带宽无限制每小时价格', 0.02)
go

update om_control_function set control = '0' where id = 'charge_switch_control'
update om_control_function set control = '0' where id = 'charge_mail_control'

go

use irosrelation
go
ALTER TABLE vmware_flavors replace is_public DEFAULT 1
go

use zxinsys
go
exec proc_res_op_function 0, 1, 1396, 139620,'设备规格'
exec proc_res_op_function 0, 1, 1396, 139621,'物理设备'
exec proc_res_op_function 0, 1, 1396, 139622,'数据字典'
go

-- 默认不显示
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139620 and servicekey='uniportal'
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139621 and servicekey='uniportal'
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139622 and servicekey='uniportal'
go

exec zxinsys..proc_add_res_definition 'PH_DEVICE', '物理机', 'ROOT', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_iros_phdevice', '', null
exec zxinsys..proc_add_res_definition 'IROS_VDC', '租户', 'PH_DEVICE', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_iros_irosvdc', '', null
exec zxinsys..proc_add_res_definition 'PH_COMPANY', '厂商', 'IROS_VDC', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_phcompany', '', null
exec zxinsys..proc_add_res_definition 'PH_MACHINE', '单个物理机', 'PH_COMPANY', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_phmachine', '', null

go

use iros
go

delete from om_control_function where id = 'phydevice_switch_control'
insert into om_control_function values ('phydevice_switch_control', '资产管理开关','0') -- 0、关闭1、开启
go

if (exists(select 1 from sysobjects where name = 'common_dict_catalog'))
	drop table common_dict_catalog
go
create table common_dict_catalog 
(
	typeid   			varchar(100)	not null,	
	typename			varchar(200)	not null,	
	parenttypeid   		varchar(100)	null,		
	visiableflag   		varchar(10)	default '1' null,		
	editflag      		varchar(10)	default '0' null,		
	constraint PK_COMMON_DICT_CATALOG primary key clustered (typeid)
)
go

if (exists(select 1 from sysobjects where name = 'common_dict_item'))
	drop table common_dict_item
go
create table common_dict_item 
(
	typeid   			varchar(100)	not null,	
	dataid				varchar(100)	not null,	
	dataname   			varchar(200)	not null,	
	parenttypeid		varchar(100)	null,		
	parentdataid   		varchar(100)	null,
    visiableflag        varchar(10)     default '1' null,  
    editflag            varchar(10)     default '0' null, 
	constraint PK_COMMON_DICT_ITEM primary key clustered (dataid)
)
go

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('7','操作系统大类','')
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('8','操作系统小类','7')

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-1','Microsoft Windows','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-2','SUSELINUX','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-3','TURBOLINUX','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-4','AIX','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-5','HPUNIX','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-6','HPIA','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-7','SOLARIS','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-8','REDHATLINUX','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-9','CGSL','','')

--Microsoft Windows 1 
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800101','Microsoft Windows xp','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800102','Microsoft Windows 7','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800103','Microsoft Windows 8','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800104','Microsoft Windows Server 2003,Enterprise Edition','7','os-1')
--SUSELINUX 2 
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800201','Suse Linux Enterprise 10','7','os-2')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800202','Suse Linux Enterprise 11','7','os-2')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800203','Other Linux','7','os-2')
--TURBOLINUX 3
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800301','Suse Linux Enterprise 10','7','os-3')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800302','Suse Linux Enterprise 11','7','os-3')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800303','Other Linux','7','os-3')
--AIX  4 
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800401','AIX','7','os-4')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800402','Other AIX','7','os-4')
--HPUNIX 5
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800501','HPUNIX','7','os-5')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800502','Other HPUNIX','7','os-5')
--HPIA 6
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800601','AIX','7','os-6')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800602','Other AIX','7','os-6')
--SOLARIS 7
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800701','SOLARIS','7','os-7')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800702','SOLARIS10','7','os-7')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800703','SOLARIS11','7','os-7')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800704','Other SOLARIS','7','os-7')
--REDHATLINUX 8
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800801','REDHATLINUX','7','os-8')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800802','REDHATLINUX4.2','7','os-8')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800803','REDHATLINUX6.5','7','os-8')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800804','REDHATLINUX9','7','os-8')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800805','Other REDHATLINUX','7','os-8')
--CGSL 9
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800901','CGSL','7','os-9')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800902','CGSL V3','7','os-9')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800903','CGSL V4','7','os-9')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800904','Other CGSL','7','os-9')
go

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('4','设备类型','')
go

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('4','104001','服务器','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('4','104002','个人电脑','','')
go

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('5','服务器类型','')
go

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105001','小型机','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105002','小型机','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105003','PC 服务器','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105004','台式机','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105005','瘦客户机','','')
go

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('6','厂商','')
go

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106001','联想','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106002','DELL','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106003','方正','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106004','SUN','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106005','HP','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106007','IBM','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106008','中兴(ZTE)','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106010','Intel','','')
go

if exists (select 1 from sysobjects where id = object_id('om_device_info') )
  drop table om_device_info
go
create table om_device_info
(
  devicemospecid     varchar(100)                    not null,   
  devicemospecname   varchar(200)                    not null,   
  deviceid           varchar(100)                    null,       
  devicemodel        varchar(100)                    not null,    
  specidnum          int          default 0          not null,
  devicestatus       tinyint      default 0          not null    
)
go
create unique index i_om_device_info_specid on om_device_info(devicemospecid)
go

if exists (select 1 from sysobjects where id = object_id('om_devicespec_info') )
  drop table om_devicespec_info
go
create table om_devicespec_info
(
  devicemospecid   varchar(100)                     not null,  
  devicetype       varchar(100)                     null,  
  servertype       varchar(100)                     null,   
  devdisk          varchar(50)                      null,    
  memeory          varchar(50)                      null,   
  nicmodel         varchar(100)                     null,   
  niunum           int                              null,  
  cpumodel         varchar(100)                     null,  
  cpumohz          varchar(10)                      null,   
  cpunum           int                              null,   
  cpucores         int                              null,   
  hbamodel         varchar(100)                     null,  
  hbanum           int                              null,   
  cost              decimal(20,5)           default 0           null    
)
go
create unique index i_om_devicespec_info_specid on om_devicespec_info(devicemospecid)
go

if exists (select 1 from sysobjects where id = object_id('om_phydevice_user_his') )
  drop table om_phydevice_user_his
go
create table om_phydevice_user_his
(
  entid            varchar(100)                    not null,   
  userid           int           default 0         null,       
  order_id         int           default 0         null,   
  order_code       varchar(64)                     null,   
  hostname         varchar(50)                     null,   
  desciption       varchar(100)                    null,   
  purchasedate     datetime                        null,   
  enddate          datetime                        null,   
  opertiondivid    varchar(10)                     null,   
  opertiongroupid  varchar(10)                     null,   
  userip           varchar(100)                    null,   
  managername      varchar(50)                     null,   
  managerpwd       varchar(50)                     null,   
  operid           varchar(50)                     null,   
  opertime         datetime                        null,   
  vdcid            varchar(64)                     not null   
)
go

if exists (select 1 from sysobjects where id = object_id('om_phydevice_info') )
  drop table om_phydevice_info
go
create table om_phydevice_info
(
  entid            varchar(100)                    not null,   
  entname          varchar(100)                    not null,   
  devicemospecid   varchar(100)                    not null,  
  --areaid           varchar(200)                    null,   
  deviceid         varchar(200)                    null,   
  fixedassetnum    varchar(200)                    null,   
  systemnum        varchar(200)                    null,  
  productmnum      varchar(200)                    null,   
  purchasedate     date                            null,  
  assurancetime    int                             null,  
  assurancedesc    varchar(200)                    null,      
  location         varchar(200)                    null,  
  locationdesc     varchar(50)                     null,  
  upframenum       varchar(50)                     null,      
  roundframenum    varchar(50)                     null,       
  slotnum          varchar(50)                     null,      
  ipmiip           varchar(100)                    null,   
  ipmiuser         varchar(50)                     null,   
  ipmipwd          varchar(50)                     null,   
  status           int             default 0       null,  
  phstatus         int             default 0       null,  
  operid           varchar(50)                     null,      
  opertime         date                            null,         
  hand_over        varchar(10)                     null,      
  uuid             varchar(100)                    null,  
  is_measure       int             default 0       null   
)
go
create index i_om_phydevice_info_specid on om_phydevice_info(devicemospecid)
go
create unique index i_om_phydevice_info_entid on om_phydevice_info(entid)
go

if exists (select 1 from sysobjects where id = object_id('om_phydevice_user') )
  drop table om_phydevice_user
go
create table om_phydevice_user
(
  entid            varchar(100)                    not null,   
  userid           int           default 0         null,       
  order_id         int           default 0         null,  
  order_code       varchar(64)                     null,   
  hostname         varchar(64)                     null,  
  desciption       varchar(100)                    null,  
  purchasedate     datetime                        null,   
  enddate          datetime                        null,  
  opertiondivid    varchar(10)                     null,   
  opertiongroupid  varchar(10)                     null,  
  userip           varchar(100)                    null,  
  managername      varchar(50)                     null,  
  managerpwd       varchar(50)                     null,  
  operid           varchar(50)                     null,   
  opertime         datetime                        null,   
  vdcid            varchar(64)                     not null   
)
go

create unique index i_om_phydevice_user_entid on om_phydevice_user(entid)
go

create index i_om_phydevice_user_order_id on om_phydevice_user(order_id)
go

if exists(select 1 from sysobjects where id = object_id('ent_iros_phdevice'))
   drop table ent_iros_phdevice 
go
create table ent_iros_phdevice
(	
    entid                varchar(200)                    not null,  --物理大类ID,所有物理机均挂靠在上面
    entname              varchar(200)                    null,      ---名字
    entrid               varchar(200)                    not null,  ---固定
    parentrid            varchar(100)                    not null,  ---固定
    parententid          varchar(200)                    not null,  ---母节点ID,挂在根目录
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
)
go
create unique index i_ent_iros_phdevice_entid on ent_iros_phdevice(entid)
go

delete from ent_iros_phdevice
go

insert into ent_iros_phdevice (entid,entname,entrid,parentrid,parententid) values ('101','物理机','PH_DEVICE','ROOT','ROOT')
go


if exists(select 1 from sysobjects where id = object_id('ent_iros_irosarea'))
drop table ent_iros_irosarea 
go
create table ent_iros_irosarea 
(
    entid                varchar(200)                    not null,  ---物理机区域ID,标识
    entname              varchar(200)                    null,      ---区域名
    entrid               varchar(200)                    not null,  ---固定标识
    parentrid            varchar(100)                    not null,  ---固定标识
    parententid          varchar(200)                    not null,  ---挂载在root之下
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
)
go
create unique index i_ent_iros_irosarea_entid on ent_iros_irosarea(entid)
go

if exists(select 1 from sysobjects where id = object_id('ent_phcompany'))
   drop table ent_phcompany 
go
create table ent_phcompany
(
    entid                varchar(200)                    not null,  --厂商标识ID,HP，IBM等
    entname              varchar(200)                    null,      --厂商名字
    entrid               varchar(200)                    not null,  --固定不变
    parentrid            varchar(100)                    not null,  --固定不变
    parententid          varchar(200)                    not null,  --母节点ID
    entip                varchar(100)                    null,      --扩展
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
)
go
create unique index i_ent_phcompany_entid on ent_phcompany(entid)
go


--ommp资源树 --单个物理机 和物理机属性表关联
if exists(select 1 from sysobjects where id = object_id('ent_phmachine'))
  drop table ent_phmachine 
go
-- ostype 1:NT 2:SUSELINUX 3:TURBOLINUX 4:AIX 5:HPUNIX 6:HPIA 7:SOLARIS 8 REDHATLINUX 9:CGSL
create table ent_phmachine  
(
    entid                varchar(200)                    not null,  --单个物理机ID与实体om_phydevice_info相关联
    entname              varchar(200)                    null,      --物理机名称与实体om_phydevice_info相关联
    entrid               varchar(200)                    not null,  --固定数据
    parentrid            varchar(100)                    not null,  --固定数据
    parententid          varchar(200)                    not null,  --母节点ID,挂在ent_phcompany的entid上面
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null,
	  ostype               numeric(10)                     null,
    phyid                varchar(100)                    null   --physicial id assiociate with table ent_phmachine	  
)
go
create unique index i_ent_phmachine_entid on ent_iros_irosarea(entid)
go

delete from om_order_process where process_id = 3
delete from om_order_process_config where process_id = 3
delete from om_res_order_process_rel where res_type = 2
go

insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(3, '物理机审批流程', '适用于物理机申请审批流程', 1, 0, 0)

insert into om_order_process_config values (3, 1, '审批', null, '已提交', '待交付', 0)
insert into om_order_process_config values (3, 2, '交付', null, '待交付', '正常关闭', 0)
insert into om_order_process_config values (3, -2, '异常结束', null, '异常结束', '异常结束', 0)
insert into om_order_process_config values (3, -1, '审批拒绝', null, '审批拒绝', '审批拒绝', 0)
insert into om_order_process_config values (3, 0, '正常关闭', null, '正常关闭', '正常关闭', 0)

insert into om_res_order_process_rel (res_type, process_id) values(2, 3)


if exists (select 1 from sysobjects where id = object_id('sp_web_add_deviceinfo'))
   drop procedure sp_web_add_deviceinfo
go
create procedure sp_web_add_deviceinfo
(
   @v_i_deviceid           varchar(100),  
   @v_i_devicemodel        varchar(100),   
   @v_i_devicemospecid     varchar(100),   
   @v_i_devicemospecname   varchar(200),   
   @v_i_devicetype         varchar(10),   
   @v_i_servertype         varchar(10),  
   @v_i_devdisk            varchar(50), 
   @v_i_memeory            varchar(50), 
   @v_i_nicmodel           varchar(100), 
   @v_i_niunum             int        ,   
   @v_i_cpumodel           varchar(100),   
   @v_i_cpumohz            varchar(10),  
   @v_i_cpunum             int        ,   
   @v_i_cpucores           int        ,  
   @v_i_hbamodel           varchar(100),   
   @v_i_hbanum             int,           
   @v_i_cost               decimal(20,5)   
)  
as
  declare  @v_devicemospecid      varchar(100)
  declare  @v_devicestatus        tinyint      
  declare  @v_specidnum           int        
begin  
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_devicestatus = 0
  select  @v_specidnum = 0
  if exists(select 1 from om_devicespec_info where devicemospecid = @v_devicemospecid)
  begin
    select 1011
    return
  end

  if exists(select 1 from om_devicespec_info where devicemospecid = @v_devicemospecid)
  begin
    select 1011
    return
  end
 
  if exists(select 1 from om_device_info where deviceid = @v_i_deviceid and devicemodel = @v_i_devicemodel and devicemospecname = @v_i_devicemospecname)
  begin
    select 1011
    return
  end

  begin tran
  	insert into om_device_info( devicemospecid, deviceid, devicemodel,devicemospecname ,specidnum,devicestatus)
  	       values(@v_devicemospecid, @v_i_deviceid, @v_i_devicemodel,  @v_i_devicemospecname, @v_specidnum ,@v_devicestatus)
    if @@error<>0
    begin
      rollback tran
      select 1001
      return
    end
    
    insert into om_devicespec_info (devicemospecid ,devicetype ,servertype ,devdisk ,memeory ,nicmodel ,niunum ,
                     cpumodel ,cpumohz ,cpunum ,cpucores ,hbamodel ,hbanum, cost)
           values (@v_devicemospecid ,@v_i_devicetype ,@v_i_servertype ,@v_i_devdisk ,@v_i_memeory ,@v_i_nicmodel ,@v_i_niunum ,
                  @v_i_cpumodel ,@v_i_cpumohz ,@v_i_cpunum ,@v_i_cpucores ,@v_i_hbamodel ,@v_i_hbanum, @v_i_cost)  
    if @@error<>0              
    begin
      rollback tran
      select 1001
      return
    end

  commit tran

  select  1
  return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_mod_deviceinfo'))
   drop procedure sp_web_mod_deviceinfo
go
create procedure sp_web_mod_deviceinfo
(
   @v_i_deviceid           varchar(100),   
   @v_i_devicemodel        varchar(100),   
   @v_i_devicemospecid     varchar(100),  
   @v_i_devicemospecname   varchar(200),  
   @v_i_devicetype         varchar(10),  
   @v_i_servertype         varchar(10),  
   @v_i_devdisk            varchar(50),   
   @v_i_memeory            varchar(50),  
   @v_i_nicmodel           varchar(10),   
   @v_i_niunum             int        ,   
   @v_i_cpumodel           varchar(10),  
   @v_i_cpumohz            varchar(10),    
   @v_i_cpunum             int        ,  
   @v_i_cpucores           int        ,  
   @v_i_hbamodel           varchar(10),  
   @v_i_hbanum             int,          
   @v_i_cost               decimal(20,5)  
)  
as
  declare  @v_devicemospecid      varchar(100)
begin  
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  if not exists(select 1 from om_devicespec_info where devicemospecid = @v_devicemospecid)
  begin
    select 1012
    return
  end

  if not exists(select 1 from om_device_info where devicemospecid = @v_devicemospecid)
  begin
    select 1012
    return
  end
  
  update om_devicespec_info set devicetype = @v_i_devicetype ,servertype = @v_i_servertype,devdisk = @v_i_devdisk,
           memeory = @v_i_memeory, nicmodel = @v_i_nicmodel, niunum = @v_i_niunum ,cpumodel = @v_i_cpumodel,
           cpumohz = @v_i_cpumohz, cpunum = @v_i_cpunum, cpucores = @v_i_cpucores,hbamodel = @v_i_hbamodel,
           hbanum = @v_i_hbanum, cost = @v_i_cost
         where devicemospecid = @v_devicemospecid
  if @@error<>0
  begin
    select 1001
    return
  end

  select  1
  return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_del_deviceinfo'))
   drop procedure sp_web_del_deviceinfo
go
create procedure sp_web_del_deviceinfo
(
   @v_i_devicemospecid     varchar(100)  
)  
as
  declare  @v_devicemospecid      varchar(100)
  declare  @v_specidnum           int        
begin  
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_specidnum = 0
    
  select @v_specidnum = specidnum from om_device_info where devicemospecid = @v_devicemospecid
  if @@rowcount = 0
  begin
    select  @v_specidnum = 0
  end 
  
  if (@v_specidnum = 0)
  begin
	    begin tran
	  	delete from om_device_info where devicemospecid = @v_devicemospecid
	    if @@error<>0
	    begin
	      rollback tran
	      select 1001
	      return
	    end
	    
	  	delete from om_devicespec_info where devicemospecid = @v_devicemospecid
	    if @@error<>0
	    begin
	      rollback tran
	      select 1001
	      return
	    end	
	  commit tran
  end
  else 
  begin
  	update om_device_info set devicestatus = 1  where devicemospecid = @v_devicemospecid
  	if @@error<>0
	  begin
	    select 1001
	    return
	  end	 	
  end	
	
  select  1
  return
end
go
if exists (select 1 from sysobjects where id = object_id('sp_web_add_phymachineinfo'))
   drop procedure sp_web_add_phymachineinfo
go
create procedure sp_web_add_phymachineinfo
(
  @v_i_entid            varchar(100), 
  @v_i_devicemospecid   varchar(100), 
  --@v_i_areaid           varchar(200), 
  @v_i_fixedassetnum    varchar(200),
  @v_i_systemnum        varchar(200), 
  @v_i_productmnum      varchar(200), 
  @v_i_purchasedate     date,        
  @v_i_assurancetime    int,          
  @v_i_assurancedesc    varchar(200), 
  @v_i_location         varchar(200), 
  @v_i_locationdesc     varchar(50) , 
  @v_i_upframenum       varchar(50) , 
  @v_i_roundframenum    varchar(50) , 
  @v_i_slotnum          varchar(50) , 
  @v_i_ipmiip           varchar(100), 
  @v_i_ipmiuser         varchar(50) , 
  @v_i_ipmipwd          varchar(50) , 
  @v_i_status           int         , 
  @v_i_operid           varchar(50) ,   
  @v_i_entname          varchar(200),           
  @v_i_ommpid           varchar(200)     
)  
as
  declare  @v_entid               varchar(100)
  declare  @v_devicemospecid      varchar(100)
  declare  @v_opertime            date
  declare  @v_deviceid            varchar(200)  
  declare  @v_devicename          varchar(200)   
  declare  @v_phstatus            int          
begin  
  select  @v_entid = ltrim(rtrim(@v_i_entid))	
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_opertime = getdate()
  select  @v_phstatus = 9
  

  select @v_deviceid = deviceid from om_device_info where devicemospecid = @v_i_devicemospecid
  if @@rowcount = 0
  begin
    select 3001
    return
  end 
  select @v_devicename = dataname from common_dict_item where dataid = @v_deviceid
  if @@rowcount = 0
  begin
    select 3006
    return
  end 
   
  if exists(select 1 from om_phydevice_info where entid = @v_entid)
  begin
    select 3001
    return
  end  

  if exists(select 1 from om_phydevice_info where entname = @v_i_entname)
  begin
    select 3001
    return
  end

  if exists(select 1 from om_phydevice_info where fixedassetnum = @v_i_fixedassetnum)
  begin
    select 3003
    return
  end

  if exists(select 1 from om_phydevice_info where systemnum = @v_i_systemnum)
  begin
    select 3004
    return
  end
  
    if exists(select 1 from om_phydevice_info where productmnum = @v_i_productmnum)
  begin
    select 3005
    return
  end

  begin tran
  	insert into om_phydevice_info (entid, entname,devicemospecid ,deviceid ,fixedassetnum ,systemnum ,productmnum ,purchasedate ,
                       assurancetime ,assurancedesc ,location ,locationdesc ,upframenum ,roundframenum ,
                      slotnum ,ipmiip ,ipmiuser ,ipmipwd ,status ,phstatus ,operid , opertime)
  	       values(@v_entid ,@v_i_entname,@v_devicemospecid,@v_deviceid, @v_i_fixedassetnum ,@v_i_systemnum ,@v_i_productmnum,@v_i_purchasedate, 
                  @v_i_assurancetime ,@v_i_assurancedesc  ,@v_i_location ,@v_i_locationdesc ,@v_i_upframenum ,@v_i_roundframenum ,
                  @v_i_slotnum ,@v_i_ipmiip ,@v_i_ipmiuser ,@v_i_ipmipwd ,@v_i_status, @v_phstatus ,@v_i_operid,@v_opertime)
    if @@error<>0
    begin
      rollback tran
      select 1001
      return
    end
    
  commit tran

  begin
  	update om_device_info set specidnum = specidnum + 1  where devicemospecid = @v_devicemospecid
  	if @@error<>0
	  begin
	    select 1001
	    return
	  end	 	
  end	 

  select  1
  return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_mod_phymachineinfo'))
   drop procedure sp_web_mod_phymachineinfo
go
create procedure sp_web_mod_phymachineinfo
(
  @v_i_entid            varchar(100), 
  @v_i_devicemospecid   varchar(100), 
  --@v_i_areaid           varchar(200), 
  @v_i_fixedassetnum    varchar(200), 
  @v_i_systemnum        varchar(200), 
  @v_i_productmnum      varchar(200), 
  @v_i_purchasedate     date,         
  @v_i_assurancetime    int,          
  @v_i_assurancedesc    varchar(200), 
  @v_i_location         varchar(200),
  @v_i_locationdesc     varchar(50) , 
  @v_i_upframenum       varchar(50) , 
  @v_i_roundframenum    varchar(50) , 
  @v_i_slotnum          varchar(50) , 
  @v_i_ipmiip           varchar(100), 
  @v_i_ipmiuser         varchar(50) , 
  @v_i_ipmipwd          varchar(50) , 
  @v_i_status           int         , 
  @v_i_operid           varchar(50) , 
  @v_i_entname          varchar(200)                            
)  
as
  declare  @v_entid               varchar(100)
  declare  @v_devicemospecid      varchar(100)
  declare  @v_opertime            date
begin  
  select  @v_entid = ltrim(rtrim(@v_i_entid))	
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_opertime = getdate()
  if not exists(select 1 from om_phydevice_info where entid = @v_entid)
  begin
    select 3011
    return
  end  
  update  om_phydevice_info set devicemospecid = @v_devicemospecid, fixedassetnum = @v_i_fixedassetnum, systemnum = @v_i_systemnum,
               productmnum = @v_i_productmnum, purchasedate = @v_i_purchasedate,  assurancetime = @v_i_assurancetime,
                assurancedesc = @v_i_assurancedesc,  location = @v_i_location, locationdesc = @v_i_locationdesc, upframenum = @v_i_upframenum,
                roundframenum = @v_i_roundframenum ,  slotnum = @v_i_slotnum,  ipmiip = @v_i_ipmiip, ipmiuser = @v_i_ipmiuser,
                ipmipwd = @v_i_ipmipwd, operid = @v_i_operid, opertime = @v_opertime
               where entid = @v_entid  
  select  1
  return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_del_phydevice'))
   drop procedure sp_web_del_phydevice
go
create procedure sp_web_del_phydevice
(
  @v_i_entid            varchar(100)                           
)  
as
  declare  @v_entid               varchar(100)
  declare  @v_parentrid           varchar(100)  
  declare  @v_status              int           
  declare  @v_devicemospecid      varchar(100)    
begin  
  select  @v_entid = ltrim(rtrim(@v_i_entid))	
  select  @v_status = 0 
  
  select @v_status = status ,@v_devicemospecid = devicemospecid from om_phydevice_info where entid = @v_entid 
  if @@rowcount = 0
  begin
    select 3023
    return  
  end	
  
  if (@v_status = 1 or @v_status = 2 or @v_status = 9 or @v_status = 10)
  begin
    select 3022
    return  
  end	
   
  if (@v_status = 0)
  begin
    begin tran
    delete from  om_phydevice_info  where entid = @v_entid  
    if @@error<>0
    begin
      rollback tran
      select 1001
      return
    end
     
    delete from  ent_phmachine where phyid = @v_entid 
    if @@error<>0                    
    begin
      rollback tran
      select 1001
      return
    end
    
    commit tran  
  end	
  else
  begin  
  	update om_phydevice_info set status = 9 where entid = @v_entid 
  	if @@error<>0                    
    begin
      select 1001
      return
    end
  end
   
  begin
  	update om_device_info set specidnum = specidnum - 1  where devicemospecid = @v_devicemospecid
  	if @@error<>0
	  begin
	    select 1001
	    return
	  end	 	
  end	 

  select  1
  return
end
go

-- 物理机订单审批
if exists (select 1 from sysobjects where id = object_id('sp_web_audit_order'))
   drop procedure sp_web_audit_order
go
create procedure sp_web_audit_order
(
  @v_i_orderid          int,              --订单号
  @v_i_entid            varchar(100),     --physicial id 唯一索引
  @v_i_purchasedate     datetime,         --2017.12.12
  @v_i_enddate          datetime,         --2017.12.12
  @v_i_opertiongroupid  varchar(10),       --操作系统小类
  @v_i_operid           varchar(50)        --操作员ID 
)  
as
    declare  @v_vdcid              varchar(64)
    declare  @v_order_code         varchar(64)  
    declare  @v_opertime           date
    declare  @v_applicant_id       int
    declare  @v_opertiondivid      varchar(10)       --操作系统大类
begin  
	select  @v_opertime = getdate()  
	select  @v_opertiondivid = '1'  ---默认操作系统大类为1
	  
    select  @v_order_code = order_code,@v_applicant_id = user_id from om_order where order_id = @v_i_orderid
    if @@rowcount = 0
    begin
        select 4001
        return
    end 
    ---从数据字段读取
    select @v_opertiondivid = parentdataid from common_dict_item where dataid = @v_i_opertiongroupid
    if @@rowcount = 0
    begin
        select 5001
    end 
  
    if exists(select 1 from om_phydevice_user where entid = @v_i_entid)
    begin
        select 5002
        return
    end
  
    insert into om_phydevice_user (entid ,userid ,order_id,order_code ,hostname ,desciption ,purchasedate ,enddate ,opertiondivid ,
                 opertiongroupid ,userip ,managername ,managerpwd ,operid ,opertime, vdcid)
         values(@v_i_entid ,@v_applicant_id,@v_i_orderid, @v_order_code,'' ,'' ,@v_i_purchasedate  ,
                @v_i_enddate ,@v_opertiondivid ,@v_i_opertiongroupid ,'' ,
                '' ,'' ,@v_i_operid ,@v_opertime, @v_vdcid)
    if @@error<>0
    begin
        select 1001
        return
    end
  
    --更新相关物理机为已分配状态
    update om_phydevice_info set status = 1 where entid = @v_i_entid
    if @@error<>0
    begin
        select 1001
        return
    end                  
    select  1
    return
end
go


---物理机订单拒绝交付
if exists (select 1 from sysobjects where id = object_id('sp_web_reject_orderphymachine'))
   drop procedure sp_web_reject_orderphymachine
go
create procedure sp_web_reject_orderphymachine
(
    @v_i_order_id       int         --订单号
)  
as
    declare  @v_status              int
begin  
	select  @v_status = 0
		
    update om_phydevice_info set status = @v_status from om_phydevice_info a
          where exists(select 1 from om_phydevice_user b where a.entid=b.entid and b.order_id = @v_i_order_id)
    if @@error<>0
    begin
       select 2001
       return
    end

    delete from om_phydevice_user where order_id = @v_i_order_id
    if @@error<>0
    begin
      select 2001
      return
    end
  
    select  1
    return
end
go

