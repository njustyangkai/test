use iros
go
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.02T02' where name = 'iROS'
go

use zxinalarm
go

-- iECS
exec proc_alm_code_new 2,1000001,'主机离线告警',1,13,1,22537
exec proc_alm_code_new 2,1000002,'虚拟机关闭告警',1,13,1,22537
exec proc_alm_code_new 2,1000003,'VMC数据库异常',1,13,1,22537
exec proc_alm_code_new 2,1000004,'存储库状态异常',1,13,1,22537
exec proc_alm_code_new 2,1000005,'存储库使用率超过阈值',1,13,1,22537
exec proc_alm_code_new 2,1000008,'虚机崩溃告警',8,13,1,22537
exec proc_alm_code_new 2,1000009,'虚机重启告警',8,13,1,22537
exec proc_alm_code_new 2,1000014,'存储库代理状态异常',1,13,1,22537
exec proc_alm_code_new 2,1000016,'存储库单元可访问异常',1,13,1,22537
exec proc_alm_code_new 2,1000017,'主机访问存储库目录异常',1,13,1,22537
exec proc_alm_code_new 2,1000018,'主机网络异常',1,13,1,22537
exec proc_alm_code_new 2,1000020,'虚拟机故障切换资源',1,13,1,22537
exec proc_alm_code_new 2,1000021,'光纤告警',1,13,1,22537
exec proc_alm_code_new 2,1000025,'日志空间超限',1,13,1,22537
exec proc_alm_code_new 2,1000026,'MCE硬件异常',1,13,1,22537
exec proc_alm_code_new 2,1000000,'VMC异常',1,13,1,22537
exec proc_alm_code_new 2,1000100,'DRS批量迁移失败', 8,13,1,22537
exec proc_alm_code_new 2,1000041,'主机磁盘异常', 1,13,1,22537
go
-- iECS
exec proc_alm_reason_new 2,1000001,'主机离线告警',22537 
exec proc_alm_reason_new 2,1000002,'虚拟机关闭告警',22537 
exec proc_alm_reason_new 2,1000003,'VMC数据库异常',22537 
exec proc_alm_reason_new 2,1000004,'存储库状态异常',22537 
exec proc_alm_reason_new 2,1000005,'存储库使用率超过阈值',22537 
exec proc_alm_reason_new 2,1000008,'虚机崩溃告警',22537 
exec proc_alm_reason_new 2,1000009,'虚机重启告警',22537 
exec proc_alm_reason_new 2,1000014,'存储库代理状态异常',22537 
exec proc_alm_reason_new 2,1000016,'存储库单元可访问异常',22537 
exec proc_alm_reason_new 2,1000017,'主机访问存储库目录异常',22537 
exec proc_alm_reason_new 2,1000018,'主机网络异常',22537 
exec proc_alm_reason_new 2,1000020,'虚拟机故障切换资源',22537 
exec proc_alm_reason_new 2,1000021,'光纤告警',22537 
exec proc_alm_reason_new 2,1000025,'日志空间超限',22537 
exec proc_alm_reason_new 2,1000026,'MCE硬件异常',22537 
exec proc_alm_reason_new 2,1000000,'VMC异常',22537 
exec proc_alm_reason_new 2,1000100,'DRS批量迁移失败',22537 
exec proc_alm_reason_new 2,1000041,'主机磁盘异常',22537
go