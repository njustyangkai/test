use iros
go
if (exists(select 1 from sysobjects where name = 'om_city'))
	drop table om_city
go
create table om_city 
(
	dc_id   			varchar(100)	not null,	
	city_id				varchar(100)	not null,	
	name   			    varchar(100)	not null,	
	description         text            null,
	primary key(city_id)
)
go
if (exists(select 1 from sysobjects where name = 'om_computerroom'))
	drop table om_computerroom
go
create table om_computerroom 
(
   city_id              varchar(100) not null,
   computerroom_id      varchar(100) not null,
   name                 varchar(100) not null,
   address              varchar(500) not null,
   area                 numeric(10,2) not null,
   rack_num             int not null,
   rack_rows            int not null,
   rack_columns         int not null,
   port_num             int not null,
   bandwidth            int not null,
   lease                tinyint not null,
   primary key (computerroom_id)
)
go
if (exists(select 1 from sysobjects where name = 'om_rack'))
	drop table om_rack
go
create table om_rack
(
   computerroom_id      varchar(100) not null,
   rack_id              varchar(100) not null,
   rack_code            varchar(100) not null,
   rack_spec            varchar(100) not null,
   power_num            int not null, 
   assign               tinyint not null,
   status               tinyint not null,
   rack_row             int not null,
   rack_column          int not null,
   tenantid             varchar(100),
   userid               varchar(100),
   lease                tinyint not null,
   primary key (rack_id)
)
go
if (exists(select 1 from sysobjects where name = 'om_rack_lease_history'))
	drop table om_rack_lease_history
go
create table om_rack_lease_history
(
   id                   varchar(100) not null,
   computerroom_id      varchar(100) not null,
   rack_id              varchar(100) not null,
   rack_code            varchar(100) not null,
   rack_spec            varchar(100) not null,
   power_num            int not null,
   rack_row             int not null,
   rack_column          int not null,
   tenantid             varchar(100) not null,
   userid               varchar(100) not null,
   startdate            datetime,
   enddate              datetime,
   order_id             int,
   status               tinyint
)
go
if (exists(select 1 from sysobjects where name = 'om_room_admin'))
	drop table om_room_admin
go
create table om_room_admin
(
   oper_id              decimal not null,
   dc_id                varchar(100) not null,
   city_id              varchar(100),
   computerroom_id      varchar(100)
)
go
if (exists(select 1 from sysobjects where name = 'om_ipsection'))
	drop table om_ipsection
go
create table om_ipsection
(
   name                 varchar(64)   not null, 
   id                   varchar(100)  not null,
   computerroom_id      varchar(100)  not null,
   cidr                 varchar(64)   not null,
   subnetmask           varchar(64)   not null,
   gateway              varchar(64)    null,
   dns                  varchar(255)   null,
   iptype               tinyint  not null, 
   primary key (id)
)
go
if (exists(select 1 from sysobjects where name = 'om_ippool'))
	drop table om_ippool
go
create table om_ippool
(
   id                   varchar(100)  not null,
   ipstart              varchar(50)   not null,
   ipend                varchar(50)   not null
)
go
if (exists(select 1 from sysobjects where name = 'om_ip_usage'))
	drop table om_ip_usage
go
create table om_ip_usage
(
   computerroom_id      varchar(100)  not null, 
   id                   varchar(100)  not null,
   ip                   varchar(50)   not null,
   status               tinyint not null,
   tenantid             varchar(100) null,
   userid               varchar(100) null,
   restype              tinyint null,
   resid                varchar(50) null,
   startdate            datetime null,
   enddate              datetime null,
   section_id           varchar(100) not null
)
go
if (exists(select 1 from sysobjects where name = 'om_bandwidth_config'))
	drop table om_bandwidth_config
go
create table om_bandwidth_config
(
   id                   varchar(100) not null,
   up_bandwidth         int not null,
   down_bandwidth		int not null,
   computerroom_id      varchar(100) not null,
   primary key (id)
)
go
if (exists(select 1 from sysobjects where name = 'om_bandwidth_usage'))
	drop table om_bandwidth_usage
go
create table om_bandwidth_usage
(
   computerroom_id      varchar(100) not null,
   id                   varchar(100) not null,
   bandwidth            int  not null,
   bw_mode              tinyint not null,
   bw_type              tinyint not null,
   status               tinyint not null,
   tenantid             varchar(100) not null,
   userid               varchar(100) not null,
   rack_id              varchar(100) not null,
   startdate            datetime  null,
   enddate              datetime  null,
   ips                  text not null,
   primary key (id)
)
go
if (exists(select 1 from sysobjects where name = 'om_networkdevice_info'))
	drop table om_networkdevice_info
go
create table om_networkdevice_info
(
   computerroom_id      varchar(100),  
   city_id              varchar(100),   
   rack_id              varchar(100),
   dc_id                varchar(100),
   entid                varchar(100),
   entname              varchar(100),
   devicetype           varchar(100),
   devicemodel          varchar(100),
   fixedassetnum        varchar(200),
   systemnum            varchar(200),
   productnum           varchar(200),
   purchasedate         datetime,
   assurancetime        int,
   assurancedesc        varchar(200),
   location             varchar(200),
   locationdesc         varchar(50),
   roundframenum        varchar(50),
   slotnum              varchar(50),
   is_measure           int
)
go
if (exists(select 1 from sysobjects where name = 'om_storedevice_info'))
	drop table om_storedevice_info
go
create table om_storedevice_info
(
   computerroom_id      varchar(100),  
   city_id              varchar(100),   
   rack_id              varchar(100),
   dc_id                varchar(100),
   entid                varchar(100),
   entname              varchar(100),
   devicetype           varchar(100),
   devicemodel          varchar(100),
   fixedassetnum        varchar(200),
   systemnum            varchar(200),
   productnum           varchar(200),
   purchasedate         datetime,
   assurancetime        int,
   assurancedesc        varchar(200),
   location             varchar(200),
   locationdesc         varchar(50),
   roundframenum        varchar(50),
   slotnum              varchar(50),
   is_measure           int
)
go
use zxinsys
go
delete from oper_virtual_grpdef where v_opergrpid=6124 and servicekey='uniportal'
delete from oper_virtual_grpdef where v_opergrpid=6125 and servicekey='uniportal'
delete from oper_virtual_grpdef where v_opergrpid=6126 and servicekey='uniportal'
go
proc_res_op_grpscript2 0, 1, 106, '机房管理员', '机房管理员'
go
proc_res_op_grpscript2 0, 1, 107, '机房工单管理员', '机房工单管理员'
go
proc_res_op_grpscript2 0, 1, 108, '机房工单处理人', '机房工单处理人'
go
-- 机房管理员
proc_res_op_grpdef 0, 1, 106, 11, 18102
go
proc_res_op_grpdef 0, 1, 106, 1396, 139640
go
proc_res_op_grpdef 0, 1, 106, 1396, 139610
go
proc_res_op_grpdef 0, 1, 106, 1396, 139605
go

-- 机房工单管理员
proc_res_op_grpdef 0, 1, 107, 11, 18102
go
proc_res_op_grpdef 0, 1, 107, 1396, 139610
go
proc_res_op_grpdef 0, 1, 107, 1396, 139618
go

-- 机房工单处理人
proc_res_op_grpdef 0, 1, 108, 11, 18102
go
proc_res_op_grpdef 0, 1, 108, 1396, 139610
go
proc_res_op_grpdef 0, 1, 108, 1396, 139618
go
proc_res_op_v_grpscript 0, 1, 6124, '机房管理员组'
go
proc_res_op_v_grpscript 0, 1, 6125, '机房工单管理员组'
go
proc_res_op_v_grpscript 0, 1, 6126, '机房工单处理人组'
go
proc_res_op_v_grpdef 0, 1, 6124, 106
go
proc_res_op_v_grpdef 0, 1, 6125, 107
go
proc_res_op_v_grpdef 0, 1, 6126, 108
go
proc_res_op_v_grpdef 0,1,1000,106
go
proc_res_op_v_grpdef 0,1,1001,106
go
proc_res_op_v_grpdef 0,1,1000,107
go
proc_res_op_v_grpdef 0,1,1001,107
go
proc_res_op_v_grpdef 0,1,1000,108
go
proc_res_op_v_grpdef 0,1,1001,108
go
exec proc_res_op_function 0, 1, 1396, 139640,'机房管理'
go
use iros
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.03T01' where name = 'iROS'
go
delete from resource_price where name in('带宽','互联网IP','1U','2U','4U','8U','16U','32U','64U')
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('1U', 5, 14, '元/时',  'Rack-0', '', 0.02)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('2U', 5, 14, '元/时',  'Rack-1', '', 0.04)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('4U', 5, 14, '元/时',  'Rack-2', '', 0.08)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('8U', 5, 14, '元/时',  'Rack-3', '', 0.16)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('16U', 5, 14, '元/时',  'Rack-4', '', 0.32)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('32U', 5, 14, '元/时',  'Rack-5', '', 0.64)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('64U', 5, 14, '元/时',  'Rack-6', '', 1.28)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('带宽', 5, 15, '元/Mbps',  '', '每M每小时价格', 2)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('互联网IP', 5, 16, '元/个',  '', '一个互联网IP每小时价格', 2)
go
DELETE from om_res_order_process_rel where res_type  = 5 and  process_id = 2
DELETE from om_base_service where id = 14
go
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (14, '机架租赁', 'switch_rackrent', '','提供机架整体对外出租的功能，同时提供高质量带宽宽带，互联网IP的接入，方便企业的接入。',',2,3,4,5,6,7,')
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'city_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_order')) )
begin
  exec('alter table om_order add  city_id  varchar(100) null')
end
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'order_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_ticket')) )
begin
  exec('alter table om_ticket add  order_id  int null')
end
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'order_detail_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_ticket')) )
begin
  exec('alter table om_ticket add  order_detail_id  int null')
end
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'city_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_ticket')) )
begin
  exec('alter table om_ticket add  city_id   varchar(100) null')
end
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'computerroom_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_ticket')) )
begin
  exec('alter table om_ticket add   computerroom_id  varchar(100) null')
end
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'computerroom_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_phydevice_info')) )
begin
  exec('alter table om_phydevice_info add   computerroom_id  varchar(100) null')
end
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'city_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_phydevice_info')) )
begin
  exec('alter table om_phydevice_info add   city_id  varchar(100) null')
end
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'rack_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_phydevice_info')) )
begin
  exec('alter table om_phydevice_info add   rack_id  varchar(100) null')
end
go
if not exists(select 1 from syscolumns where (syscolumns.name = 'dc_id') and (syscolumns.id IN (select id from sysobjects where name = 'om_phydevice_info')) )
begin
  exec('alter table om_phydevice_info add    dc_id  varchar(100) null')
end
go
use zxinsys
update oper_function set allowflag=0 where funcgrpid=1396 and funcid=139621 and servicekey='uniportal'
go
use iros
delete from common_dict_catalog where typeid  = '9'
delete from common_dict_item where typeid  = '9'
go
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('9','机架规格','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-0','1U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-1','2U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-2','4U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-3','8U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-4','16U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-5','32U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-6','64U','','')
go
update common_dict_item set dataname = '物理机' where typeid = '4' and dataid = '104001'
update common_dict_catalog set typename = '物理机类型' where typeid = '5'
go
delete from om_res_order_process_rel where res_type in (2,5,6,7,8)
delete from om_order_process where process_id = 3
go
insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(3, '物理资源审批流程', '适用于物理机、机架、互联网IP、局域网IP、带宽资源审批流程', 1, 1, 0)
insert into om_res_order_process_rel (res_type, process_id) values(2, 3)
insert into om_res_order_process_rel (res_type, process_id) values(5, 3)
insert into om_res_order_process_rel (res_type, process_id) values(6, 3)
insert into om_res_order_process_rel (res_type, process_id) values(7, 3)
insert into om_res_order_process_rel (res_type, process_id) values(8, 3)
go
if exists (select 1 from sysobjects where id = object_id('sp_web_mod_phymachineinfo'))
   drop procedure sp_web_mod_phymachineinfo
go
create procedure sp_web_mod_phymachineinfo
(
  @v_i_entid            varchar(100), 
  @v_i_devicemospecid   varchar(100), 
  --@v_i_areaid           varchar(200), 
  @v_i_fixedassetnum    varchar(200), 
  @v_i_systemnum        varchar(200), 
  @v_i_productmnum      varchar(200), 
  @v_i_purchasedate     date,         
  @v_i_assurancetime    int,          
  @v_i_assurancedesc    varchar(200), 
  @v_i_location         varchar(200),
  @v_i_locationdesc     varchar(50) , 
  @v_i_upframenum       varchar(50) , 
  @v_i_roundframenum    varchar(50) , 
  @v_i_slotnum          varchar(50) , 
  @v_i_ipmiip           varchar(100), 
  @v_i_ipmiuser         varchar(50) , 
  @v_i_ipmipwd          varchar(50) , 
  @v_i_status           int         , 
  @v_i_operid           varchar(50) , 
  @v_i_entname          varchar(200)                            
)  
as
  declare  @v_entid               varchar(100)
  declare  @v_devicemospecid      varchar(100)
  declare  @v_opertime            date
begin  
  select  @v_entid = ltrim(rtrim(@v_i_entid))	
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_opertime = getdate()
  if not exists(select 1 from om_phydevice_info where entid = @v_entid)
  begin
    select 3011
    return
  end  
  
  if exists(select 1 from om_phydevice_info where entid <> @v_entid and entname = @v_i_entname and status <>9)
  begin
    select 3001
    return
  end

  if exists(select 1 from om_phydevice_info where entid <> @v_entid and fixedassetnum = @v_i_fixedassetnum and status <>9)
  begin
    select 3003
    return
  end

  if exists(select 1 from om_phydevice_info where entid <> @v_entid and systemnum = @v_i_systemnum and status <>9)
  begin
    select 3004
    return
  end
  
    if exists(select 1 from om_phydevice_info where entid <> @v_entid and productmnum = @v_i_productmnum and status <>9)
  begin
    select 3005
    return
  end
  
  update  om_phydevice_info set devicemospecid = @v_devicemospecid, fixedassetnum = @v_i_fixedassetnum, systemnum = @v_i_systemnum,
               productmnum = @v_i_productmnum, purchasedate = @v_i_purchasedate,  assurancetime = @v_i_assurancetime,
                assurancedesc = @v_i_assurancedesc,  location = @v_i_location, locationdesc = @v_i_locationdesc, upframenum = @v_i_upframenum,
                roundframenum = @v_i_roundframenum ,  slotnum = @v_i_slotnum,  ipmiip = @v_i_ipmiip, ipmiuser = @v_i_ipmiuser,
                ipmipwd = @v_i_ipmipwd, operid = @v_i_operid, opertime = @v_opertime
               where entid = @v_entid  
  select  1
  return
end




