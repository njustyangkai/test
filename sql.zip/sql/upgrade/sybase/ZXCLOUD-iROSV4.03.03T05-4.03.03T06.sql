use zxinsys
go
exec proc_res_op_function 0, 1, 1396, 139601,'云资源'
go
exec proc_res_op_function 0, 1, 1396, 139602,'用户管理'
go

use irosrelation
go
if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 't_zone' and u.name = 'dbo' and o.type = 'U')
    drop table t_zone
go
create table t_zone
(
	dc_id              varchar(100) not null,
	id                 varchar(100) not null,
	name               varchar(100) not null,
	primary key (id, dc_id)
)
go

if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 't_aggregate' and u.name = 'dbo' and o.type = 'U')
    drop table t_aggregate
go
create table t_aggregate
(
	dc_id              varchar(100)  not null,
	zone_id            varchar(100)  not null,
	id                 varchar(100)  not null,
	name               varchar(100)  not null,
    metadata           varchar(1000) null,
    created_at         varchar(50)   null,
    deleted            varchar(10)   null,
    deleted_at         varchar(50)   null,
	primary key (id, dc_id)
)
go

if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 't_host' and u.name = 'dbo' and o.type = 'U')
    drop table t_host
go
create table t_host
(
	dc_id              varchar(100)  not null,
	zone_id            varchar(100)  not null,
	aggregate_id       varchar(100)  not null,
	id                 varchar(100)  not null,
	name               varchar(100)  not null,
    ip                 varchar(100)  not null,
    status             varchar(50)   null,
    hypervisor_type    varchar(50)   null,
    vcpus              int           null,
    vcpusused          int           null,
    memory             int           null,
    memoryused         int           null,
    memoryfree         int           null,    
    runningvms         int           null,
	primary key (id, name, dc_id)
)
go

if exists (select 1 from sysobjects o, sysusers u where o.uid=u.uid and o.name = 't_vm' and u.name = 'dbo' and o.type = 'U')
    drop table t_vm
go
create table t_vm
(
	dc_id              varchar(100)   not null,
	zone_id            varchar(100)   not null,
	aggregate_id       varchar(100)   not null,
    host_id            varchar(100)   not null,
	id                 varchar(100)   not null,
	name               varchar(100)   not null,
    power_state        varchar(50)    null,
    status             varchar(50)    null,
    address            text           null,
    memory             int            null,
    cpu_count          int            null,
    flavor             varchar(1000)  null,
    os_name            varchar(100)   null,
    disk_size          int            null,
    vnc_enable         varchar(10)    null,
    vnc_port           varchar(10)    null,
    vnc_password       varchar(100)   null,
    imgage             varchar(1000)  null,
    task_state         varchar(50)    null,
    availability_zone  varchar(100)   null,
    host               varchar(100)   null,
    hypervisorname     varchar(100)   null,
    tenant_id          varchar(100)   null,
	primary key (id, dc_id)    
)
go