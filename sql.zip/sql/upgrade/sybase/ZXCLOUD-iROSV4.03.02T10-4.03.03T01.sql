use zxinsys
go
exec proc_res_op_grpdef 0, 1, 102, 1396, 139623  
go 
exec proc_res_op_grpdef 0, 1, 103, 1396, 139623  
go
exec proc_res_op_function 0, 1, 1396, 139623,'初始化向导'
go

delete from portal_sysparam where param_name = 'cmdb_switch_control'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('cmdb_switch_control','0','CMDB控制开关','iROS','CMDB控制开关',
             4,1000,1,'0-关闭, 1-开启',1,
             '','','','','')
go

use iros
go
if exists(select 1 from sysobjects where id = object_id('om_order_forceendservers'))
    drop table om_order_forceendservers
go
create table om_order_forceendservers
(
   id       			varchar(64) not null,
   order_id             varchar(64) not null,
   instance_id          varchar(64) not null,
   dc_id           		varchar(64) not null, 
   status        		tinyint, -- 1-待删除 2-删除中 3-删除失败
   primary key (id)
)
go


if not exists(select 1 from syscolumns where (syscolumns.name = 'type') and (syscolumns.id IN (select id from sysobjects where name = 'om_service_rel')) )
begin
  exec('alter table om_service_rel add type tinyint default 1 null')
end

if exists (select * from sysobjects where id = object_id('dbo.proc_drop_om_a10_vlantag_pkey'))
    drop procedure dbo.proc_drop_om_a10_vlantag_pkey
go
create procedure proc_drop_om_a10_vlantag_pkey
as
begin
	declare @TABLE_NAME varchar(50)
	set @TABLE_NAME='om_a10_vlantag'

	declare @PK_NAME varchar(50)
	set @PK_NAME=null
	declare @sql varchar(1000)
	set @sql=null

	select @PK_NAME=name from sysindexes where indid>0 and indid<255 and status&2048=2048 and id in
		(select id from sysobjects where name=@TABLE_NAME)

	if @PK_NAME is null
		begin
			print 'pk name is null'
		end
	else
		begin
			print 'pk name is not null'
			print @PK_NAME
			select @sql='alter table '+@TABLE_NAME+' drop constraint '+@PK_NAME
			exec(@sql)
		end
end
go
exec proc_drop_om_a10_vlantag_pkey
go
drop procedure dbo.proc_drop_om_a10_vlantag_pkey
go

if exists(select 1 from sysobjects where id = object_id('om_task_instance_port'))
    drop table om_task_instance_port
go
CREATE TABLE om_task_instance_port (
    instance_id              varchar(64)      NOT NULL,
	dc_id   	           varchar(64)    	NOT NULL,
	port_id			   varchar(1024)      NOT NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_vdc_srvdir'))
    drop table om_vdc_srvdir
go
CREATE TABLE om_vdc_srvdir (
    id				int		not null,
	srvdir_id		int 	null,
	dc_id			varchar(64)		not null,
	vdc_id           numeric	not null,
	is_publish      tinyint    not null,
	parent_id		int   		null,
	template_id		int 		null,
	extra			text		null,
	primary key (id)
)
go


use zxinmeasure
go
if exists (select * from sysobjects where id = object_id('dbo.proc_stat_regiontop5server'))
    drop procedure dbo.proc_stat_regiontop5server
go

create procedure proc_stat_regiontop5server(@tName VARCHAR (64),
	@tmpTName VARCHAR (64),
	@poid VARCHAR (64),
	@dcId VARCHAR (64),
	@startTime VARCHAR (64),
	@endTime VARCHAR (64),
	@period INT)
as
begin
	   declare @vsql varchar(1000)
 
	   SELECT @vsql = 'select tmpdata.* into zxinmeasure..' + @tmpTName +
		' from (select poly.resourceid, poly.param1, max(poly.starttime) as starttime, avg(poly.statcode1) as statcode1 from 
         (select resourceid, statcode1, param1, starttime from zxinmeasure..' + @tName+ ' where param2 = ''' + @dcId +
		 ''' and starttime >= ''' + @startTime + ''' and starttime <= ''' + @endTime + ''')poly  group by resourceid, param1'
	   
	   IF (@period = 1)
	   BEGIN
		SELECT @vsql=@vsql + ', datediff(ss,''2000-01-01 16:00:00'', starttime) / 3600'
	   END
       IF (@period = 2) 
	   BEGIN
         SELECT @vsql=@vsql + ', datediff(ss,''2000-01-01 16:00:00'', starttime) / 86400'
       END
       IF (@period = 4)
	   BEGIN
         SELECT @vsql=@vsql + ', datediff(ss,''2000-01-01 16:00:00'', starttime) / 300'
       END
       SELECT @vsql=@vsql + ') tmpdata'
	   EXECUTE (@vsql)

	   SELECT @vsql = 'select tmpdata.* into zxinmeasure..' + @tmpTName + '_1' + 
		' from (select p.resourceid, p.param1, max(p.starttime) maxtime from zxinmeasure..' + @tmpTName + 
		' p group by p.resourceid, p.param1) tmpdata'
	   EXECUTE (@vsql)
	   

	   SELECT @vsql = 'select top 5 a.resourceid, a.statcode1, a.param1 from zxinmeasure..' + @tmpTName + 
		' a, zxinmeasure..' + @tmpTName + '_1 b where a.resourceid = b.resourceid and a.starttime = b.maxtime '

       IF (@poid = '1010004' or @poid = '100826')
	   BEGIN
          SELECT @vsql=@vsql + ' and a.param1 = b.param1 '
       END

       SELECT @vsql=@vsql + ' order by statcode1 desc '
       EXECUTE (@vsql)


       SELECT @vsql = 'DROP TABLE ' + @tmpTName
	   EXECUTE (@vsql)

	   SELECT @vsql = 'DROP TABLE ' + @tmpTName + '_1'
	   EXECUTE (@vsql)

end
go
