use opslog
go

if exists (select * from sysobjects where id = object_id('dbo.proc_update_columns_4_04_05_T04_to_4_04_05_T05'))
    drop procedure dbo.proc_update_columns_4_04_05_T04_to_4_04_05_T05
go

create procedure proc_update_columns_4_04_05_T04_to_4_04_05_T05
as
begin 

   declare @i int
   declare @mmdd varchar(4)
   declare @tabname varchar(20)
   declare @sql varchar(1000)  
   set @i=24

   if not exists(select 1 from syscolumns where (syscolumns.name = 'flavor') and (syscolumns.id IN (select id from sysobjects where name = 't_cost')) )
   begin
    exec('alter table t_cost add flavor varchar(500) null')
   end
   
   while @i>=1
   begin 
	  
		set @mmdd=right('0'+cast(@i as varchar(2)),2) 
		begin 
		set @tabname='t_cost_'+@mmdd         
		set @sql= 'alter table '+@tabname+ ' add flavor varchar(500) null'
		
		if not exists(select 1 from syscolumns where (syscolumns.name = 'flavor') and (syscolumns.id IN (select id from sysobjects where name = @tabname)) )
        begin
          execute (@sql)
        end	  
 
		end

	    set @i=@i-1
   end
end
go
exec proc_update_columns_4_04_05_T04_to_4_04_05_T05

use iros
go
delete from om_control_function where id in ('charge_system', 'jm_url_path', 'isware_switch_control', 'isware_path')
go
insert into om_control_function values ('charge_system','计费系统', '0')
go
insert into om_control_function values ('jm_url_path','绛门接口地址', 'http://127.0.0.5:8780/csm')
go

delete from om_base_service where id = 15
delete from om_vdc_srvdir where srvdir_id in (select id from iros.om_service_directory where switch_name = 'switch_isware')
delete from om_service_directory where switch_name = 'switch_isware'
go

use zxinsys
go
proc_res_op_grpdef 0, 1, 109, 1396, 139641
go
proc_res_op_v_grpscript 0, 1, 6141, '应用管理员组'
go
proc_res_op_v_grpdef 0, 1, 6141, 109
go
proc_res_op_v_grpdef 0,1,1000,109
go
proc_res_op_v_grpdef 0,1,1001,109
go
proc_res_op_grpscript2 0, 1, 109, '应用管理员', '应用管理员'
go
exec proc_res_op_function 0, 1, 1396, 139641,'应用管理'
go