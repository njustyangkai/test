use iros;
drop table if exists iros_version_info;
CREATE TABLE iros_version_info ( 
	name						varchar(100) 	NOT NULL,-- 名称
	version				        varchar(200) 	NULL,-- 版本
	extra						varchar(500) 	NULL
);
insert into iros_version_info (name, version, extra) values('iROS', 'ZXCLOUD-iROSV4.04.01T05', '');
insert into iros_version_info (name, version, extra) values('OMMP', 'ZXCLOUD-OMMPV6.01.13', '');
