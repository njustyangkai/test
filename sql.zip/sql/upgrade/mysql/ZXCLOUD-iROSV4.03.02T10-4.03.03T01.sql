use zxinsys;
call proc_res_op_grpdef(0, 1, 102, 1396, 139623);
call proc_res_op_grpdef(0, 1, 103, 1396, 139623);
call proc_res_op_function(0, 1, 1396, 139623,'初始化向导');

delete from portal_sysparam where param_name = 'cmdb_switch_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('cmdb_switch_control','0','CMDB控制开关','iROS','CMDB控制开关',
             4,1000,1,'0-关闭, 1-开启',1,
             '','','','','');	

use iros;			 
drop table if exists om_order_forceendservers;
create table om_order_forceendservers
(
   id       			varchar(64) not null,
   order_id             varchar(64) not null,
   instance_id          varchar(64) not null,
   dc_id           		varchar(64) not null, 
   status        		tinyint, -- 1-待删除 2-删除中 3-删除失败
   primary key (id)
);

drop procedure if exists proc_update_columns_4_03_02_T10_to_4_03_03_T01;
DELIMITER &&
create procedure proc_update_columns_4_03_02_T10_to_4_03_03_T01()
BEGIN 
	DECLARE v_count tinyint;
	DECLARE p_key varchar(20);
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_service_rel' and column_name='type';
	if(v_count < 1)  THEN 
	   alter table om_service_rel add type tinyint default 1 NULL;
	END IF; 
	
	SELECT column_key into p_key FROM information_schema.columns where table_name='om_a10_vlantag' and column_name='vlan_tag';
	if (p_key = 'PRI') THEN
		ALTER TABLE om_a10_vlantag DROP PRIMARY KEY;
	END IF; 
end&& 
DELIMITER ; 
commit;

call proc_update_columns_4_03_02_T10_to_4_03_03_T01;
drop procedure if exists proc_update_columns_4_03_02_T10_to_4_03_03_T01;

drop table if exists om_task_instance_port;
CREATE TABLE om_task_instance_port ( 
	instance_id   	varchar(64) NOT NULL,
	dc_id 	varchar(64) NOT NULL,
	port_id 	varchar(1024) NOT NULL
);

drop table if exists om_vdc_srvdir;
create table om_vdc_srvdir
(
	id				int		not null,
	srvdir_id		int 	null,
	dc_id			varchar(64)		not null,
	vdc_id           decimal	not null,
	is_publish      tinyint    not null,
	parent_id		int   		null,
	template_id		int 		null,
	extra			text		null,
	primary key (id)
);

use zxinmeasure;
DROP PROCEDURE
IF EXISTS proc_stat_regiontop5server;
DELIMITER &&

CREATE PROCEDURE proc_stat_regiontop5server (
	IN tName VARCHAR (64),
	IN tmpTName VARCHAR (64),
	IN poid VARCHAR (64),
	IN dcId VARCHAR (64),
	IN startTime VARCHAR (64),
	IN endTime VARCHAR (64),
	IN period INT
)
BEGIN
	DECLARE
		vsql text ;

	SET vsql = concat(
		'Create TEMPORARY table zxinmeasure.',
		tmpTName,
		'(select poly.resourceid, poly.param1, max(poly.starttime) as starttime, avg(poly.statcode1) as statcode1 from 
     (select resourceid, statcode1, param1, starttime from zxinmeasure.',
		tName,
		' where param2 = ',
		'''',dcId,'''',
		' and starttime >= ',
		'''',startTime,'''',
		'  and starttime <= ',
		'''',endTime,'''',
		')poly  group by resourceid, param1'
	) ;
    IF (period = 1) THEN
      SET vsql=concat(vsql,', TimeStampDiff(second,''2000-01-01 16:00:00'', starttime) DIV 3600');
    END IF;
    IF (period = 2) THEN
      SET vsql=concat(vsql,', TimeStampDiff(second,''2000-01-01 16:00:00'', starttime) DIV 86400');
    END IF;
    IF (period = 4) THEN
      SET vsql=concat(vsql,', TimeStampDiff(second,''2000-01-01 16:00:00'', starttime) DIV 300');
    END IF;
    SET vsql=concat(vsql,')');
	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

	SET vsql = concat(
		'Create TEMPORARY table zxinmeasure.',
		tmpTName,
		'_1',
		'(select p.resourceid, p.param1, max(p.starttime) maxtime from zxinmeasure.',
		tmpTName,
		' p group by p.resourceid, p.param1)'
	) ;
	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

	SET vsql = concat(
		'select a.resourceid, a.statcode1, a.param1 from  zxinmeasure.',
		tmpTName,
		' a, zxinmeasure.',
		tmpTName,
		'_1 b where a.resourceid = b.resourceid and a.starttime = b.maxtime '
	) ;

  IF (poid = '1010004' OR poid = '100826') THEN
    SET vsql=concat(vsql,' and a.param1 = b.param1 ');
  END IF;

  SET vsql=concat(vsql,' order by statcode1 desc limit 5 ');

	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

  SET vsql = concat(
		'DROP TEMPORARY TABLE IF EXISTS ',
		tmpTName
	) ;
	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

	SET vsql = concat(
		'DROP TEMPORARY TABLE IF EXISTS ',
		tmpTName,
		'_1'
	) ;
	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

	END&& 
DELIMITER ; 

COMMIT;