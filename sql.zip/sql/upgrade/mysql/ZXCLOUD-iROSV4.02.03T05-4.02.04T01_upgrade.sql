﻿use iros;

drop procedure if exists clearCidrPrimaryKey;
create procedure clearCidrPrimaryKey()
begin 
if exists(select column_key from information_schema.columns where table_schema='iros' and table_name='om_cidr' and column_name='cidr' and column_key = 'PRI')
then
select 'tt';
Alter table om_cidr drop primary key;
end if;
end;

call clearCidrPrimaryKey();

drop table if exists om_cidr;


use zxinsys;
call proc_res_op_function(0, 1, 1396, 139606,'日志管理');
call proc_res_op_function(0, 1, 1396, 139607,'备份管理');
call proc_res_op_function(0, 1, 1396, 139608,'告警地址配置');

delete from portal_sysparam where param_name = 'remote_syn_user';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_syn_user','','4A同步用户信息调用地址','iROS','4A同步用户信息调用地址',
             2,100,0,' ',1,
             '','','','','');
			 			 
delete from portal_sysparam where param_name = 'iros_backup_shell_path';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_backup_shell_path','/home/iros/db_bak','备份shell脚本放置路径','iROS','备份shell脚本放置路径',
             2,100,0,'/home/iros/db_bak',1,
             '','','','','');
			 
use iros;

drop table if exists alarm_snmp_address;
CREATE TABLE alarm_snmp_address (
   name              varchar(200)    not null,   
   port              int             not null,   
   ip                varchar(50)     not null,   
   community         varchar(200)    not null,
   type              varchar(50)      not null,
   PRIMARY KEY(name)
);
