use zxinsys;
call proc_res_op_grpdef(0, 1, 103, 1396, 139614);
call proc_res_op_grpdef(0, 1, 104, 1396, 139614);
call proc_res_op_function(0, 1, 1396, 139603,'价格管理');
call proc_res_op_function(0, 1, 1396, 139614,'易云管理');
call proc_res_op_function(0, 2, 1396, 139609,'实时告警');
call proc_res_op_function(0, 2, 1396, 139610,'历史告警');

call proc_add_res_definition('IROSOWNER', '资源属主', 'ROOT', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_owner', '', null);
call proc_add_res_definition('IROSDC', '数据中心', 'IROSOWNER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_dc', '', null);
call proc_add_res_definition('IROSCLUSTER', '集群', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_cluster', '', null);
call proc_add_res_definition('IROSHOST', '主机', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host', '', null);
call proc_add_res_definition('IROSVM', '云主机', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm', '', null);
call proc_add_oper_rmenu('IROSOWNER', 0, '同步资源', '/irosopsm/resourcemanage/tree/syncOmmpResource.action',null,1,0);

delete from portal_sysparam where param_name = 'rcs_sipmessage_url';
delete from portal_sysparam where param_name = 'receive_vnfm_feedback_timeout';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('receive_vnfm_feedback_timeout','60','主机升级通知VNFM和NFVO的超时时间(分钟)','iROS','主机升级通知VNFM和NFVO的超时时间(分钟)',
             2,1000,1,'',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'eazy_cloud_ip';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_ip','','易云数据同步IP地址','iROS','易云数据同步IP地址',
             2,1000,0,'',1,
             '','','','','');

delete from portal_sysparam where param_name = 'eazy_cloud_port';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_port','','易云数据同步端口号','iROS','易云数据同步端口号',
             2,1000,0,'',1,
             '','','','','');

delete from portal_sysparam where param_name = 'eazy_cloud_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_control','0','易云控制开关','iROS','易云控制开关',
             2,1000,1,'',1,
             '','','','','');	

delete from portal_sysparam where param_name = 'charge_tip_day';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('charge_tip_day','3','余额不足提醒','iROS','根据当前的消费，余额不能满足使用配置天数时，则进行提醒',
             1,1000,1,'3',1,
             '','','','','');   
             
delete from portal_sysparam where param_name = 'charge_mail_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('charge_mail_control','1','余额不足邮件提醒开关','iROS','余额不足时是否邮件通知用户',
             4,1000,1,'0-不通知, 1-通知',1,
             '','','','',''); 

delete from portal_sysparam where param_name = 'charge_switch_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('charge_switch_control','0','计费控制开关','iROS','计费控制开关',
             4,1000,1,'0-关闭, 1-开启',1,
             '','','','','');

			 
			 
-- 还原OMMP故障管理菜单
delete from oper_funcgrp2 where funcgrpid =3 and servicekey='uniportal';
insert into oper_funcgrp2 values (3, '3', '故障管理', 'uniportal', 0);

delete from oper_function where funcgrpid=3 and servicekey='uniportal';
insert into oper_function values (3, 12001, '1201',   '历史告警查询'       , 0, 'uniportal');
insert into oper_function values (3, 12002, '1202',   '实时观察'       , 0, 'uniportal');
insert into oper_function values (3, 12007, '1207',   '告警策略设置'   , 0, 'uniportal'); 
insert into oper_function values (3, 12008, '1208',   '告警码管理'   , 0, 'uniportal'); 
insert into oper_function values (3, 12010, '1210',   '告警参数配置'   , 0, 'uniportal');

delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =3;
insert into oper_grpdef select 1000,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and funcgrpid=3;

call proc_res_op_paratype(0 ,2, 101, '');
use zxin;
insert into oper_paratype  values('uniportal',101,'故障管理','故障管理','','','','','');
insert into oper_type values('uniportal',101,'故障管理');

			 
use iros;
drop table if exists resource_price;
CREATE TABLE resource_price (
	name        			varchar(100) 		not null,	
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
    unit                    varchar(50)         not null,
	sub_type                varchar(100)        null,
	price  			        numeric(20, 5) 		not null,
	description             varchar(100)        null   
);

insert into resource_price (name, type, unit, description, price) values ('CPU价格', 2, '元/核', '1核每小时价格', 0.05);
insert into resource_price (name, type, unit, description, price) values ('内存价格', 3, '元/GB', '1GB每小时价格', 0.05);
insert into resource_price (name, type, unit, sub_type, description, price) values ('系统盘价格', 4, '元/GB', 'Linux', 'Linux系统盘每GB每小时价格', 0.001);
insert into resource_price (name, type, unit, sub_type, description, price) values ('系统盘价格', 4, '元/GB', 'Windows', 'Windows系统盘每GB每小时价格', 0.002);
insert into resource_price (name, type, unit, description, price) values ('公网IP价格', 5, '元/个', '1个公网IP每小时价格', 0.01);
insert into resource_price (name, type, unit, description, price) values ('路由器价格', 6, '元/个', '1个路由每小时价格', 0.01);
insert into resource_price (name, type, unit, description, price) values ('卷价格', 7, '元/GB', '1GB每小时价格', 0.0006);
insert into resource_price (name, type, unit, description, price) values ('私有镜像价格', 8, '元/GB', '1GB每小时价格', 0.0006);
insert into resource_price (name, type, unit, description, price) values ('防火墙价格', 9, '元/套', '1套每小时价格', 0.1);
insert into resource_price (name, type, unit, description, price) values ('负载均衡价格', 10, '元/套', '1套每小时价格', 0.1);

drop table if exists resource_cost;
CREATE TABLE resource_cost (
	vdc_id   	            int                 not null,
	tenant_id               varchar(100)        not null,
	dc_id                   varchar(100)        not null,
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
	year                    int                 not null,
	month                   int                 not null,
	cost  			        numeric(20, 5) 		not null,
    resource_number         int                 not null,
	date  			        varchar(20) 		not null   
);
create index idx_resource_cost on resource_cost(vdc_id, tenant_id, dc_id, type, date);

drop table if exists t_task;
create table t_task
(
    id               varchar(64)   not null,
    dc_id            varchar(64)   not null,
    vdc_id           int           not null,
    tenant_id        varchar(100)  not null,
    resource_name    varchar(100)  not null,
    resource_id      varchar(100)  not null,
    resource_type    int           not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
    task_type        int           not null, -- 1.add 2.update 3.delete  
    status           int           not null, -- 1.begin 2.end 3.error    
    start_time       datetime      not null,
    end_time         datetime      null,
    operator         varchar(100)  null,
	operator_ip		 varchar(100)  null,
    description      text          null,
    primary key (id)
);

drop table if exists oandmconfig;
CREATE TABLE oandmconfig (
	id						varchar(64)			not null,
	name					varchar(255)		not null,	
	type					int					not null, -- 1.M 2.O
	description				text				null,
	url						varchar(255)		not null,
	dc_id					varchar(64)			not null,
	username				varchar(50)			not null,
	password				varchar(100)		not null,
	primary key (id)
);

drop table if exists ent_res_owner;
create table ent_res_owner(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_dc;
create table ent_res_dc(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_cluster;
create table ent_res_cluster(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_host;
create table ent_res_host(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_vm;
create table ent_res_vm(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

-- iros根
delete from ent_res_owner where entid = '1';
insert into ent_res_owner values ('1', 'iROS资源', 'IROSOWNER', 'ROOT', 'ROOT', '', 0, '', 0);

use zxinalarm;
call proc_alm_code_new(1,46087,'镜像服务器存储空间使用率较高',2,13,1,22537);
call proc_alm_code_new(1,46112,'计算服务不可用',1,13,1,22537);
call proc_alm_code_new(1,46114,'主机内存故障',1,13,1,22537);
call proc_alm_code_new(1,46115,'主机硬盘故障',2,13,1,22537);
call proc_alm_code_new(1,46119,'以太网口down',2,13,1,22537);
call proc_alm_code_new(1,46124,'内存不足',3,13,1,22537);
call proc_alm_code_new(1,46126,'主机硬盘故障(WARN)',3,13,1,22537);
call proc_alm_code_new(1,46127,'根分区使用率超额',3,13,1,22537);
call proc_alm_code_new(1,46146,'交换端口down',3,13,1,22537);
call proc_alm_code_new(1,46160,'存储离线',3,13,1,22537);
call proc_alm_code_new(1,46161,'共享存储空间不足',4,13,1,22537);
call proc_alm_code_new(1,46176,'虚拟机状态异常',4,13,1,22537);
call proc_alm_code_new(1,46178,'虚拟机状态不一致',4,13,1,22537);
call proc_alm_reason_new(1,46087,'镜像服务器存储空间使用率较高',22537);
call proc_alm_reason_new(1,46112,'计算服务不可用',22537);
call proc_alm_reason_new(1,46114,'主机内存故障',22537);
call proc_alm_reason_new(1,46115,'主机硬盘故障',22537);
call proc_alm_reason_new(1,46119,'以太网口down',22537);
call proc_alm_reason_new(1,46124,'内存不足',22537);
call proc_alm_reason_new(1,46126,'主机硬盘故障(WARN)',22537);
call proc_alm_reason_new(1,46127,'根分区使用率超额',22537);
call proc_alm_reason_new(1,46146,'交换端口down',22537);
call proc_alm_reason_new(1,46160,'存储离线',22537);
call proc_alm_reason_new(1,46161,'共享存储空间不足',22537);
call proc_alm_reason_new(1,46176,'虚拟机状态异常',22537);
call proc_alm_reason_new(1,46178,'虚拟机状态不一致',22537);


use opslog;

drop table if exists t_cost;
CREATE TABLE t_cost (
    id                      varchar(100)        not null,
	vdc_id   	            int                 not null,
	dc_id                   varchar(100)        not null,
	tenant_id               varchar(100)        not null,
	resource_id             varchar(100)        not null,  
	resource_name           varchar(100)        null,    
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
	price                   numeric(20, 5)      not null,
	cost  			        numeric(20, 5) 		not null,
    status                  varchar(100)        null,
    is_submit               int     default 1   not null,
    begin_time              datetime            not null,
    end_time                datetime            not null,
    description             text                null,
    primary key (id)
    
);

drop procedure if exists p_create_cost;
DELIMITER &&
create procedure p_create_cost()
begin
    declare i int;
	declare mmdd varchar(4);
	declare tabname varchar(20);
	declare vsql varchar(1000); 
	set i=24;	   
	while i>=1 do
	    set mmdd=right(concat('0', i), 2);
	    set tabname=concat('t_cost_',mmdd);
		SET @sql_txt = concat('drop table if exists ', tabname); 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;

		set vsql=concat('create table ', tabname,
		                  '(id                   varchar(100)        not null,',
                          'vdc_id         		 int                 not null,',
                          'dc_id                 varchar(100)        not null,',
                          'tenant_id             varchar(100)        not null,',
                          'resource_id           varchar(100)        not null,',  
                          'resource_name         varchar(100)        null,',    
                          'type                  int                 not null,',
                          'price                 numeric(20, 5)      not null,',
                          'cost  			     numeric(20, 5) 	 not null,',
                          'status                varchar(100)        null,',
                          'begin_time            datetime            not null,',
                          'end_time              datetime            not null,',
                          'description           text                null,',
                          'is_deduct             int default 0       not null,',
                          'deduct_time           datetime            null,',
                          'primary key (id))');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt; 
		
		set vsql=concat('create index idx_vdcid_',mmdd,' on ',tabname,'(vdc_id)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt; 
        set vsql=concat('create index idx_dcid_',mmdd,' on ',tabname,'(dc_id)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_dcid_tenantid_',mmdd,' on ',tabname,'(dc_id, tenant_id)');
	    SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
        set vsql=concat('create index idx_resourceid_',mmdd,' on ',tabname,'(resource_id)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;                 
		set vsql=concat('create index idx_instances_begintime_',mmdd,' on ',tabname,'(begin_time)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt; 
		set vsql=concat('create index idx_instances_endtime_',mmdd,' on ',tabname,'(end_time)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;            
	   	set i=i-1;
    end while;
end&& 
DELIMITER ; 
commit;

call p_create_cost();

drop table if exists t_deduct;
CREATE TABLE t_deduct (
    id                      varchar(100)        not null,
	vdc_id   	            int                 not null,
	value                   numeric(20, 5)      not null,
	update_time  			datetime     		not null,
	deduct_time  			datetime     		null,
    description             text                null,
    primary key (id)
);

drop procedure if exists p_create_deduct;
DELIMITER &&
create procedure p_create_deduct()
begin
    declare i int;
	declare mmdd varchar(4);
	declare tabname varchar(20);
	declare vsql varchar(1000); 
	set i=24;	   
	while i>=1 do
	    set mmdd=right(concat('0', i), 2);
	    set tabname=concat('t_deduct_',mmdd);
		SET @sql_txt = concat('drop table if exists ', tabname); 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;       
        
        set vsql=concat('create table ', tabname,
		                  '(id                   varchar(100)        not null,',
                          'vdc_id         		 int                 not null,',                          
                          'old_value             numeric(20, 5)      not null,',  
                          'value                 numeric(20, 5)      not null,',                       
                          'type                  int                 null,',
                          'update_time           datetime            not null,', 
                          'description           text                null,',
                          'primary key (id))');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt; 
		
		set vsql=concat('create index idx_vdcid_',mmdd,' on ',tabname,'(vdc_id)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;     
		set vsql=concat('create index idx_instances_updatetime_',mmdd,' on ',tabname,'(update_time)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;     
	   	set i=i-1;
    end while;
end&& 
DELIMITER ; 
commit;

call p_create_deduct();


use zxinmeasure;

delete from measure_sysset where sysno in (2071, 2072);
delete from measure_typeset where sysno in (2071, 2072);
delete from measure_itemset where sysno in (2071, 2072);
delete from measure_paramset where sysno in (2071, 2072);
commit;

insert into measure_sysset(sysno, sysname, bvisible) values(2071, '物理机性能统计', 1);
insert into measure_sysset(sysno, sysname, bvisible) values(2072, '虚拟机性能统计', 1);
commit;



insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100701, '物理机CPU使用率', 'iROSHOST', 1, 'measure_hcpudata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100702, '物理机内存使用情况', 'iROSHOST', 1, 'measure_hmemdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100703, '物理机磁盘读取速率', 'iROSHOST', 1, 'measure_hdiskreaddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100704, '物理机磁盘写入速率', 'iROSHOST', 1, 'measure_hdiskwritedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100705, '物理机磁盘大小', 'iROSHOST', 1, 'measure_hdisksizedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100706, '物理机磁盘已使用大小', 'iROSHOST', 1, 'measure_hdiskuseddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100707, '物理机网络出口带宽', 'iROSHOST', 1, 'measure_hnicoutdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100708, '物理机网络入口带宽', 'iROSHOST', 1, 'measure_hnicindata', 2, 1, 1);
commit;

insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100701, 1, '物理机CPU使用率', 'statcode1', 'measure_hcpudata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100702, 1, '物理机内存使用情况', 'statcode1', 'measure_hmemdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100703, 1, '物理机磁盘读取速率', 'statcode1', 'measure_hdiskreaddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100704, 1, '物理机磁盘写入速率', 'statcode1', 'measure_hdiskwritedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100705, 1, '物理机磁盘大小', 'statcode1', 'measure_hdisksizedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100706, 1, '物理机磁盘已使用大小', 'statcode1', 'measure_hdiskuseddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100707, 1, '物理机网络出口带宽', 'statcode1', 'measure_hnicoutdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100708, 1, '物理机网络入口带宽', 'statcode1', 'measure_hnicindata', 3, 1);
commit;

insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100701, 1, 'CPU名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100701, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100702, 1, '内存名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100702, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100703, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100703, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100704, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100704, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100705, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100705, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100706, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100706, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100707, 1, '网卡名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100707, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100708, 1, '网卡名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100708, 2, 'DCID', 'param2', 0);
commit;
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100721, '虚拟机CPU使用率', 'iROSVM', 1, 'measure_vcpudata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100722, '虚拟机内存使用情况', 'iROSVM', 1, 'measure_vmemdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100723, '虚拟机磁盘读取速率', 'iROSVM', 1, 'measure_vdiskreaddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100724, '虚拟机磁盘写入速率', 'iROSVM', 1, 'measure_vdiskwritedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100725, '虚拟机磁盘大小', 'iROSVM', 1, 'measure_vdisksizedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100726, '虚拟机网络出口带宽', 'iROSVM', 1, 'measure_vnicoutdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100727, '虚拟机网络入口带宽', 'iROSVM', 1, 'measure_vnicindata', 2, 1, 1);
commit;
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100721, 1, '虚拟机CPU使用率', 'statcode1', 'measure_vcpudata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100722, 1, '虚拟机内存使用情况', 'statcode1', 'measure_vmemdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100723, 1, '虚拟机磁盘读取速率', 'statcode1', 'measure_vdiskreaddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100724, 1, '虚拟机磁盘写入速率', 'statcode1', 'measure_vdiskwritedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100725, 1, '虚拟机磁盘大小', 'statcode1', 'measure_vdisksizedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100726, 1, '虚拟机网络出口带宽', 'statcode1', 'measure_vnicoutdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100727, 1, '虚拟机网络入口带宽', 'statcode1', 'measure_vnicindata', 3, 1);
commit; 
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100721, 1, 'CPU名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100721, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100722, 1, '内存名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100722, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100723, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100723, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100724, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100724, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100725, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100725, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100726, 1, '网卡名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100726, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100727, 1, '网卡名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100727, 2, 'DCID', 'param2', 0);
commit;

drop procedure if exists p_create_table;
DELIMITER &&
create procedure p_create_table(in vname varchar(50))
begin
		declare i int;
	    declare mmdd varchar(4);
		declare tabname varchar(50);
		declare vsql varchar(4000);
 
		set i=24;
		while i>=1 do
			set mmdd=right(concat('0', i), 2);
			set tabname=concat(vname,mmdd);
            SET @sql_txt = concat('drop table if exists ', tabname); 
            PREPARE stmt FROM @sql_txt; 
		    EXECUTE stmt;
			  
			set vsql=concat('create table ',tabname,
		                     '(starttime      datetime not null,',
						     'endtime         datetime null,',
							 'resourcetype    varchar(255) not null,',
						     'resourceid      varchar(200) not null,',
						     'param1          varchar(200) null,',
						     'param2          varchar(200) null,',
							 'statcode1       float null)');
		
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt; 
		
		       
			set vsql=concat('create index idx_starttime_',tabname,' on ',tabname,'(starttime)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_resourceid_',tabname,' on ',tabname,'(resourceid)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_param1_',tabname,' on ',tabname,'(param1)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_param2_',tabname,' on ',tabname,'(param2)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
		set i=i-1;
		end while;
end&& 
DELIMITER ; 
commit;

call p_create_table('measure_vcpudata');
call p_create_table('measure_vmemdata');
call p_create_table('measure_vdiskreaddata');
call p_create_table('measure_vdiskwritedata');
call p_create_table('measure_vdisksizedata');
call p_create_table('measure_vnicoutdata');
call p_create_table('measure_vnicindata');

call p_create_table('measure_hcpudata');
call p_create_table('measure_hmemdata');
call p_create_table('measure_hdiskreaddata');
call p_create_table('measure_hdiskwritedata');
call p_create_table('measure_hdisksizedata');
call p_create_table('measure_hdiskuseddata');
call p_create_table('measure_hnicoutdata');
call p_create_table('measure_hnicindata');


-- 建立业务侧统计项表

drop table if exists ros_ptypedef;
create table ros_ptypedef (
   res_type             varchar(100)                   not null,
   poid                 varchar(20)                    not null,
   poname               varchar(128)                   not null,
   tablename            varchar(32)                    not null,
   bvisible             tinyint                        not null,
   isrealtime           tinyint                        not null,
   extrastr             varchar(255)                   null,
   primary key (res_type, poid)
);


drop table if exists ros_pitemdef;
create table ros_pitemdef (
   dc_type              integer                        not null,
   poid                 varchar(20)                    not null,
   pitemid              integer                        not null,
   pitemname            varchar(128)                   not null,
   pitemfield           varchar(128)                   not null,
   pitemutil            varchar(32)                    not null,
   datatype             tinyint                        not null,
   bvisible             tinyint                        not null,
   extrastr             varchar(256)                   null,
   primary key (poid, pitemid)
);

drop table if exists ros_data_lasttime;
create table ros_data_lasttime (
   dc_id                varchar(100)                   not null,
   poid                 varchar(20)                    not null,
   pitemid              integer                        not null,
   lasttime             datetime                       null,
   primary key (dc_id, poid, pitemid)
);

drop procedure if exists p_create_table;
DELIMITER &&
create procedure p_create_table(in vname varchar(50))
begin
		declare i int;
	    declare mmdd varchar(4);
		declare tabname varchar(20);
		declare vsql varchar(1000);
 
		set i=24;
		while i>=1 do
			set mmdd=right(concat('0', i), 2);
			set tabname=concat(vname,mmdd);
            SET @sql_txt = concat('drop table if exists ', tabname); 
            PREPARE stmt FROM @sql_txt; 
		    EXECUTE stmt;
			  
			set vsql=concat('create table ',tabname,
		                     '(time            datetime not null,',
						     'res_type         varchar(100) null,',
							 'dc_id            varchar(100) not null,',
						     'res_id           varchar(100) not null,',
						     'moc_id           varchar(100) null,',
							 'pitemid          integer null,',
							 'usage_value      float null)');
		
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt; 
		
		       
			set vsql=concat('create index idx_time_',tabname,' on ',tabname,'(time)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_res_id_',tabname,' on ',tabname,'(res_id)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_moc_id_',tabname,' on ',tabname,'(moc_id)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
		set i=i-1;
		end while;
end&& 
DELIMITER ; 
commit;


call p_create_table('data_vm_cpu');
call p_create_table('data_vm_mem');
call p_create_table('data_vm_disk'); 
call p_create_table('data_vm_nic');
call p_create_table('data_host_cpu');
call p_create_table('data_host_mem');
call p_create_table('data_host_disk'); 
call p_create_table('data_host_nic');

-- iecs
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100821', '虚拟机CPU性能', 'data_vm_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100824', '虚拟机磁盘性能', 'data_vm_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100826', '虚拟机网卡性能', 'data_vm_nic', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100801', '物理机CPU性能', 'data_host_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100802', '物理机内存性能', 'data_host_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100803', '物理机磁盘性能', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100806', '物理机网卡性能', 'data_host_nic', 1, 0);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100821', 2, '虚拟机CPU使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 2, '虚拟机磁盘读取速率', '', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 6, '虚拟机磁盘写入速率', '', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 2, '虚拟机网络出口带宽', '', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 6, '虚拟机网络入口带宽', '', 'B/s', 2, 1);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100801', 2, '物理机CPU使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100802', 2, '物理机内存使用情况', '', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100803', 2, '物理机磁盘已使用大小', '', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 30, '物理机端口流出速率', '', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 26, '物理机端口流入速率', '', 'B/s', 2, 1);

-- openstack
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010001', '虚拟机CPU性能', 'data_vm_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010002', '虚拟机内存性能', 'data_vm_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010003', '虚拟机磁盘性能', 'data_vm_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010004', '虚拟机网卡性能', 'data_vm_nic', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010005', '物理机CPU性能', 'data_host_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010006', '物理机内存性能', 'data_host_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010007', '物理机磁盘性能', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010008', '物理机网卡性能', 'data_host_nic', 1, 0);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010001', 1, '虚拟机CPU使用率', 'cpu_util', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010002', 1, '虚拟机内存使用情况', 'memory.usage', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 1, '虚拟机磁盘读取速率', 'disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 2, '虚拟机磁盘写入速率', 'disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 3, '虚拟机磁盘大小', 'disk.total.size', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 1, '虚拟机网络出口带宽', 'network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 2, '虚拟机网络入口带宽', 'network.incoming.bytes.rate', 'B/s', 2, 1);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010005', 1, '物理机CPU使用率', 'compute.node.cpu.percent', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010006', 1, '物理机内存使用情况', 'compute.node.memory.used', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 1, '物理机磁盘读取速率', 'compute.node.disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 2, '物理机磁盘写入速率', 'compute.node.disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 3, '物理机磁盘大小', 'compute.node.disk.total', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 4, '物理机磁盘已使用大小', 'compute.node.disk.used', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 1, '物理机网络出口带宽', 'compute.node.network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 2, '物理机网络入口带宽', 'compute.node.network.incoming.bytes.rate', 'B/s', 2, 1);

-- vmware
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020001', '虚拟机CPU性能', 'data_vm_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020002', '虚拟机内存性能', 'data_vm_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020003', '虚拟机磁盘性能', 'data_vm_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020004', '虚拟机网卡性能', 'data_vm_nic', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020005', '物理机CPU性能', 'data_host_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020006', '物理机内存性能', 'data_host_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020007', '物理机磁盘性能', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020008', '物理机网卡性能', 'data_host_nic', 1, 0);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020001', 1, '虚拟机CPU使用率', '2', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020002', 1, '虚拟机内存使用率', '24', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 1, '虚拟机磁盘读取', '130', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 2, '虚拟机磁盘写入', '131', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 1, '虚拟机网络出口带宽', '149', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 2, '虚拟机网络入口带宽', '148', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020005', 1, '物理机CPU使用率', '2', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020006', 1, '物理机内存使用情况', '24', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 1, '物理机磁盘读取速率', '130', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 2, '物理机磁盘写入速率', '131', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 1, '物理机网络出口带宽', '149', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 2, '物理机网络入口带宽', '148', 'KB/s', 2, 1);

-- 将业务侧统计项与OMMP统计项关联

drop table if exists ros_ommp_rel;
create table ros_ommp_rel (
   dc_type          integer                   not null,
   poid             varchar(20)               not null,
   pitemid          integer                   not null,
   sysno            integer                   not null,
   typeno           integer                   not null,
   primary key (poid, pitemid, sysno, typeno)
);

-- IECS

-- VM
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100821', 2, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100824', 2, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100824', 6, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100826', 2, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100826', 6, 2072, 100727);

-- HOST
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100801', 2, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100802', 2, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100803', 2, 2071, 100706);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100806', 30, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100806', 26, 2071, 100708);


-- OPENSTACK

-- VM
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010001', 1, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010002', 1, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 1, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 2, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 3, 2072, 100725);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010004', 1, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010004', 2, 2072, 100727);

-- HOST
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010005', 1, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010006', 1, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 1, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 2, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 3, 2071, 100705);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 4, 2071, 100706);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010008', 1, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010008', 2, 2071, 100708);


-- VMWARE

-- VM

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020001', 1, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020002', 1, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020003', 1, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020003', 2, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020004', 1, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020004', 2, 2072, 100727);

-- HOST
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020005', 1, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020006', 1, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020007', 1, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020007', 2, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020008', 1, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1020008', 2, 2071, 100708);











