﻿use iros;
drop table if exists om_cidr;
