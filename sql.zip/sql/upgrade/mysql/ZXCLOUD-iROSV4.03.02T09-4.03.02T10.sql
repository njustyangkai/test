use iros;
delete from os_name_config where os_id in ('36', '37', '38', '39', '40', '41');
insert into os_name_config(os_id, os_type, os_name) values('36','Windows','Microsoft Windows 8(32)');
insert into os_name_config(os_id, os_type, os_name) values('37','Windows','Microsoft Windows 8(64)');
insert into os_name_config(os_id, os_type, os_name) values('38','Windows','Microsoft Windows Server 2012,Essentials Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('39','Windows','Microsoft Windows Server 2012,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('40','Windows','Microsoft Windows Server 2012,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('41','Windows','Microsoft Windows Server 2012,Foundation Edition(64)');

drop table if exists om_a10_vlantag;
CREATE TABLE om_a10_vlantag (
    vlan_tag                int        				not null,
	status   	            tinyint    default 0 	not null,
	a10_vm_uuid          	varchar(64)				not null,
	network_id              varchar(64)        		null,
	a10_port_id             varchar(64)        		null,  
	vnetid           		varchar(64)      		null,    
    vip_list             	text                	null,
    primary key (vlan_tag) 
);

drop procedure if exists p_insert_vlantag;
DELIMITER &&
create procedure p_insert_vlantag(IN vmUuid varchar(64))
begin
  declare i int;
	declare vsql text; 
	set i=4094;	   
	set vsql=concat('insert into om_a10_vlantag (vlan_tag,a10_vm_uuid) values ');
	while i>=0 do
	 if (i%1000 = 0) THEN
		SET @sql_txt = substring(vsql,1,length(vsql)-1); 
        PREPARE stmt FROM @sql_txt; 
        EXECUTE stmt; 
        set vsql=concat('insert into om_a10_vlantag (vlan_tag,a10_vm_uuid) values ');
    end if;
    set vsql=concat(vsql,'(''',i,''',''',vmUuid,'''),');
    set i=i-1;
  end while;
	SET @delsql='delete from om_a10_vlantag where vlan_tag = 1';
	PREPARE stmt FROM @delsql; 
  EXECUTE stmt; 	
end&& 
DELIMITER ; 
commit;


drop table if exists om_a10_dvsport;
CREATE TABLE om_a10_dvsport (
	a10_vm_uuid			   varchar(64)      null,
    device_id              varchar(64)      null,
	port_id   	           varchar(64)    	null
);

drop table if exists om_a10_tenant;
CREATE TABLE om_a10_tenant (
    tenant_id              varchar(64)      null,
	dc_id   	           varchar(64)    	null,
	a10_vm_uuid			   varchar(64)      null
);

drop procedure if exists proc_update_columns_4_03_02_T09_to_T10;
create procedure proc_update_columns_4_03_02_T09_to_T10()
BEGIN 
	DECLARE v_count tinyint;
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_ade_instance' and column_name='status';
	if(v_count < 1)  THEN 
	   alter table om_ade_instance add status tinyint  NULL;
	   update om_ade_instance set status = 1;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_ade_instance' and column_name='update_time';
	if(v_count < 1)  THEN 
	   alter table om_ade_instance add update_time datetime  NULL;
	END IF; 
	
END;
call proc_update_columns_4_03_02_T09_to_T10;
