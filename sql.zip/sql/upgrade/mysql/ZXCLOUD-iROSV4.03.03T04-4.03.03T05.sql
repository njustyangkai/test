use zxinsys;
call proc_res_op_grpdef(0, 2, 102, 1396, 139623);
call proc_res_op_grpdef(0, 2, 103, 1396, 139623);
call proc_res_op_grpdef(0, 2, 103, 1396, 139614);
call proc_res_op_grpdef(0, 2, 104, 1396, 139614);
call proc_res_op_grpdef(0, 1, 102, 1396, 139620);

call proc_res_op_grpdef(0, 1, 102, 1396, 139604);
call proc_res_op_grpdef(0, 1, 103, 1396, 139604);
call proc_res_op_grpdef(0, 1, 105, 1396, 139604);

call proc_res_op_function(0, 1, 1396, 139601,'云管理');
call proc_res_op_function(0, 1, 1396, 139604,'云服务');
call proc_res_op_function(0, 2, 1396, 139623,'初始化向导');
call proc_res_op_function(0, 2, 1396, 139611,'性能统计');
call proc_res_op_function(0, 2, 1396, 139614,'易云管理');

call proc_res_op_function(0, 1, 1396, 139620,'设备监控');
call proc_res_op_function(0, 1, 1396, 139621,'资产管理');
call proc_res_op_function(0, 2, 1396, 139622,'数据字典');

delete from portal_sysparam where param_name = 'receive_vnfm_feedback_timeout';

delete from portal_sysparam where param_name = 'image_delete_interval';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('image_delete_interval','180','删除下载镜像任务默认比较时间','iROS','删除下载镜像任务默认比较时间，单位：分钟',
             2,100,0,'',0,
             '','','','','');


use zxinmeasure;
drop procedure if exists p_create_table;
DELIMITER &&
create procedure p_create_table(in tablename varchar(50))
BEGIN
    declare currentTableName VARCHAR(128);
    declare nextTableName VARCHAR(128);
		declare _currentmonth INT;
		declare _nextmonth INT;
		declare _addNum INT;
		declare vsql varchar(4000);

    SELECT MONTH(NOW()) INTO _currentmonth FROM DUAL;
		SELECT (YEAR(NOW()) % 2) * 12 INTO _addNum FROM DUAL;

		SET _nextmonth = _currentmonth + 1;

		SET _currentmonth = _currentmonth + _addNum;
		SET _nextmonth = _nextmonth + _addNum;
    IF _nextmonth > 24 THEN
       SET _nextmonth = 1;
    END IF;

    SET currentTableName = concat(tablename, right(concat('0', _currentmonth), 2));
    SET nextTableName = concat(tablename, right(concat('0', _nextmonth), 2));

	IF NOT EXISTS (SELECT TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA = 'zxinmeasure' and TABLE_NAME = currentTableName) THEN
		set vsql=concat('create table if not exists ',currentTableName,
		                     '(starttime      datetime not null,',
						     'endtime         datetime null,',
							 'resourcetype    varchar(255) not null,',
						     'resourceid      varchar(200) not null,',
						     'param1          varchar(200) null,',
						     'param2          varchar(200) null,',
							 'statcode1       float null)');
		
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;

		set vsql=concat('create index idx_starttime_',currentTableName,' on ',currentTableName,'(starttime)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_resourceid_',currentTableName,' on ',currentTableName,'(resourceid)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_param1_',currentTableName,' on ',currentTableName,'(param1)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_param2_',currentTableName,' on ',currentTableName,'(param2)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
	END IF;
	IF NOT EXISTS (SELECT TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA = 'zxinmeasure' and TABLE_NAME = nextTableName) THEN
		set vsql=concat('create table if not exists ',nextTableName,
		                     '(starttime      datetime not null,',
						     'endtime         datetime null,',
							 'resourcetype    varchar(255) not null,',
						     'resourceid      varchar(200) not null,',
						     'param1          varchar(200) null,',
						     'param2          varchar(200) null,',
							 'statcode1       float null)');
		
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;

		set vsql=concat('create index idx_starttime_',nextTableName,' on ',nextTableName,'(starttime)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_resourceid_',nextTableName,' on ',nextTableName,'(resourceid)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_param1_',nextTableName,' on ',nextTableName,'(param1)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_param2_',nextTableName,' on ',nextTableName,'(param2)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
	END IF;
END&& 
DELIMITER ; 
commit;


delete from ros_ptypedef where poid = '100822';
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100822', '虚拟机内存性能', 'data_vm_mem', 1, 0);

delete from ros_pitemdef where dc_type = 1;
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100821', 2, '虚拟机CPU使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100822', 2, '虚拟机内存使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 2, '虚拟机磁盘读取速率', '', 'MB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 6, '虚拟机磁盘写入速率', '', 'MB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 26, '虚拟机网络出口带宽', '', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 30, '虚拟机网络入口带宽', '', 'KB/s', 2, 1);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100801', 2, '物理机CPU使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100802', 2, '物理机内存使用情况', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100803', 2, '物理机磁盘使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 30, '物理机端口流出速率', '', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 26, '物理机端口流入速率', '', 'KB/s', 2, 1);


