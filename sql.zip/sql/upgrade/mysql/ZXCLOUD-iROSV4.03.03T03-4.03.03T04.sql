use zxinsys;
call proc_add_res_definition('IROS_REPOS_GRP', '存储组', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp', '', null);
call proc_add_res_definition('IROS_REPOS_GRP_MANAGE', '存储组', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_manage', '', null);
call proc_add_res_definition('IROS_REPOS_GRP_PUB', '存储组', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_pub', '', null);
call proc_add_res_definition('IROS_REPOS', '存储', 'IROS_REPOS_GRP', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos', '', null);
call proc_add_res_definition('IROS_REPOS_MANAGE', '存储', 'IROS_REPOS_GRP_MANAGE', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_manage', '', null);
call proc_add_res_definition('IROS_REPOS_PUB', '存储', 'IROS_REPOS_GRP_PUB', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_pub', '', null);
call proc_add_res_definition('IROS_HOSTNIC', '主机网卡', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host_nic', '', null);
call proc_add_res_definition('IROS_VMNIC', '云主机网卡', 'IROSVM', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm_nic', '', null);

call proc_res_op_function(0, 1, 1396, 139630,'租期统计');
call proc_res_op_function(0, 2, 1396, 139629,'服务监控');

use iros;
drop table if exists ent_res_repos_grp;
create table ent_res_repos_grp(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_grp_manage;
create table ent_res_repos_grp_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_grp_pub;
create table ent_res_repos_grp_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos;
create table ent_res_repos(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_manage;
create table ent_res_repos_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_pub;
create table ent_res_repos_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_host_nic;
create table ent_res_host_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_vm_nic;
create table ent_res_vm_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists dc_ommp_restype_rel;
create table dc_ommp_restype_rel (
   dc_type           integer                   not null,
   dc_restype        varchar(50)               not null,
   ommp_restype      varchar(50)               not null, 
   primary key (dc_type, dc_restype)
);

-- iECS 
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP', 'IROS_REPOS_GRP');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_MANAGE', 'IROS_REPOS_GRP_MANAGE');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_PUB', 'IROS_REPOS_GRP_PUB');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS', 'IROS_REPOS');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_MANAGE', 'IROS_REPOS_MANAGE');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_PUB', 'IROS_REPOS_PUB');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMC', 'IROSDC');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VM', 'IROSVM');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'HOST', 'IROSHOST');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'POOL', 'IROSCLUSTER');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'NIC', 'IROS_HOSTNIC');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMNETCARD', 'IROS_VMNIC');


drop procedure if exists proc_update_columns_4_03_03_T03_to_4_03_03_T04;
DELIMITER &&
create procedure proc_update_columns_4_03_03_T03_to_4_03_03_T04()
BEGIN 
	DECLARE v_count tinyint;	
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_resource_statistic' and column_name='dc_id';
	if(v_count < 1)  THEN 
	   alter table om_resource_statistic add  dc_id  varchar(100);
	END IF; 
	
	
end&& 
DELIMITER ; 
commit;


call proc_update_columns_4_03_03_T03_to_4_03_03_T04;
drop procedure if exists proc_update_columns_4_03_03_T03_to_4_03_03_T04;

ALTER TABLE om_resource_statistic 
DROP PRIMARY KEY,
ADD PRIMARY KEY (type, resource_id, resource_name, date);


use zxinalarm;
call proc_alm_systypedic(1,22537,'iROS');

-- iECS
call proc_alm_code_new(1,1000001,'主机离线告警',1,13,1,22537);
call proc_alm_code_new(1,1000002,'虚拟机关闭告警',1,13,1,22537);
call proc_alm_code_new(1,1000003,'VMC数据库异常',1,13,1,22537);
call proc_alm_code_new(1,1000004,'存储库状态异常',1,13,1,22537);
call proc_alm_code_new(1,1000005,'存储库使用率超过阈值',1,13,1,22537);
call proc_alm_code_new(1,1000008,'虚机崩溃告警',8,13,1,22537);
call proc_alm_code_new(1,1000009,'虚机重启告警',8,13,1,22537);
call proc_alm_code_new(1,1000014,'存储库代理状态异常',1,13,1,22537);
call proc_alm_code_new(1,1000016,'存储库单元可访问异常',1,13,1,22537);
call proc_alm_code_new(1,1000017,'主机访问存储库目录异常',1,13,1,22537);
call proc_alm_code_new(1,1000018,'主机网络异常',1,13,1,22537);
call proc_alm_code_new(1,1000020,'虚拟机故障切换资源',1,13,1,22537);
call proc_alm_code_new(1,1000021,'光纤告警',1,13,1,22537);
call proc_alm_code_new(1,1000025,'日志空间超限',1,13,1,22537);
call proc_alm_code_new(1,1000026,'MCE硬件异常',1,13,1,22537);
call proc_alm_code_new(1,1000000,'VMC异常',1,13,1,22537);
call proc_alm_code_new(1,1000100,'DRS批量迁移失败', 8,13,1,22537);

-- iECS
call proc_alm_reason_new(1,1000001,'主机离线告警',22537);
call proc_alm_reason_new(1,1000002,'虚拟机关闭告警',22537);
call proc_alm_reason_new(1,1000003,'VMC数据库异常',22537);
call proc_alm_reason_new(1,1000004,'存储库状态异常',22537);
call proc_alm_reason_new(1,1000005,'存储库使用率超过阈值',22537);
call proc_alm_reason_new(1,1000008,'虚机崩溃告警',22537);
call proc_alm_reason_new(1,1000009,'虚机重启告警',22537);
call proc_alm_reason_new(1,1000014,'存储库代理状态异常',22537);
call proc_alm_reason_new(1,1000016,'存储库单元可访问异常',22537);
call proc_alm_reason_new(1,1000017,'主机访问存储库目录异常',22537);
call proc_alm_reason_new(1,1000018,'主机网络异常',22537);
call proc_alm_reason_new(1,1000020,'虚拟机故障切换资源',22537);
call proc_alm_reason_new(1,1000021,'光纤告警',22537);
call proc_alm_reason_new(1,1000025,'日志空间超限',22537);
call proc_alm_reason_new(1,1000026,'MCE硬件异常',22537);
call proc_alm_reason_new(1,1000000,'VMC异常',22537);
call proc_alm_reason_new(1,1000100,'DRS批量迁移失败',22537);



