use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.04T01' where name = 'iROS';