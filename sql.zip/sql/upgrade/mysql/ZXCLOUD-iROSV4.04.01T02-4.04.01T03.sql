use iros;
update om_order_process set description='适用于云主机、云桌面、防火墙、负载均衡资源的申请审批流程' where process_id=2;

delete from om_res_order_process_rel where res_type = 5 and process_id = 2;
insert into om_res_order_process_rel (res_type, process_id) values(5, 2);

-- 增加物理设备
drop procedure if exists sp_web_add_phymachineinfo;
DELIMITER //
create procedure sp_web_add_phymachineinfo
(
  in v_i_entid            varchar(100), -- physicial id
  in v_i_devicemospecid   varchar(100), -- associate om_devicespec_info 物理机
  -- in v_i_areaid           varchar(200), -- 增加areaid，
  -- in v_i_dcid           varchar(200), -- 增加areaid，
  in v_i_fixedassetnum    varchar(200), -- 固定资产编号
  in v_i_systemnum        varchar(200), -- 系统编号
  in v_i_productmnum      varchar(200), -- 产品编号
  in v_i_purchasedate     date,         -- 2017.12.12  待定
  in v_i_assurancetime    int,          -- month 质保月份
  in v_i_assurancedesc    varchar(200), -- 质保描述
  in v_i_location         varchar(200), -- 位置
  in v_i_locationdesc     varchar(50) , -- 大小
  in v_i_upframenum       varchar(50) , -- 机驾号
  in v_i_roundframenum    varchar(50) , -- 机框号
  in v_i_slotnum          varchar(50) , -- 槽位号
  in v_i_ipmiip           varchar(100), -- ipmiip
  in v_i_ipmiuser         varchar(50) , -- ipmiuser
  in v_i_ipmipwd          varchar(50) , -- ipmi passsword
  in v_i_status           int         , -- 0 未使用 1 已使用
  in v_i_operid           varchar(50) , -- 操作ID
  in v_i_entname          varchar(200), -- ommp 物理机名字
  in v_i_ommpid           varchar(200), -- ommp 物理机id
  out v_i_ret            int
)
begin
  declare  v_entid               varchar(100);
  declare  v_devicemospecid      varchar(100);
  declare  v_opertime            date;
  declare  v_deviceid            varchar(200);  -- 厂商ID
  declare  v_devicename          varchar(200);  -- 厂商名字
  declare  v_phstatus            int;           -- 物理机状态   9关机
  set v_entid = trim(v_i_entid);
  set v_devicemospecid = trim(v_i_devicemospecid);
  set v_opertime = now();
  set v_phstatus = 7;

  -- 根据规格ID查询厂商ID
  select deviceid into v_deviceid from om_device_info where devicemospecid = v_i_devicemospecid;

  if FOUND_ROWS() = 0
    || exists(select 1 from om_phydevice_info where entid = v_entid)
    || exists(select 1 from om_phydevice_info where entname = v_i_entname and status <>9 ) then
    set v_i_ret = 3001;
  elseif exists(select 1 from om_phydevice_info where fixedassetnum = v_i_fixedassetnum and status <>9 ) then
    set v_i_ret = 3003;
  elseif exists(select 1 from om_phydevice_info where systemnum = v_i_systemnum and status <>9 ) then
    set v_i_ret = 3004;
  elseif exists(select 1 from om_phydevice_info where productmnum = v_i_productmnum and status <>9 ) then
    set v_i_ret = 3005;
  else
    select dataname into v_devicename from common_dict_item where dataid = v_deviceid;

    if FOUND_ROWS() = 0 then
      set v_i_ret = 3006;
    else
      start transaction;
      insert into om_phydevice_info (entid, entname,devicemospecid ,deviceid ,fixedassetnum ,systemnum ,productmnum ,purchasedate ,
                       assurancetime ,assurancedesc ,location ,locationdesc ,upframenum ,roundframenum ,
                      slotnum ,ipmiip ,ipmiuser ,ipmipwd ,status ,phstatus ,operid , opertime)
           values(v_entid, v_i_entname, v_devicemospecid, v_deviceid, v_i_fixedassetnum, v_i_systemnum, v_i_productmnum, v_i_purchasedate,
                  v_i_assurancetime, v_i_assurancedesc, v_i_location, v_i_locationdesc, v_i_upframenum, v_i_roundframenum,
                  v_i_slotnum, v_i_ipmiip, v_i_ipmiuser, v_i_ipmipwd, v_i_status, v_phstatus, v_i_operid, v_opertime);
      if @@warning_count <> 0 || @@error_count > 0 then
        rollback;
        set v_i_ret = 1001;
      else
        commit;
        update om_device_info set specidnum = specidnum + 1  where devicemospecid = v_devicemospecid;
        if @@warning_count <> 0 || @@error_count > 0 then
          set v_i_ret = 1001;
        else
          set v_i_ret = 1;
        end if;
      end if;
    end if;
  end if;
end //
DELIMITER ;