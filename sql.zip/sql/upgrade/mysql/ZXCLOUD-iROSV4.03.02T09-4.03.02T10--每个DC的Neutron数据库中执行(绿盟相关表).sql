use neutron;
drop table if exists nsfocus_vnidsmipmaps;
drop table if exists nsfocus_vdasmipmaps;
drop table if exists nsfocus_vwafmipmaps;
drop table if exists nsfocus_vsashmipmaps;

create table nsfocus_vnidsmipmaps 
( 
	tenant_id        		varchar(255) 		 null,		
	vm_id        			varchar(64) 		not null,		
	port_id        			varchar(64) 		 null,		
	manage_ip        		varchar(64) 		 null,	
    primary key(vm_id)
);
create table nsfocus_vdasmipmaps 
( 
	tenant_id        		varchar(255) 		 null,		
	vm_id        			varchar(64) 		not null,		
	port_id        			varchar(64) 		 null,		
	manage_ip        		varchar(64) 		 null,	
    primary key(vm_id)
);
create table nsfocus_vwafmipmaps 
( 
	tenant_id        		varchar(255) 		 null,		
	vm_id        			varchar(64) 		not null,		
	port_id        			varchar(64) 		 null,		
	manage_ip        		varchar(64) 		 null,	
    primary key(vm_id)
);
create table nsfocus_vsashmipmaps 
( 
	tenant_id        		varchar(255) 		 null,		
	vm_id        			varchar(64) 		not null,		
	port_id        			varchar(64) 		 null,		
	manage_ip        		varchar(64) 		 null,	
    primary key(vm_id)
);