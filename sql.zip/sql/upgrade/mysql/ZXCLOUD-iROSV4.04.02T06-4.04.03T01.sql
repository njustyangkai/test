/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2016-6-13 18:11:04                           */
/*==============================================================*/
use iros;

/*==============================================================*/
/* Table: om_city     地市表                                    */
/*==============================================================*/
drop table if exists om_city;
create table om_city
(
   dc_id                varchar(100)  not null,
   city_id              varchar(100)  not null,
   name                 varchar(100)  not null,
   description          text,
   primary key (city_id)
);

/*==============================================================*/
/* Table: om_computerroom         机房表                        */
/*==============================================================*/
drop table if exists om_computerroom;
create table om_computerroom
(
   city_id              varchar(100) not null,
   computerroom_id      varchar(100) not null,
   name                 varchar(100) not null,
   address              varchar(500) not null,
   area                 numeric(10,2) not null,
   rack_num             int not null,
   rack_rows            int not null,
   rack_columns         int not null,
   port_num             int not null,
   bandwidth            int not null,
   lease                tinyint not null,
   primary key (computerroom_id)
);


/*==============================================================*/
/* Table: om_rack     机架表                                    */
/*==============================================================*/
drop table if exists om_rack;
create table om_rack
(
   computerroom_id      varchar(100) not null,
   rack_id              varchar(100) not null,
   rack_code            varchar(100) not null,
   rack_spec            varchar(100) not null,
   power_num            int not null, 
   assign               tinyint not null,
   status               tinyint not null,
   rack_row             int not null,
   rack_column          int not null,
   tenantid             varchar(100),
   userid               varchar(100),
   lease                tinyint not null,
   primary key (rack_id)
);

/*==============================================================*/
/* Table: om_rack_lease_history            机架租赁历史表       */
/*==============================================================*/
drop table if exists om_rack_lease_history;
create table om_rack_lease_history
(
   id                   varchar(100) not null,
   computerroom_id      varchar(100) not null,
   rack_id              varchar(100) not null,
   rack_code            varchar(100) not null,
   rack_spec            varchar(100) not null,
   power_num            int not null,
   rack_row             int not null,
   rack_column          int not null,
   tenantid             varchar(100) not null,
   userid               varchar(100) not null,
   startdate            datetime,
   enddate              datetime,
   order_id             int,
   status               tinyint
);


/*==============================================================*/
/* Table: om_room_admin          机房管理员(包括工单)           */
/*==============================================================*/
drop table if exists om_room_admin;
create table om_room_admin
(
   oper_id              decimal not null,
   dc_id                varchar(100) not null,
   city_id              varchar(100),
   computerroom_id      varchar(100)
);

/*==============================================================*/
/* Table: om_ipsection             IP地址段(互联网/局域网)   */
/*==============================================================*/
drop table if exists om_ipsection;
create table om_ipsection
(
   name                 varchar(64)   not null, 
   id                   varchar(100)  not null,
   computerroom_id      varchar(100)  not null,
   cidr                 varchar(64)   not null,
   subnetmask           varchar(64)   not null,
   gateway              varchar(64)    null,
   dns                  varchar(255)   null,
   iptype               tinyint  not null, 
   primary key (id)
);

/*==============================================================*/
/* Table: om_ippool                可用IP地址池                 */
/*==============================================================*/
drop table if exists om_ippool;
create table om_ippool
(
   id                   varchar(100)  not null,
   ipstart              varchar(50)   not null,
   ipend                varchar(50)   not null
);

/*==============================================================*/
/* Table: om_ip_usage             IP使用情况                    */
/*==============================================================*/
drop table if exists om_ip_usage;
create table om_ip_usage
(
   computerroom_id      varchar(100)  not null, 
   id                   varchar(100)  not null,
   ip                   varchar(50)   not null,
   status               tinyint not null,
   tenantid             varchar(100) null,
   userid               varchar(100) null,
   restype              tinyint null,
   resid                varchar(50) null,
   startdate            datetime null,
   enddate              datetime null,
   section_id           varchar(100) not null
);

/*==============================================================*/
/* Table: om_bandwidth_config        带宽配置情况                */
/*==============================================================*/
drop table if exists om_bandwidth_config;
create table om_bandwidth_config
(
   id                   varchar(100) not null,
   up_bandwidth         int not null,
   down_bandwidth		int not null,
   computerroom_id      varchar(100) not null,
   primary key (id)
);

/*==============================================================*/
/* Table: om_bandwidth_usage        带宽使用情况                */
/*==============================================================*/
drop table if exists om_bandwidth_usage;
create table om_bandwidth_usage
(
   computerroom_id      varchar(100) not null,
   id                   varchar(100) not null,
   bandwidth            int  not null,
   bw_mode              tinyint not null,
   bw_type              tinyint not null,
   status               tinyint not null,
   tenantid             varchar(100) not null,
   userid               varchar(100) not null,
   rack_id              varchar(100) not null,
   startdate            datetime  null,
   enddate              datetime  null,
   ips                  text not null,
   primary key (id)
);




/*==============================================================*/
/* Table: om_networkdevice_info           网络设备表            */
/*==============================================================*/
drop table if exists om_networkdevice_info;
create table om_networkdevice_info
(
   computerroom_id      varchar(100),  
   city_id              varchar(100),   
   rack_id              varchar(100),
   dc_id                varchar(100),
   entid                varchar(100),
   entname              varchar(100),
   devicetype           varchar(100),
   devicemodel          varchar(100),
   fixedassetnum        varchar(200),
   systemnum            varchar(200),
   productnum           varchar(200),
   purchasedate         datetime,
   assurancetime        int,
   assurancedesc        varchar(200),
   location             varchar(200),
   locationdesc         varchar(50),
   roundframenum        varchar(50),
   slotnum              varchar(50),
   is_measure           int
);



/*==============================================================*/
/* Table: om_storedevice_info            存储设备表             */
/*==============================================================*/
drop table if exists om_storedevice_info;
create table om_storedevice_info
(
   computerroom_id      varchar(100),  
   city_id              varchar(100),   
   rack_id              varchar(100),
   dc_id                varchar(100),
   entid                varchar(100),
   entname              varchar(100),
   devicetype           varchar(100),
   devicemodel          varchar(100),
   fixedassetnum        varchar(200),
   systemnum            varchar(200),
   productnum           varchar(200),
   purchasedate         datetime,
   assurancetime        int,
   assurancedesc        varchar(200),
   location             varchar(200),
   locationdesc         varchar(50),
   roundframenum        varchar(50),
   slotnum              varchar(50),
   is_measure           int
);
use zxinsys;
delete from oper_virtual_grpdef where v_opergrpid=6124 and servicekey='uniportal';
delete from oper_virtual_grpdef where v_opergrpid=6125 and servicekey='uniportal';
delete from oper_virtual_grpdef where v_opergrpid=6126 and servicekey='uniportal';
call proc_res_op_grpscript2(0, 1, 106, '机房管理员', '机房管理员');
call proc_res_op_grpscript2(0, 1, 107, '机房工单管理员', '机房工单管理员');
call proc_res_op_grpscript2(0, 1, 108, '机房工单处理人', '机房工单处理人');
-- 机房管理员
call proc_res_op_grpdef(0, 1, 106, 11, 18102);
call proc_res_op_grpdef(0, 1, 106, 1396, 139640);
call proc_res_op_grpdef(0, 1, 106, 1396, 139610);
call proc_res_op_grpdef(0, 1, 106, 1396, 139605);
-- 机房工单管理员
call proc_res_op_grpdef(0, 1, 107, 11, 18102);
call proc_res_op_grpdef(0, 1, 107, 1396, 139610);
call proc_res_op_grpdef(0, 1, 107, 1396, 139618);
-- 机房工单处理人
call proc_res_op_grpdef(0, 1, 108, 11, 18102);
call proc_res_op_grpdef(0, 1, 108, 1396, 139610);
call proc_res_op_grpdef(0, 1, 108, 1396, 139618);

call proc_res_op_v_grpscript(0, 1, 6124, '机房管理员组');
call proc_res_op_v_grpscript(0, 1, 6125, '机房工单管理员组');
call proc_res_op_v_grpscript(0, 1, 6126, '机房工单处理人组');
call proc_res_op_v_grpdef(0, 1, 6124, 106);
call proc_res_op_v_grpdef(0, 1, 6125, 107);
call proc_res_op_v_grpdef(0, 1, 6126, 108);
call proc_res_op_v_grpdef(0,1,1000,106);
call proc_res_op_v_grpdef(0,1,1001,106);
call proc_res_op_v_grpdef(0,1,1000,107);
call proc_res_op_v_grpdef(0,1,1001,107);
call proc_res_op_v_grpdef(0,1,1000,108);
call proc_res_op_v_grpdef(0,1,1001,108);

call proc_res_op_function(0, 1, 1396, 139640,'机房管理');

use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.03T01' where name = 'iROS';

delete from resource_price where name in('带宽','互联网IP','1U','2U','4U','8U','16U','32U','64U');
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('1U', 5, 14, '元/时',  'Rack-0', '', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('2U', 5, 14, '元/时',  'Rack-1', '', 0.04);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('4U', 5, 14, '元/时',  'Rack-2', '', 0.08);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('8U', 5, 14, '元/时',  'Rack-3', '', 0.16);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('16U', 5, 14, '元/时',  'Rack-4', '', 0.32);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('32U', 5, 14, '元/时',  'Rack-5', '', 0.64);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('64U', 5, 14, '元/时',  'Rack-6', '', 1.28);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('带宽', 5, 15, '元/Mbps',  '', '每M每小时价格', 2);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('互联网IP', 5, 16, '元/个',  '', '一个互联网IP每小时价格', 2);
delete from om_res_order_process_rel where res_type  = 5 and  process_id = 2;
delete from om_base_service where id = 14;
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (14, '机架租赁', 'switch_rackrent', '','提供机架整体对外出租的功能，同时提供高质量带宽宽带，互联网IP的接入，方便企业的接入。',',2,3,4,5,6,7,');
use zxinsys;
update oper_function set allowflag=0 where funcgrpid=1396 and funcid=139621 and servicekey='uniportal';
use iros;
delete from om_control_function where id = 'phydevice_switch_control';
delete from common_dict_catalog where typeid  = '9';
delete from common_dict_item where typeid  = '9';
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('9','机架规格','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-0','1U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-1','2U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-2','4U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-3','8U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-4','16U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-5','32U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-6','64U','','');
update common_dict_item set dataname = '物理机' where typeid = '4' and dataid = '104001';
update common_dict_catalog set typename = '物理机类型' where typeid = '5';
delete from om_res_order_process_rel where res_type in (2,5,6,7,8);
delete from om_order_process where process_id = 3;
insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(3, '物理资源审批流程', '适用于物理机、机架、互联网IP、局域网IP、带宽资源审批流程', 1, 1, 0);
insert into om_res_order_process_rel (res_type, process_id) values(2, 3);
insert into om_res_order_process_rel (res_type, process_id) values(5, 3);
insert into om_res_order_process_rel (res_type, process_id) values(6, 3);
insert into om_res_order_process_rel (res_type, process_id) values(7, 3);
insert into om_res_order_process_rel (res_type, process_id) values(8, 3);
-- 修改物理设备
drop procedure if exists sp_web_mod_phymachineinfo;
DELIMITER //
create procedure sp_web_mod_phymachineinfo
(
  in v_i_entid            varchar(100), -- physicial id
  in v_i_devicemospecid   varchar(100), -- associate om_devicespec_info 物理机
  -- in v_i_areaid           varchar(200), -- 增加areaid，
  -- in v_i_dcid          varchar(200), -- 增加dcid，
  in v_i_fixedassetnum    varchar(200), -- 固定资产编号
  in v_i_systemnum        varchar(200), -- 系统编号
  in v_i_productmnum      varchar(200), -- 产品编号
  in v_i_purchasedate     date,         -- 2017.12.12  待定
  in v_i_assurancetime    int,          -- month 质保月份
  in v_i_assurancedesc    varchar(200), -- 质保描述
  in v_i_location         varchar(200), -- 位置
  in v_i_locationdesc     varchar(50) , -- 大小
  in v_i_upframenum       varchar(50) , -- 机驾号
  in v_i_roundframenum    varchar(50) , -- 机框号
  in v_i_slotnum          varchar(50) , -- 槽位号
  in v_i_ipmiip           varchar(100), -- ipmiip
  in v_i_ipmiuser         varchar(50) , -- ipmiuser
  in v_i_ipmipwd          varchar(50) , -- ipmi passsword
  in v_i_status           int         , -- 0 未使用 1 已使用
  in v_i_operid           varchar(50) , -- 操作ID
  in v_i_entname          varchar(200),
  out v_i_ret             int
)
begin
  declare  v_devicemospecid      varchar(100);
  declare  v_devicestatus        int;     -- 0未使用该规格是否被使用
  declare  v_specidnum           int;         -- 该规格下默认有多少机器默认0

  set  v_devicemospecid = trim(v_i_devicemospecid);
  set  v_devicestatus = 0;
  set  v_specidnum = 0;
  if exists(select 1 from om_devicespec_info where devicemospecid = v_devicemospecid)
    || exists(select 1 from om_devicespec_info where devicemospecid = v_devicemospecid)
    || exists(select 1 from om_device_info where deviceid = v_i_deviceid and devicemodel = v_i_devicemodel and devicemospecname = v_i_devicemospecname)
  then
    set v_i_ret = 1011;
  else
    start transaction;
    insert into om_device_info( devicemospecid, deviceid, devicemodel,devicemospecname ,specidnum,devicestatus)
         values(v_i_devicemospecid, v_i_deviceid, v_i_devicemodel,  v_i_devicemospecname, v_specidnum ,v_devicestatus);

    insert into om_devicespec_info (devicemospecid ,devicetype ,servertype ,devdisk ,memeory ,nicmodel ,niunum ,
             cpumodel ,cpumohz ,cpunum ,cpucores ,hbamodel ,hbanum, cost)
         values (v_devicemospecid ,v_i_devicetype ,v_i_servertype ,v_i_devdisk ,v_i_memeory ,v_i_nicmodel ,v_i_niunum ,
            v_i_cpumodel ,v_i_cpumohz ,v_i_cpunum ,v_i_cpucores ,v_i_hbamodel ,v_i_hbanum, v_i_cost);
    if @@warning_count <> 0 || @@error_count > 0 then
      rollback;
      set v_i_ret = 1001;
    else
      commit;
      set v_i_ret = 1;
    end if;
  end if;
end //
DELIMITER ;
commit;
-- 增加物理设备
drop procedure if exists sp_web_add_phymachineinfo;
DELIMITER //
create procedure sp_web_add_phymachineinfo
(
  in v_i_entid            varchar(100), -- physicial id
  in v_i_devicemospecid   varchar(100), -- associate om_devicespec_info 物理机
  -- in v_i_areaid           varchar(200), -- 增加areaid，
  -- in v_i_dcid           varchar(200), -- 增加areaid，
  in v_i_fixedassetnum    varchar(200), -- 固定资产编号
  in v_i_systemnum        varchar(200), -- 系统编号
  in v_i_productmnum      varchar(200), -- 产品编号
  in v_i_purchasedate     date,         -- 2017.12.12  待定
  in v_i_assurancetime    int,          -- month 质保月份
  in v_i_assurancedesc    varchar(200), -- 质保描述
  in v_i_location         varchar(200), -- 位置
  in v_i_locationdesc     varchar(50) , -- 大小
  in v_i_upframenum       varchar(50) , -- 机驾号
  in v_i_roundframenum    varchar(50) , -- 机框号
  in v_i_slotnum          varchar(50) , -- 槽位号
  in v_i_ipmiip           varchar(100), -- ipmiip
  in v_i_ipmiuser         varchar(50) , -- ipmiuser
  in v_i_ipmipwd          varchar(50) , -- ipmi passsword
  in v_i_status           int         , -- 0 未使用 1 已使用
  in v_i_operid           varchar(50) , -- 操作ID
  in v_i_entname          varchar(200), -- ommp 物理机名字
  in v_i_ommpid           varchar(200), -- ommp 物理机id
  in v_i_rack_id          varchar(100),
  in v_i_computerroom_id  varchar(100),
  in v_i_city_id          varchar(100),
  in v_i_dc_id            varchar(100),
  out v_i_ret            int
)
begin
  declare  v_entid               varchar(100);
  declare  v_devicemospecid      varchar(100);
  declare  v_opertime            date;
  declare  v_deviceid            varchar(200);  -- 厂商ID
  declare  v_devicename          varchar(200);  -- 厂商名字
  declare  v_phstatus            int;           -- 物理机状态   9关机
  set v_entid = trim(v_i_entid);
  set v_devicemospecid = trim(v_i_devicemospecid);
  set v_opertime = now();
  set v_phstatus = 7;
  -- 根据规格ID查询厂商ID
  select deviceid into v_deviceid from om_device_info where devicemospecid = v_i_devicemospecid;

  if FOUND_ROWS() = 0
    || exists(select 1 from om_phydevice_info where entid = v_entid)
    || exists(select 1 from om_phydevice_info where entname = v_i_entname and status <>9 ) then
    set v_i_ret = 3001;
  elseif exists(select 1 from om_phydevice_info where fixedassetnum = v_i_fixedassetnum and status <>9 ) then
    set v_i_ret = 3003;
  elseif exists(select 1 from om_phydevice_info where systemnum = v_i_systemnum and status <>9 ) then
    set v_i_ret = 3004;
  elseif exists(select 1 from om_phydevice_info where productmnum = v_i_productmnum and status <>9 ) then
    set v_i_ret = 3005;
  else
    select dataname into v_devicename from common_dict_item where dataid = v_deviceid;

    if FOUND_ROWS() = 0 then
      set v_i_ret = 3006;
    else
      start transaction;
      insert into om_phydevice_info (rack_id, computerroom_id, city_id, dc_id, entid, entname,devicemospecid ,deviceid ,fixedassetnum ,systemnum ,productmnum ,purchasedate ,
                       assurancetime ,assurancedesc ,location ,locationdesc ,upframenum ,roundframenum ,
                      slotnum ,ipmiip ,ipmiuser ,ipmipwd ,status ,phstatus ,operid , opertime)
           values(v_i_rack_id, v_i_computerroom_id, v_i_city_id, v_i_dc_id, v_entid, v_i_entname, v_devicemospecid, v_deviceid, v_i_fixedassetnum, v_i_systemnum, v_i_productmnum, v_i_purchasedate,
                  v_i_assurancetime, v_i_assurancedesc, v_i_location, v_i_locationdesc, v_i_upframenum, v_i_roundframenum,
                  v_i_slotnum, v_i_ipmiip, v_i_ipmiuser, v_i_ipmipwd, v_i_status, v_phstatus, v_i_operid, v_opertime);
      if @@warning_count <> 0 || @@error_count > 0 then
        rollback;
        set v_i_ret = 1001;
      else
        commit;
        update om_device_info set specidnum = specidnum + 1  where devicemospecid = v_devicemospecid;
        if @@warning_count <> 0 || @@error_count > 0 then
          set v_i_ret = 1001;
        else
          set v_i_ret = 1;
        end if;
      end if;
    end if;
  end if;
end //
DELIMITER ;
commit;
drop procedure if exists proc_update_columns_4_04_02_T06_to_4_04_03_T01;
DELIMITER &&
create procedure proc_update_columns_4_04_02_T06_to_4_04_03_T01()
BEGIN 
	DECLARE v_count tinyint;	
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_order' and column_name='city_id';
	if(v_count < 1)  THEN 
	   alter table om_order add  city_id  varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_ticket' and column_name='order_id';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_ticket add order_id   int null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_ticket' and column_name='order_detail_id';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_ticket add order_detail_id  int null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_ticket' and column_name='city_id';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_ticket add city_id   varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_ticket' and column_name='computerroom_id';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_ticket add computerroom_id   varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_phydevice_info' and column_name='computerroom_id';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_phydevice_info add computerroom_id   varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_phydevice_info' and column_name='city_id';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_phydevice_info add city_id   varchar(100) null;
	END IF;
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_phydevice_info' and column_name='rack_id';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_phydevice_info add rack_id   varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_phydevice_info' and column_name='dc_id';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_phydevice_info add  dc_id   varchar(100) null;
	END IF;
end&& 
DELIMITER ; 
commit;
call proc_update_columns_4_04_02_T06_to_4_04_03_T01;
drop procedure if exists proc_update_columns_4_04_02_T06_to_4_04_03_T01;


