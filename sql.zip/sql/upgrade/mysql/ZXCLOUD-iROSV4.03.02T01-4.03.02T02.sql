use zxinsys;
call proc_res_op_function(0, 1, 1396, 139619,'功能控制');

delete from portal_sysparam where param_name = 'charge_tip_day';
delete from portal_sysparam where param_name = 'resource_close_day';
delete from portal_sysparam where param_name = 'charge_mail_control';
delete from portal_sysparam where param_name = 'charge_switch_control';
delete from portal_sysparam where param_name = 'iros_ticket_attachment_path';
delete from portal_sysparam where param_name = 'ticket_switch_control';

use iros;

drop table if exists om_control_function;
CREATE TABLE om_control_function ( 
	id      varchar(64) NOT NULL,
	name    varchar(64) NULL,
	control varchar(200) NULL,  
	primary key (id)
);
insert into om_control_function values ('order_switch_control', '订单开关','0'); -- 0、关闭1、开启
insert into om_control_function values ('ticket_switch_control','工单开关', '0'); -- 0、关闭1、开启
insert into om_control_function values ('iros_ticket_attachment_path', '工单附件存放路径','/home/zxin10/was/tomcat/webapps/workorder/attachment');
insert into om_control_function values ('ade_switch_control','ADE开关', '0'); -- 0、关闭1、开启
insert into om_control_function values ('ade_path','ADE接口地址', 'http://10.129.172.20:8103/ade');
insert into om_control_function values ('charge_switch_control', '计费开关','0'); -- 0、关闭1、开启
insert into om_control_function values ('charge_mail_control','余额不足邮件提醒开关', '1'); -- 0、关闭1、开启
insert into om_control_function values ('charge_tip_day','余额不足提醒', '3');
insert into om_control_function values ('resource_close_day','欠费后资源预留天数', '10');

drop table if exists om_base_service;
CREATE TABLE om_base_service ( 
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64) NOT NULL,
	rel_id      varchar(500) NOT NULL,
	primary key (id)
);


insert into om_base_service values (1, 'VPN', 'switch_vpn', '');
insert into om_base_service values (2, '负载均衡', 'switch_lb', '');
insert into om_base_service values (3, '防火墙', 'switch_firewall', '');
insert into om_base_service values (4, 'DCI', 'switch_dci', '');
insert into om_base_service values (5, '安全组', 'switch_sg', '');
insert into om_base_service values (6, '基础虚拟化功能', 'switch_base', '');
insert into om_base_service values (7, '业务自动编排', 'switch_adt', '');
insert into om_base_service values (8, '业务环境', 'switch_service', '7');

commit;