use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.02T06' where name = 'iROS';
