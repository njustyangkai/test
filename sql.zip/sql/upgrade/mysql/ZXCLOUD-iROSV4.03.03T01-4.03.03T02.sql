use zxinsys;
delete from portal_sysparam where param_name ='versionnumber';
insert into portal_sysparam(param_name,param_value, description) values('versionnumber', 'ZXCLOUD-iROSV4.03.03', '版本号');

delete from portal_sysparam where param_name = 'log_collect_upper_limit';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('log_collect_upper_limit','300','日志一键收集文件个数上限(个)','iROS','日志一键收集文件个数上限(个)',
             2,300,0,' ',1,
             '','','','','');
			 
call proc_res_op_function(0, 1, 1396, 139624,'日志收集');

call proc_add_res_definition ('PH_DEVICE', 'iROS物理设备', 'ROOT', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_iros_phdevice', '', null);
call proc_add_res_definition ('PH_MACHINE', '物理机', 'PH_COMPANY', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_phmachine', '', null);

use iros;
delete from om_order_process where process_id =2;
insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(2, '云资源申请审批流程', '适用于云主机、防火墙、负载均衡资源的申请审批流程', 2, 0, 0);

delete from om_res_order_process_rel;
insert into om_res_order_process_rel (res_type, process_id) values(1, 2);
insert into om_res_order_process_rel (res_type, process_id) values(3, 2);
insert into om_res_order_process_rel (res_type, process_id) values(4, 2);


drop procedure if exists proc_update_columns_4_03_03_T01_to_4_03_03_T02;
DELIMITER &&
create procedure proc_update_columns_4_03_03_T01_to_4_03_03_T02()
BEGIN 
	DECLARE v_count tinyint;	
	SELECT count(*) into v_count FROM information_schema.tables where table_name='om_server';
	if(v_count > 0)  THEN 
	   ALTER TABLE om_server RENAME TO om_order_res_rel;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_order_res_rel' and column_name='res_type';
	if(v_count < 1)  THEN 
	   alter table om_order_res_rel add res_type tinyint default 1  not null;
	END IF; 
end&& 
DELIMITER ; 
commit;

call proc_update_columns_4_03_03_T01_to_4_03_03_T02;
drop procedure if exists proc_update_columns_4_03_03_T01_to_4_03_03_T02;

delete from om_base_service;
insert into om_base_service values (1, 'VPN', 'switch_vpn', '6');
insert into om_base_service values (2, '负载均衡', 'switch_lb', '6');
insert into om_base_service values (3, '防火墙', 'switch_firewall', '6');
insert into om_base_service values (4, 'DCI', 'switch_dci', '6');
insert into om_base_service values (5, '安全组', 'switch_sg', '6');
insert into om_base_service values (6, '基础虚拟化功能', 'switch_base', '');
insert into om_base_service values (7, '业务自动编排', 'switch_adt', '6');
insert into om_base_service values (8, '业务环境', 'switch_service', '6,7');
insert into om_base_service values (9, '增量备份', 'switch_backup_add', '6');
insert into om_base_service values (10, '全量备份', 'switch_backup_all', '6');
insert into om_base_service values (11, '端口流统计', 'switch_flow', '6');

delete from common_dict_item where dataid in ('800105', '800106', '800107');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800105','Windows2003','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800106','Windows2008','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800107','Windows2012','7','os-1');

delete from ent_iros_phdevice;
insert into ent_iros_phdevice (entid,entname,entrid,parentrid,parententid) values ('101','iROS物理设备','PH_DEVICE','ROOT','ROOT');
