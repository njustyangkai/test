use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.05T01' where name = 'iROS';

delete from os_name_config where os_id = '63';
insert into os_name_config(os_id, os_type, os_name) values('63','Linux','Ubuntu 14.4 Standard Edition(64)');


delete from resource_price;

insert into resource_price (name, groups, type, unit, description, price) values ('CPU', 1, 2, '元/核', '1核单位时间价格', 0.05);
insert into resource_price (name, groups, type, unit, description, price) values ('内存', 1, 3, '元/GB', '1GB单位时间价格', 0.05);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('AIX系统盘', 1, 4, '元/GB', 'AIX', 'AIX系统盘每GB单位时间价格', 0.002);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Linux系统盘', 1, 4, '元/GB', 'Linux', 'Linux系统盘每GB单位时间价格', 0.001);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Windows系统盘', 1, 4, '元/GB', 'Windows', 'Windows系统盘每GB单位时间价格', 0.002);
insert into resource_price (name, groups, type, unit, description, price) values ('卷', 1, 7, '元/GB', '1GB单位时间价格', 0.0006);
insert into resource_price (name, groups, type, unit, description, price) values ('私有镜像', 1, 8, '元/GB', '1GB单位时间价格', 0.0006);
insert into resource_price (name, groups, type, unit, description, price) values ('公网IP', 3, 5, '元/个', '1个公网IP单位时间价格', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('路由器', 3, 6, '元/个', '1个路由单位时间价格', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('防火墙', 3, 9, '元/套', '1套单位时间价格', 0.1);
insert into resource_price (name, groups, type, unit, description, price) values ('负载均衡', 3, 10, '元/套', '1套单位时间价格', 0.1);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽', 3, 13, '元/Mbps', 'up',  '1Mbps上行带宽单位时间价格', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽', 3, 13, '元/Mbps', 'down',  '1Mbps下行带宽单位时间价格', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽无限制', 3, 13, '元', 'unlimit up',  '上行带宽无限制单位时间价格', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽无限制', 3, 13, '元',  'unlimit down', '下行带宽无限制单位时间价格', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('1U', 5, 14, '元/时',  'Rack-0', '', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('2U', 5, 14, '元/时',  'Rack-1', '', 0.04);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('4U', 5, 14, '元/时',  'Rack-2', '', 0.08);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('8U', 5, 14, '元/时',  'Rack-3', '', 0.16);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('16U', 5, 14, '元/时',  'Rack-4', '', 0.32);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('32U', 5, 14, '元/时',  'Rack-5', '', 0.64);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('64U', 5, 14, '元/时',  'Rack-6', '', 1.28);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('带宽', 5, 15, '元/Mbps',  '', '每M单位时间价格', 2);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('互联网IP', 5, 16, '元/个',  '', '一个互联网IP单位时间价格', 2);

-- 删除 VDC审批流程
delete from om_order_process where process_id = 4;
delete from om_order_process where process_id = 2;

-- 新增 VDC审批流程
insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(4, 'VDC申请审批流程', '适用于VDC的申请审批流程', 1, 0, 0);
insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(2, '云资源申请审批流程', '适用于云主机、云桌面、防火墙、负载均衡资源的申请审批流程', 2, 0, 0);

-- 删除 VDC资源和审批流程关系
delete from om_res_order_process_rel where res_type=10;
delete from om_res_order_process_rel where res_type = 9 and process_id = 2;
insert into om_res_order_process_rel (res_type, process_id) values(9, 2);
-- 新增 VDC和审批流程的对应关系
insert into om_res_order_process_rel (res_type, process_id) values(10, 4);

delete from om_base_service where id = 16;
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (16, '云桌面', 'switch_irai', '','',',1,');

delete from om_order_process_config where process_id = 4;
-- 新增 VDC的审批流程配置
insert into om_order_process_config values ('4', '1', '一级审批', null, '待处理', '处理中', '0');
insert into om_order_process_config values ('4', '2', '二级审批', null, '处理中', '正常关闭', '0');
insert into om_order_process_config values ('4', '-3', '异常结束', null, '异常结束', '异常结束', '0');
insert into om_order_process_config values ('4', '-2', '二级审批拒绝', null, '二级审批拒绝', '审批拒绝', '0');
insert into om_order_process_config values ('4', '-1', '一级审批拒绝', null, '一级审批拒绝', '审批拒绝', '0');
insert into om_order_process_config values ('4', '0', '正常关闭', null, '正常关闭', '正常关闭', '0');

-- 新增 VDC申请表
drop table if exists om_vdc_apply;
create table om_vdc_apply
(
   apply_id             int NOT NULL,
   vdcname 				varchar(64) NOT NULL,
   vdcdesc 				varchar(256) NULL,
   vdcid   				numeric NULL,
   dcids				varchar(512) NOT NULL,
   dctypes				varchar(64) NOT NULL,
   quotas				varchar(2048) NOT NULL,
   operators			varchar(64) NOT NULL,
   operatoroles			varchar(256) NOT NULL,
   dcids_audited		varchar(512) NULL,
   dctypes_audited		varchar(64) NULL,
   quotas_audited		varchar(2048) NULL,
   creatorid			int NOT NULL,
   tenantid				varchar(64) NOT NULL,
   current_step         int NOT NULL,
   apply_date           datetime NOT NULL,
   primary key (apply_id)
);

use zxinsys;
call proc_res_op_function(0, 1, 1396, 139642,'License管理');

-- 新增菜单 VDC审批
call proc_res_op_function(0, 1, 1396, 139643,'VDC审批');

delete from oper_virtual_grpdef where v_opergrpid=6142 and servicekey='uniportal';
delete from oper_virtual_grpdef where v_opergrpid=6143 and servicekey='uniportal';

-- 新增角色 VDC审批员
call proc_res_op_grpscript2(0, 1, 110, 'VDC审批员', 'VDC审批员');

-- 赋予权限 VDC审批员
call proc_res_op_grpdef(0, 1, 110, 11, 18102);
call proc_res_op_grpdef(0, 1, 110, 1396, 139610);
call proc_res_op_grpdef(0, 1, 110, 1396, 139643);

-- 新增操作组 VDC一级、二级审批员组
call proc_res_op_v_grpscript(0, 1, 6142, 'VDC一级审批员组');
call proc_res_op_v_grpscript(0, 1, 6143, 'VDC二级审批员组');

-- 为操作组赋予角色
call proc_res_op_v_grpdef(0, 1, 6142, 110);
call proc_res_op_v_grpdef(0, 1, 6143, 110);

-- 为super赋予角色
call proc_res_op_v_grpdef(0,1,1000,110);
call proc_res_op_v_grpdef(0,1,1001,110);

-- 新增操作员:VDC一级审批员组和VDC二级审批员组下的操作员 level1/1 level2/2
delete from oper_information2 where operid in(3,4);
insert into oper_information2 (operid,opername,operpwd,operdescription,operallname ,creatorid,pwdhintday,pwdhintnum,initpwd,trait) 
    values  (3,'level1','!@#$%^SXrlgdxUjGmM9b4P8f/GaA==','VDC一级审批员','VDC一级审批员',1,0,5,' ','a');
insert into oper_information2 (operid,opername,operpwd,operdescription,operallname ,creatorid,pwdhintday,pwdhintnum,initpwd,trait) 
    values  (4,'level2','!@#$%^rdDNMAnl/Z1lM+gtF9zs6A==','VDC二级审批员','VDC二级审批员',1,0,5,' ','a');
	
delete from oper_rights2 where operid in(3,4);
insert into oper_rights2 (operid, servicekey,opergrpid,param1,param2,param3,param4) values(3,'uniportal',6142,0,0,-1,-1);
insert into oper_rights2 (operid, servicekey,opergrpid,param1,param2,param3,param4) values(4,'uniportal',6143,0,0,-1,-1);