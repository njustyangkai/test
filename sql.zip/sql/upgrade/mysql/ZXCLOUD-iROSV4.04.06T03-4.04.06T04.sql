use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.06T04' where name = 'iROS';

insert into om_control_function values ('nubosh_switch_control', '云安全开关','1');
insert into om_control_function values ('antivurs_url', '杀毒服务URL','https://127.0.0.1:8443');
insert into om_control_function values ('antivurs_user', '杀毒服务用户名','extapiuser');
insert into om_control_function values ('antivurs_password', '杀毒服务密码','vMsec#1.');
insert into om_control_function values ('antivurs_sso_aes_password', '安贤单点登录AES秘钥','ZTE&nubosh#T0en');

use zxinsys;
delete from portal_sysparam where param_name = 'antivurs_url';
delete from portal_sysparam where param_name = 'antivurs_user';
delete from portal_sysparam where param_name = 'antivurs_password';
delete from portal_sysparam where param_name = 'antivurs_sso_aes_password';

call proc_res_op_paratype(0 ,1, 102, '性能统计');		-- 增加【性能统计】操作日志统计类型
