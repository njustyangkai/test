﻿use iros;

drop procedure if exists clearCidrPrimaryKey;
create procedure clearCidrPrimaryKey()
begin 
if exists(select column_key from information_schema.columns where table_schema='iros' and table_name='om_cidr' and column_name='cidr' and column_key = 'PRI')
then
select 'tt';
Alter table om_cidr drop primary key;
end if;
end;

call clearCidrPrimaryKey();