use iros;
drop table if exists om_ticket_process;
create table om_ticket_process
(
   process_id           int not null,
   ticket_id            int not null,
   step                 int not null,
   oper_type            int not null, -- 1创建 2指派 3拒绝 4接受处理 5转移 6回退 7关闭
   opinion              text null,
   handler_id           int null,
   handler              varchar(50) not null,
   handle_time          datetime not null,
   attachment_path      varchar(255) null,
   attachment           varchar(1000) null,
   attachmentids        varchar(200) null, 
   primary key (process_id)
);

drop table if exists om_ticket;
create table om_ticket
(
   ticket_id            int not null,
   code                 varchar(64) not null,
   title                varchar(64) not null,
   description          text not null,
   category             tinyint not null,
   status               tinyint not null, -- 1、待处理 2、已响应 3、处理中 4、正常结束 5、异常结束 6、转移处理中 
   creator_id           int not null,
   creator              varchar(64) not null,
   phone                varchar(20) not null,
   create_time          datetime not null,
   step                 int not null,
   handler_id           int null,
   handler              varchar(64) null,
   respond_time         datetime,
   update_time          datetime,
   close_time           datetime,
   extra                text,
   primary key (ticket_id)
);
alter table om_ticket_process add constraint FK_ticket_process foreign key (ticket_id)
      references om_ticket (ticket_id) on delete restrict on update restrict;

drop table if exists om_bak_vm_policy;
create table om_bak_vm_policy
(
   vdc_id   	numeric NOT NULL,
   bak_cycle 	tinyint not null, -- 0、天1、周2、月
   bak_day		tinyint not null, -- 天
   bak_time		varchar(5),  -- 时间
   primary key (vdc_id)
);


drop table if exists om_bak_vm;
create table om_bak_vm
(
   bak_id		int not null,
   vdc_id   	numeric NOT NULL,
   dc_id        varchar(64) NOT NULL,
   project_id   varchar(64) NOT NULL,
   vm_id		varchar(64) NOT NULL,
   vm_name		varchar(200),
   vm_type		tinyint null, -- 1、openstack
   image_id		varchar(64) NOT NULL,
   image_name 	varchar(200),
   type			tinyint not null, -- 1、自动 2、手动
   update_date  datetime not null,
   extra		text,
   
   primary key (bak_id)
);	 	  

drop table if exists om_resource_statistic;
create table om_resource_statistic
(
   vdc_id   	   int not null,
   year            varchar(10) not null,
   yearmonth       varchar(10) not null,
   date            varchar(10) not null,
   type            int not null, -- 1.instance 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
   resource_id     varchar(100) not null,
   resource_name   varchar(100) not null,
   usagetime       int          not null,
   
   primary key (type, resource_id, date)
);

use opslog;
alter table t_cost_01 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_02 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_03 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_04 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_05 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_06 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_07 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_08 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_09 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_10 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_11 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_12 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_13 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_14 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_15 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_16 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_17 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_18 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_19 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_20 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_21 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_22 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_23 add column duration  numeric(20, 0)  default 0 not null;
alter table t_cost_24 add column duration  numeric(20, 0)  default 0 not null;
      
use zxinsys;
call proc_res_op_grpscript2(0, 1, 105, '工单管理', '工单管理'); 
call proc_res_op_grpdef(0, 1, 105, 1396, 139618);
call proc_res_op_v_grpscript(0, 1, 6122, '工单管理员组');
call proc_res_op_v_grpscript(0, 1, 6123, '工单操作员组');
call proc_res_op_v_grpdef(0, 1, 6122, 105);
call proc_res_op_v_grpdef(0, 1, 6123, 105);
call proc_res_op_v_grpdef(0,1,1000,105);
call proc_res_op_v_grpdef(0,1,1001,105);
call proc_res_op_function(0, 1, 1396, 139618,'工单管理');

insert into oper_rights2 (operid, servicekey, opergrpid) values(1, 'uniportal', 6122);
insert into oper_rights2 (operid, servicekey, opergrpid) values(1, 'uniportal', 6123);

insert into opergrp_homepage (v_opergrpid, servicekey, homepage) values (6122, 'uniportal','');
insert into opergrp_homepage (v_opergrpid, servicekey, homepage) values (6123, 'uniportal','');

delete from portal_sysparam where param_name = 'ticket_switch_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('ticket_switch_control','0','工单控制开关','iROS','工单控制开关',
             4,1000,1,'0-关闭, 1-开启',1,
             '','','','','');delete from portal_sysparam where param_name = 'order_task_count';
delete from portal_sysparam where param_name = 'order_task_count';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('order_task_count','3','订单创建资源重试最大次数','iROS','订单创建资源重试最大次数',
             2,1000,0,'',1,
             '','','','','');
	 		 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,field_type,max_value,min_value,default_value,visiblelevel,check_script,ext1,ext2,ext3,ext4) 
select 'iros_ticket_attachment_path','/home/zxin10/was/tomcat/webapps/workorder/attachment','工单附件存放路径','iROS','工单附件存放路径',
             2,100,0,'/home/zxin10/was/tomcat/webapps/workorder/attachment',1,'','','','','' from dual 
where not exists(select * from portal_sysparam where param_name='iros_ticket_attachment_path')
;
