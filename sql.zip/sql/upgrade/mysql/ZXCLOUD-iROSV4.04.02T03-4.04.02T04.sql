use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.02T04' where name = 'iROS';

use zxinmeasure;
DELETE from measure_typeset where sysno = '2071';
DELETE from measure_typeset where sysno = '2072';
DELETE from measure_itemset where sysno = '2071';
DELETE from measure_itemset where sysno = '2072';
DELETE from ros_pitemdef;
DELETE from ros_ptypedef where poid in ('100821','100822','100824','100826','100801','100802','100803','100813','100806');
DELETE from ros_ommp_rel;
commit;
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100701, 'CPU使用率', 'IROSHOST', 1, 'measure_hcpudata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100702, '内存使用情况', 'IROSHOST', 1, 'measure_hmemdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100703, '磁盘读取速率', 'IROSHOST', 1, 'measure_hdiskreaddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100704, '磁盘写入速率', 'IROSHOST', 1, 'measure_hdiskwritedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100705, '磁盘大小', 'IROSHOST', 1, 'measure_hdisksizedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100706, '磁盘已使用大小', 'IROSHOST', 1, 'measure_hdiskuseddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100709, '磁盘每秒读次数', 'IROSHOST', 1, 'measure_hdiskreadtimesdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100710, '磁盘每秒写次数', 'IROSHOST', 1, 'measure_hdiskwritetimesdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100711, '磁盘IO延迟', 'IROSHOST', 1, 'measure_hdiskiodelaydata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100707, '网络出口带宽', 'IROSHOST', 1, 'measure_hnicoutdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100708, '网络入口带宽', 'IROSHOST', 1, 'measure_hnicindata', 2, 1, 1);
commit;

insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100701, 1, 'CPU使用率', 'statcode1', 'measure_hcpudata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100702, 1, '内存使用情况', 'statcode1', 'measure_hmemdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100703, 1, '磁盘读取速率', 'statcode1', 'measure_hdiskreaddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100704, 1, '磁盘写入速率', 'statcode1', 'measure_hdiskwritedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100705, 1, '磁盘大小', 'statcode1', 'measure_hdisksizedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100706, 1, '磁盘已使用大小', 'statcode1', 'measure_hdiskuseddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100709, 1, '磁盘每秒读次数', 'statcode1', 'measure_hdiskreadtimesdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100710, 1, '磁盘每秒写次数', 'statcode1', 'measure_hdiskwritetimesdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100711, 1, '磁盘IO延迟', 'statcode1', 'measure_hdiskiodelaydata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100707, 1, '网络出口带宽', 'statcode1', 'measure_hnicoutdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100708, 1, '网络入口带宽', 'statcode1', 'measure_hnicindata', 3, 1);
commit;

insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100721, 'CPU使用率', 'IROSVM', 1, 'measure_vcpudata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100722, '内存使用情况', 'IROSVM', 1, 'measure_vmemdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100723, '磁盘读取速率', 'IROSVM', 1, 'measure_vdiskreaddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100724, '磁盘写入速率', 'IROSVM', 1, 'measure_vdiskwritedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100725, '磁盘大小', 'IROSVM', 1, 'measure_vdisksizedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100726, '网络出口带宽', 'IROSVM', 1, 'measure_vnicoutdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100727, '网络入口带宽', 'IROSVM', 1, 'measure_vnicindata', 2, 1, 1);
commit;
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100721, 1, 'CPU使用率', 'statcode1', 'measure_vcpudata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100722, 1, '内存使用情况', 'statcode1', 'measure_vmemdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100723, 1, '磁盘读取速率', 'statcode1', 'measure_vdiskreaddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100724, 1, '磁盘写入速率', 'statcode1', 'measure_vdiskwritedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100725, 1, '磁盘大小', 'statcode1', 'measure_vdisksizedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100726, 1, '网络出口带宽', 'statcode1', 'measure_vnicoutdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100727, 1, '网络入口带宽', 'statcode1', 'measure_vnicindata', 3, 1);
commit; 

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010001', 1, 'CPU使用率', 'cpu_util', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010002', 1, '内存使用情况', 'memory.usage', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 1, '磁盘读取速率', 'disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 2, '磁盘写入速率', 'disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 3, '磁盘大小', 'disk.total.size', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 1, '网络出口带宽', 'network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 2, '网络入口带宽', 'network.incoming.bytes.rate', 'B/s', 2, 1);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010005', 1, 'CPU使用率', 'compute.node.cpu.percent', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010006', 1, '内存使用情况', 'compute.node.memory.used', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 1, '磁盘读取速率', 'compute.node.disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 2, '磁盘写入速率', 'compute.node.disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 3, '磁盘大小', 'compute.node.disk.total', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 4, '磁盘已使用大小', 'compute.node.disk.used', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 1, '网络出口带宽', 'compute.node.network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 2, '网络入口带宽', 'compute.node.network.incoming.bytes.rate', 'B/s', 2, 1);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020001', 1, 'CPU使用率', '2', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020002', 1, '内存使用率', '24', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 1, '磁盘读取', '130', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 2, '磁盘写入', '131', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 1, '网络出口带宽', '149', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 2, '网络入口带宽', '148', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020005', 1, 'CPU使用率', '2', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020006', 1, '内存使用情况', '24', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 1, '磁盘读取速率', '130', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 2, '磁盘写入速率', '131', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 1, '网络出口带宽', '149', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 2, '网络入口带宽', '148', 'KB/s', 2, 1);

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010001', 1, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010002', 1, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 1, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 2, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 3, 2072, 100725);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010004', 1, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010004', 2, 2072, 100727);

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010005', 1, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010006', 1, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 1, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 2, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 3, 2071, 100705);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 4, 2071, 100706);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010008', 1, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010008', 2, 2071, 100708);


insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020001', 1, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020002', 1, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020003', 1, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020003', 2, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020004', 1, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020004', 2, 2072, 100727);

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020005', 1, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020006', 1, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020007', 1, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020007', 2, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020008', 1, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020008', 2, 2071, 100708);

commit;
