use zxinsys;
call proc_res_op_grpdef(0, 1, 102, 11, 18102);

delete from portal_sysparam where param_name = 'resource_close_day';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('resource_close_day','10','欠费后资源预留天数','iROS','欠费后资源预留天数',
             1,1000,1,'10',1,
             '','','','','');      


use iros;

drop procedure  if exists proc_t_task_col_update;
DELIMITER &&
create procedure proc_t_task_col_update()
BEGIN 
	DECLARE v_count tinyint;
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_task' and column_name='endt_ime';
	if(v_count > 0)  THEN 
		ALTER TABLE `t_task`
		CHANGE COLUMN `endt_ime` `end_time`  datetime NULL DEFAULT NULL,
		CHANGE COLUMN `operatorip` `operator_ip`  varchar(100) NULL DEFAULT NULL;
	END IF; 
end&& 
DELIMITER ; 
call proc_t_task_col_update;


use zxinsys;
call proc_res_op_function(0, 1, 1396, 139605,'订单审批');
call proc_res_op_function(0, 1, 1396, 139617,'流程配置');


use iros;

drop table if exists om_order_task;
drop table if exists om_order_detail;
drop table if exists om_order_audit;
drop table if exists om_order;
drop table if exists om_order_process;
drop table if exists om_order_process_config;
drop table if exists om_order_sequence;
drop table if exists om_res_order_process_rel;
drop table if exists om_server;

create table om_order
(
   order_id             int not null,
   order_code           varchar(64) not null,
   dc_id                varchar(64),
   vdc_id               varchar(64),
   user_id              int not null,
   res_type             tinyint not null,
   oper_type            tinyint not null comment '1-申请资源 2-变更资源 3-回收资源',
   process_id           int not null,
   current_step         int not null,
   start_date           datetime not null,
   end_date             datetime,
   quantity             int not null,
   primary key (order_id)
);

create table om_order_audit
(
   order_audit_id       int not null,
   order_id             int not null,
   auditor_id           int not null,
   audit_date           datetime not null,
   audit_content        varchar(500) not null,
   primary key (order_audit_id)
);

create table om_order_detail
(
   order_detail_id      int not null,
   order_id             int not null,
   order_params         text not null,
   primary key (order_detail_id)
);

create table om_order_process
(
   process_id           int not null,
   name                 varchar(50) not null,
   description          text,
   auto_step            int not null,
   is_use               tinyint not null comment '0:  不启用   1:  启用',
   is_auto_deliver      tinyint not null comment '0:  手工交付 1:  自动交付',
   primary key (process_id)
);

insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(2, '云服务器审批流程', '适用于虚拟机申请审批流程', 2, 0, 0);
commit;

create table om_order_process_config
(
   process_id           int not null,
   step                 int not null,
   description          text,
   role_id              int,
   current_status       varchar(50) not null,
   next_status          varchar(50) not null,
   is_rollback          tinyint not null comment '0：不可以回退 1：可以回退'
);


insert into om_order_process_config values ('2', '1', '审批', null, '已提交', '待创建', '0');
insert into om_order_process_config values ('2', '2', '系统创建', null, '待创建', '待交付', '0');
insert into om_order_process_config values ('2', '3', '交付', null, '待交付', '正常关闭', '0');
insert into om_order_process_config values ('2', '-2', '异常结束', null, '异常结束', '异常结束', '0');
insert into om_order_process_config values ('2', '-1', '审批拒绝', null, '审批拒绝', '审批拒绝', '0');
insert into om_order_process_config values ('2', '0', '正常关闭', null, '正常关闭', '正常关闭', '0');
commit;

create table om_res_order_process_rel
(
   res_type             tinyint not null,
   process_id           int not null
);

create table om_order_sequence
(
   cur_month            int not null,
   cur_value            int not null
);

create table om_order_task
(
   order_detail_id      int not null,
   task_id              int not null,
   task_step            tinyint not null,
   task_status          tinyint not null comment '1-成功 2-失败 3-处理中',
   retry_num            int not null default 0,
   req_params           text,
   resp_params          text,
   primary key (task_id)
);

insert into om_res_order_process_rel (res_type, process_id) values(1, 2);
commit;


alter table om_order_audit add constraint FK_order_orderaudit foreign key (order_id)
      references om_order (order_id) on delete restrict on update restrict;

alter table om_order_detail add constraint FK_order_orderdetail foreign key (order_id)
      references om_order (order_id) on delete restrict on update restrict;

alter table om_order_task add constraint FK_orderdetail_ordertask foreign key (order_detail_id)
      references om_order_detail (order_detail_id) on delete restrict on update restrict;

create table om_server 
(
   id          varchar(64) not null,
   dc_id       varchar(64) not null,
   vdc_id      int not null,
   user_id     int not null,
   order_id    int not null,
   primary key (id)
);


use opslog;
drop procedure  if exists proc_t_cost_col_update;
create procedure proc_t_cost_col_update()
BEGIN 
	DECLARE v_count tinyint;
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost' and column_name='is_submit';
	if(v_count < 1)  THEN 
	   alter table t_cost add is_submit int  default 1   not null;
	END IF; 
	
END;
call proc_t_cost_col_update;

drop procedure  if exists proc_t_deduct_col_update;
create procedure proc_t_deduct_col_update()
BEGIN 
	DECLARE v_count tinyint;
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_deduct' and column_name='deduct_time';
	if(v_count < 1)  THEN 
	   alter table t_deduct add deduct_time datetime     		null;
	END IF; 
	
END;
call proc_t_deduct_col_update;