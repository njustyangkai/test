use zxinsys;

delete from oper_virtual_grpdef where v_opergrpid=6141 and servicekey='uniportal';

-- 创建菜单
call proc_res_op_function(0, 1, 1396, 139641,'应用管理');

-- 增加新角色：应用管理员
call proc_res_op_grpscript2(0, 1, 109, '应用管理员', '应用管理员');

-- 增加相应的权限
call proc_res_op_grpdef(0, 1, 109, 1396, 139641);

-- 创建操作员组
call proc_res_op_v_grpscript(0, 1, 6141, '应用管理员组');

-- 给新增的操作员组赋予新的角色：
call proc_res_op_v_grpdef(0, 1, 6141, 109);

-- 给初始化用户super所在的组赋予新增角色：
call proc_res_op_v_grpdef(0,1,1000,109);
call proc_res_op_v_grpdef(0,1,1001,109);

use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.04T03' where name = 'iROS';

-- 增加服务目录
delete from om_base_service where id = 15;
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (15, '应用服务', 'switch_isware', '','通过iROS界面可以链接到iSWare首页，进行应用管理。',',1,2,');

-- 增加功能控制配置项
delete from om_control_function where id = 'isware_switch_control';
delete from om_control_function where id = 'isware_path';
insert into om_control_function values ('isware_switch_control','iSWare融合开关', '0'); -- 0、关闭1、开启
insert into om_control_function values ('isware_path','iSWare地址', 'http://127.0.0.1:8101/uniportal/frame/login.action?directTurnToHome=false&userName=super&password=Zte@12345');

-- 新增历史记录表
drop table if exists om_history_records;
CREATE TABLE om_history_records ( 
	dc_id						varchar(64) 	NOT NULL, 
	instance_id					varchar(100) 	NOT NULL,  
	oper_type					int 		    NOT NULL,  
	created						varchar(64) 	NULL,
	status						int     		NULL,
	detail						text 			NULL
);
