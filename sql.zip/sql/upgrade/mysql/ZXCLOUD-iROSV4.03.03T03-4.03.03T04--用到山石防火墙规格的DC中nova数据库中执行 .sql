use nova;
delete from instance_types where name = 'VFW001';
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('VFW001',21 , 1024, 1, 0, NULL, '21', 0, 0, 0, 0, 1, 0);
delete from instance_types where name = 'VFW002';
INSERT INTO `instance_types` (`name`, `id`, `memory_mb`, `vcpus`, `swap`, `vcpu_weight`, `flavorid`, `rxtx_factor`, `root_gb`, `ephemeral_gb`, `disabled`, `is_public`, `deleted`) VALUES ('VFW002', 22, 2048, 2, 0, NULL, '22', 0, 0, 0, 0, 1, 0);