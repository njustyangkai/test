use zxinsys;
-- 删除性能和故障两个菜单
delete from oper_funcgrp2 where funcgrpid =1 and servicekey='uniportal';
delete from oper_funcgrp2 where funcgrpid =3 and servicekey='uniportal';

delete from oper_function where funcgrpid=1 and servicekey='uniportal';
delete from oper_function where funcgrpid=3 and servicekey='uniportal';

delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =1;
delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =3;

-- 隐藏性能统计菜单
call proc_res_op_function(0, 2, 1396, 139611,'');

UPDATE portal_sysparam SET description = '镜像下载缺省绝对路径(/开头,只能有-_/字母和数字),最长254个字符', check_script = '/^[/]([a-zA-Z0-9-_/]){0,254}$/' 
	WHERE param_name = 'download_image_default_path';


use irosmeasure;
delete from ros_ptypedef where poid = '1010002';
delete from ros_pitemdef where pitemfield = 'memory.usage';