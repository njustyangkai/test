use opslog;

drop procedure  if exists proc_t_cost_col_temp;
DELIMITER &&
create procedure proc_t_cost_col_temp()
BEGIN 
	DECLARE v_count tinyint;
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_01' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_01 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_02' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_02 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_03' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_03 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_04' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_04 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_05' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_05 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_06' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_06 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_07' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_07 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_08' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_08 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_09' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_09 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_10' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_10 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_11' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_11 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_12' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_12 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_13' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_13 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_14' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_14 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_15' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_15 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_16' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_16 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_17' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_17 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_18' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_18 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_19' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_19 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_20' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_20 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_21' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_21 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_22' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_22 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_23' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_23 add duration numeric(20, 0) default 0 not null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_cost_24' and column_name='duration';
	if(v_count < 1)  THEN 
	   alter table t_cost_24 add duration numeric(20, 0) default 0 not null;
	END IF; 

END&&
DELIMITER ;
call proc_t_cost_col_temp;

use iros;

create table if not exists om_resource_statistic
(
   vdc_id   	   int not null,
   year            varchar(10) not null,
   yearmonth       varchar(10) not null,
   date            varchar(10) not null,
   type            int not null, -- 1.instance 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
   resource_id     varchar(100) not null,
   resource_name   varchar(100) not null,
   usagetime       int          not null,
   
   primary key (type, resource_id, date)
);

create table if not exists om_compute_threshold
(
	dc_id				varchar(64)		not null,
	compute				varchar(100)	not null,
	cpu					int				not null,
	mem					int				not null,
	primary key (dc_id, compute)
);

create table if not exists om_compute_migrate
(
	task_id				varchar(64)		not null,
	dc_id				varchar(64)		not null,
	compute				varchar(100)	not null,
	server_id			varchar(64)		not null,
	server_name			varchar(64)		not null,
	migrate_result		int				not null,
	migrate_detail		text			null,
	migrate_time		datetime		not null,
	primary key (task_id)
);

use zxinsys;
delete from portal_sysparam where param_name = 'compute_threshold';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('compute_threshold', '1', '是否支持服务器阈值设置', 'iROS', '服务器阈值设置开关', 
			4, null, null, '1-支持,0-不支持', 0, 
			'', '', '', '', '');
			
use zxinmeasure;
update measure_typeset set resourcetype = 'IROSHOST' where resourcetype = 'iROSHOST';
update measure_typeset set resourcetype = 'IROSVM' where resourcetype = 'iROSVM';