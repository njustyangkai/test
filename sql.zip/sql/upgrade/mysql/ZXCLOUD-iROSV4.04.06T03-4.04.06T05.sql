use opslog;
drop procedure if exists proc_update_columns_4_04_05_T04_to_4_04_05_T05;
DELIMITER &&
create procedure proc_update_columns_4_04_05_T04_to_4_04_05_T05()
BEGIN 
  DECLARE v_count tinyint;
  DECLARE col_count tinyint;
  DECLARE col_count_cost tinyint;
  DECLARE table_suffix CHAR(10);
  set v_count=1;
  set col_count=0;

  SELECT count(*) into col_count_cost FROM information_schema.columns where table_name= 't_cost' and column_name='flavor';
  if(col_count_cost < 1)  THEN 
    ALTER table t_cost add flavor varchar(500);     
	END IF;

  while v_count<25 DO
      
      IF(v_count<10) THEN
        set table_suffix = CONCAT('0',CONVERT(v_count,CHAR(5)));
      ELSE
        set table_suffix = CONVERT(v_count,CHAR(5));
      END IF;

      SELECT count(*) into col_count FROM information_schema.columns where table_name= CONCAT('t_cost_',table_suffix) and column_name='flavor'; 	
	    if(col_count < 1)  THEN 
          SET @sqlStr = CONCAT('t_cost_',table_suffix);
          SET @sqlStr = CONCAT('alter table ',@sqlStr);
          SET @sqlStr = CONCAT(@sqlStr,' add flavor varchar(500)');
          PREPARE stmt FROM @sqlStr; 
          EXECUTE stmt;
	    END IF;
      
      set v_count = v_count +1;
 end while; 

end&& 
DELIMITER ; 
commit;

call proc_update_columns_4_04_05_T04_to_4_04_05_T05;
drop procedure if exists proc_update_columns_4_04_05_T04_to_4_04_05_T05;

use iros;
delete from om_control_function where id in ('charge_system', 'jm_url_path', 'isware_switch_control', 'isware_path');
insert into om_control_function values ('charge_system','计费系统', '0'); -- 0、其他1、绛门
insert into om_control_function values ('jm_url_path','绛门接口地址', 'http://127.0.0.5:8780/csm');

delete from om_base_service where id = 15;
delete from om_vdc_srvdir where srvdir_id in (select id from iros.om_service_directory where switch_name = 'switch_isware');
delete from om_service_directory where switch_name = 'switch_isware';

use zxinsys;
call proc_res_op_grpdef(0, 1, 109, 1396, 139641);
call proc_res_op_v_grpscript(0, 1, 6141, '应用管理员组');
call proc_res_op_v_grpdef(0, 1, 6141, 109);
call proc_res_op_v_grpdef(0,1,1000,109);
call proc_res_op_v_grpdef(0,1,1001,109);
call proc_res_op_grpscript2(0, 1, 109, '应用管理员', '应用管理员');
call proc_res_op_function(0, 1, 1396, 139641,'应用管理');
