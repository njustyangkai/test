use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.05T03' where name = 'iROS';

delete from os_name_config where os_id = '64';
delete from os_name_config where os_id = '65';
delete from os_name_config where os_id = '66';
delete from os_name_config where os_id = '67';
delete from os_name_config where os_id = '68';
delete from os_name_config where os_id = '69';
delete from os_name_config where os_id = '70';
delete from os_name_config where os_id = '71';
delete from os_name_config where os_id = '72';
delete from os_name_config where os_id = '73';
delete from os_name_config where os_id = '74';
delete from os_name_config where os_id = '75';
delete from os_name_config where os_id = '76';
delete from os_name_config where os_id = '77';
delete from os_name_config where os_id = '78';
delete from os_name_config where os_id = '79';
delete from os_name_config where os_id = '80';
delete from os_name_config where os_id = '81';
delete from os_name_config where os_id = '82';
delete from os_name_config where os_id = '83';

insert into os_name_config(os_id, os_type, os_name) values('64','Linux','CentOS Linux 6.3 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('65','Linux','CentOS Linux 6.4 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('66','Linux','CentOS Linux 6.5 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('67','Linux','CentOS Linux 4/5(32)');
insert into os_name_config(os_id, os_type, os_name) values('68','Linux','CentOS Linux 4/5(64)');
insert into os_name_config(os_id, os_type, os_name) values('69','Linux','NewStart Destop Linux Office Editon(64)');
insert into os_name_config(os_id, os_type, os_name) values('70','Linux','Red Hat Enterprise Linux 5.8 Enterprise Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('71','Linux','Red Hat Enterprise Linux 6.3 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('72','Linux','Red Hat Linux 4/5(32)');
insert into os_name_config(os_id, os_type, os_name) values('73','Linux','Red Hat Linux 4/5(64)');
insert into os_name_config(os_id, os_type, os_name) values('74','Linux','Suse Linux Enterprise 12(32)');
insert into os_name_config(os_id, os_type, os_name) values('75','Linux','Suse Linux Enterprise 12(64)');
insert into os_name_config(os_id, os_type, os_name) values('76','Windows','Microsoft Windows 10(32)');
insert into os_name_config(os_id, os_type, os_name) values('77','Windows','Microsoft Windows 10(64)');
insert into os_name_config(os_id, os_type, os_name) values('78','Windows','Microsoft Windows Server 2008 R2,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('79','Windows','Microsoft Windows Server 2008 R2,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('80','Windows','Microsoft Windows Server 2012 R2,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('81','Windows','Microsoft Windows Server 2012 R2,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('82','Windows','Microsoft Windows Server 2012,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('83','Windows','Microsoft Windows Server 2012,Standard Edition(64)');


drop procedure if exists proc_update_columns_4_04_05_T02_to_4_04_05_T03;
DELIMITER &&
create procedure proc_update_columns_4_04_05_T02_to_4_04_05_T03()
BEGIN 
	DECLARE v_count tinyint;	
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_user_info' and column_name='description';
	if(v_count < 1)  THEN 
	   alter table om_user_info add  description  text;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_user_info' and column_name='opinion';
	if(v_count < 1)  THEN 
	   alter table om_user_info add  opinion  text;
	END IF;
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_user_info' and column_name='createdtime';
	if(v_count < 1)  THEN 
	   alter table om_user_info add  createdtime  datetime 	NULL;
	END IF;
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_user_info' and column_name='auditedtime';
	if(v_count < 1)  THEN 
	   alter table om_user_info add  auditedtime  datetime 	NULL;
	END IF;
	
end&& 
DELIMITER ; 
commit;


call proc_update_columns_4_04_05_T02_to_4_04_05_T03;
drop procedure if exists proc_update_columns_4_04_05_T02_to_4_04_05_T03;

delete from om_control_function where id in ('evaluate_switch_control', 'evaluate_period', 'vdc_user_register_control');
insert into om_control_function values ('evaluate_switch_control','系统和服务评价开关', '0'); -- 0、关闭1、开启
insert into om_control_function values ('evaluate_period','调研时间', '');
insert into om_control_function values ('vdc_user_register_control','vdc用户注册开关', '0');	-- 0、关闭 1、开启

-- 新增 服务评价表
drop table if exists om_service_evaluation;
create table om_service_evaluation
(
   order_id             int NOT NULL,
   type 				int NOT NULL,
   user_id 				int NOT NULL,
   evaluation   		int NOT NULL,
   comment				varchar(512) NULL,
   evaluate_date        datetime NOT NULL
);

-- 新增 系统评价表
drop table if exists om_system_evaluation;
create table om_system_evaluation
(
  id                int NOT NULL,
  user_id 			int NOT NULL,
  vdc_id            int NOT NULL,
  usability 		int NOT NULL,
  systemic_fluency  int NOT NULL,
  processing_rate   int NOT NULL,
  comment			varchar(512) NULL,
  evaluate_date     datetime NOT NULL,
  primary key (id)
);

use zxinsys;
call proc_res_op_function(0, 1, 1396, 139645,'系统调查');