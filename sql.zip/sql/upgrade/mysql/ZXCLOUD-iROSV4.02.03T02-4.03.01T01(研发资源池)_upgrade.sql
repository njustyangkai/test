﻿drop database if exists irosmeasure;  
create database irosmeasure DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
grant all privileges on irosmeasure.* to 'irosmeasure'@'localhost' identified by 'db10$ZTE';
commit;

use irosmeasure;

drop table if exists ros_ptypedef;
create table ros_ptypedef (
   res_type             varchar(100)                   not null,
   poid                 varchar(20)                    not null,
   poname               varchar(128)                   not null,
   tablename            varchar(32)                    not null,
   bvisible             tinyint                        not null,
   isrealtime           tinyint                        not null,
   extrastr             varchar(255)                   null,
   primary key (res_type, poid)
);


drop table if exists ros_pitemdef;
create table ros_pitemdef (
   poid                 varchar(20)                    not null,
   pitemid              integer                        not null,
   pitemname            varchar(128)                   not null,
   pitemfield           varchar(128)                    not null,
   pitemutil            varchar(32)                    not null,
   datatype             tinyint                        not null,
   bvisible             tinyint                        not null,
   lasttime             datetime                       null,
   extrastr             varchar(256)                   null,
   primary key (poid, pitemid)
);



drop procedure if exists p_create_table;
DELIMITER &&
create procedure p_create_table(in vname varchar(50))
begin
		declare i int;
	    declare mmdd varchar(4);
		declare tabname varchar(20);
		declare vsql varchar(1000);
 
		set i=24;
		while i>=1 do
			set mmdd=right(concat('0', i), 2);
			set tabname=concat(vname,mmdd);
            SET @sql_txt = concat('drop table if exists ', tabname); 
            PREPARE stmt FROM @sql_txt; 
		    EXECUTE stmt;
			  
			set vsql=concat('create table ',tabname,
		                     '(time            datetime not null,',
						     'res_type         varchar(100) null,',
							 'dc_id            varchar(100) not null,',
						     'res_id           varchar(100) not null,',
						     'moc_id           varchar(100) null,',
							 'pitemid          integer null,',
							 'usage_value      float null)');
		
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt; 
		
		       
			set vsql=concat('create index idx_time_',tabname,' on ',tabname,'(time)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_res_id_',tabname,' on ',tabname,'(res_id)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_moc_id_',tabname,' on ',tabname,'(moc_id)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
		set i=i-1;
		end while;
end&& 
DELIMITER ; 
commit;


call p_create_table('data_vm_cpu');
call p_create_table('data_vm_mem');
call p_create_table('data_vm_disk'); 
call p_create_table('data_vm_nic');
call p_create_table('data_host_cpu');
call p_create_table('data_host_mem');
call p_create_table('data_host_disk'); 
call p_create_table('data_host_nic');

insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010001', '虚拟机CPU性能', 'data_vm_cpu', 1, 0);
-- insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010002', '虚拟机内存性能', 'data_vm_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010003', '虚拟机磁盘性能', 'data_vm_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010004', '虚拟机网卡性能', 'data_vm_nic', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010005', '物理机CPU性能', 'data_host_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010006', '物理机内存性能', 'data_host_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010007', '物理机磁盘性能', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010008', '物理机网卡性能', 'data_host_nic', 1, 0);

insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010001', 1, '虚拟机CPU使用率', 'cpu_util', '%', 2, 1);
-- insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010002', 1, '虚拟机内存使用情况', 'memory.usage', 'MB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 1, '虚拟机磁盘读取速率', 'disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 2, '虚拟机磁盘写入速率', 'disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 3, '虚拟机磁盘大小', 'disk.total.size', 'GB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010004', 1, '虚拟机网络出口带宽', 'network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010004', 2, '虚拟机网络入口带宽', 'network.incoming.bytes.rate', 'B/s', 2, 1);

insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010005', 1, '物理机CPU使用率', 'compute.node.cpu.percent', '%', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010006', 1, '物理机内存使用情况', 'compute.node.memory.used', 'MB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 1, '物理机磁盘读取速率', 'compute.node.disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 2, '物理机磁盘写入速率', 'compute.node.disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 3, '物理机磁盘大小', 'compute.node.disk.total', 'GB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 4, '物理机磁盘已使用大小', 'compute.node.disk.used', 'GB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010008', 1, '物理机网络出口带宽', 'compute.node.network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010008', 2, '物理机网络入口带宽', 'compute.node.network.incoming.bytes.rate', 'B/s', 2, 1);



use zxinsys;

delete from portal_sysparam where param_name ='versionnumber';
insert into portal_sysparam(param_name,param_value, description) values('versionnumber', 'ZXCLOUD-iROSV4.03.01', '版本号');

-- 删除性能和故障两个菜单
delete from oper_funcgrp2 where funcgrpid =1 and servicekey='uniportal';
delete from oper_funcgrp2 where funcgrpid =3 and servicekey='uniportal';

delete from oper_function where funcgrpid=1 and servicekey='uniportal';
delete from oper_function where funcgrpid=3 and servicekey='uniportal';

delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =1;
delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =3;

call proc_res_op_paratype(0 ,2, 101, '');		-- 去除【故障管理】操作日志统计类型
call proc_res_op_paratype(0 ,2, 102, '');		-- 去除【性能统计】操作日志统计类型
call proc_res_op_paratype(0 ,2, 103, '');		-- 去除【资源管理】操作日志统计类型


call proc_res_op_grpdef(0, 1, 103, 1396, 139601);

call proc_res_op_function(0, 1, 1396, 139606,'日志管理');
call proc_res_op_function(0, 1, 1396, 139607,'备份管理');
call proc_res_op_function(0, 1, 1396, 139608,'告警地址配置');
call proc_res_op_function(0, 1, 1396, 139609,'实时告警');
call proc_res_op_function(0, 1, 1396, 139610,'历史告警');
call proc_res_op_function(0, 1, 1396, 139611,'性能统计');

call proc_res_op_function(0, 2, 1396, 139603,'') -- 价格管理

call proc_res_op_paratype(0, 1, 3961, '云管理');

UPDATE portal_sysparam SET description = '镜像下载缺省绝对路径(/开头,只能有-_/字母和数字),最长254个字符', check_script = '/^[/]([a-zA-Z0-9-_/]){0,254}$/' 
	WHERE param_name = 'download_image_default_path';
	
delete from portal_sysparam where param_name = 'remote_syn_user';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_syn_user','','4A同步用户信息调用地址','iROS','4A同步用户信息调用地址',
             2,100,0,' ',1,
             '','','','','');
delete from portal_sysparam where param_name = 'remote_idcim_host';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_idcim_host','','获取物理主机列表调用地址','iROS','获取物理主机列表调用地址',
             2,100,0,' ',1,
             '','','','','');			 
			 			 
delete from portal_sysparam where param_name = 'iros_backup_shell_path';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_backup_shell_path','/home/iros/db_bak','备份shell脚本放置路径','iROS','备份shell脚本放置路径',
             2,100,0,'/home/iros/db_bak',0,
             '','','','','');

delete from portal_sysparam where param_name = 'volume_upper_limit';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('volume_upper_limit','500','云硬盘大小上限(GB)','iROS','云硬盘大小上限(GB)',
             2,100,0,' ',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'om_support_hr';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('om_support_hr', '1', '是否支持hr鉴权', 'iROS', '是否支持hr鉴权', 
			4, null, null, '1-支持,0-不支持', 1, 
			'', '', '', '', '');
			
delete from portal_sysparam where param_name = 'hr_server_url';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('hr_server_url', 'http://tech.zte.com.cn/tech/xmlrpc', 'hr鉴权url', 'iROS', 'hr鉴权url', 
			2, 100, 0, '', 0, 
			'', '', '', '', '');
			
			
delete from ommp_res_definition where rid = 'OPENSTACK';


-- 针对RCS需求，用户直接与权限关联控制开关打开，前提是ommp已升级到对应的版本
delete from oper_funcgrp2 where funcgrpid = 4;
insert into oper_funcgrp2 values (4, '4', '权限管理', 'uniportal', 0);
delete from oper_function where funcdescription in ('操作员管理','角色信息','组信息','安全等级','安全规则设置','操作员信息编辑','角色信息编辑','组信息编辑','安全等级编辑','安全规则设置编辑','创建删除资源');
insert into oper_function values (4, 13001, '1301' , '操作员管理'  ,       0, 'uniportal');
insert into oper_function values (4, 13003, '1303' , '角色信息'    ,       0, 'uniportal');
insert into oper_function values (4, 13005, '1305' , '组信息'      ,       0, 'uniportal');
insert into oper_function values (4, 13007, '1307' , '安全等级'     ,      0, 'uniportal');
insert into oper_function values (4, 13008, '1308' , '安全规则设置'  ,      0, 'uniportal');
insert into oper_function values (4, 13009, '1309' , '操作员信息编辑'  ,      0, 'uniportal');
insert into oper_function values (4, 13011, '1311' , '角色信息编辑'  ,      0, 'uniportal');
insert into oper_function values (4, 13014, '1314' , '组信息编辑'  ,       0, 'uniportal'); 
insert into oper_function values (4, 13016, '1316' , '安全等级编辑'  ,       0, 'uniportal'); 
insert into oper_function values (4, 13017, '1317' , '安全规则设置编辑'  ,       0, 'uniportal');
insert into oper_function values (4, 13020, '1320' , '创建删除资源'  ,       0, 'uniportal');

delete from oper_grpdef where funcgrpid=4 and opergrpid=1000  and servicekey='uniportal';
insert into oper_grpdef select 1000,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4;
delete from oper_grpdef where funcgrpid=4 and opergrpid=1001  and servicekey='uniportal';
insert into oper_grpdef select 1001,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4; 

-- 增加rcs已经存在的四种角色，4a同步用户

-- 增加新的角色：
-- proc_res_op_grpscript2 产品ID，修改标识(add-1,del-2)，角色标识，角色名称
call proc_res_op_grpscript2(0, 1, 201, '管理员角色', '管理员角色');
call proc_res_op_grpscript2(0, 1, 202, '操作员角色', '操作员角色');
call proc_res_op_grpscript2(0, 1, 203, '维护员角色', '维护员角色');
call proc_res_op_grpscript2(0, 1, 204, '监控员角色', '监控员角色'); 
call proc_res_op_grpscript2(0, 1, 205, '自定义角色', '自定义角色'); 

-- 给新增加的角色增加相应的权限：
-- 管理员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 201, 1,  10001);
call proc_res_op_grpdef(0, 1, 201, 1,  10003);
call proc_res_op_grpdef(0, 1, 201, 1,  10006);
call proc_res_op_grpdef(0, 1, 201, 1,  10007);
call proc_res_op_grpdef(0, 1, 201, 3,  12001);
call proc_res_op_grpdef(0, 1, 201, 3,  12002);
call proc_res_op_grpdef(0, 1, 201, 3,  12003);
call proc_res_op_grpdef(0, 1, 201, 3,  12007);
call proc_res_op_grpdef(0, 1, 201, 3,  12008);
call proc_res_op_grpdef(0, 1, 201, 3,  12010);
call proc_res_op_grpdef(0, 1, 201, 4,  13001);
call proc_res_op_grpdef(0, 1, 201, 4,  13003);
call proc_res_op_grpdef(0, 1, 201, 4,  13005);
call proc_res_op_grpdef(0, 1, 201, 4,  13007);
call proc_res_op_grpdef(0, 1, 201, 4,  13008);
call proc_res_op_grpdef(0, 1, 201, 4,  13009);
call proc_res_op_grpdef(0, 1, 201, 4,  13011);
call proc_res_op_grpdef(0, 1, 201, 4,  13014);
call proc_res_op_grpdef(0, 1, 201, 4,  13016);
call proc_res_op_grpdef(0, 1, 201, 4,  13017);
call proc_res_op_grpdef(0, 1, 201, 4,  13020);
call proc_res_op_grpdef(0, 1, 201, 10, 15001);
call proc_res_op_grpdef(0, 1, 201, 10, 15005);
call proc_res_op_grpdef(0, 1, 201, 10, 15007);
call proc_res_op_grpdef(0, 1, 201, 11, 18005);
call proc_res_op_grpdef(0, 1, 201, 11, 18102);
call proc_res_op_grpdef(0, 1, 201, 1396, 139601);
call proc_res_op_grpdef(0, 1, 201, 1396, 139602);
call proc_res_op_grpdef(0, 1, 201, 1396, 139603);
call proc_res_op_grpdef(0, 1, 201, 1396, 139604);
call proc_res_op_grpdef(0, 1, 201, 1396, 139605);
call proc_res_op_grpdef(0, 1, 201, 1396, 139606);
call proc_res_op_grpdef(0, 1, 201, 1396, 139607);
call proc_res_op_grpdef(0, 1, 201, 1396, 139608);
call proc_res_op_grpdef(0, 1, 201, 1396, 139609);
call proc_res_op_grpdef(0, 1, 201, 1396, 139610);


-- 给新增加的角色增加相应的权限：
-- 操作员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 202, 1,  10001);
call proc_res_op_grpdef(0, 1, 202, 1,  10003);
call proc_res_op_grpdef(0, 1, 202, 1,  10006);
call proc_res_op_grpdef(0, 1, 202, 1,  10007);
call proc_res_op_grpdef(0, 1, 202, 3,  12001);
call proc_res_op_grpdef(0, 1, 202, 3,  12002);
call proc_res_op_grpdef(0, 1, 202, 3,  12003);
call proc_res_op_grpdef(0, 1, 202, 3,  12007);
call proc_res_op_grpdef(0, 1, 202, 3,  12008);
call proc_res_op_grpdef(0, 1, 202, 3,  12010);
call proc_res_op_grpdef(0, 1, 202, 4,  13001);
call proc_res_op_grpdef(0, 1, 202, 4,  13003);
call proc_res_op_grpdef(0, 1, 202, 4,  13005);
call proc_res_op_grpdef(0, 1, 202, 4,  13007);
call proc_res_op_grpdef(0, 1, 202, 4,  13008);
call proc_res_op_grpdef(0, 1, 202, 4,  13009);
call proc_res_op_grpdef(0, 1, 202, 4,  13011);
call proc_res_op_grpdef(0, 1, 202, 4,  13014);
call proc_res_op_grpdef(0, 1, 202, 4,  13016);
call proc_res_op_grpdef(0, 1, 202, 4,  13017);
call proc_res_op_grpdef(0, 1, 202, 4,  13020);
call proc_res_op_grpdef(0, 1, 202, 10, 15001);
call proc_res_op_grpdef(0, 1, 202, 10, 15005);
call proc_res_op_grpdef(0, 1, 202, 10, 15007);
call proc_res_op_grpdef(0, 1, 202, 11, 18005);
call proc_res_op_grpdef(0, 1, 202, 11, 18102);
call proc_res_op_grpdef(0, 1, 202, 1396, 139601);
call proc_res_op_grpdef(0, 1, 202, 1396, 139602);
call proc_res_op_grpdef(0, 1, 202, 1396, 139603);
call proc_res_op_grpdef(0, 1, 202, 1396, 139604);
call proc_res_op_grpdef(0, 1, 202, 1396, 139605);
call proc_res_op_grpdef(0, 1, 202, 1396, 139606);
call proc_res_op_grpdef(0, 1, 202, 1396, 139607);
call proc_res_op_grpdef(0, 1, 202, 1396, 139608);
call proc_res_op_grpdef(0, 1, 202, 1396, 139609);
call proc_res_op_grpdef(0, 1, 202, 1396, 139610);



-- 给新增加的角色增加相应的权限：
-- 维护员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 203, 1,  10001);
call proc_res_op_grpdef(0, 1, 203, 1,  10003);
call proc_res_op_grpdef(0, 1, 203, 1,  10006);
call proc_res_op_grpdef(0, 1, 203, 1,  10007);
call proc_res_op_grpdef(0, 1, 203, 3,  12001);
call proc_res_op_grpdef(0, 1, 203, 3,  12002);
call proc_res_op_grpdef(0, 1, 203, 3,  12003);
call proc_res_op_grpdef(0, 1, 203, 3,  12007);
call proc_res_op_grpdef(0, 1, 203, 3,  12008);
call proc_res_op_grpdef(0, 1, 203, 3,  12010);
call proc_res_op_grpdef(0, 1, 203, 4,  13001);
call proc_res_op_grpdef(0, 1, 203, 4,  13003);
call proc_res_op_grpdef(0, 1, 203, 4,  13005);
call proc_res_op_grpdef(0, 1, 203, 4,  13007);
call proc_res_op_grpdef(0, 1, 203, 4,  13008);
call proc_res_op_grpdef(0, 1, 203, 4,  13009);
call proc_res_op_grpdef(0, 1, 203, 4,  13011);
call proc_res_op_grpdef(0, 1, 203, 4,  13014);
call proc_res_op_grpdef(0, 1, 203, 4,  13016);
call proc_res_op_grpdef(0, 1, 203, 4,  13017);
call proc_res_op_grpdef(0, 1, 203, 4,  13020);
call proc_res_op_grpdef(0, 1, 203, 10, 15001);
call proc_res_op_grpdef(0, 1, 203, 10, 15005);
call proc_res_op_grpdef(0, 1, 203, 10, 15007);
call proc_res_op_grpdef(0, 1, 203, 11, 18005);
call proc_res_op_grpdef(0, 1, 203, 11, 18102);


-- 给新增加的角色增加相应的权限：
-- 监控员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 204, 1,  10001);
call proc_res_op_grpdef(0, 1, 204, 1,  10003);
call proc_res_op_grpdef(0, 1, 204, 1,  10006);
call proc_res_op_grpdef(0, 1, 204, 1,  10007);
call proc_res_op_grpdef(0, 1, 204, 3,  12001);
call proc_res_op_grpdef(0, 1, 204, 3,  12002);
call proc_res_op_grpdef(0, 1, 204, 3,  12003);
call proc_res_op_grpdef(0, 1, 204, 3,  12007);
call proc_res_op_grpdef(0, 1, 204, 3,  12008);
call proc_res_op_grpdef(0, 1, 204, 3,  12010);
call proc_res_op_grpdef(0, 1, 204, 4,  13001);
call proc_res_op_grpdef(0, 1, 204, 4,  13003);
call proc_res_op_grpdef(0, 1, 204, 4,  13005);
call proc_res_op_grpdef(0, 1, 204, 4,  13007);
call proc_res_op_grpdef(0, 1, 204, 4,  13008);
call proc_res_op_grpdef(0, 1, 204, 4,  13009);
call proc_res_op_grpdef(0, 1, 204, 4,  13011);
call proc_res_op_grpdef(0, 1, 204, 4,  13014);
call proc_res_op_grpdef(0, 1, 204, 4,  13016);
call proc_res_op_grpdef(0, 1, 204, 4,  13017);
call proc_res_op_grpdef(0, 1, 204, 4,  13020);
call proc_res_op_grpdef(0, 1, 204, 10, 15001);
call proc_res_op_grpdef(0, 1, 204, 10, 15005);
call proc_res_op_grpdef(0, 1, 204, 10, 15007);
call proc_res_op_grpdef(0, 1, 204, 11, 18005);
call proc_res_op_grpdef(0, 1, 204, 11, 18102);
call proc_res_op_grpdef(0, 1, 204, 1396, 139601);
call proc_res_op_grpdef(0, 1, 204, 1396, 139602);
call proc_res_op_grpdef(0, 1, 204, 1396, 139603);
call proc_res_op_grpdef(0, 1, 204, 1396, 139604);
call proc_res_op_grpdef(0, 1, 204, 1396, 139605);
call proc_res_op_grpdef(0, 1, 204, 1396, 139606);
call proc_res_op_grpdef(0, 1, 204, 1396, 139607);
call proc_res_op_grpdef(0, 1, 204, 1396, 139608);
call proc_res_op_grpdef(0, 1, 204, 1396, 139609);
call proc_res_op_grpdef(0, 1, 204, 1396, 139610);



-- 给新增加的角色增加相应的权限：
-- 自定义角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 205, 1,  10001);
call proc_res_op_grpdef(0, 1, 205, 1,  10003);
call proc_res_op_grpdef(0, 1, 205, 1,  10006);
call proc_res_op_grpdef(0, 1, 205, 1,  10007);
call proc_res_op_grpdef(0, 1, 205, 3,  12001);
call proc_res_op_grpdef(0, 1, 205, 3,  12002);
call proc_res_op_grpdef(0, 1, 205, 3,  12003);
call proc_res_op_grpdef(0, 1, 205, 3,  12007);
call proc_res_op_grpdef(0, 1, 205, 3,  12008);
call proc_res_op_grpdef(0, 1, 205, 3,  12010);
call proc_res_op_grpdef(0, 1, 205, 4,  13001);
call proc_res_op_grpdef(0, 1, 205, 4,  13003);
call proc_res_op_grpdef(0, 1, 205, 4,  13005);
call proc_res_op_grpdef(0, 1, 205, 4,  13007);
call proc_res_op_grpdef(0, 1, 205, 4,  13008);
call proc_res_op_grpdef(0, 1, 205, 4,  13009);
call proc_res_op_grpdef(0, 1, 205, 4,  13011);
call proc_res_op_grpdef(0, 1, 205, 4,  13014);
call proc_res_op_grpdef(0, 1, 205, 4,  13016);
call proc_res_op_grpdef(0, 1, 205, 4,  13017);
call proc_res_op_grpdef(0, 1, 205, 4,  13020);
call proc_res_op_grpdef(0, 1, 205, 10, 15001);
call proc_res_op_grpdef(0, 1, 205, 10, 15005);
call proc_res_op_grpdef(0, 1, 205, 10, 15007);
call proc_res_op_grpdef(0, 1, 205, 11, 18005);
call proc_res_op_grpdef(0, 1, 205, 11, 18102);
call proc_res_op_grpdef(0, 1, 205, 1396, 139601);
call proc_res_op_grpdef(0, 1, 205, 1396, 139602);
call proc_res_op_grpdef(0, 1, 205, 1396, 139603);
call proc_res_op_grpdef(0, 1, 205, 1396, 139604);
call proc_res_op_grpdef(0, 1, 205, 1396, 139605);
call proc_res_op_grpdef(0, 1, 205, 1396, 139606);
call proc_res_op_grpdef(0, 1, 205, 1396, 139607);
call proc_res_op_grpdef(0, 1, 205, 1396, 139608);
call proc_res_op_grpdef(0, 1, 205, 1396, 139609);
call proc_res_op_grpdef(0, 1, 205, 1396, 139610);

update portal_sysparam set param_value='1'  where param_name='RCS';
call proc_rcs_updateRole;



use iros;
drop view if exists v_ent_openstack;

CREATE TABLE if not exists common_organization ( 
	id         	numeric(18,0) NOT NULL,
	parentid   	numeric(18,0) NOT NULL,
	name       	varchar(128) NOT NULL,
	description	varchar(256) NULL,
	creator    	numeric(18,0) NULL,
	createtime 	datetime NULL,
	tenantid   	numeric(18,0) NULL 
);

ALTER TABLE om_vdc MODIFY tenantid varchar(64);
ALTER TABLE om_user_info ADD orgid varchar(64) NULL,  type int NULL,  state int NULL;

CREATE TABLE if not exists om_res_template
(
   id                   varchar(64) not null,
   dcid                 varchar(64) not null,
   name                 varchar(200) null,
   flavorid            varchar(64) null,
   imageid              varchar(64) null,
   status               varchar(10) null,
   description          varchar(400) null,
   PRIMARY KEY(id)
);

CREATE TABLE if not exists om_vm_info_task ( 
	id							varchar(64) 	NOT NULL,   -- ID
	dc_id						varchar(64) 	NULL,   -- dcID
	dc_name						varchar(100) 	NULL,   -- dc名称
	dc_type						varchar(2) 		NULL,   -- dc类型
	domain_id					varchar(64) 	NULL,   -- domain ID
	domain_name					varchar(100) 	NULL,   -- domain name
	zone_name					varchar(100) 	NULL,   -- 集群名称
	host_name					varchar(100) 	NULL,   -- 主机名称
	name						varchar(100) 	NULL,   -- 虚机名称
	created						varchar(32) 	NULL,   -- 创建时间
	user_id						varchar(100) 	NULL,   -- 用户id
	user_name					varchar(100) 	NULL,   -- 用户名称
	tenant_id					varchar(100) 	NULL,   -- 租户id
	tenant_name					varchar(100) 	NULL,   -- 租户名称
	image_id					varchar(100) 	NULL,   -- 镜像id
	image_name					varchar(100) 	NULL,   -- 镜像名称
	addresses					varchar(100) 	NULL,   -- mac地址
	flavor_id					varchar(200) 	NULL,   -- 规格id
	flavor_info					varchar(200) 	NULL,   -- 规格
	ip_info						varchar(1000) 	NULL,   -- IP
	task_state					varchar(100) 	NULL,   -- 当前任务
	power_state					varchar(2) 		NULL,   -- 电源状态
	vm_state					varchar(100) 	NULL,   -- 虚机状态
	servergroup_info			varchar(100) 	NULL,   -- 云主机组
	is_volume_attached			varchar(64) 	NULL,   
	
    PRIMARY KEY(id)
);


CREATE TABLE if not exists om_dc_info_task ( 
	dc_id							varchar(64) 	NOT NULL,   -- ID
	dc_name							varchar(100) 	NOT NULL,   -- 名称
	dc_type							varchar(2) 		NULL,   -- dc类型
	domain_id						varchar(64) 	NULL,   -- domain ID
	domain_name						varchar(100) 	NULL,   -- domain name
	zone_count						int 	 NULL,		-- 集群数
	host_count						int 	 NULL,		-- 主机数
	vm_count						int 	 NULL,	-- 虚机数	
	cpu_used						int		 NULL,	-- cpu使用量(个)
	cpu_all							int		 NULL,		-- cpu总量(个)
	mem_used						bigint 	 NULL,   -- 内存使用量(MB)
	mem_all							bigint      NULL,   -- 内存总量(MB)
	disk_used						int	     NULL,		-- 存储使用量(GB)
	disk_all						int 	 NULL,	-- 存储总量	(GB)
	volume_count					int			NULL,	-- 云硬盘个数
	image_count						int			NULL,	-- 镜像个数
	network_count					int			NULL,	-- 网络个数
	shared_network_count			int			NULL,	-- 共享网络个数
	external_network_count			int			NULL,	-- 外部网络个数
	extra							varchar(1000)	NULL,		-- 扩展字段
    PRIMARY KEY(dc_id)
);

CREATE TABLE if not exists om_host_info_task ( 
	id							varchar(64) 	NOT NULL,   -- ID
	dc_id						varchar(64) 	NULL,   -- dcID
	dc_name						varchar(100) 	NULL,   -- dc名称
	dc_type						varchar(2) 		NULL,   -- dc类型
	zone_name					varchar(100) 	NULL,   -- 集群名称
	host_name					varchar(100) 	NULL,   -- 主机名称
	status						varchar(32) 	NULL,   -- 状态
	hypervisor_type				varchar(32)		NULL,   -- 类型
	vcpus						int		 NULL,		-- 虚拟内核（总计）
	vcpus_used					int 	 NULL,   -- 虚拟内核（已使用）
	memory_mb					bigint   NULL,   -- 内存总计
	memory_mb_used				bigint	 NULL,		-- 内存已使用
	local_gb					int 	 NULL,	-- 存储总计
	local_gb_used				int	NULL,		-- 存储已使用
	running_vms					int	NULL,		-- 云主机个数
    PRIMARY KEY(id)
);


CREATE TABLE if not exists om_base_tree ( 
	tree_id						varchar(64) 	NOT NULL,   -- ID
	tree_name						varchar(100) 	NOT NULL,   -- 名称
	tree_desc						varchar(250) 	NULL,		-- 描述
	parent_id						varchar(100) 	NOT NULL,	-- 父节点	
	type							int		NOT NULL,	-- 类型（0、资源 1、组织）
	extra							varchar(500)	NULL,		-- 扩展字段
    PRIMARY KEY(tree_id)
);



CREATE TABLE if not exists om_oper_res_rel ( 
	rel_id						varchar(64) 	NOT NULL,   -- 关联id
	oper_id					decimal(10) 	NOT NULL,   -- 用户id（ommp的用户id）
	type						int		NOT NULL,	-- 关联节点类型（1、tree节点 2、dc节点）当关联的是tree节点，则默认为此tree节点下所有节点都关联
	resource_id					varchar(100) 	NOT NULL,	-- 关联的资源节点id
    PRIMARY KEY(rel_id)
);



CREATE TABLE if not exists om_oper_org_rel ( 
	rel_id						varchar(64) 	NOT NULL,   -- 关联id
	oper_id					decimal(10) 	NOT NULL,   -- 用户id（ommp的用户id）
	type						int		NOT NULL,	-- 关联节点类型（1、tree节点 2、vdc节点）当关联的是tree节点，则默认为此tree节点下所有节点都关联
	resource_id					varchar(100) 	NOT NULL,	-- 关联的资源节点id
    PRIMARY KEY(rel_id)
);



CREATE TABLE if not exists om_org_res_rel ( 
	rel_id						varchar(64) 	NOT NULL,   -- 关联id
	org_id					varchar(100) 	NOT NULL,   -- 组织id
	type						int		NOT NULL,	-- 关联节点类型（1、domain节点 2、dc节点）当关联的是domain，则默认为此domain下所有节点都能看到
	resource_id					varchar(100) 	NOT NULL,	-- 关联的资源节点id
    PRIMARY KEY(rel_id)
);


DROP FUNCTION IF EXISTS getBaseChildren;
CREATE FUNCTION `getBaseChildren`(parentId VARCHAR(64))
RETURNS varchar(10000)
BEGIN
	DECLARE sTemp VARCHAR(10000);
	DECLARE sTempChd VARCHAR(10000);

	SET sTemp = '$';
	SET sTempChd =parentId;

	SELECT group_concat(id) INTO sTempChd FROM om_base_tree where FIND_IN_SET(parent_id,sTempChd)>0;
	WHILE sTempChd is not null DO
		SET sTemp = concat(sTemp,',',sTempChd);
		SELECT group_concat(id) INTO sTempChd FROM om_base_tree where FIND_IN_SET(parent_id,sTempChd)>0;
	END WHILE;
	RETURN sTemp;
END

CREATE TABLE if not exists alarm_snmp_address (
   name              varchar(200)    not null,   
   port              int             not null,   
   ip                varchar(50)     not null,  
   community         varchar(200)    not null, 
   type              varchar(50)      not null,
   PRIMARY KEY(name)
);

CREATE TABLE if not exists alarming (
  globalid      	numeric(10,0)    not   null,              
	localid         varchar(100)     not   null,             
    objid           varchar(200)     null,                    
	objtype         varchar(200)     null,                    
	objname         varchar(200)     null,                    
	sourceid        varchar(200)     not   null,              
	sourcetype      varchar(200)     not   null,              
	sourcename      varchar(200)     not   null,              
	code		    varchar(100) 	 not   null,              
	almlevel	    int			     not   null,              
	content         varchar(1500)    null,                    
	createtime		varchar(100)     not   null,              
	cleartime	    varchar(100)     null,                    
	cleartype	    int	             null,                    
	objip     	    varchar(200)     null,                    
	confirmtime     varchar(100)     null,                    
    confirmuser     varchar(200)     null,                    
    confirmtype     int		         null,                    
    confirminfo     varchar(200)     null,                   
    keeptime         int             null,       
   primary key (globalid)  
);

CREATE TABLE if not exists alarm_his (
  globalid      	numeric(10,0)    not   null,              
	localid         varchar(100)     not   null,             
    objid           varchar(200)     null,                    
	objtype         varchar(200)     null,                    
	objname         varchar(200)     null,                    
	sourceid        varchar(200)     not   null,              
	sourcetype      varchar(200)     not   null,              
	sourcename      varchar(200)     not   null,              
	code		    varchar(100) 	 not   null,              
	almlevel	    int			     not   null,              
	content         varchar(1500)    null,                    
	createtime		varchar(100)     not   null,              
	cleartime	    varchar(100)     null,                    
	cleartype	    int	             null,                    
	objip     	    varchar(200)     null,                    
	confirmtime     varchar(100)     null,                    
    confirmuser     varchar(200)     null,                    
    confirmtype     int		         null,                    
    confirminfo     varchar(200)     null,                   
    keeptime         int             null,       
   primary key (globalid)  
);

CREATE TABLE if not exists alarm_code (
    code              varchar(100)            not    null,      
    description       varchar(254)            not    null,     
    almlevel          int                     not    null,      
    isshow            int                     not    null,     
	solution		  varchar(400)            null,    
   primary key (code)  
);

CREATE TABLE if not exists alarm_config (
    name          varchar(100)                 not null,     
    value         varchar(100)                 not null,     
   primary key (name)  
);

insert into alarm_config(name, value) values('alarm_globalid', '1');
insert into alarm_config(name, value) values('realalarm_maxcount', '1000');

insert into alarm_code(code, description, almlevel, isshow) values('46112', '计算服务不可用',1,1);
insert into alarm_code(code, description, almlevel, isshow) values('46114', '主机内存故障',1,1);
insert into alarm_code(code, description, almlevel, isshow) values('46176', '虚拟机状态异常',4,1);

CREATE TABLE if not exists alarm_oid (
     name            varchar(100)                   not null,     
     oid             varchar(100)                   not null,  
   primary key (name)  
);

insert into alarm_oid(oid, name) values('1.3.6.1.6.3.1.1.4.1.0','alarmType');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.1','alarmReport');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.2','alarmRestore');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.3','alarmEventTime');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.2','sendNotificationId');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.4','lastSendNotificationId');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.3','systemDN');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.11','alarmCode');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.2','alarmManagedObjectInstance');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.4','alarmEventType');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.5','alarmProbableCause');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.6','alarmPerceivedSeverity');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.7','alarmSpecificProblem');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.8','alarmAdditionalText');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.12','alarmNetype');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.9','alarmIndex');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.1','alarmId');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.14','alarmCodeName');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.15','alarmManagedObjectInstanceName');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.16','alarmSystemType');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.17','alarmNeIP');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.18','alarmACK');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.19','cleiCode');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.20','timeZoneID');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.21','timeZoneOffset');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.22','dSTSaving');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.23','aid');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.24','id');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.26','alarmMocObjectInstatance');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.10','alarmComment');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.25','alarmOtherInfo');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.2.0','opencos_snmpTrapCommunity');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.3.0','opencos_snmpTrapVersion');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.2.1.3','opencos_trapIpaddressPort');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.4.2.1.1','heartbeatNotification');


use opslog;

drop procedure  if exists proc_operlogcol_temp;
create procedure proc_operlogcol_temp()
BEGIN 
	DECLARE v_count tinyint;
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log01' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log01 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log02' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log02 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log03' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log03 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log04' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log04 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log05' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log05 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log06' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log06 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log07' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log07 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log08' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log08 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log09' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log09 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log10' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log10 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log11' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log11 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log12' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log12 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log13' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log13 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log14' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log14 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log15' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log15 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log16' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log16 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log17' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log17 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log18' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log18 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log19' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log19 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log20' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log20 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log21' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log21 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log22' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log22 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log23' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log23 add domainid varchar(100) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='oper_log24' and column_name='domainid';
	if(v_count < 1)  THEN 
	   alter table oper_log24 add domainid varchar(100) null;
	END IF; 

END;
call proc_operlogcol_temp;