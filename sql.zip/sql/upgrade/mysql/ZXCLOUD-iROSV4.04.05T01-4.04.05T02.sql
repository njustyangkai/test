use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.05T02' where name = 'iROS';

delete from os_name_config where os_id = '63';
insert into os_name_config(os_id, os_type, os_name) values('63','Linux','Ubuntu 14.04 Standard Edition(64)');

delete from om_control_function where id = 'phydevice_switch_control';
insert into om_control_function values ('phydevice_switch_control', '�ʲ���������','0'); -- 0���ر�1������
