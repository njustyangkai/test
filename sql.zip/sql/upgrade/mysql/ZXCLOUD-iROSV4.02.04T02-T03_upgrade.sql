create database if not EXISTS irosmeasure DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
grant all privileges on irosmeasure.* to 'irosmeasure'@'localhost' identified by 'db10$ZTE';
commit;

use irosmeasure;

create table if not exists ros_ptypedef (
   res_type             varchar(100)                   not null,
   poid                 varchar(20)                    not null,
   poname               varchar(128)                   not null,
   tablename            varchar(32)                    not null,
   bvisible             tinyint                        not null,
   isrealtime           tinyint                        not null,
   extrastr             varchar(255)                   null,
   primary key (res_type, poid)
);

create table if not exists ros_pitemdef (
   poid                 varchar(20)                    not null,
   pitemid              integer                        not null,
   pitemname            varchar(128)                   not null,
   pitemfield           varchar(128)                    not null,
   pitemutil            varchar(32)                    not null,
   datatype             tinyint                        not null,
   bvisible             tinyint                        not null,
   lasttime             datetime                       null,
   extrastr             varchar(256)                   null,
   primary key (poid, pitemid)
);

drop procedure if exists p_create_table;
DELIMITER &&
create procedure p_create_table(in vname varchar(50))
begin
		declare i int;
	    declare mmdd varchar(4);
		declare tabname varchar(20);
		declare vsql varchar(1000);
 
		set i=24;
		while i>=1 do
			set mmdd=right(concat('0', i), 2);
			set tabname=concat(vname,mmdd);
			  
			set vsql=concat('create table if not exists ',tabname,
		                     '(time            datetime not null,',
						     'res_type         varchar(100) null,',
							 'dc_id            varchar(100) not null,',
						     'res_id           varchar(100) not null,',
						     'moc_id           varchar(100) null,',
							 'pitemid          integer null,',
							 'usage_value      float null)');
		
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt; 
		
		       
			set vsql=concat('create index idx_time_',tabname,' on ',tabname,'(time)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_res_id_',tabname,' on ',tabname,'(res_id)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_moc_id_',tabname,' on ',tabname,'(moc_id)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
		set i=i-1;
		end while;
end&& 
DELIMITER ; 
commit;


call p_create_table('data_vm_cpu');
call p_create_table('data_vm_mem');
call p_create_table('data_vm_disk'); 
call p_create_table('data_vm_nic');
call p_create_table('data_host_cpu');
call p_create_table('data_host_mem');
call p_create_table('data_host_disk'); 
call p_create_table('data_host_nic');

insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010001', '虚拟机CPU性能', 'data_vm_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010002', '虚拟机内存性能', 'data_vm_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010003', '虚拟机磁盘性能', 'data_vm_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010004', '虚拟机网卡性能', 'data_vm_nic', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010005', '物理机CPU性能', 'data_host_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010006', '物理机内存性能', 'data_host_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010007', '物理机磁盘性能', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010008', '物理机网卡性能', 'data_host_nic', 1, 0);

insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010001', 1, '虚拟机CPU使用率', 'cpu_util', '%', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010002', 1, '虚拟机内存使用情况', 'memory.usage', 'MB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 1, '虚拟机磁盘读取速率', 'disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 2, '虚拟机磁盘写入速率', 'disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010003', 3, '虚拟机磁盘大小', 'disk.total.size', 'GB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010004', 1, '虚拟机网络出口带宽', 'network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010004', 2, '虚拟机网络入口带宽', 'network.incoming.bytes.rate', 'B/s', 2, 1);

insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010005', 1, '物理机CPU使用率', 'compute.node.cpu.percent', '%', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010006', 1, '物理机内存使用情况', 'compute.node.memory.used', 'MB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 1, '物理机磁盘读取速率', 'compute.node.disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 2, '物理机磁盘写入速率', 'compute.node.disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 3, '物理机磁盘大小', 'compute.node.disk.total', 'GB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010007', 4, '物理机磁盘已使用大小', 'compute.node.disk.used', 'GB', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010008', 1, '物理机网络出口带宽', 'compute.node.network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values('1010008', 2, '物理机网络入口带宽', 'compute.node.network.incoming.bytes.rate', 'B/s', 2, 1);



use zxinsys;

call proc_res_op_function(0, 1, 1396, 139611,'性能统计');

delete from portal_sysparam where param_name = 'volume_upper_limit';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('volume_upper_limit','500','云硬盘大小上限(GB)','iROS','云硬盘大小上限(GB)',
             2,100,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'iros_management_address';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_management_address','127.0.0.1','iROS管理网地址','iROS','iROS管理网地址,告警SNMP监听地址,下发给opencos',
             2,100,1,' ',1,
             '','','','','');

-- 增加rcs已经存在的四种角色，4a同步用户

-- 增加新的角色：
-- proc_res_op_grpscript2 产品ID，修改标识(add-1,del-2)，角色标识，角色名称
call proc_res_op_grpscript2(0, 1, 201, '管理员角色', '管理员角色');
call proc_res_op_grpscript2(0, 1, 202, '操作员角色', '操作员角色');
call proc_res_op_grpscript2(0, 1, 203, '维护员角色', '维护员角色');
call proc_res_op_grpscript2(0, 1, 204, '监控员角色', '监控员角色'); 
call proc_res_op_grpscript2(0, 1, 205, '自定义角色', '自定义角色'); 

-- 给新增加的角色增加相应的权限：
-- 管理员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 201, 1,  10001);
call proc_res_op_grpdef(0, 1, 201, 1,  10003);
call proc_res_op_grpdef(0, 1, 201, 1,  10006);
call proc_res_op_grpdef(0, 1, 201, 1,  10007);
call proc_res_op_grpdef(0, 1, 201, 3,  12001);
call proc_res_op_grpdef(0, 1, 201, 3,  12002);
call proc_res_op_grpdef(0, 1, 201, 3,  12003);
call proc_res_op_grpdef(0, 1, 201, 3,  12007);
call proc_res_op_grpdef(0, 1, 201, 3,  12008);
call proc_res_op_grpdef(0, 1, 201, 3,  12010);
call proc_res_op_grpdef(0, 1, 201, 4,  13001);
call proc_res_op_grpdef(0, 1, 201, 4,  13003);
call proc_res_op_grpdef(0, 1, 201, 4,  13005);
call proc_res_op_grpdef(0, 1, 201, 4,  13007);
call proc_res_op_grpdef(0, 1, 201, 4,  13008);
call proc_res_op_grpdef(0, 1, 201, 4,  13009);
call proc_res_op_grpdef(0, 1, 201, 4,  13011);
call proc_res_op_grpdef(0, 1, 201, 4,  13014);
call proc_res_op_grpdef(0, 1, 201, 4,  13016);
call proc_res_op_grpdef(0, 1, 201, 4,  13017);
call proc_res_op_grpdef(0, 1, 201, 4,  13020);
call proc_res_op_grpdef(0, 1, 201, 10, 15001);
call proc_res_op_grpdef(0, 1, 201, 10, 15005);
call proc_res_op_grpdef(0, 1, 201, 10, 15007);
call proc_res_op_grpdef(0, 1, 201, 11, 18005);
call proc_res_op_grpdef(0, 1, 201, 11, 18102);
call proc_res_op_grpdef(0, 1, 201, 1396, 139601);
call proc_res_op_grpdef(0, 1, 201, 1396, 139602);
call proc_res_op_grpdef(0, 1, 201, 1396, 139603);
call proc_res_op_grpdef(0, 1, 201, 1396, 139604);
call proc_res_op_grpdef(0, 1, 201, 1396, 139605);
call proc_res_op_grpdef(0, 1, 201, 1396, 139606);
call proc_res_op_grpdef(0, 1, 201, 1396, 139607);
call proc_res_op_grpdef(0, 1, 201, 1396, 139608);
call proc_res_op_grpdef(0, 1, 201, 1396, 139609);
call proc_res_op_grpdef(0, 1, 201, 1396, 139610);


-- 给新增加的角色增加相应的权限：
-- 操作员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 202, 1,  10001);
call proc_res_op_grpdef(0, 1, 202, 1,  10003);
call proc_res_op_grpdef(0, 1, 202, 1,  10006);
call proc_res_op_grpdef(0, 1, 202, 1,  10007);
call proc_res_op_grpdef(0, 1, 202, 3,  12001);
call proc_res_op_grpdef(0, 1, 202, 3,  12002);
call proc_res_op_grpdef(0, 1, 202, 3,  12003);
call proc_res_op_grpdef(0, 1, 202, 3,  12007);
call proc_res_op_grpdef(0, 1, 202, 3,  12008);
call proc_res_op_grpdef(0, 1, 202, 3,  12010);
call proc_res_op_grpdef(0, 1, 202, 4,  13001);
call proc_res_op_grpdef(0, 1, 202, 4,  13003);
call proc_res_op_grpdef(0, 1, 202, 4,  13005);
call proc_res_op_grpdef(0, 1, 202, 4,  13007);
call proc_res_op_grpdef(0, 1, 202, 4,  13008);
call proc_res_op_grpdef(0, 1, 202, 4,  13009);
call proc_res_op_grpdef(0, 1, 202, 4,  13011);
call proc_res_op_grpdef(0, 1, 202, 4,  13014);
call proc_res_op_grpdef(0, 1, 202, 4,  13016);
call proc_res_op_grpdef(0, 1, 202, 4,  13017);
call proc_res_op_grpdef(0, 1, 202, 4,  13020);
call proc_res_op_grpdef(0, 1, 202, 10, 15001);
call proc_res_op_grpdef(0, 1, 202, 10, 15005);
call proc_res_op_grpdef(0, 1, 202, 10, 15007);
call proc_res_op_grpdef(0, 1, 202, 11, 18005);
call proc_res_op_grpdef(0, 1, 202, 11, 18102);
call proc_res_op_grpdef(0, 1, 202, 1396, 139601);
call proc_res_op_grpdef(0, 1, 202, 1396, 139602);
call proc_res_op_grpdef(0, 1, 202, 1396, 139603);
call proc_res_op_grpdef(0, 1, 202, 1396, 139604);
call proc_res_op_grpdef(0, 1, 202, 1396, 139605);
call proc_res_op_grpdef(0, 1, 202, 1396, 139606);
call proc_res_op_grpdef(0, 1, 202, 1396, 139607);
call proc_res_op_grpdef(0, 1, 202, 1396, 139608);
call proc_res_op_grpdef(0, 1, 202, 1396, 139609);
call proc_res_op_grpdef(0, 1, 202, 1396, 139610);



-- 给新增加的角色增加相应的权限：
-- 维护员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 203, 1,  10001);
call proc_res_op_grpdef(0, 1, 203, 1,  10003);
call proc_res_op_grpdef(0, 1, 203, 1,  10006);
call proc_res_op_grpdef(0, 1, 203, 1,  10007);
call proc_res_op_grpdef(0, 1, 203, 3,  12001);
call proc_res_op_grpdef(0, 1, 203, 3,  12002);
call proc_res_op_grpdef(0, 1, 203, 3,  12003);
call proc_res_op_grpdef(0, 1, 203, 3,  12007);
call proc_res_op_grpdef(0, 1, 203, 3,  12008);
call proc_res_op_grpdef(0, 1, 203, 3,  12010);
call proc_res_op_grpdef(0, 1, 203, 4,  13001);
call proc_res_op_grpdef(0, 1, 203, 4,  13003);
call proc_res_op_grpdef(0, 1, 203, 4,  13005);
call proc_res_op_grpdef(0, 1, 203, 4,  13007);
call proc_res_op_grpdef(0, 1, 203, 4,  13008);
call proc_res_op_grpdef(0, 1, 203, 4,  13009);
call proc_res_op_grpdef(0, 1, 203, 4,  13011);
call proc_res_op_grpdef(0, 1, 203, 4,  13014);
call proc_res_op_grpdef(0, 1, 203, 4,  13016);
call proc_res_op_grpdef(0, 1, 203, 4,  13017);
call proc_res_op_grpdef(0, 1, 203, 4,  13020);
call proc_res_op_grpdef(0, 1, 203, 10, 15001);
call proc_res_op_grpdef(0, 1, 203, 10, 15005);
call proc_res_op_grpdef(0, 1, 203, 10, 15007);
call proc_res_op_grpdef(0, 1, 203, 11, 18005);
call proc_res_op_grpdef(0, 1, 203, 11, 18102);


-- 给新增加的角色增加相应的权限：
-- 监控员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 204, 1,  10001);
call proc_res_op_grpdef(0, 1, 204, 1,  10003);
call proc_res_op_grpdef(0, 1, 204, 1,  10006);
call proc_res_op_grpdef(0, 1, 204, 1,  10007);
call proc_res_op_grpdef(0, 1, 204, 3,  12001);
call proc_res_op_grpdef(0, 1, 204, 3,  12002);
call proc_res_op_grpdef(0, 1, 204, 3,  12003);
call proc_res_op_grpdef(0, 1, 204, 3,  12007);
call proc_res_op_grpdef(0, 1, 204, 3,  12008);
call proc_res_op_grpdef(0, 1, 204, 3,  12010);
call proc_res_op_grpdef(0, 1, 204, 4,  13001);
call proc_res_op_grpdef(0, 1, 204, 4,  13003);
call proc_res_op_grpdef(0, 1, 204, 4,  13005);
call proc_res_op_grpdef(0, 1, 204, 4,  13007);
call proc_res_op_grpdef(0, 1, 204, 4,  13008);
call proc_res_op_grpdef(0, 1, 204, 4,  13009);
call proc_res_op_grpdef(0, 1, 204, 4,  13011);
call proc_res_op_grpdef(0, 1, 204, 4,  13014);
call proc_res_op_grpdef(0, 1, 204, 4,  13016);
call proc_res_op_grpdef(0, 1, 204, 4,  13017);
call proc_res_op_grpdef(0, 1, 204, 4,  13020);
call proc_res_op_grpdef(0, 1, 204, 10, 15001);
call proc_res_op_grpdef(0, 1, 204, 10, 15005);
call proc_res_op_grpdef(0, 1, 204, 10, 15007);
call proc_res_op_grpdef(0, 1, 204, 11, 18005);
call proc_res_op_grpdef(0, 1, 204, 11, 18102);
call proc_res_op_grpdef(0, 1, 204, 1396, 139601);
call proc_res_op_grpdef(0, 1, 204, 1396, 139602);
call proc_res_op_grpdef(0, 1, 204, 1396, 139603);
call proc_res_op_grpdef(0, 1, 204, 1396, 139604);
call proc_res_op_grpdef(0, 1, 204, 1396, 139605);
call proc_res_op_grpdef(0, 1, 204, 1396, 139606);
call proc_res_op_grpdef(0, 1, 204, 1396, 139607);
call proc_res_op_grpdef(0, 1, 204, 1396, 139608);
call proc_res_op_grpdef(0, 1, 204, 1396, 139609);
call proc_res_op_grpdef(0, 1, 204, 1396, 139610);



-- 给新增加的角色增加相应的权限：
-- 自定义角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 205, 1,  10001);
call proc_res_op_grpdef(0, 1, 205, 1,  10003);
call proc_res_op_grpdef(0, 1, 205, 1,  10006);
call proc_res_op_grpdef(0, 1, 205, 1,  10007);
call proc_res_op_grpdef(0, 1, 205, 3,  12001);
call proc_res_op_grpdef(0, 1, 205, 3,  12002);
call proc_res_op_grpdef(0, 1, 205, 3,  12003);
call proc_res_op_grpdef(0, 1, 205, 3,  12007);
call proc_res_op_grpdef(0, 1, 205, 3,  12008);
call proc_res_op_grpdef(0, 1, 205, 3,  12010);
call proc_res_op_grpdef(0, 1, 205, 4,  13001);
call proc_res_op_grpdef(0, 1, 205, 4,  13003);
call proc_res_op_grpdef(0, 1, 205, 4,  13005);
call proc_res_op_grpdef(0, 1, 205, 4,  13007);
call proc_res_op_grpdef(0, 1, 205, 4,  13008);
call proc_res_op_grpdef(0, 1, 205, 4,  13009);
call proc_res_op_grpdef(0, 1, 205, 4,  13011);
call proc_res_op_grpdef(0, 1, 205, 4,  13014);
call proc_res_op_grpdef(0, 1, 205, 4,  13016);
call proc_res_op_grpdef(0, 1, 205, 4,  13017);
call proc_res_op_grpdef(0, 1, 205, 4,  13020);
call proc_res_op_grpdef(0, 1, 205, 10, 15001);
call proc_res_op_grpdef(0, 1, 205, 10, 15005);
call proc_res_op_grpdef(0, 1, 205, 10, 15007);
call proc_res_op_grpdef(0, 1, 205, 11, 18005);
call proc_res_op_grpdef(0, 1, 205, 11, 18102);
call proc_res_op_grpdef(0, 1, 205, 1396, 139601);
call proc_res_op_grpdef(0, 1, 205, 1396, 139602);
call proc_res_op_grpdef(0, 1, 205, 1396, 139603);
call proc_res_op_grpdef(0, 1, 205, 1396, 139604);
call proc_res_op_grpdef(0, 1, 205, 1396, 139605);
call proc_res_op_grpdef(0, 1, 205, 1396, 139606);
call proc_res_op_grpdef(0, 1, 205, 1396, 139607);
call proc_res_op_grpdef(0, 1, 205, 1396, 139608);
call proc_res_op_grpdef(0, 1, 205, 1396, 139609);
call proc_res_op_grpdef(0, 1, 205, 1396, 139610);

update portal_sysparam set param_value='1'  where param_name='RCS';
call proc_rcs_updateRole;


use iros;
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.2.0','opencos_snmpTrapCommunity');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.3.0','opencos_snmpTrapVersion');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.2.1.3','opencos_trapIpaddressPort');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.4.2.1.1','heartbeatNotification');
