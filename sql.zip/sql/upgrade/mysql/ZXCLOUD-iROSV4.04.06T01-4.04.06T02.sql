use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.06T02' where name = 'iROS';
