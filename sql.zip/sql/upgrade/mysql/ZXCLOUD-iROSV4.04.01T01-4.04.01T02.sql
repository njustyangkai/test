use iros;
drop table if exists om_irai_quota;
CREATE TABLE om_irai_quota ( 
	id						varchar(64)				not null, 	-- id
	create_date				datetime				not null, 	-- 创建时间
	update_date				datetime				not null, 	-- 更新时间
	dc_id					varchar(64)				not null, 	-- dc_id
	dc_type					int						not null,	-- dc类型，3是vmware，4是power，
	tenant_id				varchar(64)				not null, 	-- 租户id
	vdc_id					numeric					not null,
	resource_id				varchar(64)				not null,	-- 配额id
	resource				varchar(100)			not null,	-- 配额名称
	in_use					numeric					default 0		not null, 	-- 已使用
	hard_limit				numeric					not null, 	-- 上限
	PRIMARY KEY(id)
);

drop table if exists om_resize_flavor_record;
create table om_resize_flavor_record
(
	instanceid varchar(100) NOT NULL,
	vdcid varchar(10) NOT NULL,
	dcid varchar(100) NOT NULL,
	flag int(11) NOT NULL,
	operation varchar(20) DEFAULT NULL,
	vcpus int(11) NOT NULL,
	memory bigint(20) NOT NULL,
	disk int(11) NOT NULL,
	created datetime DEFAULT NULL,
	updated datetime DEFAULT NULL
);

drop procedure if exists proc_update_columns_4_04_01_T01_to_4_04_01_T02;
DELIMITER &&
create procedure proc_update_columns_4_04_01_T01_to_4_04_01_T02()
BEGIN 
	DECLARE v_count tinyint;	
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_base_service' and column_name='description';
	if(v_count < 1)  THEN 
	   alter table om_base_service add  description  varchar(500) null;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_dci' and column_name='tag';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_dci add tag  varchar(100) NULL;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_dci' and column_name='tag_type';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_dci add tag_type  varchar(100) NULL;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='om_dci' and column_name='dscp';
	if(v_count < 1)  THEN 
	   ALTER TABLE om_dci add dscp  int NULL;
	END IF; 

end&& 
DELIMITER ; 
commit;
call proc_update_columns_4_04_01_T01_to_4_04_01_T02;
drop procedure if exists proc_update_columns_4_04_01_T01_to_4_04_01_T02;

delete from om_base_service where switch_name = 'switch_irai';
insert into om_base_service (id, name, switch_name, rel_id, description) values (12, '云桌面', 'switch_irai', '6','');

use zxinmeasure;
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100709, '物理机磁盘每秒读次数', 'IROSHOST', 1, 'measure_hdiskreadtimesdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100710, '物理机磁盘每秒写次数', 'IROSHOST', 1, 'measure_hdiskwritetimesdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100711, '物理机磁盘IO延迟', 'IROSHOST', 1, 'measure_hdiskiodelaydata', 2, 1, 1);

insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100709, 1, '物理机磁盘每秒读次数', 'statcode1', 'measure_hdiskreadtimesdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100710, 1, '物理机磁盘每秒写次数', 'statcode1', 'measure_hdiskwritetimesdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100711, 1, '物理机磁盘IO延迟', 'statcode1', 'measure_hdiskiodelaydata', 3, 1);

insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100709, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100709, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100710, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100710, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100711, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100711, 2, 'DCID', 'param2', 0);

call p_create_table('measure_hdiskreadtimesdata');
call p_create_table('measure_hdiskwritetimesdata');
call p_create_table('measure_hdiskiodelaydata');

delete from ros_ptypedef where res_type = 'host' and poid = '100803';
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100803', '物理机磁盘使用率', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100813', '物理机磁盘性能', 'data_host_disk', 1, 0);


insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 2, '物理机磁盘每秒读次数', '', '', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 6, '物理机磁盘每秒写次数', '', '', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 10, '物理机磁盘读取速率', '', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 14, '物理机磁盘写入速率', '', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 18, '物理机磁盘IO延迟', '', 'Ms', 2, 1);

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 2, 2071, 100709);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 6, 2071, 100710);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 10, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 14, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 18, 2071, 100711);


use zxinalarm;
call proc_alm_code_new(1,1000041,'主机磁盘异常', 1,13,1,22537);
call proc_alm_reason_new(1,1000041,'主机磁盘异常', 22537);

alter table alarming modify reserve1 varchar(250)  null;
alter table alarm01 modify reserve1 varchar(250)  null;
alter table alarm02 modify reserve1 varchar(250)  null;
alter table alarm03 modify reserve1 varchar(250)  null;
alter table alarm04 modify reserve1 varchar(250)  null;
alter table alarm05 modify reserve1 varchar(250)  null;
alter table alarm06 modify reserve1 varchar(250)  null;
alter table alarm07 modify reserve1 varchar(250)  null;
alter table alarm08 modify reserve1 varchar(250)  null;
alter table alarm09 modify reserve1 varchar(250)  null;
alter table alarm10 modify reserve1 varchar(250)  null;
alter table alarm11 modify reserve1 varchar(250)  null;
alter table alarm12 modify reserve1 varchar(250)  null;
alter table inform01 modify reserve1 varchar(250)  null;
alter table inform02 modify reserve1 varchar(250)  null;
alter table inform03 modify reserve1 varchar(250)  null;
alter table inform04 modify reserve1 varchar(250)  null;
alter table inform05 modify reserve1 varchar(250)  null;
alter table inform06 modify reserve1 varchar(250)  null;
alter table inform07 modify reserve1 varchar(250)  null;
alter table inform08 modify reserve1 varchar(250)  null;
alter table inform09 modify reserve1 varchar(250)  null;
alter table inform10 modify reserve1 varchar(250)  null;
alter table inform11 modify reserve1 varchar(250)  null;
alter table inform12 modify reserve1 varchar(250)  null;
alter table impinform01 modify reserve1 varchar(250)  null;
alter table impinform02 modify reserve1 varchar(250)  null;
alter table impinform03 modify reserve1 varchar(250)  null;
alter table impinform04 modify reserve1 varchar(250)  null;
alter table impinform05 modify reserve1 varchar(250)  null;
alter table impinform06 modify reserve1 varchar(250)  null;
alter table impinform07 modify reserve1 varchar(250)  null;
alter table impinform08 modify reserve1 varchar(250)  null;
alter table impinform09 modify reserve1 varchar(250)  null;
alter table impinform10 modify reserve1 varchar(250)  null;
alter table impinform11 modify reserve1 varchar(250)  null;
alter table impinform12 modify reserve1 varchar(250)  null;

-- 增加物理设备
drop procedure if exists sp_web_add_phymachineinfo;
DELIMITER //
create procedure sp_web_add_phymachineinfo
(
  in v_i_entid            varchar(100), -- physicial id
  in v_i_devicemospecid   varchar(100), -- associate om_devicespec_info 物理机
  -- in v_i_areaid           varchar(200), -- 增加areaid，
  -- in v_i_dcid           varchar(200), -- 增加areaid，
  in v_i_fixedassetnum    varchar(200), -- 固定资产编号
  in v_i_systemnum        varchar(200), -- 系统编号
  in v_i_productmnum      varchar(200), -- 产品编号
  in v_i_purchasedate     date,         -- 2017.12.12  待定
  in v_i_assurancetime    int,          -- month 质保月份
  in v_i_assurancedesc    varchar(200), -- 质保描述
  in v_i_location         varchar(200), -- 位置
  in v_i_locationdesc     varchar(50) , -- 大小
  in v_i_upframenum       varchar(50) , -- 机驾号
  in v_i_roundframenum    varchar(50) , -- 机框号
  in v_i_slotnum          varchar(50) , -- 槽位号
  in v_i_ipmiip           varchar(100), -- ipmiip
  in v_i_ipmiuser         varchar(50) , -- ipmiuser
  in v_i_ipmipwd          varchar(50) , -- ipmi passsword
  in v_i_status           int         , -- 0 未使用 1 已使用
  in v_i_operid           varchar(50) , -- 操作ID
  in v_i_entname          varchar(200), -- ommp 物理机名字
  in v_i_ommpid           varchar(200), -- ommp 物理机id
  out v_i_ret            int
)
begin
  declare  v_entid               varchar(100);
  declare  v_devicemospecid      varchar(100);
  declare  v_opertime            date;
  declare  v_deviceid            varchar(200);  -- 厂商ID
  declare  v_devicename          varchar(200);  -- 厂商名字
  declare  v_phstatus            int;           -- 物理机状态   9关机
  set v_entid = trim(v_i_entid);
  set v_devicemospecid = trim(v_i_devicemospecid);
  set v_opertime = now();
  set v_phstatus = 9;

  -- 根据规格ID查询厂商ID
  select deviceid into v_deviceid from om_device_info where devicemospecid = v_i_devicemospecid;

  if FOUND_ROWS() = 0
    || exists(select 1 from om_phydevice_info where entid = v_entid)
    || exists(select 1 from om_phydevice_info where entname = v_i_entname and status <>9 ) then
    set v_i_ret = 3001;
  elseif exists(select 1 from om_phydevice_info where fixedassetnum = v_i_fixedassetnum and status <>9 ) then
    set v_i_ret = 3003;
  elseif exists(select 1 from om_phydevice_info where systemnum = v_i_systemnum and status <>9 ) then
    set v_i_ret = 3004;
  elseif exists(select 1 from om_phydevice_info where productmnum = v_i_productmnum and status <>9 ) then
    set v_i_ret = 3005;
  else
    select dataname into v_devicename from common_dict_item where dataid = v_deviceid;

    if FOUND_ROWS() = 0 then
      set v_i_ret = 3006;
    else
      start transaction;
      insert into om_phydevice_info (entid, entname,devicemospecid ,deviceid ,fixedassetnum ,systemnum ,productmnum ,purchasedate ,
                       assurancetime ,assurancedesc ,location ,locationdesc ,upframenum ,roundframenum ,
                      slotnum ,ipmiip ,ipmiuser ,ipmipwd ,status ,phstatus ,operid , opertime)
           values(v_entid, v_i_entname, v_devicemospecid, v_deviceid, v_i_fixedassetnum, v_i_systemnum, v_i_productmnum, v_i_purchasedate,
                  v_i_assurancetime, v_i_assurancedesc, v_i_location, v_i_locationdesc, v_i_upframenum, v_i_roundframenum,
                  v_i_slotnum, v_i_ipmiip, v_i_ipmiuser, v_i_ipmipwd, v_i_status, v_phstatus, v_i_operid, v_opertime);
      if @@warning_count <> 0 || @@error_count > 0 then
        rollback;
        set v_i_ret = 1001;
      else
        commit;
        update om_device_info set specidnum = specidnum + 1  where devicemospecid = v_devicemospecid;
        if @@warning_count <> 0 || @@error_count > 0 then
          set v_i_ret = 1001;
        else
          set v_i_ret = 1;
        end if;
      end if;
    end if;
  end if;
end //
DELIMITER ;

-- 修改物理设备
drop procedure if exists sp_web_mod_phymachineinfo;
DELIMITER //
create procedure sp_web_mod_phymachineinfo
(
  in v_i_entid            varchar(100), -- physicial id
  in v_i_devicemospecid   varchar(100), -- associate om_devicespec_info 物理机
  -- in v_i_areaid           varchar(200), -- 增加areaid，
  -- in v_i_dcid          varchar(200), -- 增加dcid，
  in v_i_fixedassetnum    varchar(200), -- 固定资产编号
  in v_i_systemnum        varchar(200), -- 系统编号
  in v_i_productmnum      varchar(200), -- 产品编号
  in v_i_purchasedate     date,         -- 2017.12.12  待定
  in v_i_assurancetime    int,          -- month 质保月份
  in v_i_assurancedesc    varchar(200), -- 质保描述
  in v_i_location         varchar(200), -- 位置
  in v_i_locationdesc     varchar(50) , -- 大小
  in v_i_upframenum       varchar(50) , -- 机驾号
  in v_i_roundframenum    varchar(50) , -- 机框号
  in v_i_slotnum          varchar(50) , -- 槽位号
  in v_i_ipmiip           varchar(100), -- ipmiip
  in v_i_ipmiuser         varchar(50) , -- ipmiuser
  in v_i_ipmipwd          varchar(50) , -- ipmi passsword
  in v_i_status           int         , -- 0 未使用 1 已使用
  in v_i_operid           varchar(50) , -- 操作ID
  in v_i_entname          varchar(200),
  out v_i_ret             int
)
begin
  declare  v_entid               varchar(100);
  declare  v_devicemospecid      varchar(100);
  declare  v_opertime            date;
  set v_entid = trim(v_i_entid);
  set v_devicemospecid = trim(v_i_devicemospecid);
  set v_opertime = now();

  if not exists(select 1 from om_phydevice_info where entid = v_entid) then
     set v_i_ret = 3011;
  elseif exists(select 1 from om_phydevice_info where (entid <> v_entid and entname = v_i_entname and status <>9 )) then
     set v_i_ret = 3001;
  elseif exists(select 1 from om_phydevice_info where (entid <> v_entid and fixedassetnum = v_i_fixedassetnum and status <>9)) then
     set v_i_ret = 3003;
  elseif exists(select 1 from om_phydevice_info where (entid <> v_entid and systemnum = v_i_systemnum and status <>9)) then
     set v_i_ret = 3004;
  elseif exists(select 1 from om_phydevice_info where (entid <> v_entid and productmnum = v_i_productmnum and status <>9)) then
     set v_i_ret = 3005;
   else
  
    update om_phydevice_info set devicemospecid = v_devicemospecid, fixedassetnum = v_i_fixedassetnum, systemnum = v_i_systemnum,
               productmnum = v_i_productmnum, purchasedate = v_i_purchasedate,  assurancetime = v_i_assurancetime,
                assurancedesc = v_i_assurancedesc,  location = v_i_location, locationdesc = v_i_locationdesc, upframenum = v_i_upframenum,
                roundframenum = v_i_roundframenum ,  slotnum = v_i_slotnum,  ipmiip = v_i_ipmiip, ipmiuser = v_i_ipmiuser,
                ipmipwd = v_i_ipmipwd, operid = v_i_operid,entname = v_i_entname, opertime = v_opertime, deviceid=(select deviceid from om_device_info where devicemospecid=v_devicemospecid)
                where entid = v_entid;
	set v_i_ret = 1;
 
  end if;
end //
DELIMITER ;

