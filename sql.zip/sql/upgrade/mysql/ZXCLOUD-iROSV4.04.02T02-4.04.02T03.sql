use iros;
update iros_version_info set version = 'ZXCLOUD-iROSV4.04.02T03' where name = 'iROS';

drop table if exists resource_price;
CREATE TABLE resource_price (
	name        			varchar(100) 		not null,	
	groups        			int         		not null, -- 1.虚拟资源 2.物理资源 3.网络资源 4.物理机os
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance 11.iecs os 12.physical 13.network bandwidth
    unit                    varchar(50)         not null,
	sub_type                varchar(100)        null,
	price  			        numeric(20, 5) 		not null,
	description             varchar(100)        null   
);

insert into resource_price (name, groups, type, unit, description, price) values ('CPU', 1, 2, '元/核', '1核每小时价格', 0.05);
insert into resource_price (name, groups, type, unit, description, price) values ('内存', 1, 3, '元/GB', '1GB每小时价格', 0.05);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('AIX系统盘', 1, 4, '元/GB', 'AIX', 'AIX系统盘每GB每小时价格', 0.002);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Linux系统盘', 1, 4, '元/GB', 'Linux', 'Linux系统盘每GB每小时价格', 0.001);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Windows系统盘', 1, 4, '元/GB', 'Windows', 'Windows系统盘每GB每小时价格', 0.002);
insert into resource_price (name, groups, type, unit, description, price) values ('卷', 1, 7, '元/GB', '1GB每小时价格', 0.0006);
insert into resource_price (name, groups, type, unit, description, price) values ('私有镜像', 1, 8, '元/GB', '1GB每小时价格', 0.0006);
insert into resource_price (name, groups, type, unit, description, price) values ('公网IP', 3, 5, '元/个', '1个公网IP每小时价格', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('路由器', 3, 6, '元/个', '1个路由每小时价格', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('防火墙', 3, 9, '元/套', '1套每小时价格', 0.1);
insert into resource_price (name, groups, type, unit, description, price) values ('负载均衡', 3, 10, '元/套', '1套每小时价格', 0.1);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽', 3, 13, '元/Mbps', 'up',  '1Mbps上行带宽每小时价格', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽', 3, 13, '元/Mbps', 'down',  '1Mbps下行带宽每小时价格', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽无限制', 3, 13, '元', 'unlimit up',  '上行带宽无限制每小时价格', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽无限制', 3, 13, '元',  'unlimit down', '下行带宽无限制每小时价格', 0.02);


use zxinsys;
call proc_res_op_grpdef(0, 2, 102, 1396, 139601);
call proc_res_op_grpdef(0, 2, 103, 1396, 139601);
call proc_res_op_grpdef(0, 2, 105, 1396, 139604);
call proc_res_op_grpdef(0, 1, 105, 1396, 139610);
call proc_res_op_function(0, 2, 1396, 139601,'云资源');
call proc_res_op_function(0, 1, 1396, 139604,'资源管理');
call proc_res_op_function(0, 1, 1396, 139610,'运营维护');
call proc_res_op_grpdef(0, 2, 201, 1396, 139601);
call proc_res_op_grpdef(0, 2, 202, 1396, 139601);
call proc_res_op_grpdef(0, 2, 204, 1396, 139601);
call proc_res_op_grpdef(0, 2, 205, 1396, 139601);

use zxinmeasure;
DELETE from measure_typeset where sysno = '2071';
DELETE from measure_typeset where sysno = '2072';
DELETE from measure_itemset where sysno = '2071';
DELETE from measure_itemset where sysno = '2072';
DELETE from ros_pitemdef;
DELETE from ros_ptypedef where poid in ('100821','100822','100824','100826','100801','100802','100803','100813','100806');
DELETE from ros_ommp_rel;
commit;
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100701, 'CPU使用率', 'IROSHOST', 1, 'measure_hcpudata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100702, '内存使用情况', 'IROSHOST', 1, 'measure_hmemdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100703, '磁盘读取速率', 'IROSHOST', 1, 'measure_hdiskreaddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100704, '磁盘写入速率', 'IROSHOST', 1, 'measure_hdiskwritedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100705, '磁盘大小', 'IROSHOST', 1, 'measure_hdisksizedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100706, '磁盘已使用大小', 'IROSHOST', 1, 'measure_hdiskuseddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100709, '磁盘每秒读次数', 'IROSHOST', 1, 'measure_hdiskreadtimesdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100710, '磁盘每秒写次数', 'IROSHOST', 1, 'measure_hdiskwritetimesdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100711, '磁盘IO延迟', 'IROSHOST', 1, 'measure_hdiskiodelaydata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100707, '网络出口带宽', 'IROSHOST', 1, 'measure_hnicoutdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100708, '网络入口带宽', 'IROSHOST', 1, 'measure_hnicindata', 2, 1, 1);
commit;

insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100701, 1, 'CPU使用率', 'statcode1', 'measure_hcpudata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100702, 1, '内存使用情况', 'statcode1', 'measure_hmemdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100703, 1, '磁盘读取速率', 'statcode1', 'measure_hdiskreaddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100704, 1, '磁盘写入速率', 'statcode1', 'measure_hdiskwritedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100705, 1, '磁盘大小', 'statcode1', 'measure_hdisksizedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100706, 1, '磁盘已使用大小', 'statcode1', 'measure_hdiskuseddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100709, 1, '磁盘每秒读次数', 'statcode1', 'measure_hdiskreadtimesdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100710, 1, '磁盘每秒写次数', 'statcode1', 'measure_hdiskwritetimesdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100711, 1, '磁盘IO延迟', 'statcode1', 'measure_hdiskiodelaydata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100707, 1, '网络出口带宽', 'statcode1', 'measure_hnicoutdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100708, 1, '网络入口带宽', 'statcode1', 'measure_hnicindata', 3, 1);
commit;

insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100721, 'CPU使用率', 'IROSVM', 1, 'measure_vcpudata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100722, '内存使用情况', 'IROSVM', 1, 'measure_vmemdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100723, '磁盘读取速率', 'IROSVM', 1, 'measure_vdiskreaddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100724, '磁盘写入速率', 'IROSVM', 1, 'measure_vdiskwritedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100725, '磁盘大小', 'IROSVM', 1, 'measure_vdisksizedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100726, '网络出口带宽', 'IROSVM', 1, 'measure_vnicoutdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100727, '网络入口带宽', 'IROSVM', 1, 'measure_vnicindata', 2, 1, 1);
commit;
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100721, 1, 'CPU使用率', 'statcode1', 'measure_vcpudata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100722, 1, '内存使用情况', 'statcode1', 'measure_vmemdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100723, 1, '磁盘读取速率', 'statcode1', 'measure_vdiskreaddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100724, 1, '磁盘写入速率', 'statcode1', 'measure_vdiskwritedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100725, 1, '磁盘大小', 'statcode1', 'measure_vdisksizedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100726, 1, '网络出口带宽', 'statcode1', 'measure_vnicoutdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100727, 1, '网络入口带宽', 'statcode1', 'measure_vnicindata', 3, 1);
commit; 

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010001', 1, 'CPU使用率', 'cpu_util', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010002', 1, '内存使用情况', 'memory.usage', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 1, '磁盘读取速率', 'disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 2, '磁盘写入速率', 'disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 3, '磁盘大小', 'disk.total.size', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 1, '网络出口带宽', 'network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 2, '网络入口带宽', 'network.incoming.bytes.rate', 'B/s', 2, 1);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010005', 1, 'CPU使用率', 'compute.node.cpu.percent', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010006', 1, '内存使用情况', 'compute.node.memory.used', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 1, '磁盘读取速率', 'compute.node.disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 2, '磁盘写入速率', 'compute.node.disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 3, '磁盘大小', 'compute.node.disk.total', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 4, '磁盘已使用大小', 'compute.node.disk.used', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 1, '网络出口带宽', 'compute.node.network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 2, '网络入口带宽', 'compute.node.network.incoming.bytes.rate', 'B/s', 2, 1);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020001', 1, 'CPU使用率', '2', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020002', 1, '内存使用率', '24', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 1, '磁盘读取', '130', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 2, '磁盘写入', '131', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 1, '网络出口带宽', '149', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 2, '网络入口带宽', '148', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020005', 1, 'CPU使用率', '2', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020006', 1, '内存使用情况', '24', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 1, '磁盘读取速率', '130', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 2, '磁盘写入速率', '131', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 1, '网络出口带宽', '149', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 2, '网络入口带宽', '148', 'KB/s', 2, 1);

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010001', 1, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010002', 1, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 1, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 2, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 3, 2072, 100725);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010004', 1, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010004', 2, 2072, 100727);

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010005', 1, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010006', 1, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 1, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 2, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 3, 2071, 100705);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 4, 2071, 100706);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010008', 1, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010008', 2, 2071, 100708);


insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020001', 1, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020002', 1, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020003', 1, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020003', 2, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020004', 1, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020004', 2, 2072, 100727);

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020005', 1, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020006', 1, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020007', 1, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020007', 2, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020008', 1, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020008', 2, 2071, 100708);

commit;