use iros;
drop table if exists vlantag_ip_rel;

use irosrelation;

drop procedure if exists proc_update_columns_4_03_03_T06_to_4_03_03_T07;
DELIMITER &&
create procedure proc_update_columns_4_03_03_T06_to_4_03_03_T07()
BEGIN 
	DECLARE v_count tinyint;	
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_vm' and column_name='zone_id';
	if(v_count > 0)  THEN 
	   ALTER TABLE t_vm MODIFY COLUMN zone_id  varchar(100) NULL;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_vm' and column_name='aggregate_id';
	if(v_count > 0)  THEN 
	   ALTER TABLE t_vm MODIFY COLUMN aggregate_id  varchar(100) NULL;
	END IF; 
	
	SELECT count(*) into v_count FROM information_schema.columns where table_name='t_vm' and column_name='host_id';
	if(v_count > 0)  THEN 
	   ALTER TABLE t_vm MODIFY COLUMN host_id  varchar(100) NULL;
	END IF; 
	
end&& 
DELIMITER ; 
commit;
call proc_update_columns_4_03_03_T06_to_4_03_03_T07;
drop procedure if exists proc_update_columns_4_03_03_T06_to_4_03_03_T07;

use zxinmeasure;
drop procedure if exists p_dynamic_create_table;
DELIMITER &&
create procedure p_dynamic_create_table(in vname varchar(50))
begin
	declare i int;
	declare mmdd varchar(4);
	declare tabname varchar(50);
	declare vsql varchar(4000);

	set i=24;
	while i>=1 do
		set mmdd=right(concat('0', i), 2);
		set tabname=concat(vname,mmdd);
		-- SET @sql_txt = concat('drop table if exists ', tabname); 
		-- PREPARE stmt FROM @sql_txt; 
		-- EXECUTE stmt;
		IF NOT EXISTS (SELECT TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA = 'zxinmeasure' and TABLE_NAME = tabname) THEN  
			set vsql=concat('create table ',tabname,
							 '(starttime      datetime not null,',
							 'endtime         datetime null,',
							 'resourcetype    varchar(255) not null,',
							 'resourceid      varchar(200) not null,',
							 'param1          varchar(200) null,',
							 'param2          varchar(200) null,',
							 'statcode1       float null)');
		
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt; 
		
			   
			set vsql=concat('create index idx_starttime_',tabname,' on ',tabname,'(starttime)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_resourceid_',tabname,' on ',tabname,'(resourceid)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_param1_',tabname,' on ',tabname,'(param1)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_param2_',tabname,' on ',tabname,'(param2)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
		END IF;	
		set i=i-1;
	end while;
end&& 
DELIMITER ; 
commit;


delete from ros_pitemdef where poid = '100826';
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 30, '虚拟机网络出口带宽', '', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 26, '虚拟机网络入口带宽', '', 'KB/s', 2, 1);


delete from ros_ommp_rel where poid in ( '100826', '100822');
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100822', 2, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100826', 30, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100826', 26, 2072, 100727);
