﻿use iros;
create table if not exists om_cidr ( 
		vdcid						varchar(100)				NULL,	-- vdcid
		cidr						varchar(100)				NOT NULL,	-- 网络地址
		vlan						varchar(10)					NULL,		-- vlan id
		PRIMARY KEY(cidr)
);