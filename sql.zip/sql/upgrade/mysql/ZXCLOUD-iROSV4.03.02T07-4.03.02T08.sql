use zxinsys;


call proc_res_op_grpscript2(0, 1, 102, '资源管理', '资源管理');
call proc_res_op_grpscript2(0, 1, 103, '组织管理', '组织管理');

call proc_res_op_v_grpscript(0, 1, 6102, '资源管理员组');
call proc_res_op_v_grpscript(0, 1, 6103, '组织管理员组');


call proc_res_op_v_grpdef(0,2,1000,101);
call proc_res_op_v_grpdef(0,2,1001,101);

call proc_res_op_v_grpdef(0, 2, 6101, 101);

call proc_res_op_v_grpscript(0, 2, 6101, '域管理员组');

call proc_res_op_grpdef(0, 2, 101, 1,  10001);
call proc_res_op_grpdef(0, 2, 101, 1,  10003);
call proc_res_op_grpdef(0, 2, 101, 1,  10006);
call proc_res_op_grpdef(0, 2, 101, 1,  10007);
call proc_res_op_grpdef(0, 2, 101, 3,  12001);
call proc_res_op_grpdef(0, 2, 101, 3,  12002);
call proc_res_op_grpdef(0, 2, 101, 3,  12003);
call proc_res_op_grpdef(0, 2, 101, 3,  12007);
call proc_res_op_grpdef(0, 2, 101, 3,  12008);
call proc_res_op_grpdef(0, 2, 101, 3,  12010);
call proc_res_op_grpdef(0, 2, 101, 4,  13001);
call proc_res_op_grpdef(0, 2, 101, 4,  13003);
call proc_res_op_grpdef(0, 2, 101, 4,  13005);
call proc_res_op_grpdef(0, 2, 101, 4,  13007);
call proc_res_op_grpdef(0, 2, 101, 4,  13008);
call proc_res_op_grpdef(0, 2, 101, 4,  13009);
call proc_res_op_grpdef(0, 2, 101, 4,  13011);
call proc_res_op_grpdef(0, 2, 101, 4,  13014);
call proc_res_op_grpdef(0, 2, 101, 4,  13016);
call proc_res_op_grpdef(0, 2, 101, 4,  13017);
call proc_res_op_grpdef(0, 2, 101, 4,  13020);
call proc_res_op_grpdef(0, 2, 101, 10, 15001);
call proc_res_op_grpdef(0, 2, 101, 10, 15005);
call proc_res_op_grpdef(0, 2, 101, 10, 15007);
call proc_res_op_grpdef(0, 2, 101, 11, 18005);
call proc_res_op_grpdef(0, 2, 101, 11, 18102);
call proc_res_op_grpdef(0, 2, 101, 1396, 139601);

call proc_res_op_grpscript2(0, 2, 101, '域管理', '域管理');


