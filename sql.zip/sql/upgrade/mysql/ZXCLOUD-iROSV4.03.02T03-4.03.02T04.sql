use zxinsys;

call proc_res_op_function(0, 1, 1396, 139615,'模板管理');
call proc_res_op_function(0, 1, 1396, 139616,'实例化管理');
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139615 and servicekey='uniportal';
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139616 and servicekey='uniportal';


use iros;

drop table if exists resource_price;
CREATE TABLE resource_price (
	name        			varchar(100) 		not null,	
	groups        			int         		not null, -- 1.虚拟资源 2.物理资源 3.网络资源 4.物理机os
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance 11.iecs os 12.physical 13.network bandwidth
    unit                    varchar(50)         not null,
	sub_type                varchar(100)        null,
	price  			        numeric(20, 5) 		not null,
	description             varchar(100)        null   
);

insert into resource_price (name, groups, type, unit, description, price) values ('CPU价格', 1, 2, '元/核', '1核每小时价格', 0.05);
insert into resource_price (name, groups, type, unit, description, price) values ('内存价格', 1, 3, '元/GB', '1GB每小时价格', 0.05);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('AIX系统盘价格', 1, 4, '元/GB', 'AIX', 'AIX系统盘每GB每小时价格', 0.002);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Linux系统盘价格', 1, 4, '元/GB', 'Linux', 'Linux系统盘每GB每小时价格', 0.001);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Windows系统盘价格', 1, 4, '元/GB', 'Windows', 'Windows系统盘每GB每小时价格', 0.002);
insert into resource_price (name, groups, type, unit, description, price) values ('卷价格', 1, 7, '元/GB', '1GB每小时价格', 0.0006);
insert into resource_price (name, groups, type, unit, description, price) values ('私有镜像价格', 1, 8, '元/GB', '1GB每小时价格', 0.0006);

-- insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('AIX系统价格', 2, 11, '元/套', 'AIX', '1套AIX系统在物理机上每小时价格', 0.01);
-- insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Linux系统价格', 2, 11, '元/套', 'Linux', '1套Linux系统在物理机上每小时价格', 0.001);
-- insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Windows系统价格', 2, 11, '元/套', 'Windows', '1套Windows系统在物理机上每小时价格', 0.01);

insert into resource_price (name, groups, type, unit, description, price) values ('公网IP价格', 3, 5, '元/个', '1个公网IP每小时价格', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('路由器价格', 3, 6, '元/个', '1个路由每小时价格', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('防火墙价格', 3, 9, '元/套', '1套每小时价格', 0.1);
insert into resource_price (name, groups, type, unit, description, price) values ('负载均衡价格', 3, 10, '元/套', '1套每小时价格', 0.1);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽价格', 3, 13, '元/Mbps', 'up',  '1Mbps上行带宽每小时价格', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽价格', 3, 13, '元/Mbps', 'down',  '1Mbps下行带宽每小时价格', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽无限制价格', 3, 13, '元', 'unlimit up',  '上行带宽无限制每小时价格', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽无限制价格', 3, 13, '元',  'unlimit down', '下行带宽无限制每小时价格', 0.02);

update om_control_function set control = '0' where id = 'charge_switch_control';
update om_control_function set control = '0' where id = 'charge_mail_control';

use irosrelation;
ALTER TABLE vmware_flavors MODIFY is_public tinyint DEFAULT 1 ;

use zxinsys;
call proc_res_op_function(0, 1, 1396, 139620,'设备规格');
call proc_res_op_function(0, 1, 1396, 139621,'物理设备');
call proc_res_op_function(0, 1, 1396, 139622,'数据字典');

-- 默认不显示
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139620 and servicekey='uniportal';
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139621 and servicekey='uniportal';
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139622 and servicekey='uniportal';

call proc_add_res_definition ('PH_DEVICE', '物理机', 'ROOT', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_iros_phdevice', '', null);
call proc_add_res_definition ('IROS_VDC', '租户', 'PH_DEVICE', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_iros_irosvdc', '', null);
call proc_add_res_definition ('PH_COMPANY', '厂商', 'IROS_VDC', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_phcompany', '', null);
call proc_add_res_definition ('PH_MACHINE', '单个物理机', 'PH_COMPANY', 'RESOURCE', 'TOPO,MM,AM', 0, 'OMM', 'iros', 'ent_phmachine', '', null);

use iros;
delete from om_control_function where id = 'phydevice_switch_control';
insert into om_control_function values ('phydevice_switch_control', '资产管理开关','0'); -- 0、关闭1、开启

/*==============================================================*/
/* 数据字典--操作系统                                            */
/*==============================================================*/

-- 操作系统大类与OMMP统计指标中的操作系统对应

-- "os-1", "1007" // WINDOWS服务器统计系统
-- "os-2", "1006" // SUSE服务器统计系统
-- "os-4", "1001" // AIX服务器统计系统
-- "os-5", "1002" // HP服务器统计系统
-- "os-7", "1005" // SOLARIS服务器统计系统
-- "os-8", "1004" // REDHAT服务器统计系统
-- "os-9", "1003" // CGSL服务器统计系统

-- 数据字典
drop table if exists common_dict_catalog;
create table common_dict_catalog
(
  typeid        varchar(100)  not null, -- 类型id
  typename      varchar(200)  not null, -- 类型名称
  parenttypeid      varchar(100)  null,   -- 父类型id
  visiableflag      varchar(10) default '1' null,   -- 0 不可见1可见
  editflag          varchar(10) default '0' null,   -- 0不可以编辑1可编辑
  constraint PK_COMMON_DICT_CATALOG primary key clustered (typeid)
);

drop table if exists common_dict_item;
create table common_dict_item
(
  typeid        varchar(100)  not null, --  类型id
  dataid        varchar(100)  not null, -- 数据ID
  dataname        varchar(200)  not null, --  数据名称
  parenttypeid    varchar(100)  null,   -- 父数据类型ID
  parentdataid      varchar(100)  null,   --  父数据ID
  visiableflag      varchar(10) default '1' null,   -- 0 不可见1可见
  editflag          varchar(10) default '0' null,   -- 0不可以编辑1可编辑
  constraint PK_COMMON_DICT_ITEM primary key clustered (dataid)
);



-- 操作系统大类需
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('7','操作系统大类','');
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('8','操作系统小类','7');

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-1','Microsoft Windows','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-2','SUSELINUX','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-3','TURBOLINUX','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-4','AIX','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-5','HPUNIX','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-6','HPIA','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-7','SOLARIS','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-8','REDHATLINUX','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-9','CGSL','','');

-- Microsoft Windows 1
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800101','Microsoft Windows xp','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800102','Microsoft Windows 7','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800103','Microsoft Windows 8','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800104','Microsoft Windows Server 2003,Enterprise Edition','7','os-1');
-- SUSELINUX 2
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800201','Suse Linux Enterprise 10','7','os-2');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800202','Suse Linux Enterprise 11','7','os-2');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800203','Other Linux','7','os-2');
-- TURBOLINUX 3
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800301','Suse Linux Enterprise 10','7','os-3');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800302','Suse Linux Enterprise 11','7','os-3');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800303','Other Linux','7','os-3');
-- AIX  4
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800401','AIX','7','os-4');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800402','Other AIX','7','os-4');
-- HPUNIX 5
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800501','HPUNIX','7','os-5');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800502','Other HPUNIX','7','os-5');
-- HPIA 6
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800601','AIX','7','os-6');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800602','Other AIX','7','os-6');
-- SOLARIS 7
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800701','SOLARIS','7','os-7');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800702','SOLARIS10','7','os-7');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800703','SOLARIS11','7','os-7');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800704','Other SOLARIS','7','os-7');
-- REDHATLINUX 8
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800801','REDHATLINUX','7','os-8');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800802','REDHATLINUX4.2','7','os-8');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800803','REDHATLINUX6.5','7','os-8');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800804','REDHATLINUX9','7','os-8');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800805','Other REDHATLINUX','7','os-8');
-- CGSL 9
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800901','CGSL','7','os-9');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800902','CGSL V3','7','os-9');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800903','CGSL V4','7','os-9');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800904','Other CGSL','7','os-9');


insert into common_dict_catalog(typeid,typename,parenttypeid) values ('4','设备类型','');
-- 服务器类型
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('4','104001','服务器','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('4','104002','个人电脑','','');

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('5','服务器类型','');
-- 服务器类型
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105001','小型机','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105002','小型机','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105003','PC服务器','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105004','台式机','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105005','瘦客户机','','');

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('6','厂商','');
-- 服务器厂家
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106001','联想','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106002','DELL','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106003','方正','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106004','SUN','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106005','HP','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106007','IBM','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106008','中兴(ZTE)','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106010','Intel','','');

 
-- 规格表型号表
drop table if exists om_device_info;
create table om_device_info
(
  devicemospecid     varchar(100)                    not null,   -- speciation hp-- id
  devicemospecname   varchar(200)                    not null,   -- speciation hp-- id -- 规格名字
  deviceid           varchar(100)                    null,       -- 厂商 hp -- 读取数据字典
  devicemodel        varchar(100)                    not null,   -- model hp-1型号，可编辑下拉框
  specidnum          int          default 0          not null,
  devicestatus       tinyint      default 0          not null    -- 规格状态，后续扩展，该规格是否已将不在使用,0为使用，1已经使用
);

create unique index i_om_device_info_specid on om_device_info(devicemospecid);


-- 规格表
drop table if exists om_devicespec_info;
create table om_devicespec_info
(
  devicemospecid   varchar(100)                     not null,   -- speciation 规格id
  devicetype       varchar(100)                     null,   -- device type  -- 设备类型，个人电脑或者服务器
  servertype       varchar(100)                     null,   -- server type  -- 服务器类型
  devdisk          varchar(50)                      null,   -- GB
  memeory          varchar(50)                      null,   -- GB
  nicmodel         varchar(100)                     null,   -- network type -- 网卡类型(不转换)，千兆网卡，百兆网卡
  niunum           int                              null,   -- network number
  cpumodel         varchar(100)                     null,  -- cpu model   --  (不转换)
  cpumohz          varchar(10)                      null,   -- cpu hz
  cpunum           int                              null,   -- associate with t_dc
  cpucores         int                              null,   -- cpu number
  hbamodel         varchar(100)                     null,   -- hba type   -- (不转换)
  hbanum           int                              null,   -- hba number
  cost             decimal(20,5)                    default 0           null    -- 单价
);

create unique index i_om_devicespec_info_specid on om_devicespec_info(devicemospecid);


-- 物理机分配历史表
drop table if exists om_phydevice_user_his;
create table om_phydevice_user_his
(
  entid            varchar(100)                    not null,   -- physicial id assiociate with table ent_phmachine
  userid           int           default 0         null,       -- 用户名，申请人-- 要修改为int？？？
  order_id         int           default 0         null,   -- 订单号
  order_code       varchar(64)                     null,   -- 订单号
  hostname         varchar(64)                     null,   -- 主机名称
  desciption       varchar(100)                    null,   -- 主机描
  purchasedate     datetime                        null,   -- 2017.12.12
  enddate          datetime                        null,   -- 2017.12.12
  opertiondivid    varchar(10)                     null,   -- 操作系统大类
  opertiongroupid  varchar(10)                     null,   -- 操作系统小类
  userip           varchar(100)                    null,   -- userip
  managername      varchar(50)                     null,   -- 管理员用户名
  managerpwd       varchar(50)                     null,   -- 管理员密码
  operid           varchar(50)                     null,   -- 操作ID
  opertime         datetime                        null,   -- 操作时间
  vdcid            varchar(64)                     not null   -- 申请人所属的vdc
 );


-- 物理机信息表iros
drop table if exists om_phydevice_info;
create table om_phydevice_info
(
  entid            varchar(100)                    not null,   -- physicial id assiociate with table ent_phmachine
  entname          varchar(100)                    not null,   -- 物理机名称
  devicemospecid   varchar(100)                    null,   -- associate om_devicespec_info 物理机,规格ID
  -- areaid           varchar(200)                    null,   -- associate with t_domain 区域ID t_domain,
  -- dcid             varchar(200)                    null,   -- associate with t_dc dcID t_dc,
  deviceid         varchar(200)                    null,   -- associate with ent_phcompany 厂商id  entid关联
  fixedassetnum    varchar(200)                    null,   -- 固定资产编号
  systemnum        varchar(200)                    null,   -- 系统编号
  productmnum      varchar(200)                    null,   -- 产品编号
  purchasedate     date                            null,   -- 2017.12.12  待定
  assurancetime    int                             null,   -- month 质保月份
  assurancedesc    varchar(200)                    null,   -- 质保描述
  location         varchar(200)                    null,   -- 位置
  locationdesc     varchar(50)                     null,   -- 大小
  upframenum       varchar(50)                     null,   -- 机驾号
  roundframenum    varchar(50)                     null,   -- 机框号
  slotnum          varchar(50)                     null,   -- 槽位号
  ipmiip           varchar(100)                    null,   -- ipmiip
  ipmiuser         varchar(50)                     null,   -- ipmiuser
  ipmipwd          varchar(50)                     null,   -- ipmi passsword
  status           int             default 0       null,   -- 机器是否被分配,0 未使用 1 已交付 2已经使用，9置成不可用状态
  phstatus         int             default 0       null,   -- 机器的运行状态 9 关机 8 开机
  operid           varchar(50)                     null,   -- 操作ID
  opertime         date                            null,   -- 操作时间
  hand_over        varchar(10)                     null,   -- 是否交付，0未交付 1已交付
  uuid             varchar(100)                    null,   -- 物理资源UUID
  is_measure       int             default 0       null    -- 是否监控，0不监控 1监控
);

-- 规格索引ID
create index i_om_phydevice_info_specid on om_phydevice_info(devicemospecid);
-- 物理机ID
create unique index i_om_phydevice_info_entid on om_phydevice_info(entid);


-- 物理机分配用户表
drop table if exists om_phydevice_user;
create table om_phydevice_user
(
  entid            varchar(100)                    not null,   -- physicial id assiociate with table ent_phmachine
  userid           int           default 0         null,       -- 用户名，申请人-- 要修改为int？？？
  order_id         int           default 0         null,   -- 订单号
  order_code       varchar(64)                     null,   -- 订单号
  hostname         varchar(64)                     null,   -- 主机名称
  desciption       varchar(100)                    null,   -- 主机描
  purchasedate     datetime                        null,   -- 2017.12.12
  enddate          datetime                        null,   -- 2017.12.12
  opertiondivid    varchar(10)                     null,   -- 操作系统大类
  opertiongroupid  varchar(10)                     null,   -- 操作系统小类
  userip           varchar(100)                    null,   -- userip
  managername      varchar(50)                     null,   -- 管理员用户名
  managerpwd       varchar(50)                     null,   -- 管理员密码
  operid           varchar(50)                     null,   -- 操作ID
  opertime         datetime                        null,   -- 操作时间
  vdcid            varchar(64)                     not null   -- 申请人所属的vdc
  
);
-- 物理机ID
create unique index i_om_phydevice_user_entid on om_phydevice_user(entid);
-- 订单
create index i_om_phydevice_user_order_id on om_phydevice_user(order_id);
 
 
drop table if exists ent_iros_phdevice;
create table ent_iros_phdevice
(	
    entid                varchar(200)                    not null,  -- 物理大类ID,所有物理机均挂靠在上面
    entname              varchar(200)                    null,      -- 名字
    entrid               varchar(200)                    not null,  -- 固定
    parentrid            varchar(100)                    not null,  -- 固定
    parententid          varchar(200)                    not null,  -- 母节点ID,挂在根目录
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
);

create unique index i_ent_iros_phdevice_entid on ent_iros_phdevice(entid);


delete from ent_iros_phdevice;

insert into ent_iros_phdevice (entid,entname,entrid,parentrid,parententid) values ('101','物理机','PH_DEVICE','ROOT','ROOT');



drop table if exists ent_iros_irosvdc;
create table ent_iros_irosvdc 
(
    entid                varchar(200)                    not null,  -- 物理机区域ID,标识
    entname              varchar(200)                    null,      -- 区域名
    entrid               varchar(200)                    not null,  -- 固定标识
    parentrid            varchar(100)                    not null,  -- 固定标识
    parententid          varchar(200)                    not null,  -- 挂载在root之下
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
);
create unique index i_ent_iros_irosvdc_entid on ent_iros_irosvdc(entid);



drop table if exists ent_phcompany;
create table ent_phcompany
(
    entid                varchar(200)                    not null,  -- 厂商标识ID,HP，IBM等
    entname              varchar(200)                    null,      -- 厂商名字
    entrid               varchar(200)                    not null,  -- 固定不变
    parentrid            varchar(100)                    not null,  -- 固定不变
    parententid          varchar(200)                    not null,  -- 母节点ID
    entip                varchar(100)                    null,      -- 扩展
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
);

create unique index i_ent_phcompany_entid on ent_phcompany(entid);



drop table if exists ent_phmachine;
-- ostype 1:NT 2:SUSELINUX 3:TURBOLINUX 4:AIX 5:HPUNIX 6:HPIA 7:SOLARIS 8 REDHATLINUX 9:CGSL
create table ent_phmachine  
(
    entid                varchar(200)                    not null,  -- 单个物理机ID与实体om_phydevice_info相关联
    entname              varchar(200)                    null,      -- 物理机名称与实体om_phydevice_info相关联
    entrid               varchar(200)                    not null,  -- 固定数据
    parentrid            varchar(100)                    not null,  -- 固定数据
    parententid          varchar(200)                    not null,  -- 母节点ID,挂在ent_phcompany的entid上面
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null,
	  ostype               numeric(10)                     null,
    phyid                varchar(100)                    null   -- physicial id assiociate with table ent_phmachine	  
);

create unique index i_ent_phmachine_entid on ent_phmachine(entid);

delete from om_order_process where process_id = 3;
delete from om_order_process_config where process_id = 3;
delete from om_res_order_process_rel where res_type = 2;
commit;

insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(3, '物理机审批流程', '适用于物理机申请审批流程', 1, 0, 0);
commit;

insert into om_order_process_config values ('3', '1', '审批', null, '已提交', '待交付', '0');
insert into om_order_process_config values ('3', '2', '交付', null, '待交付', '正常关闭', '0');
insert into om_order_process_config values ('3', '-2', '异常结束', null, '异常结束', '异常结束', '0');
insert into om_order_process_config values ('3', '-1', '审批拒绝', null, '审批拒绝', '审批拒绝', '0');
insert into om_order_process_config values ('3', '0', '正常关闭', null, '正常关闭', '正常关闭', '0');
commit;

insert into om_res_order_process_rel (res_type, process_id) values(2, 3);
commit; 
  
 
-- 增加设备规格 
drop procedure if exists sp_web_add_deviceinfo;
DELIMITER //
create procedure sp_web_add_deviceinfo
(
   in v_i_deviceid           varchar(100),   -- name hp
   in v_i_devicemodel        varchar(100),   -- model hp-1
   in v_i_devicemospecid     varchar(100),   -- speciation hp--id 唯一索引
   in v_i_devicemospecname   varchar(200),   -- speciation hp--id --name
   in v_i_devicetype         varchar(10),   -- device type  --待定
   in v_i_servertype         varchar(10),   -- server type  --待定
   in v_i_devdisk            varchar(50),   -- GB
   in v_i_memeory            varchar(50),   -- GB
   in v_i_nicmodel           varchar(100),  -- network type --待定
   in v_i_niunum             int        ,   -- network number
   in v_i_cpumodel           varchar(100),   -- cpu model   --待定
   in v_i_cpumohz            varchar(10),   -- cpu hz(G)
   in v_i_cpunum             int        ,   -- associate with t_dc
   in v_i_cpucores           int        ,   -- cpu number
   in v_i_hbamodel           varchar(100),   -- hba type   --待定
   in v_i_hbanum             int,            -- hba number
   in v_i_cost               decimal(20,5),   -- 价格
   out v_i_ret               int
)
begin
  declare  v_devicemospecid      varchar(100);
  declare  v_devicestatus        int;     -- 0未使用该规格是否被使用
  declare  v_specidnum           int;         -- 该规格下默认有多少机器默认0

  set  v_devicemospecid = trim(v_i_devicemospecid);
  set  v_devicestatus = 0;
  set  v_specidnum = 0;
  if exists(select 1 from om_devicespec_info where devicemospecid = v_devicemospecid)
    || exists(select 1 from om_devicespec_info where devicemospecid = v_devicemospecid)
    || exists(select 1 from om_device_info where deviceid = v_i_deviceid and devicemodel = v_i_devicemodel and devicemospecname = v_i_devicemospecname)
  then
    set v_i_ret = 1011;
  else
    start transaction;
    insert into om_device_info( devicemospecid, deviceid, devicemodel,devicemospecname ,specidnum,devicestatus)
         values(v_devicemospecid, v_i_deviceid, v_i_devicemodel,  v_i_devicemospecname, v_specidnum ,v_devicestatus);

    insert into om_devicespec_info (devicemospecid ,devicetype ,servertype ,devdisk ,memeory ,nicmodel ,niunum ,
             cpumodel ,cpumohz ,cpunum ,cpucores ,hbamodel ,hbanum, cost)
         values (v_devicemospecid ,v_i_devicetype ,v_i_servertype ,v_i_devdisk ,v_i_memeory ,v_i_nicmodel ,v_i_niunum ,
            v_i_cpumodel ,v_i_cpumohz ,v_i_cpunum ,v_i_cpucores ,v_i_hbamodel ,v_i_hbanum, v_i_cost);
    if @@warning_count <> 0 || @@error_count > 0 then
      rollback;
      set v_i_ret = 1001;
    else
      commit;
      set v_i_ret = 1;
    end if;
  end if;
end //
DELIMITER ;


-- 修改设备规格
drop procedure if exists sp_web_mod_deviceinfo;
DELIMITER //
create procedure sp_web_mod_deviceinfo
(
   v_i_deviceid           varchar(100),  -- name hp
   v_i_devicemodel        varchar(100),  -- model hp-1
   v_i_devicemospecid     varchar(100),  -- speciation hp--id 唯一索引
   v_i_devicemospecname   varchar(200),  -- speciation hp--id --name
   v_i_devicetype         varchar(10),   -- device type  --待定
   v_i_servertype         varchar(10),   -- server type  --待定
   v_i_devdisk            varchar(50),   -- GB
   v_i_memeory            varchar(50),   -- GB
   v_i_nicmodel           varchar(10),   -- network type 待定
   v_i_niunum             int        ,   -- network number
   v_i_cpumodel           varchar(10),   -- cpu model 待定
   v_i_cpumohz            varchar(10),   -- cpu hz(G)
   v_i_cpunum             int        ,   -- associate with t_dc
   v_i_cpucores           int        ,   -- cpu number
   v_i_hbamodel           varchar(10),   -- hba type  待定
   v_i_hbanum             int,           -- hba number
   v_i_cost               decimal(20,5),         -- 价格
   out v_i_ret            int
)
begin
  declare  v_devicemospecid      varchar(100);
  set  v_devicemospecid = trim(v_i_devicemospecid);

  if not exists(select 1 from om_devicespec_info where devicemospecid = v_devicemospecid)
    || not exists(select 1 from om_device_info where devicemospecid = v_devicemospecid)
  then
    set v_i_ret = 1012;
  else
    update om_devicespec_info set devicetype = v_i_devicetype, servertype = v_i_servertype, devdisk = v_i_devdisk,
           memeory = v_i_memeory, nicmodel = v_i_nicmodel, niunum = v_i_niunum, cpumodel = v_i_cpumodel,
           cpumohz = v_i_cpumohz, cpunum = v_i_cpunum, cpucores = v_i_cpucores, hbamodel = v_i_hbamodel,
           hbanum = v_i_hbanum, cost = v_i_cost
         where devicemospecid = v_devicemospecid;
    If @@warning_count <> 0 || @@error_count > 0 then
      set v_i_ret = 1001;
    Else
      set v_i_ret = 1;
    End if;
  End if;
end //
DELIMITER ;


-- 删除设备规格
drop procedure if exists sp_web_del_deviceinfo;
DELIMITER //
create procedure sp_web_del_deviceinfo
(
   v_i_devicemospecid     varchar(100),   -- speciation hp id 唯一索引
   out v_i_ret            int
)
begin
  declare  v_devicemospecid      varchar(100);
  declare  v_specidnum           int;        -- 该规格下默认有多少机器默认0
  set  v_devicemospecid = trim(v_i_devicemospecid);
  set  v_specidnum = 0;
  -- 根据规格ID查询厂商ID
  select specidnum into v_specidnum from om_device_info where devicemospecid = v_devicemospecid;

  if v_specidnum = -1
  then
    set v_specidnum = 0;
  end if;

  if v_specidnum = 0 then
    start transaction;
    delete from om_device_info where devicemospecid = v_devicemospecid;
    delete from om_devicespec_info where devicemospecid = v_devicemospecid;

    if @@warning_count <> 0 || @@error_count > 0 then
      rollback;
      set v_i_ret = 1001;
    else
      commit;
      set v_i_ret = 1;
    end if;
  else
    -- 将该规格修改为已经使用状态
    update om_device_info set devicestatus = 1  where devicemospecid = v_devicemospecid;

    if @@warning_count <> 0 || @@error_count > 0 then
      set v_i_ret = 1001;
    else
      set v_i_ret = 1;
    end if;
  end if;
end //
DELIMITER ;

-- 增加物理设备
drop procedure if exists sp_web_add_phymachineinfo;
DELIMITER //
create procedure sp_web_add_phymachineinfo
(
  in v_i_entid            varchar(100), -- physicial id
  in v_i_devicemospecid   varchar(100), -- associate om_devicespec_info 物理机
  -- in v_i_areaid           varchar(200), -- 增加areaid，
  -- in v_i_dcid           varchar(200), -- 增加areaid，
  in v_i_fixedassetnum    varchar(200), -- 固定资产编号
  in v_i_systemnum        varchar(200), -- 系统编号
  in v_i_productmnum      varchar(200), -- 产品编号
  in v_i_purchasedate     date,         -- 2017.12.12  待定
  in v_i_assurancetime    int,          -- month 质保月份
  in v_i_assurancedesc    varchar(200), -- 质保描述
  in v_i_location         varchar(200), -- 位置
  in v_i_locationdesc     varchar(50) , -- 大小
  in v_i_upframenum       varchar(50) , -- 机驾号
  in v_i_roundframenum    varchar(50) , -- 机框号
  in v_i_slotnum          varchar(50) , -- 槽位号
  in v_i_ipmiip           varchar(100), -- ipmiip
  in v_i_ipmiuser         varchar(50) , -- ipmiuser
  in v_i_ipmipwd          varchar(50) , -- ipmi passsword
  in v_i_status           int         , -- 0 未使用 1 已使用
  in v_i_operid           varchar(50) , -- 操作ID
  in v_i_entname          varchar(200), -- ommp 物理机名字
  in v_i_ommpid           varchar(200), -- ommp 物理机id
  out v_i_ret            int
)
begin
  declare  v_entid               varchar(100);
  declare  v_devicemospecid      varchar(100);
  declare  v_opertime            date;
  declare  v_deviceid            varchar(200);  -- 厂商ID
  declare  v_devicename          varchar(200);  -- 厂商名字
  declare  v_phstatus            int;           -- 物理机状态   9关机
  set v_entid = trim(v_i_entid);
  set v_devicemospecid = trim(v_i_devicemospecid);
  set v_opertime = now();
  set v_phstatus = 9;

  -- 根据规格ID查询厂商ID
  select deviceid into v_deviceid from om_device_info where devicemospecid = v_i_devicemospecid;

  if FOUND_ROWS() = 0
    || exists(select 1 from om_phydevice_info where entid = v_entid)
    || exists(select 1 from om_phydevice_info where entname = v_i_entname) then
    set v_i_ret = 3001;
  elseif exists(select 1 from om_phydevice_info where fixedassetnum = v_i_fixedassetnum) then
    set v_i_ret = 3003;
  elseif exists(select 1 from om_phydevice_info where systemnum = v_i_systemnum) then
    set v_i_ret = 3004;
  elseif exists(select 1 from om_phydevice_info where productmnum = v_i_productmnum) then
    set v_i_ret = 3005;
  else
    select dataname into v_devicename from common_dict_item where dataid = v_deviceid;

    if FOUND_ROWS() = 0 then
      set v_i_ret = 3006;
    else
      start transaction;
      insert into om_phydevice_info (entid, entname,devicemospecid ,deviceid ,fixedassetnum ,systemnum ,productmnum ,purchasedate ,
                       assurancetime ,assurancedesc ,location ,locationdesc ,upframenum ,roundframenum ,
                      slotnum ,ipmiip ,ipmiuser ,ipmipwd ,status ,phstatus ,operid , opertime)
           values(v_entid, v_i_entname, v_devicemospecid, v_deviceid, v_i_fixedassetnum, v_i_systemnum, v_i_productmnum, v_i_purchasedate,
                  v_i_assurancetime, v_i_assurancedesc, v_i_location, v_i_locationdesc, v_i_upframenum, v_i_roundframenum,
                  v_i_slotnum, v_i_ipmiip, v_i_ipmiuser, v_i_ipmipwd, v_i_status, v_phstatus, v_i_operid, v_opertime);
      if @@warning_count <> 0 || @@error_count > 0 then
        rollback;
        set v_i_ret = 1001;
      else
        commit;
        update om_device_info set specidnum = specidnum + 1  where devicemospecid = v_devicemospecid;
        if @@warning_count <> 0 || @@error_count > 0 then
          set v_i_ret = 1001;
        else
          set v_i_ret = 1;
        end if;
      end if;
    end if;
  end if;
end //
DELIMITER ;

-- 修改物理设备
drop procedure if exists sp_web_mod_phymachineinfo;
DELIMITER //
create procedure sp_web_mod_phymachineinfo
(
  in v_i_entid            varchar(100), -- physicial id
  in v_i_devicemospecid   varchar(100), -- associate om_devicespec_info 物理机
  -- in v_i_areaid           varchar(200), -- 增加areaid，
  -- in v_i_dcid          varchar(200), -- 增加dcid，
  in v_i_fixedassetnum    varchar(200), -- 固定资产编号
  in v_i_systemnum        varchar(200), -- 系统编号
  in v_i_productmnum      varchar(200), -- 产品编号
  in v_i_purchasedate     date,         -- 2017.12.12  待定
  in v_i_assurancetime    int,          -- month 质保月份
  in v_i_assurancedesc    varchar(200), -- 质保描述
  in v_i_location         varchar(200), -- 位置
  in v_i_locationdesc     varchar(50) , -- 大小
  in v_i_upframenum       varchar(50) , -- 机驾号
  in v_i_roundframenum    varchar(50) , -- 机框号
  in v_i_slotnum          varchar(50) , -- 槽位号
  in v_i_ipmiip           varchar(100), -- ipmiip
  in v_i_ipmiuser         varchar(50) , -- ipmiuser
  in v_i_ipmipwd          varchar(50) , -- ipmi passsword
  in v_i_status           int         , -- 0 未使用 1 已使用
  in v_i_operid           varchar(50) , -- 操作ID
  in v_i_entname          varchar(200),
  out v_i_ret             int
)
begin
  declare  v_entid               varchar(100);
  declare  v_devicemospecid      varchar(100);
  declare  v_opertime            date;
  set v_entid = trim(v_i_entid);
  set v_devicemospecid = trim(v_i_devicemospecid);
  set v_opertime = now();

  if not exists(select 1 from om_phydevice_info where entid = v_entid) then
    set v_i_ret = 3011;
  else
    update om_phydevice_info set devicemospecid = v_devicemospecid, fixedassetnum = v_i_fixedassetnum, systemnum = v_i_systemnum,
               productmnum = v_i_productmnum, purchasedate = v_i_purchasedate,  assurancetime = v_i_assurancetime,
                assurancedesc = v_i_assurancedesc,  location = v_i_location, locationdesc = v_i_locationdesc, upframenum = v_i_upframenum,
                roundframenum = v_i_roundframenum ,  slotnum = v_i_slotnum,  ipmiip = v_i_ipmiip, ipmiuser = v_i_ipmiuser,
                ipmipwd = v_i_ipmipwd, operid = v_i_operid,entname = v_i_entname, opertime = v_opertime, deviceid=(select deviceid from om_device_info where devicemospecid=v_devicemospecid)
                where entid = v_entid;
	set v_i_ret = 1;
 
  end if;
end //
DELIMITER ;

-- 删除物理设备
drop procedure if exists sp_web_del_phydevice;
DELIMITER //
create procedure sp_web_del_phydevice
(
  in v_i_entid           varchar(100), -- physicial id
  out v_i_ret            int
)
begin
  declare  v_entid               varchar(100);
  declare  v_parentrid           varchar(100);  -- 挂靠在树上的ID，ID生成规则areaid +'_' +companyid
  declare  v_status              int;           -- 初始化状态
  declare  v_devicemospecid      varchar(100);  -- associate om_devicespec_info 物理机,规格ID
  set v_entid = trim(v_i_entid);
  set v_status = 0; -- 初始化状态等于0

  select status, devicemospecid into v_status, v_devicemospecid from om_phydevice_info where entid = v_entid;
  if FOUND_ROWS() = 0 then
    set v_i_ret = 3023;
  else if v_status = 1 || v_status = 2 || v_status = 9 || @v_status = 10 then
    set v_i_ret = 3022;
  else
    if v_status = 0 then
      start transaction;
      delete from om_phydevice_info  where entid = v_entid;

      if @@warning_count <> 0 || @@error_count > 0 then
        rollback;
        set v_i_ret = 1001;
      else
        delete from ent_phmachine where phyid = v_entid;

        if @@warning_count <> 0 || @@error_count > 0 then
          rollback;
          set v_i_ret = 1001;
        else
          commit;
          update om_device_info set specidnum = specidnum - 1  where devicemospecid = v_devicemospecid;

          if @@warning_count <> 0 || @@error_count > 0 then
            set v_i_ret = 1001;
          else
            set v_i_ret = 1;
          end if;
        end if;
      end if;
    else
      update om_phydevice_info set status = 9 where entid = v_entid;

      if @@warning_count <> 0 || @@error_count > 0 then
        set v_i_ret = 1001;
      else
        update om_device_info set specidnum = specidnum - 1  where devicemospecid = v_devicemospecid;
        if @@warning_count <> 0 || @@error_count > 0 then
          set v_i_ret = 1001;
        else
          set v_i_ret = 1;
        end if;
      end if;
    end if;
  end if;
    end if;
end //
DELIMITER ;

-- 物理机订单审批
drop procedure if exists sp_web_audit_order;
DELIMITER //
create procedure sp_web_audit_order
(
  in v_i_orderid          int,
  in v_i_entid            varchar(100),
  in v_i_purchasedate     datetime,
  in v_i_enddate          datetime,
  in v_i_opertiongroupid  varchar(10),
  in v_i_operid           varchar(50),
  out v_o_ret            int
)
begin
    declare  v_vdcid              varchar(64);
    declare  v_order_code         varchar(64);
    declare  v_opertime           date;
    declare  v_applicant_id       int;
    declare  v_opertiondivid      varchar(10);
	set  v_opertime = now();
	set  v_opertiondivid = '1';
	   
    select order_code, user_id into v_order_code, v_applicant_id from om_order where order_id = v_i_orderid;   
    if FOUND_ROWS() = 0 then
         set v_o_ret = 4001;
    else
        select vdcid into v_vdcid from om_user_info where userid = v_applicant_id;
        if FOUND_ROWS() = 0 then
            set v_o_ret = 4001;
        else
	        select parentdataid into v_opertiondivid from common_dict_item where dataid = v_i_opertiongroupid;
	        if FOUND_ROWS() = 0 then
		        set v_o_ret = 5001;
	        else
		        if exists(select 1 from om_phydevice_user where entid = v_i_entid) then
			       set v_o_ret = 5002;
		        else
			        insert into om_phydevice_user (entid ,userid ,order_id,order_code ,hostname ,desciption ,purchasedate ,enddate ,opertiondivid ,
							 opertiongroupid ,userip ,managername ,managerpwd ,operid ,opertime, vdcid)
					 values(v_i_entid ,v_applicant_id,v_i_orderid, v_order_code,'' ,'' ,v_i_purchasedate  ,
							v_i_enddate ,v_opertiondivid ,v_i_opertiongroupid ,'' ,
							'' ,'' ,v_i_operid ,v_opertime, v_vdcid);
			        if @@warning_count <> 0 || @@error_count > 0 then
				        set v_o_ret = 1001;
			        else
				        update om_phydevice_info set status = 1 where entid = v_i_entid;
				        if @@warning_count <> 0 || @@error_count > 0 then
				           set v_o_ret = 1001;
				        else
				           set v_o_ret = 1;
				        end if;
			        end if;
		        end if;
	        end if;
        end if;
    end if;
end
//
DELIMITER ;

-- 物理订单交付拒绝
drop procedure if exists sp_web_reject_orderphymachine;
DELIMITER //
create procedure sp_web_reject_orderphymachine
(
  in  v_i_order_id       int,
  out v_o_ret           int
)
begin
  declare v_status   int;
  set     v_status = 0;
  update om_phydevice_info set status = v_status where entid in (select entid from om_phydevice_user where order_id = v_i_order_id);
  if @@warning_count <> 0 || @@error_count > 0 then
	set v_o_ret = 2001;
  else
	delete from om_phydevice_user where order_id = v_i_order_id;
	if @@warning_count <> 0 || @@error_count > 0 then
	  set v_o_ret = 2001;
	else
	  set v_o_ret = 1;
	end if;
  end if;
end
//
DELIMITER ;

