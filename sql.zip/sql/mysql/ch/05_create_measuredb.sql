﻿-- **********************************************************************
-- * SQL Name: create_measuredb.sql 
-- * Version: mysql  
-- * 2014-12-11
-- * Author: lb
-- **********************************************************************
-- drop database if exists irosmeasure;  
-- create database irosmeasure DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
-- grant all privileges on irosmeasure.* to 'irosmeasure'@'localhost' identified by 'db10$ZTE';
-- commit;
