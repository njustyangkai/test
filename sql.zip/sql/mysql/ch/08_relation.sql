-- 创建资源关联库
create database if not exists irosrelation DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
grant all privileges on irosrelation.* to 'irosrelation'@'localhost' identified by 'db10$ZTE';
commit;

use irosrelation;
-- 云主机与用户的关联关系表
drop table if exists om_relation_instance;
create table om_relation_instance (
	res_id				varchar(64) 	not null,	-- 云主机id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power
	extra				text			null,
	primary key (res_id)
);

-- 网络与用户的关联关系表
drop table if exists om_relation_network;
create table om_relation_network (
	res_id				varchar(64) 	not null,	-- 网络id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power
	extra				text			null,
	primary key (res_id)
);

-- 子网与用户的关联关系表
drop table if exists om_relation_subnet;
create table om_relation_subnet (
	res_id				varchar(64) 	not null,	-- 子网id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power
	extra				text			null,
	primary key (res_id)
);

-- 镜像与用户的关联关系表
drop table if exists om_relation_image;
create table om_relation_image (
	res_id				varchar(64) 	not null,	-- 镜像id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power，7是IECS
	extra				text			null,
	primary key (res_id)
);

-- 云硬盘与用户的关联关系表
drop table if exists om_relation_volume;
create table om_relation_volume (
	res_id				varchar(64) 	not null,	-- 云硬盘id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power，7是IECS
	extra				text			null,
	primary key (res_id)
);

-- 备份与用户的关联关系表
drop table if exists om_relation_backup;
create table om_relation_backup (
	res_id				varchar(64) 	not null,	-- 备份id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power，7是IECS
	extra				text			null,
	primary key (res_id)
);

-- 快照与用户的关联关系表
drop table if exists om_relation_snapshot;
create table om_relation_snapshot (
	res_id				varchar(64) 	not null,	-- 快照id
	tenant_id			varchar(64)		not null,	-- 租户id
	user_id				int				not null,	-- 用户id
	dc_id				varchar(64) 	not null,	-- dc id
	dc_type				int				not null,	-- dc类型，3是vmware，4是power，7是IECS
	extra				text			null,
	primary key (res_id)
);

-- 租户信息表
drop table if exists om_relation_tenant;
create table om_relation_tenant(
  id 					varchar(64)		not null,		-- 租户id
  name 					varchar(64)		not null,		-- 租户名称
  extra 				text,							-- 扩展信息
  description 			text,							-- 描述信息
  enabled 				tinyint(1)		default null,	-- 是否可用,
  dc_id					varchar(64) 	not null,		-- dc id
  dc_type				int				not null,		-- dc类型，3是vmware，4是power
  primary key (id)
);

-- 用户信息表
drop table if exists om_relation_user;
create table om_relation_user (
  id					varchar(64) 	not null,		-- 用户id
  name 					varchar(255)	not null,		-- 用户名称
  extra 				text,							-- 扩展信息
  password 				varchar(128) 	default null,	-- 密码
  enabled 				tinyint(1) 		default null,	-- 是否可用
  is_admin				int				default 0		not null,		-- 是否管理员 0表示普通用户 1表示管理员
  email					varchar(100)	default null,	-- 邮箱
  dc_id					varchar(64) 	not null,		-- dc id
  dc_type				int				not null,		-- dc类型，3是vmware，4是power
  primary key (id)
);

-- 用户租户关联信息表
drop table if exists om_relation_assignment;
create table om_relation_assignment (
  user_id					varchar(64) 	not null,		-- 用户id
  tenant_id 				varchar(64)		not null		-- 租户id
);

-- 配额相关
drop table if exists om_quota_class;
CREATE TABLE om_quota_class (
	id						varchar(64)					not null,	-- id
	create_date				datetime					not null,	-- 创建时间
	update_date				datetime					not null,	-- 更新时间
	name					varchar(100)				not null,	-- 配额类名
	resource_id				varchar(64)					not null,	-- 配额id
	resource				varchar(100)				not null,	-- 配额名称
	resource_type			varchar(50)					null,		-- 资源所属的大类
	hard_limit				numeric						not null,	-- 上限
	deleted					numeric						not null,	-- 是否删除
	delete_date				datetime					null,		-- 删除时间
	dc_type					int							not null,	-- dc类型，3是vmware，4是power，用来标示该类型特有的配额，如果为-1，标示公共的
	primary key(id)
);

-- 初始化数据，根据需要补充
insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('1', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '云主机(台)', 'nova_instances', 50, 0, null, '计算', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('2', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'CPU(核)', 'nova_cores', 50, 0, null, '计算', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('3', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '内存(MB)', 'nova_ram', 51200, 0, null, '计算', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('4', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '网络(个)', 'neutron_networks', 50, 0, null, '网络', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('5', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '云硬盘(个)', 'cinder_volumes', 50, 0, null, '云硬盘', 4);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('6', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '云硬盘总大小(GB)', 'cinder_gigabytes', 100, 0, null, '云硬盘', 4);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('7', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '备份(个)', 'nova_backup', 50, 0, null, '备份', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('8', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', '快照(个)', 'nova_snapshot', 50, 0, null, '快照', -1);


drop table if exists om_quotas;
CREATE TABLE om_quotas (
	id						varchar(64)				not null, 	-- id
	create_date				datetime				not null, 	-- 创建时间
	update_date				datetime				not null, 	-- 更新时间
	dc_id					varchar(64)				not null, 	-- dc_id
	dc_type					int						not null,	-- dc类型，3是vmware，4是power，
	tenant_id				varchar(64)				not null, 	-- 租户id
	resource_id				varchar(64)				not null,	-- 配额id
	resource				varchar(100)			not null,	-- 配额名称
	resource_type			varchar(50)				null,     	-- 资源所属的大类
	in_use					numeric					default 0		not null, 	-- 已使用
	hard_limit				numeric					not null, 	-- 上限
	PRIMARY KEY(id)
);

-- vmware规格信息表
drop table if exists vmware_flavors;
create table vmware_flavors (
	name			varchar(255)		not null,
	id				varchar(64)			not null,
	memory_mb		int(11)				not null,
	vcpus			int(11)				not null,
	root_gb			int(11)				default null,
	disabled		tinyint(1)			default 0		not null,
	is_public		tinyint(1)			default 1		not null,
	dc_id			varchar(64) 		not null,		-- dc id
	dc_type			int					not null,		-- dc类型,目前只是3，vmware
	deleted			int					default 0		not null		-- 是否删除 0表示正常 1表示删除
);

drop table if exists t_zone;
create table t_zone
(
	dc_id              varchar(100) not null,
	id                 varchar(100) not null,
	name               varchar(100) not null,
	primary key (id, dc_id)
);

drop table if exists t_aggregate;
create table t_aggregate
(
	dc_id              varchar(100)  not null,
	zone_id            varchar(100)  not null,
	id                 varchar(100)  not null,
	name               varchar(100)  not null,
    metadata           varchar(1000) null,
    created_at         varchar(50)   null,
    deleted            varchar(10)   null,
    deleted_at         varchar(50)   null,
	primary key (id, dc_id)
);

drop table if exists t_host;
create table t_host
(
	dc_id              varchar(100)  not null,
	zone_id            varchar(100)  not null,
	aggregate_id       varchar(100)  not null,
	id                 varchar(100)  not null,
	name               varchar(100)  not null,
    ip                 varchar(100)  not null,
    status             varchar(50)   null,
    hypervisor_type    varchar(50)   null,
    vcpus              int           null,
    vcpusused          int           null,
    memory             int           null,
    memoryused         int           null,
    memoryfree         int           null,    
    runningvms         int           null,
	primary key (id, name, dc_id)
);

drop table if exists t_vm;
create table t_vm
(
	dc_id              varchar(100)   not null,
	zone_id            varchar(100)   null,
	aggregate_id       varchar(100)   null,
    host_id            varchar(100)   null,
	id                 varchar(100)   not null,
	name               varchar(100)   not null,
    power_state        varchar(50)    null,
    status             varchar(50)    null,
    address            text           null,
    memory             int            null,
    cpu_count          int            null,
    flavor             varchar(1000)  null,
    os_name            varchar(100)   null,
    disk_size          int            null,
    vnc_enable         varchar(10)    null,
    vnc_port           varchar(10)    null,
    vnc_password       varchar(100)   null,
    imgage             varchar(1000)  null,
    task_state         varchar(50)    null,
    availability_zone  varchar(100)   null,
    host               varchar(100)   null,
    hypervisorname     varchar(100)   null,
    tenant_id          varchar(100)   null,
	primary key (id, dc_id)    
);
