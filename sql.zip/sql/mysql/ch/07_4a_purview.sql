﻿-- 针对RCS需求，用户直接与权限关联控制开关打开，前提是ommp已升级到对应的版本
use zxinsys;
delete from oper_funcgrp2 where funcgrpid = 4;
insert into oper_funcgrp2 values (4, '4', '权限管理', 'uniportal', 0);
delete from oper_function where funcdescription in ('操作员管理','角色信息','组信息','安全等级','安全规则设置','操作员信息编辑','角色信息编辑','组信息编辑','安全等级编辑','安全规则设置编辑','创建删除资源');
insert into oper_function values (4, 13001, '1301' , '操作员管理'  ,       0, 'uniportal');
insert into oper_function values (4, 13003, '1303' , '角色信息'    ,       0, 'uniportal');
insert into oper_function values (4, 13005, '1305' , '组信息'      ,       0, 'uniportal');
insert into oper_function values (4, 13007, '1307' , '安全等级'     ,      0, 'uniportal');
insert into oper_function values (4, 13008, '1308' , '安全规则设置'  ,      0, 'uniportal');
insert into oper_function values (4, 13009, '1309' , '操作员信息编辑'  ,      0, 'uniportal');
insert into oper_function values (4, 13011, '1311' , '角色信息编辑'  ,      0, 'uniportal');
insert into oper_function values (4, 13014, '1314' , '组信息编辑'  ,       0, 'uniportal'); 
insert into oper_function values (4, 13016, '1316' , '安全等级编辑'  ,       0, 'uniportal'); 
insert into oper_function values (4, 13017, '1317' , '安全规则设置编辑'  ,       0, 'uniportal');
insert into oper_function values (4, 13020, '1320' , '创建删除资源'  ,       0, 'uniportal');

delete from oper_grpdef where funcgrpid=4 and opergrpid=1000  and servicekey='uniportal';
insert into oper_grpdef select 1000,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4;
delete from oper_grpdef where funcgrpid=4 and opergrpid=1001  and servicekey='uniportal';
insert into oper_grpdef select 1001,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4; 

-- 增加rcs已经存在的四种角色，4a同步用户

-- 增加新的角色：
-- proc_res_op_grpscript2 产品ID，修改标识(add-1,del-2)，角色标识，角色名称
call proc_res_op_grpscript2(0, 1, 201, '管理员角色', '管理员角色');
call proc_res_op_grpscript2(0, 1, 202, '操作员角色', '操作员角色');
call proc_res_op_grpscript2(0, 1, 203, '维护员角色', '维护员角色');
call proc_res_op_grpscript2(0, 1, 204, '监控员角色', '监控员角色'); 
call proc_res_op_grpscript2(0, 1, 205, '自定义角色', '自定义角色'); 

-- 给新增加的角色增加相应的权限：
-- 管理员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 201, 1,  10001);
call proc_res_op_grpdef(0, 1, 201, 1,  10003);
call proc_res_op_grpdef(0, 1, 201, 1,  10006);
call proc_res_op_grpdef(0, 1, 201, 1,  10007);
call proc_res_op_grpdef(0, 1, 201, 3,  12001);
call proc_res_op_grpdef(0, 1, 201, 3,  12002);
call proc_res_op_grpdef(0, 1, 201, 3,  12003);
call proc_res_op_grpdef(0, 1, 201, 3,  12007);
call proc_res_op_grpdef(0, 1, 201, 3,  12008);
call proc_res_op_grpdef(0, 1, 201, 3,  12010);
call proc_res_op_grpdef(0, 1, 201, 4,  13001);
call proc_res_op_grpdef(0, 1, 201, 4,  13003);
call proc_res_op_grpdef(0, 1, 201, 4,  13005);
call proc_res_op_grpdef(0, 1, 201, 4,  13007);
call proc_res_op_grpdef(0, 1, 201, 4,  13008);
call proc_res_op_grpdef(0, 1, 201, 4,  13009);
call proc_res_op_grpdef(0, 1, 201, 4,  13011);
call proc_res_op_grpdef(0, 1, 201, 4,  13014);
call proc_res_op_grpdef(0, 1, 201, 4,  13016);
call proc_res_op_grpdef(0, 1, 201, 4,  13017);
call proc_res_op_grpdef(0, 1, 201, 4,  13020);
call proc_res_op_grpdef(0, 1, 201, 10, 15001);
call proc_res_op_grpdef(0, 1, 201, 10, 15005);
call proc_res_op_grpdef(0, 1, 201, 10, 15007);
call proc_res_op_grpdef(0, 1, 201, 11, 18005);
call proc_res_op_grpdef(0, 1, 201, 11, 18102);
call proc_res_op_grpdef(0, 1, 201, 1396, 139602);
call proc_res_op_grpdef(0, 1, 201, 1396, 139603);
call proc_res_op_grpdef(0, 1, 201, 1396, 139604);
call proc_res_op_grpdef(0, 1, 201, 1396, 139605);
call proc_res_op_grpdef(0, 1, 201, 1396, 139606);
call proc_res_op_grpdef(0, 1, 201, 1396, 139607);
call proc_res_op_grpdef(0, 1, 201, 1396, 139608);
call proc_res_op_grpdef(0, 1, 201, 1396, 139609);
call proc_res_op_grpdef(0, 1, 201, 1396, 139610);


-- 给新增加的角色增加相应的权限：
-- 操作员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 202, 1,  10001);
call proc_res_op_grpdef(0, 1, 202, 1,  10003);
call proc_res_op_grpdef(0, 1, 202, 1,  10006);
call proc_res_op_grpdef(0, 1, 202, 1,  10007);
call proc_res_op_grpdef(0, 1, 202, 3,  12001);
call proc_res_op_grpdef(0, 1, 202, 3,  12002);
call proc_res_op_grpdef(0, 1, 202, 3,  12003);
call proc_res_op_grpdef(0, 1, 202, 3,  12007);
call proc_res_op_grpdef(0, 1, 202, 3,  12008);
call proc_res_op_grpdef(0, 1, 202, 3,  12010);
call proc_res_op_grpdef(0, 1, 202, 4,  13001);
call proc_res_op_grpdef(0, 1, 202, 4,  13003);
call proc_res_op_grpdef(0, 1, 202, 4,  13005);
call proc_res_op_grpdef(0, 1, 202, 4,  13007);
call proc_res_op_grpdef(0, 1, 202, 4,  13008);
call proc_res_op_grpdef(0, 1, 202, 4,  13009);
call proc_res_op_grpdef(0, 1, 202, 4,  13011);
call proc_res_op_grpdef(0, 1, 202, 4,  13014);
call proc_res_op_grpdef(0, 1, 202, 4,  13016);
call proc_res_op_grpdef(0, 1, 202, 4,  13017);
call proc_res_op_grpdef(0, 1, 202, 4,  13020);
call proc_res_op_grpdef(0, 1, 202, 10, 15001);
call proc_res_op_grpdef(0, 1, 202, 10, 15005);
call proc_res_op_grpdef(0, 1, 202, 10, 15007);
call proc_res_op_grpdef(0, 1, 202, 11, 18005);
call proc_res_op_grpdef(0, 1, 202, 11, 18102);
call proc_res_op_grpdef(0, 1, 202, 1396, 139602);
call proc_res_op_grpdef(0, 1, 202, 1396, 139603);
call proc_res_op_grpdef(0, 1, 202, 1396, 139604);
call proc_res_op_grpdef(0, 1, 202, 1396, 139605);
call proc_res_op_grpdef(0, 1, 202, 1396, 139606);
call proc_res_op_grpdef(0, 1, 202, 1396, 139607);
call proc_res_op_grpdef(0, 1, 202, 1396, 139608);
call proc_res_op_grpdef(0, 1, 202, 1396, 139609);
call proc_res_op_grpdef(0, 1, 202, 1396, 139610);



-- 给新增加的角色增加相应的权限：
-- 维护员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 203, 1,  10001);
call proc_res_op_grpdef(0, 1, 203, 1,  10003);
call proc_res_op_grpdef(0, 1, 203, 1,  10006);
call proc_res_op_grpdef(0, 1, 203, 1,  10007);
call proc_res_op_grpdef(0, 1, 203, 3,  12001);
call proc_res_op_grpdef(0, 1, 203, 3,  12002);
call proc_res_op_grpdef(0, 1, 203, 3,  12003);
call proc_res_op_grpdef(0, 1, 203, 3,  12007);
call proc_res_op_grpdef(0, 1, 203, 3,  12008);
call proc_res_op_grpdef(0, 1, 203, 3,  12010);
call proc_res_op_grpdef(0, 1, 203, 4,  13001);
call proc_res_op_grpdef(0, 1, 203, 4,  13003);
call proc_res_op_grpdef(0, 1, 203, 4,  13005);
call proc_res_op_grpdef(0, 1, 203, 4,  13007);
call proc_res_op_grpdef(0, 1, 203, 4,  13008);
call proc_res_op_grpdef(0, 1, 203, 4,  13009);
call proc_res_op_grpdef(0, 1, 203, 4,  13011);
call proc_res_op_grpdef(0, 1, 203, 4,  13014);
call proc_res_op_grpdef(0, 1, 203, 4,  13016);
call proc_res_op_grpdef(0, 1, 203, 4,  13017);
call proc_res_op_grpdef(0, 1, 203, 4,  13020);
call proc_res_op_grpdef(0, 1, 203, 10, 15001);
call proc_res_op_grpdef(0, 1, 203, 10, 15005);
call proc_res_op_grpdef(0, 1, 203, 10, 15007);
call proc_res_op_grpdef(0, 1, 203, 11, 18005);
call proc_res_op_grpdef(0, 1, 203, 11, 18102);


-- 给新增加的角色增加相应的权限：
-- 监控员角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 204, 1,  10001);
call proc_res_op_grpdef(0, 1, 204, 1,  10003);
call proc_res_op_grpdef(0, 1, 204, 1,  10006);
call proc_res_op_grpdef(0, 1, 204, 1,  10007);
call proc_res_op_grpdef(0, 1, 204, 3,  12001);
call proc_res_op_grpdef(0, 1, 204, 3,  12002);
call proc_res_op_grpdef(0, 1, 204, 3,  12003);
call proc_res_op_grpdef(0, 1, 204, 3,  12007);
call proc_res_op_grpdef(0, 1, 204, 3,  12008);
call proc_res_op_grpdef(0, 1, 204, 3,  12010);
call proc_res_op_grpdef(0, 1, 204, 4,  13001);
call proc_res_op_grpdef(0, 1, 204, 4,  13003);
call proc_res_op_grpdef(0, 1, 204, 4,  13005);
call proc_res_op_grpdef(0, 1, 204, 4,  13007);
call proc_res_op_grpdef(0, 1, 204, 4,  13008);
call proc_res_op_grpdef(0, 1, 204, 4,  13009);
call proc_res_op_grpdef(0, 1, 204, 4,  13011);
call proc_res_op_grpdef(0, 1, 204, 4,  13014);
call proc_res_op_grpdef(0, 1, 204, 4,  13016);
call proc_res_op_grpdef(0, 1, 204, 4,  13017);
call proc_res_op_grpdef(0, 1, 204, 4,  13020);
call proc_res_op_grpdef(0, 1, 204, 10, 15001);
call proc_res_op_grpdef(0, 1, 204, 10, 15005);
call proc_res_op_grpdef(0, 1, 204, 10, 15007);
call proc_res_op_grpdef(0, 1, 204, 11, 18005);
call proc_res_op_grpdef(0, 1, 204, 11, 18102);
call proc_res_op_grpdef(0, 1, 204, 1396, 139602);
call proc_res_op_grpdef(0, 1, 204, 1396, 139603);
call proc_res_op_grpdef(0, 1, 204, 1396, 139604);
call proc_res_op_grpdef(0, 1, 204, 1396, 139605);
call proc_res_op_grpdef(0, 1, 204, 1396, 139606);
call proc_res_op_grpdef(0, 1, 204, 1396, 139607);
call proc_res_op_grpdef(0, 1, 204, 1396, 139608);
call proc_res_op_grpdef(0, 1, 204, 1396, 139609);
call proc_res_op_grpdef(0, 1, 204, 1396, 139610);



-- 给新增加的角色增加相应的权限：
-- 自定义角色：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 205, 1,  10001);
call proc_res_op_grpdef(0, 1, 205, 1,  10003);
call proc_res_op_grpdef(0, 1, 205, 1,  10006);
call proc_res_op_grpdef(0, 1, 205, 1,  10007);
call proc_res_op_grpdef(0, 1, 205, 3,  12001);
call proc_res_op_grpdef(0, 1, 205, 3,  12002);
call proc_res_op_grpdef(0, 1, 205, 3,  12003);
call proc_res_op_grpdef(0, 1, 205, 3,  12007);
call proc_res_op_grpdef(0, 1, 205, 3,  12008);
call proc_res_op_grpdef(0, 1, 205, 3,  12010);
call proc_res_op_grpdef(0, 1, 205, 4,  13001);
call proc_res_op_grpdef(0, 1, 205, 4,  13003);
call proc_res_op_grpdef(0, 1, 205, 4,  13005);
call proc_res_op_grpdef(0, 1, 205, 4,  13007);
call proc_res_op_grpdef(0, 1, 205, 4,  13008);
call proc_res_op_grpdef(0, 1, 205, 4,  13009);
call proc_res_op_grpdef(0, 1, 205, 4,  13011);
call proc_res_op_grpdef(0, 1, 205, 4,  13014);
call proc_res_op_grpdef(0, 1, 205, 4,  13016);
call proc_res_op_grpdef(0, 1, 205, 4,  13017);
call proc_res_op_grpdef(0, 1, 205, 4,  13020);
call proc_res_op_grpdef(0, 1, 205, 10, 15001);
call proc_res_op_grpdef(0, 1, 205, 10, 15005);
call proc_res_op_grpdef(0, 1, 205, 10, 15007);
call proc_res_op_grpdef(0, 1, 205, 11, 18005);
call proc_res_op_grpdef(0, 1, 205, 11, 18102);
call proc_res_op_grpdef(0, 1, 205, 1396, 139602);
call proc_res_op_grpdef(0, 1, 205, 1396, 139603);
call proc_res_op_grpdef(0, 1, 205, 1396, 139604);
call proc_res_op_grpdef(0, 1, 205, 1396, 139605);
call proc_res_op_grpdef(0, 1, 205, 1396, 139606);
call proc_res_op_grpdef(0, 1, 205, 1396, 139607);
call proc_res_op_grpdef(0, 1, 205, 1396, 139608);
call proc_res_op_grpdef(0, 1, 205, 1396, 139609);
call proc_res_op_grpdef(0, 1, 205, 1396, 139610);

update portal_sysparam set param_value='1'  where param_name='RCS';
call proc_rcs_updateRole;

