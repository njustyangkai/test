-- **********************************************************************
-- * SQL Name: irosmeasure.sql 
-- * Version: mysql
-- * 2014-12-10
-- * Author: lb
-- **********************************************************************


use zxinmeasure;

delete from measure_sysset where sysno in (2071, 2072);
delete from measure_typeset where sysno in (2071, 2072);
delete from measure_itemset where sysno in (2071, 2072);
delete from measure_paramset where sysno in (2071, 2072);
commit;

insert into measure_sysset(sysno, sysname, bvisible) values(2071, '物理机性能统计', 1);
insert into measure_sysset(sysno, sysname, bvisible) values(2072, '虚拟机性能统计', 1);
commit;



insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100701, 'CPU使用率', 'IROSHOST', 1, 'measure_hcpudata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100702, '内存使用情况', 'IROSHOST', 1, 'measure_hmemdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100703, '磁盘读取速率', 'IROSHOST', 1, 'measure_hdiskreaddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100704, '磁盘写入速率', 'IROSHOST', 1, 'measure_hdiskwritedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100705, '磁盘大小', 'IROSHOST', 1, 'measure_hdisksizedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100706, '磁盘已使用大小', 'IROSHOST', 1, 'measure_hdiskuseddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100709, '磁盘每秒读次数', 'IROSHOST', 1, 'measure_hdiskreadtimesdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100710, '磁盘每秒写次数', 'IROSHOST', 1, 'measure_hdiskwritetimesdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100711, '磁盘IO延迟', 'IROSHOST', 1, 'measure_hdiskiodelaydata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100707, '网络出口带宽', 'IROSHOST', 1, 'measure_hnicoutdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2071, 100708, '网络入口带宽', 'IROSHOST', 1, 'measure_hnicindata', 2, 1, 1);
commit;

insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100701, 1, 'CPU使用率', 'statcode1', 'measure_hcpudata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100702, 1, '内存使用情况', 'statcode1', 'measure_hmemdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100703, 1, '磁盘读取速率', 'statcode1', 'measure_hdiskreaddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100704, 1, '磁盘写入速率', 'statcode1', 'measure_hdiskwritedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100705, 1, '磁盘大小', 'statcode1', 'measure_hdisksizedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100706, 1, '磁盘已使用大小', 'statcode1', 'measure_hdiskuseddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100709, 1, '磁盘每秒读次数', 'statcode1', 'measure_hdiskreadtimesdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100710, 1, '磁盘每秒写次数', 'statcode1', 'measure_hdiskwritetimesdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100711, 1, '磁盘IO延迟', 'statcode1', 'measure_hdiskiodelaydata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100707, 1, '网络出口带宽', 'statcode1', 'measure_hnicoutdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2071, 100708, 1, '网络入口带宽', 'statcode1', 'measure_hnicindata', 3, 1);
commit;

insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100701, 1, 'CPU名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100701, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100702, 1, '内存名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100702, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100703, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100703, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100704, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100704, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100705, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100705, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100706, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100706, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100707, 1, '网卡名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100707, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100708, 1, '网卡名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100708, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100709, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100709, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100710, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100710, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100711, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2071, 100711, 2, 'DCID', 'param2', 0);
commit;
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100721, 'CPU使用率', 'IROSVM', 1, 'measure_vcpudata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100722, '内存使用情况', 'IROSVM', 1, 'measure_vmemdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100723, '磁盘读取速率', 'IROSVM', 1, 'measure_vdiskreaddata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100724, '磁盘写入速率', 'IROSVM', 1, 'measure_vdiskwritedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100725, '磁盘大小', 'IROSVM', 1, 'measure_vdisksizedata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100726, '网络出口带宽', 'IROSVM', 1, 'measure_vnicoutdata', 2, 1, 1);
insert into measure_typeset(sysno, typeno, typename, resourcetype, bvisible, tablename, paramcount, itemcount, monthlytable) values(2072, 100727, '网络入口带宽', 'IROSVM', 1, 'measure_vnicindata', 2, 1, 1);
commit;
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100721, 1, 'CPU使用率', 'statcode1', 'measure_vcpudata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100722, 1, '内存使用情况', 'statcode1', 'measure_vmemdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100723, 1, '磁盘读取速率', 'statcode1', 'measure_vdiskreaddata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100724, 1, '磁盘写入速率', 'statcode1', 'measure_vdiskwritedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100725, 1, '磁盘大小', 'statcode1', 'measure_vdisksizedata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100726, 1, '网络出口带宽', 'statcode1', 'measure_vnicoutdata', 3, 1);
insert into measure_itemset(sysno, typeno, itemno, itemname, fieldname, tablename, itemtype, bvisible) values(2072, 100727, 1, '网络入口带宽', 'statcode1', 'measure_vnicindata', 3, 1);
commit; 
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100721, 1, 'CPU名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100721, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100722, 1, '内存名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100722, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100723, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100723, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100724, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100724, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100725, 1, '磁盘名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100725, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100726, 1, '网卡名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100726, 2, 'DCID', 'param2', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100727, 1, '网卡名称', 'param1', 0);
insert into measure_paramset(sysno, typeno, paramno, paramname, fieldname, paramtype) values(2072, 100727, 2, 'DCID', 'param2', 0);
commit;

drop procedure if exists p_create_table;
DELIMITER &&
create procedure p_create_table(in tablename varchar(50))
BEGIN
    declare currentTableName VARCHAR(128);
    declare nextTableName VARCHAR(128);
		declare _currentmonth INT;
		declare _nextmonth INT;
		declare _addNum INT;
		declare vsql varchar(4000);

    SELECT MONTH(NOW()) INTO _currentmonth FROM DUAL;
		SELECT (YEAR(NOW()) % 2) * 12 INTO _addNum FROM DUAL;

		SET _nextmonth = _currentmonth + 1;

		SET _currentmonth = _currentmonth + _addNum;
		SET _nextmonth = _nextmonth + _addNum;
    IF _nextmonth > 24 THEN
       SET _nextmonth = 1;
    END IF;

    SET currentTableName = concat(tablename, right(concat('0', _currentmonth), 2));
    SET nextTableName = concat(tablename, right(concat('0', _nextmonth), 2));

	IF NOT EXISTS (SELECT TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA = 'zxinmeasure' and TABLE_NAME = currentTableName) THEN
		set vsql=concat('create table if not exists ',currentTableName,
		                     '(starttime      datetime not null,',
						     'endtime         datetime null,',
							 'resourcetype    varchar(255) not null,',
						     'resourceid      varchar(200) not null,',
						     'param1          varchar(200) null,',
						     'param2          varchar(200) null,',
							 'statcode1       float null)');
		
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;

		set vsql=concat('create index idx_starttime_',currentTableName,' on ',currentTableName,'(starttime)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_resourceid_',currentTableName,' on ',currentTableName,'(resourceid)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_param1_',currentTableName,' on ',currentTableName,'(param1)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_param2_',currentTableName,' on ',currentTableName,'(param2)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
	END IF;
	IF NOT EXISTS (SELECT TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA = 'zxinmeasure' and TABLE_NAME = nextTableName) THEN
		set vsql=concat('create table if not exists ',nextTableName,
		                     '(starttime      datetime not null,',
						     'endtime         datetime null,',
							 'resourcetype    varchar(255) not null,',
						     'resourceid      varchar(200) not null,',
						     'param1          varchar(200) null,',
						     'param2          varchar(200) null,',
							 'statcode1       float null)');
		
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;

		set vsql=concat('create index idx_starttime_',nextTableName,' on ',nextTableName,'(starttime)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_resourceid_',nextTableName,' on ',nextTableName,'(resourceid)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_param1_',nextTableName,' on ',nextTableName,'(param1)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_param2_',nextTableName,' on ',nextTableName,'(param2)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
	END IF;
END&& 
DELIMITER ; 
commit;

call p_create_table('measure_vcpudata');
call p_create_table('measure_vmemdata');
call p_create_table('measure_vdiskreaddata');
call p_create_table('measure_vdiskwritedata');
call p_create_table('measure_vdisksizedata');
call p_create_table('measure_vnicoutdata');
call p_create_table('measure_vnicindata');

call p_create_table('measure_hcpudata');
call p_create_table('measure_hmemdata');
call p_create_table('measure_hdiskreaddata');
call p_create_table('measure_hdiskwritedata');
call p_create_table('measure_hdisksizedata');
call p_create_table('measure_hdiskuseddata');
call p_create_table('measure_hdiskreadtimesdata');
call p_create_table('measure_hdiskwritetimesdata');
call p_create_table('measure_hdiskiodelaydata');
call p_create_table('measure_hnicoutdata');
call p_create_table('measure_hnicindata');


-- 建立业务侧统计项表

drop table if exists ros_ptypedef;
create table ros_ptypedef (
   res_type             varchar(100)                   not null,
   poid                 varchar(20)                    not null,
   poname               varchar(128)                   not null,
   tablename            varchar(32)                    not null,
   bvisible             tinyint                        not null,
   isrealtime           tinyint                        not null,
   extrastr             varchar(255)                   null,
   primary key (res_type, poid)
);


drop table if exists ros_pitemdef;
create table ros_pitemdef (
   dc_type              integer                        not null,
   poid                 varchar(20)                    not null,
   pitemid              integer                        not null,
   pitemname            varchar(128)                   not null,
   pitemfield           varchar(128)                   not null,
   pitemutil            varchar(32)                    not null,
   datatype             tinyint                        not null,
   bvisible             tinyint                        not null,
   extrastr             varchar(256)                   null,
   primary key (poid, pitemid)
);

drop table if exists ros_data_lasttime;
create table ros_data_lasttime (
   dc_id                varchar(100)                   not null,
   poid                 varchar(20)                    not null,
   pitemid              integer                        not null,
   lasttime             datetime                       null,
   primary key (dc_id, poid, pitemid)
);

-- iecs
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100821', '虚拟机CPU性能', 'data_vm_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100822', '虚拟机内存性能', 'data_vm_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100824', '虚拟机磁盘性能', 'data_vm_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '100826', '虚拟机网卡性能', 'data_vm_nic', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100801', '物理机CPU性能', 'data_host_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100802', '物理机内存性能', 'data_host_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100803', '物理机磁盘使用率', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100813', '物理机磁盘性能', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '100806', '物理机网卡性能', 'data_host_nic', 1, 0);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100821', 2, 'CPU使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100822', 2, '内存使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 2, '磁盘读取速率', '', 'MB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100824', 6, '磁盘写入速率', '', 'MB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 30, '网络出口带宽', '', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100826', 26, '网络入口带宽', '', 'KB/s', 2, 1);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100801', 2, 'CPU使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100802', 2, '内存使用情况', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100803', 2, '磁盘使用率', '', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 2, '磁盘每秒读次数', '', '', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 6, '磁盘每秒写次数', '', '', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 10, '磁盘读取速率', '', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 14, '磁盘写入速率', '', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100813', 18, '磁盘IO延迟', '', 'Ms', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 30, '端口流出速率', '', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(1, '100806', 26, '端口流入速率', '', 'KB/s', 2, 1);


-- openstack
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010001', '虚拟机CPU性能', 'data_vm_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010002', '虚拟机内存性能', 'data_vm_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010003', '虚拟机磁盘性能', 'data_vm_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1010004', '虚拟机网卡性能', 'data_vm_nic', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010005', '物理机CPU性能', 'data_host_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010006', '物理机内存性能', 'data_host_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010007', '物理机磁盘性能', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1010008', '物理机网卡性能', 'data_host_nic', 1, 0);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010001', 1, 'CPU使用率', 'cpu_util', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010002', 1, '内存使用情况', 'memory.usage', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 1, '磁盘读取速率', 'disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 2, '磁盘写入速率', 'disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010003', 3, '磁盘大小', 'disk.total.size', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 1, '网络出口带宽', 'network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010004', 2, '网络入口带宽', 'network.incoming.bytes.rate', 'B/s', 2, 1);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010005', 1, 'CPU使用率', 'compute.node.cpu.percent', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010006', 1, '内存使用情况', 'compute.node.memory.used', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 1, '磁盘读取速率', 'compute.node.disk.read.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 2, '磁盘写入速率', 'compute.node.disk.write.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 3, '磁盘大小', 'compute.node.disk.total', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010007', 4, '磁盘已使用大小', 'compute.node.disk.used', 'GB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 1, '网络出口带宽', 'compute.node.network.outgoing.bytes.rate', 'B/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(2, '1010008', 2, '网络入口带宽', 'compute.node.network.incoming.bytes.rate', 'B/s', 2, 1);

-- vmware
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020001', '虚拟机CPU性能', 'data_vm_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020002', '虚拟机内存性能', 'data_vm_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020003', '虚拟机磁盘性能', 'data_vm_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('vm', '1020004', '虚拟机网卡性能', 'data_vm_nic', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020005', '物理机CPU性能', 'data_host_cpu', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020006', '物理机内存性能', 'data_host_mem', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020007', '物理机磁盘性能', 'data_host_disk', 1, 0);
insert into ros_ptypedef(res_type, poid, poname, tablename, bvisible, isrealtime) values('host', '1020008', '物理机网卡性能', 'data_host_nic', 1, 0);

insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020001', 1, 'CPU使用率', '2', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020002', 1, '内存使用率', '24', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 1, '磁盘读取', '130', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020003', 2, '磁盘写入', '131', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 1, '网络出口带宽', '149', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020004', 2, '网络入口带宽', '148', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020005', 1, 'CPU使用率', '2', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020006', 1, '内存使用情况', '24', '%', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 1, '磁盘读取速率', '130', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020007', 2, '磁盘写入速率', '131', 'MB', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 1, '网络出口带宽', '149', 'KB/s', 2, 1);
insert into ros_pitemdef(dc_type, poid, pitemid, pitemname, pitemfield, pitemutil, datatype, bvisible) values(3, '1020008', 2, '网络入口带宽', '148', 'KB/s', 2, 1);

-- 将业务侧统计项与OMMP统计项关联

drop table if exists ros_ommp_rel;
create table ros_ommp_rel (
   dc_type          integer                   not null,
   poid             varchar(20)               not null,
   pitemid          integer                   not null,
   sysno            integer                   not null,
   typeno           integer                   not null,
   primary key (poid, pitemid, sysno, typeno)
);

-- IECS

-- VM
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100821', 2, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100822', 2, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100824', 2, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100824', 6, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100826', 30, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100826', 26, 2072, 100727);

-- HOST
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100801', 2, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100802', 2, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100803', 2, 2071, 100706);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 2, 2071, 100709);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 6, 2071, 100710);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 10, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 14, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100813', 18, 2071, 100711);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100806', 30, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '100806', 26, 2071, 100708);


-- OPENSTACK

-- VM
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010001', 1, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010002', 1, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 1, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 2, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010003', 3, 2072, 100725);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010004', 1, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010004', 2, 2072, 100727);

-- HOST
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010005', 1, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010006', 1, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 1, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 2, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 3, 2071, 100705);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010007', 4, 2071, 100706);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010008', 1, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(1, '1010008', 2, 2071, 100708);


-- VMWARE

-- VM

insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020001', 1, 2072, 100721);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020002', 1, 2072, 100722);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020003', 1, 2072, 100723);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020003', 2, 2072, 100724);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020004', 1, 2072, 100726);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020004', 2, 2072, 100727);

-- HOST
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020005', 1, 2071, 100701);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020006', 1, 2071, 100702);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020007', 1, 2071, 100703);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020007', 2, 2071, 100704);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020008', 1, 2071, 100707);
insert into ros_ommp_rel(dc_type, poid, pitemid, sysno, typeno) values(3, '1020008', 2, 2071, 100708);



DROP PROCEDURE
IF EXISTS proc_stat_regiontop5server;
DELIMITER &&


CREATE PROCEDURE proc_stat_regiontop5server (
	IN tName VARCHAR (64),
	IN tmpTName VARCHAR (64),
	IN poid VARCHAR (64),
	IN dcId VARCHAR (64),
	IN startTime VARCHAR (64),
	IN endTime VARCHAR (64),
	IN period INT
)
BEGIN
	DECLARE
		vsql text ;

	SET vsql = concat(
		'Create TEMPORARY table zxinmeasure.',
		tmpTName,
		'(select poly.resourceid, poly.param1, max(poly.starttime) as starttime, avg(poly.statcode1) as statcode1 from 
     (select resourceid, statcode1, param1, starttime from zxinmeasure.',
		tName,
		' where param2 = ',
		'''',dcId,'''',
		' and starttime >= ',
		'''',startTime,'''',
		'  and starttime <= ',
		'''',endTime,'''',
		')poly  group by resourceid, param1'
	) ;
    IF (period = 1) THEN
      SET vsql=concat(vsql,', TimeStampDiff(second,''2000-01-01 16:00:00'', starttime) DIV 3600');
    END IF;
    IF (period = 2) THEN
      SET vsql=concat(vsql,', TimeStampDiff(second,''2000-01-01 16:00:00'', starttime) DIV 86400');
    END IF;
    IF (period = 4) THEN
      SET vsql=concat(vsql,', TimeStampDiff(second,''2000-01-01 16:00:00'', starttime) DIV 300');
    END IF;
    SET vsql=concat(vsql,')');
	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

	SET vsql = concat(
		'Create TEMPORARY table zxinmeasure.',
		tmpTName,
		'_1',
		'(select p.resourceid, p.param1, max(p.starttime) maxtime from zxinmeasure.',
		tmpTName,
		' p group by p.resourceid, p.param1)'
	) ;
	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

	SET vsql = concat(
		'select a.resourceid, a.statcode1, a.param1 from  zxinmeasure.',
		tmpTName,
		' a, zxinmeasure.',
		tmpTName,
		'_1 b where a.resourceid = b.resourceid and a.starttime = b.maxtime '
	) ;

  IF (poid = '1010004' OR poid = '100826') THEN
    SET vsql=concat(vsql,' and a.param1 = b.param1 ');
  END IF;

  SET vsql=concat(vsql,' order by statcode1 desc limit 5 ');

	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

  SET vsql = concat(
		'DROP TEMPORARY TABLE IF EXISTS ',
		tmpTName
	) ;
	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

	SET vsql = concat(
		'DROP TEMPORARY TABLE IF EXISTS ',
		tmpTName,
		'_1'
	) ;
	SET @sql_txt = vsql ; PREPARE stmt FROM @sql_txt ; EXECUTE stmt ;

	END&& 
DELIMITER ; 


COMMIT;

DROP TABLE IF EXISTS ros_port_info;

CREATE TABLE ros_port_info (
	resource_id VARCHAR (128) NOT NULL,
	tenant_id VARCHAR (64) NOT NULL,
	port_id VARCHAR (64) NOT NULL,
	mac VARCHAR (64) NOT NULL,
	bandwidth INT NOT NULL
);

DROP TABLE IF EXISTS ros_bandwidth_utilization;

CREATE TABLE ros_bandwidth_utilization (
	dc_id VARCHAR (64) NOT NULL,
	resource_id VARCHAR (128) NOT NULL,
	tenant_id VARCHAR (64) NOT NULL,
	mac VARCHAR (64) NOT NULL,
	starttime VARCHAR (64) NOT NULL,
	utilization FLOAT NOT NULL
);

drop procedure if exists p_dynamic_create_table;
DELIMITER &&
create procedure p_dynamic_create_table(in vname varchar(50))
begin
	declare i int;
	declare mmdd varchar(4);
	declare tabname varchar(50);
	declare vsql varchar(4000);

	set i=24;
	while i>=1 do
		set mmdd=right(concat('0', i), 2);
		set tabname=concat(vname,mmdd);
		-- SET @sql_txt = concat('drop table if exists ', tabname); 
		-- PREPARE stmt FROM @sql_txt; 
		-- EXECUTE stmt;
		IF NOT EXISTS (SELECT TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA = 'zxinmeasure' and TABLE_NAME = tabname) THEN  
			set vsql=concat('create table ',tabname,
							 '(starttime      datetime not null,',
							 'endtime         datetime null,',
							 'resourcetype    varchar(255) not null,',
							 'resourceid      varchar(200) not null,',
							 'param1          varchar(200) null,',
							 'param2          varchar(200) null,',
							 'statcode1       float null)');
		
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt; 
		
			   
			set vsql=concat('create index idx_starttime_',tabname,' on ',tabname,'(starttime)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_resourceid_',tabname,' on ',tabname,'(resourceid)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_param1_',tabname,' on ',tabname,'(param1)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
			set vsql=concat('create index idx_param2_',tabname,' on ',tabname,'(param2)');
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt;
		END IF;	
		set i=i-1;
	end while;
end&& 
DELIMITER ; 
commit;