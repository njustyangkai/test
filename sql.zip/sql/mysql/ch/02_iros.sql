use zxinsys;

-- OMMP6.01.10U1脚本bug，后提供补丁包，为了便于安装和升级，将OMMP的补丁脚本放入iros的脚本中，仅适用于OMMP6.01.10U1
delete from portal_sysparam where param_name='FLOOTMSG';
insert into portal_sysparam(param_name,param_value, param_desc, paramgroup, description, field_type, max_value, min_value, visiblelevel) values('FLOOTMSG','','Add description at bottom of Home', 'System Configuration','Description information (such as: Contact: xxxx Phone: xxxx)', 2, 100, 0, 1);


-- 修改logo
update portal_sysparam set param_value = 'iROS' where param_name = 'LOGINMSG';

-- 不按ID合并菜单
-- update portal_sysparam set param_value = '0' where param_name = 'IsJoinMenuByID';

-- 修改首页
update portal_sysparam set param_value = '2' where param_name = 'IS_SET_HOMEPAGE';
update portal_sysparam set param_value = '/pages/irosopsm/pages/frame/rms-homepage.jsp' where param_name = 'HOMEPAGE_URL';
-- 隐藏左视图
update portal_sysparam set param_value = '2' where param_name = 'IS_NEED_HEADER_LEFT';

-- 去掉“资源”和“配置”两个菜单
delete from oper_funcgrp2 where funcgrpid in ( 2, 4, 12);
delete from oper_function where funcgrpid in ( 2, 4, 12);
delete from oper_grpdef where servicekey = 'uniportal';
insert into oper_grpdef select 1000,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal';
insert into oper_grpdef select 1001,funcgrpid,funcid,'uniportal' from oper_function   where servicekey='uniportal' and funcgrpid not in (2);

-- 删除性能、日志两个菜单
-- delete from oper_funcgrp2 where funcgrpid =1 and servicekey='uniportal';
-- delete from oper_funcgrp2 where funcgrpid =3 and servicekey='uniportal';
delete from oper_funcgrp2 where funcgrpid =10 and servicekey='uniportal';

-- delete from oper_function where funcgrpid=1 and servicekey='uniportal';
-- delete from oper_function where funcgrpid=3 and servicekey='uniportal';
delete from oper_function where funcgrpid=10 and servicekey='uniportal';

-- delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =1;
-- delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =3;
delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =10;

-- call proc_res_op_paratype(0 ,2, 101, '');		-- 去除【故障管理】操作日志统计类型
-- call proc_res_op_paratype(0 ,2, 102, '');		-- 去除【性能统计】操作日志统计类型
call proc_res_op_paratype(0 ,2, 103, '');		-- 去除【资源管理】操作日志统计类型
call proc_res_op_paratype(0 ,2, 105, '');		-- 去除【日志管理】操作日志统计类型

-- ***********************************************************************************************
-- *       Initialization Part                                                                   *
-- ***********************************************************************************************
-- use zxinsys
-- go
-- 执行 OMMP 创建角色和用户组
-- ***********************************************************************************************
-- *       Role and user group Initialization Part                                               *
-- ***********************************************************************************************

-- 增加新的角色：
-- proc_res_op_grpscript2 产品ID，修改标识(add-1,del-2)，角色标识，角色名称

call proc_res_op_grpscript2(0, 1, 102, '资源管理', '资源管理');
call proc_res_op_grpscript2(0, 1, 103, '组织管理', '组织管理');
call proc_res_op_grpscript2(0, 1, 104, 'VDC管理', 'VDC管理'); 
call proc_res_op_grpscript2(0, 1, 105, '工单管理', '工单管理'); 
call proc_res_op_grpscript2(0, 1, 106, '机房管理员', '机房管理员');
call proc_res_op_grpscript2(0, 1, 107, '机房工单管理员', '机房工单管理员');
call proc_res_op_grpscript2(0, 1, 108, '机房工单处理人', '机房工单处理人');
call proc_res_op_grpscript2(0, 1, 110, 'VDC审批员', 'VDC审批员');

-- 给新增加的角色增加相应的权限：


-- 资源管理：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 102, 11, 18102);
call proc_res_op_grpdef(0, 1, 102, 1396, 139615);
call proc_res_op_grpdef(0, 1, 102, 1396, 139620);
call proc_res_op_grpdef(0, 1, 102, 1396, 139604);

-- 组织管理：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 103, 11, 18102);
call proc_res_op_grpdef(0, 1, 103, 1396, 139602);

-- VDC管理：
-- proc_res_op_grpdef 产品ID， 修改标识(add-1,del-2)，角色id， 权限组id，权限id
call proc_res_op_grpdef(0, 1, 104, 1396, 139602);
call proc_res_op_grpdef(0, 1, 104, 1396, 139616);

-- 工单管理
call proc_res_op_grpdef(0, 1, 105, 1396, 139618);
call proc_res_op_grpdef(0, 1, 105, 11, 18102);
call proc_res_op_grpdef(0, 1, 105, 1396, 139610);

-- 机房管理员
call proc_res_op_grpdef(0, 1, 106, 11, 18102);
call proc_res_op_grpdef(0, 1, 106, 1396, 139640);
call proc_res_op_grpdef(0, 1, 106, 1396, 139610);
call proc_res_op_grpdef(0, 1, 106, 1396, 139605);

-- 机房工单管理员
call proc_res_op_grpdef(0, 1, 107, 11, 18102);
call proc_res_op_grpdef(0, 1, 107, 1396, 139610);
call proc_res_op_grpdef(0, 1, 107, 1396, 139618);

-- 机房工单处理人
call proc_res_op_grpdef(0, 1, 108, 11, 18102);
call proc_res_op_grpdef(0, 1, 108, 1396, 139610);
call proc_res_op_grpdef(0, 1, 108, 1396, 139618);

-- VDC审批员
call proc_res_op_grpdef(0, 1, 110, 11, 18102);
call proc_res_op_grpdef(0, 1, 110, 1396, 139610);
call proc_res_op_grpdef(0, 1, 110, 1396, 139643);

-- 创建四个角色对应的操作员组：
-- proc_res_op_v_grpdef 产品ID， 修改标识(add-1,del-2)，虚拟操作员组标识， 组描述

call proc_res_op_v_grpscript(0, 1, 6102, '资源管理员组');
call proc_res_op_v_grpscript(0, 1, 6103, '组织管理员组');
call proc_res_op_v_grpscript(0, 1, 6104, 'VDC管理员组');
call proc_res_op_v_grpscript(0, 1, 6122, '工单管理员组');
call proc_res_op_v_grpscript(0, 1, 6123, '工单操作员组');
call proc_res_op_v_grpscript(0, 1, 6124, '机房管理员组');
call proc_res_op_v_grpscript(0, 1, 6125, '机房工单管理员组');
call proc_res_op_v_grpscript(0, 1, 6126, '机房工单处理人组');

-- 新增操作组 VDC一级、二级审批员组
call proc_res_op_v_grpscript(0, 1, 6142, 'VDC一级审批员组');
call proc_res_op_v_grpscript(0, 1, 6143, 'VDC二级审批员组');

-- 给新增的操作员组赋予新的角色：
-- proc_res_op_v_grpdef 产品ID， 修改标识(add-1,del-2)，虚拟操作员组标识， 角色标识

call proc_res_op_v_grpdef(0, 1, 6102, 102);
call proc_res_op_v_grpdef(0, 1, 6103, 103);
call proc_res_op_v_grpdef(0, 1, 6104, 104);
call proc_res_op_v_grpdef(0, 1, 6122, 105);
call proc_res_op_v_grpdef(0, 1, 6123, 105);
call proc_res_op_v_grpdef(0, 1, 6124, 106);
call proc_res_op_v_grpdef(0, 1, 6125, 107);
call proc_res_op_v_grpdef(0, 1, 6126, 108);
call proc_res_op_v_grpdef(0, 1, 6142, 110);
call proc_res_op_v_grpdef(0, 1, 6143, 110);

-- 给初始化用户super所在的组赋予新增角色：
-- proc_res_op_v_grpdef 产品ID， 修改标识(add-1,del-2)，虚拟操作员组标识， 角色标识
call proc_res_op_v_grpdef(0,1,1000,102);
call proc_res_op_v_grpdef(0,1,1001,102);
call proc_res_op_v_grpdef(0,1,1000,103);
call proc_res_op_v_grpdef(0,1,1001,103);
call proc_res_op_v_grpdef(0,1,1000,104);
call proc_res_op_v_grpdef(0,1,1001,104);
call proc_res_op_v_grpdef(0,1,1000,105);
call proc_res_op_v_grpdef(0,1,1001,105);
call proc_res_op_v_grpdef(0,1,1000,106);
call proc_res_op_v_grpdef(0,1,1001,106);
call proc_res_op_v_grpdef(0,1,1000,107);
call proc_res_op_v_grpdef(0,1,1001,107);
call proc_res_op_v_grpdef(0,1,1000,108);
call proc_res_op_v_grpdef(0,1,1001,108);
call proc_res_op_v_grpdef(0,1,1000,110);
call proc_res_op_v_grpdef(0,1,1001,110);

delete from oper_rights2 where operid = 1 and servicekey = 'uniportal' and opergrpid = 6122;
insert into oper_rights2 (operid, servicekey, opergrpid) values(1, 'uniportal', 6122);
delete from oper_rights2 where operid = 1 and servicekey = 'uniportal' and opergrpid = 6123;
insert into oper_rights2 (operid, servicekey, opergrpid) values(1, 'uniportal', 6123);

delete from opergrp_homepage where v_opergrpid = 6122 and servicekey = 'uniportal' and homepage = '';
insert into opergrp_homepage (v_opergrpid, servicekey, homepage) values (6122, 'uniportal','');
delete from opergrp_homepage where v_opergrpid = 6123 and servicekey = 'uniportal' and homepage = '';
insert into opergrp_homepage (v_opergrpid, servicekey, homepage) values (6123, 'uniportal','');

-- 新增操作员:VDC一级审批员组和VDC二级审批员组下的操作员 level1/1 level2/2
delete from oper_information2 where operid in(3,4);
insert into oper_information2 (operid,opername,operpwd,operdescription,operallname ,creatorid,pwdhintday,pwdhintnum,initpwd,trait) 
    values  (3,'level1','!@#$%^SXrlgdxUjGmM9b4P8f/GaA==','VDC一级审批员','VDC一级审批员',1,0,5,' ','a');
insert into oper_information2 (operid,opername,operpwd,operdescription,operallname ,creatorid,pwdhintday,pwdhintnum,initpwd,trait) 
    values  (4,'level2','!@#$%^rdDNMAnl/Z1lM+gtF9zs6A==','VDC二级审批员','VDC二级审批员',1,0,5,' ','a');
	
delete from oper_rights2 where operid in(3,4);
insert into oper_rights2 (operid, servicekey,opergrpid,param1,param2,param3,param4) values(3,'uniportal',6142,0,0,-1,-1);
insert into oper_rights2 (operid, servicekey,opergrpid,param1,param2,param3,param4) values(4,'uniportal',6143,0,0,-1,-1);

call proc_res_op_funcgrp2(0 ,1, 1396, '云管理');
call proc_res_op_function(0, 1, 1396, 139602,'用户管理');
call proc_res_op_function(0, 1, 1396, 139603,'价格管理');
call proc_res_op_function(0, 1, 1396, 139604,'资源管理');
call proc_res_op_function(0, 1, 1396, 139610,'运营维护');
call proc_res_op_function(0, 1, 1396, 139606,'操作日志');
call proc_res_op_function(0, 1, 1396, 139612,'安全日志');
call proc_res_op_function(0, 1, 1396, 139613,'日志备份配置');
call proc_res_op_function(0, 1, 1396, 139607,'备份管理');
call proc_res_op_function(0, 1, 1396, 139608,'告警地址配置');
call proc_res_op_function(0, 1, 1396, 139618,'工单管理');
call proc_res_op_function(0, 1, 1396, 139615,'模板管理');
call proc_res_op_function(0, 1, 1396, 139616,'实例化管理');
call proc_res_op_function(0, 1, 1396, 139619,'功能控制');
call proc_res_op_function(0, 1, 1396, 139624,'日志收集');
call proc_res_op_function(0, 1, 1396, 139620,'设备监控');
call proc_res_op_function(0, 1, 1396, 139640,'机房管理');
call proc_res_op_function(0, 1, 1396, 139642,'License管理');
call proc_res_op_function(0, 1, 1396, 139644,'杀毒');
call proc_res_op_function(0, 1, 1396, 139645,'系统调查');
call proc_res_op_function(0, 1, 1396, 139646,'高级');

update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139615 and servicekey='uniportal';
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139616 and servicekey='uniportal';

-- 字段说明：field_type  --节点类型  1-数字 2-字符串 3-ip 4-下拉框 5-密码 6-邮件 7-URL 
delete from portal_sysparam where param_name = 'default_admin_rolename';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('default_admin_rolename','admin','默认管理角色名称','iROS','默认管理角色名称',
             2,100,0,'',1,
             '','','','','');

delete from portal_sysparam where param_name = 'default_member_rolename';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('default_member_rolename','_member_','默认成员角色名称','iROS','默认成员角色名称',
             2,100,0,'',1,
             '','','','','');

delete from portal_sysparam where param_name = 'admin_portal_ftp_username';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('admin_portal_ftp_username','root','管理门户服务器SFTP用户名','iROS','管理门户服务器SFTP用户名',
             2,100,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'admin_portal_ftp_password';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('admin_portal_ftp_password','!@#$%^CHLGT/zyq2aAWUc1bEeChQ==','管理门户服务器SFTP密码','iROS','管理门户服务器SFTP密码',
             5,100,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'admin_portal_ftp_port';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('admin_portal_ftp_port','22','管理门户服务器SFTP端口','iROS','管理门户服务器SFTP端口',
             2,100,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'remote_syn_user';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_syn_user','','4A同步用户信息调用地址','iROS','4A同步用户信息调用地址',
             2,100,0,' ',1,
             '','','','','');
delete from portal_sysparam where param_name = 'remote_idcim_host';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_idcim_host','','获取物理主机列表调用地址','iROS','获取物理主机列表调用地址',
             2,100,0,' ',1,
             '','','','','');			 
			 			 
delete from portal_sysparam where param_name = 'iros_backup_shell_path';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_backup_shell_path','/home/iros/db_bak','备份shell脚本放置路径','iROS','备份shell脚本放置路径',
             2,100,0,'/home/iros/db_bak',0,
             '','','','','');

delete from portal_sysparam where param_name = 'volume_upper_limit';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('volume_upper_limit','500','云硬盘大小上限(GB)','iROS','云硬盘大小上限(GB)',
             2,100,0,' ',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'om_support_hr';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('om_support_hr', '0', '是否支持hr鉴权', 'iROS', '是否支持hr鉴权', 
			4, null, null, '1-支持,0-不支持', 1, 
			'', '', '', '', '');
			
delete from portal_sysparam where param_name = 'hr_server_url';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('hr_server_url', 'http://tech.zte.com.cn/tech/xmlrpc', 'hr鉴权url', 'iROS', 'hr鉴权url', 
			2, 100, 0, '', 0, 
			'', '', '', '', '');
delete from portal_sysparam where param_name = 'BAK_TASK_DAY';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('BAK_TASK_DAY','1','管理数据备份天','平台系统配置','备份的天，当备份周期为日时，请输入1-7中任一数字，1代表星期一，7代表星期日，当大于7则认为周日备份；当备份周期为月，请输入1-31中任一数字,1代表1号，31代表31号',
             1,31,1,'1',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'eazy_cloud_ip';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_ip','','易云数据同步IP地址','iROS','易云数据同步IP地址',
             2,1000,0,'',1,
             '','','','','');

delete from portal_sysparam where param_name = 'eazy_cloud_port';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_port','','易云数据同步端口号','iROS','易云数据同步端口号',
             2,1000,0,'',1,
             '','','','','');

delete from portal_sysparam where param_name = 'eazy_cloud_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_control','0','易云控制开关','iROS','易云控制开关',
             4,1000,1,'0-关闭, 1-开启',1,
             '','','','','');	
delete from portal_sysparam where param_name = 'log_collect_upper_limit';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('log_collect_upper_limit','300','日志一键收集文件个数上限(个)','iROS','日志一键收集文件个数上限(个)',
             2,300,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'compute_threshold';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('compute_threshold', '0', '是否支持服务器阈值设置', 'iROS', '服务器阈值设置开关', 
			4, null, null, '1-支持,0-不支持', 0, 
			'', '', '', '', '');
			
delete from portal_sysparam where param_name = 'idcim_switch_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_switch_control','0','IDCIM融合控制开关','iROS','IDCIM融合控制开关',
             4,1000,1,'0-关闭, 1-开启',1,
             '','','','','');
     
delete from portal_sysparam where param_name = 'idcim_restful_url';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_restful_url','http://127.0.0.1:21180','IDCIM Restful 普通请求URL','iROS','IDCIM Restful 普通请求URL',
             2,1000,0,'',1,
             '','','','','');


delete from portal_sysparam where param_name = 'res_tree_root_title';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('res_tree_root_title','计算中心','资源树根节点标签名称','iROS','资源树根节点标签名称',
             2,100,0,' ',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'org_tree_root_title';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('org_tree_root_title','组织中心','组织树根节点标签名称','iROS','组织树根节点标签名称',
             2,100,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'ade_path';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('ade_path','','ADE接口地址','iROS','ADE接口地址',
             2,1000,0,'',1,
             '','','','','');	

delete from portal_sysparam where param_name = 'cmdb_switch_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('cmdb_switch_control','0','CMDB控制开关','iROS','CMDB控制开关',
             4,1000,1,'0-关闭, 1-开启',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'corePoolSize';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('corePoolSize','100','核心池大小','iROS','核心池大小',
             2,1000,0,'',0,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'keepAliveTime';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('keepAliveTime','3','空闲线程保留时长','iROS','空闲线程保留时长，单位：秒',
             2,100,0,'',0,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'keepMonths';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('keepMonths','6','性能数据保留时长','iROS','性能数据保留时长，单位：月',
             2,100,0,'',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'maximumPoolSize';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('maximumPoolSize','200','线程池最大线程数','iROS','线程池最大线程数',
             2,100,0,'',0,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'workQueueSize';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('workQueueSize','200','工作队列最大线程数','iROS','工作队列最大线程数',
             2,100,0,'',0,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'bandwidthUtilizationKeepMonths';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('bandwidthUtilizationKeepMonths','6','带宽利用率统计数据保留时长','iROS','带宽利用率统计数据保留时长，单位：月',
             2,100,0,'',1,
             '','','','','');
             
delete from portal_sysparam where param_name = 'iros_overdue_res_email_tip_days';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_overdue_res_email_tip_days','7','资源超期提醒提前天数','iROS','资源超期提醒提前天数，单位：天',
             2,100,0,'',1,
             '','','','','');
             
delete from portal_sysparam where param_name = 'iros_overdue_res_close';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('iros_overdue_res_close', '0', '资源超期后是否关闭资源', 'iROS', '资源超期后是否关闭资源', 
			4, null, null, '1-关闭, 0-不关闭', 1, 
			'', '', '', '', '');
	
delete from portal_sysparam where param_name = 'image_delete_interval';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('image_delete_interval','180','删除下载镜像任务默认比较时间','iROS','删除下载镜像任务默认比较时间，单位：分钟',
             2,100,0,'',0,
             '','','','','');
			 
use iros;

drop table if exists iros_version_info;
CREATE TABLE iros_version_info ( 
	name						varchar(100) 	NOT NULL,-- 名称
	version				        varchar(200) 	NULL,-- 版本
	extra						varchar(500) 	NULL
);
insert into iros_version_info (name, version, extra) values('iROS', 'ZXCLOUD-iROSV4.04.06T04', '');
insert into iros_version_info (name, version, extra) values('OMMP', 'ZXCLOUD-OMMPV6.01.13', '');

drop table if exists om_control_function;
CREATE TABLE om_control_function ( 
	id      varchar(64) NOT NULL,
	name    varchar(64) NULL,
	control varchar(200) NULL,  
	primary key (id)
);
insert into om_control_function values ('order_switch_control', '订单开关','1'); -- 0、关闭1、开启
insert into om_control_function values ('ticket_switch_control','工单开关', '1'); -- 0、关闭1、开启
insert into om_control_function values ('iros_ticket_attachment_path', '工单附件存放路径','/home/zxin10/was/tomcat/webapps/workorder/attachment');
insert into om_control_function values ('ade_switch_control','ADE开关', '0'); -- 0、关闭1、开启
insert into om_control_function values ('ade_path','ADE接口地址', 'http://10.129.172.20:8103/ade');
insert into om_control_function values ('charge_switch_control', '计费开关','0'); -- 0、关闭1、开启
insert into om_control_function values ('charge_system', '计费系统','0'); -- 0、其他1、绛门
insert into om_control_function values ('jm_url_path', '绛门接口地址','http://127.0.0.1:8780/csm');
insert into om_control_function values ('charge_mail_control','余额不足邮件提醒开关', '0'); -- 0、关闭1、开启
insert into om_control_function values ('charge_tip_day','余额不足提醒', '3');
insert into om_control_function values ('resource_close_day','欠费后资源预留天数', '10');
insert into om_control_function values ('drs_switch_control','DRS开关', '0'); -- 0、关闭 1、开启
insert into om_control_function values ('nubosh_switch_control', '云安全开关','1');
insert into om_control_function values ('antivurs_url', '杀毒服务URL','https://127.0.0.1:8443');
insert into om_control_function values ('antivurs_user', '杀毒服务用户名','extapiuser');
insert into om_control_function values ('antivurs_password', '杀毒服务密码','vMsec#1.');
insert into om_control_function values ('antivurs_sso_aes_password', '安贤单点登录AES秘钥','ZTE&nubosh#T0en');
insert into om_control_function values ('phydevice_switch_control', '资产管理开关','0'); -- 0、关闭1、开启
insert into om_control_function values ('evaluate_switch_control','系统和服务评价开关', '0'); -- 0、关闭1、开启
insert into om_control_function values ('evaluate_period','调研时间', '');
insert into om_control_function values ('vdc_user_register_control','vdc用户注册开关', '0'); -- 0、关闭 1、开启
drop table if exists os_name_config;
create table os_name_config 
( 
	os_id        			varchar(100) 		not null,		
	os_type        			varchar(20) 		not null,		
	os_name        			varchar(100) 		not null,		
    primary key(os_id)
);

insert into os_name_config(os_id, os_type, os_name) values('1','Windows','Microsoft Windows 7(32)');
insert into os_name_config(os_id, os_type, os_name) values('2','Windows','Microsoft Windows 7(64)');
insert into os_name_config(os_id, os_type, os_name) values('3','Windows','Microsoft Windows Server 2003,Enterprise Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('4','Windows','Microsoft Windows Server 2003,Enterprise Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('5','Windows','Microsoft Windows Server 2003,Datacenter Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('6','Windows','Microsoft Windows Server 2003,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('7','Windows','Microsoft Windows Server 2003,Standard Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('8','Windows','Microsoft Windows Server 2003,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('9','Windows','Microsoft Windows Server 2003,Web Edition');
insert into os_name_config(os_id, os_type, os_name) values('10','Windows','Microsoft Windows XP Professional(32)');
insert into os_name_config(os_id, os_type, os_name) values('11','Windows','Microsoft Windows XP Professional(64)');
insert into os_name_config(os_id, os_type, os_name) values('12','Linux','Suse Linux Enterprise 11(32)');
insert into os_name_config(os_id, os_type, os_name) values('13','Linux','Suse Linux Enterprise 11(64)');
insert into os_name_config(os_id, os_type, os_name) values('14','Linux','Suse Linux Enterprise 10(32)');
insert into os_name_config(os_id, os_type, os_name) values('15','Linux','Suse Linux Enterprise 10(64)');
insert into os_name_config(os_id, os_type, os_name) values('16','Linux','Carrier Grade SERVER Linux 3(32)');
insert into os_name_config(os_id, os_type, os_name) values('17','Linux','Carrier Grade SERVER Linux 3(64)');
insert into os_name_config(os_id, os_type, os_name) values('18','Linux','Carrier Grade SERVER Linux 4(32)');
insert into os_name_config(os_id, os_type, os_name) values('19','Linux','Carrier Grade SERVER Linux 4(64)');
insert into os_name_config(os_id, os_type, os_name) values('20','Linux','Red Hat Enterprise Linux 5.5(64)');
insert into os_name_config(os_id, os_type, os_name) values('21','Linux','Red Hat Enterprise Linux 5.5(32)');
insert into os_name_config(os_id, os_type, os_name) values('22','Linux','CentOS Linux 5.6(64)');
insert into os_name_config(os_id, os_type, os_name) values('23','Linux','CentOS Linux 5.6(32)');
insert into os_name_config(os_id, os_type, os_name) values('24','Linux','Other Linux');
insert into os_name_config(os_id, os_type, os_name) values('25','Windows','Other Windows');
insert into os_name_config(os_id, os_type, os_name) values('26','Windows','Microsoft Windows Server 2008,Enterprise Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('27','Windows','Microsoft Windows Server 2008,Enterprise Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('28','Windows','Microsoft Windows Server 2008,Datacenter Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('29','Windows','Microsoft Windows Server 2008,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('30','Windows','Microsoft Windows Server 2008,Standard Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('31','Windows','Microsoft Windows Server 2008,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('32','Linux','Red Hat Enterprise Linux 6(64)');
insert into os_name_config(os_id, os_type, os_name) values('33','Linux','Red Hat Enterprise Linux 6(32)');
insert into os_name_config(os_id, os_type, os_name) values('34','Linux','CentOS Linux 6(64)');
insert into os_name_config(os_id, os_type, os_name) values('35','Linux','CentOS Linux 6(32)');
insert into os_name_config(os_id, os_type, os_name) values('36','Windows','Microsoft Windows Server 2012,Enterprise Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('37','Linux','CentOS Linux 6.5(64)');
insert into os_name_config(os_id, os_type, os_name) values('38','Linux','CentOS Linux 6.5(32)');
insert into os_name_config(os_id, os_type, os_name) values('39','Windows','Microsoft Windows Server 2012,Foundation Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('40','Linux','Ubuntu 12.04(64)');
insert into os_name_config(os_id, os_type, os_name) values('41','Linux','Ubuntu 12.04(32)');
insert into os_name_config(os_id, os_type, os_name) values('42','Linux','Red Hat Enterprise Linux 5.8(64)');
insert into os_name_config(os_id, os_type, os_name) values('43','Linux','Red Hat Enterprise Linux 5.8(32)');
insert into os_name_config(os_id, os_type, os_name) values('44','Linux','CentOS Linux 6.4(64)');
insert into os_name_config(os_id, os_type, os_name) values('45','Linux','CentOS Linux 6.4(32)');
insert into os_name_config(os_id, os_type, os_name) values('46','Linux','Carrier Grade SERVER Linux 5(32)');
insert into os_name_config(os_id, os_type, os_name) values('47','Linux','Carrier Grade SERVER Linux 5(64)');
insert into os_name_config(os_id, os_type, os_name) values('48','Linux','CentOS Linux 7.0(64)');
insert into os_name_config(os_id, os_type, os_name) values('49','Linux','Red Hat Enterprise Linux 6.5(64)');
insert into os_name_config(os_id, os_type, os_name) values('50','Linux','Red Hat Enterprise Linux 6.5(32)');
insert into os_name_config(os_id, os_type, os_name) values('51','Linux','Red Hat Enterprise Linux 7.0(64)');
insert into os_name_config(os_id, os_type, os_name) values('52','Windows','Microsoft Windows 8(32)');
insert into os_name_config(os_id, os_type, os_name) values('53','Windows','Microsoft Windows 8(64)');
insert into os_name_config(os_id, os_type, os_name) values('54','Windows','Microsoft Windows 8.1(32)');
insert into os_name_config(os_id, os_type, os_name) values('55','Windows','Microsoft Windows 8.1(64)');
insert into os_name_config(os_id, os_type, os_name) values('56','Linux','Ubuntu 14.04 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('57','Linux','CentOS Linux 6.3 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('58','Linux','CentOS Linux 6.4 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('59','Linux','CentOS Linux 6.5 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('60','Linux','CentOS Linux 4(64)');
insert into os_name_config(os_id, os_type, os_name) values('61','Linux','CentOS Linux 4(32)');
insert into os_name_config(os_id, os_type, os_name) values('62','Linux','CentOS Linux 5(64)');
insert into os_name_config(os_id, os_type, os_name) values('63','Linux','CentOS Linux 5(32)');
insert into os_name_config(os_id, os_type, os_name) values('64','Linux','NewStart Destop Linux Office Editon(64)');
insert into os_name_config(os_id, os_type, os_name) values('65','Linux','Red Hat Enterprise Linux 5.8 Enterprise Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('66','Linux','Red Hat Enterprise Linux 6.3 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('67','Linux','Red Hat Enterprise Linux 5(64)');
insert into os_name_config(os_id, os_type, os_name) values('68','Linux','Red Hat Enterprise Linux 5(32)');
insert into os_name_config(os_id, os_type, os_name) values('69','Linux','Red Hat Enterprise Linux 4(64)');
insert into os_name_config(os_id, os_type, os_name) values('70','Linux','Red Hat Enterprise Linux 4(32)');
insert into os_name_config(os_id, os_type, os_name) values('71','Linux','Suse Linux Enterprise 12(32)');
insert into os_name_config(os_id, os_type, os_name) values('72','Linux','Suse Linux Enterprise 12(64)');
insert into os_name_config(os_id, os_type, os_name) values('73','Windows','Microsoft Windows 10(32)');
insert into os_name_config(os_id, os_type, os_name) values('74','Windows','Microsoft Windows 10(64)');
insert into os_name_config(os_id, os_type, os_name) values('75','Windows','Microsoft Windows Server 2008 R2,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('76','Windows','Microsoft Windows Server 2008 R2,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('77','Windows','Microsoft Windows Server 2012 R2,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('78','Windows','Microsoft Windows Server 2012 R2,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('79','Windows','Microsoft Windows Server 2012,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('80','Windows','Microsoft Windows Server 2012,Standard Edition(64)');


drop table if exists resource_price;
CREATE TABLE resource_price (
	name        			varchar(100) 		not null,	
	groups        			int         		not null, -- 1.虚拟资源 2.物理资源 3.网络资源 4.物理机os
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance 11.iecs os 12.physical 13.network bandwidth
    unit                    varchar(50)         not null,
	sub_type                varchar(100)        null,
	price  			        numeric(20, 5) 		not null,
	description             varchar(100)        null   
);

insert into resource_price (name, groups, type, unit, description, price) values ('CPU', 1, 2, '元/核', '1核单位时间价格', 0.05);
insert into resource_price (name, groups, type, unit, description, price) values ('内存', 1, 3, '元/GB', '1GB单位时间价格', 0.05);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('AIX系统盘', 1, 4, '元/GB', 'AIX', 'AIX系统盘每GB单位时间价格', 0.002);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Linux系统盘', 1, 4, '元/GB', 'Linux', 'Linux系统盘每GB单位时间价格', 0.001);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Windows系统盘', 1, 4, '元/GB', 'Windows', 'Windows系统盘每GB单位时间价格', 0.002);
insert into resource_price (name, groups, type, unit, description, price) values ('卷', 1, 7, '元/GB', '1GB单位时间价格', 0.0006);
insert into resource_price (name, groups, type, unit, description, price) values ('私有镜像', 1, 8, '元/GB', '1GB单位时间价格', 0.0006);
insert into resource_price (name, groups, type, unit, description, price) values ('公网IP', 3, 5, '元/个', '1个公网IP单位时间价格', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('路由器', 3, 6, '元/个', '1个路由单位时间价格', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('防火墙', 3, 9, '元/套', '1套单位时间价格', 0.1);
insert into resource_price (name, groups, type, unit, description, price) values ('负载均衡', 3, 10, '元/套', '1套单位时间价格', 0.1);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽', 3, 13, '元/Mbps', 'up',  '1Mbps上行带宽单位时间价格', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽', 3, 13, '元/Mbps', 'down',  '1Mbps下行带宽单位时间价格', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('上行带宽无限制', 3, 13, '元', 'unlimit up',  '上行带宽无限制单位时间价格', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('下行带宽无限制', 3, 13, '元',  'unlimit down', '下行带宽无限制单位时间价格', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('1U', 5, 14, '元/时',  'Rack-0', '', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('2U', 5, 14, '元/时',  'Rack-1', '', 0.04);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('4U', 5, 14, '元/时',  'Rack-2', '', 0.08);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('8U', 5, 14, '元/时',  'Rack-3', '', 0.16);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('16U', 5, 14, '元/时',  'Rack-4', '', 0.32);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('32U', 5, 14, '元/时',  'Rack-5', '', 0.64);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('64U', 5, 14, '元/时',  'Rack-6', '', 1.28);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('带宽', 5, 15, '元/Mbps',  '', '每M单位时间价格', 2);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('互联网IP', 5, 16, '元/个',  '', '一个互联网IP单位时间价格', 2);

drop table if exists resource_cost;
CREATE TABLE resource_cost (
	vdc_id   	            int                 not null,
	tenant_id               varchar(100)        not null,
	dc_id                   varchar(100)        not null,
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
	year                    int                 not null,
	month                   int                 not null,
	cost  			        numeric(20, 5) 		not null,
    resource_number         int                 not null,
	date  			        varchar(20) 		not null   
);
create index idx_resource_cost on resource_cost(vdc_id, tenant_id, dc_id, type, date);

drop table if exists t_task;
create table t_task
(
    id               varchar(64)   not null,
    dc_id            varchar(64)   not null,
    vdc_id           int           not null,
    tenant_id        varchar(100)  not null,
    resource_name    varchar(100)  not null,
    resource_id      varchar(100)  not null,
    resource_type    int           not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
    task_type        int           not null, -- 1.add 2.update 3.delete  
    status           int           not null, -- 1.begin 2.end 3.error    
    start_time       datetime      not null,
    end_time         datetime      null,
    operator         varchar(100)  null,
	operator_ip		 varchar(100)  null,
    description      text          null,
    primary key (id)
);

-- 业务组表
drop table if exists om_business_grp;
create table om_business_grp (
   id                     varchar(40)          not null,   -- 业务组ID
   name                   varchar(100)         not null,   -- 业务组名称
   description            varchar(300)         not null,   -- 业务组描述
   image_id               varchar(40)          not null,   -- 业务组镜像ID
   flavor_id              varchar(40)          not null,   -- 业务组规格ID
   network_id             varchar(40)          not null,   -- 业务组网络ID
   primary key (id)
);

-- 业务组和虚机关系表
drop table if exists om_busigrp_instance;
create table om_busigrp_instance (
   busigrp_id             varchar(40)          not null,   -- 业务组ID
   instance_id            varchar(40)          not null,   -- 虚机ID
   primary key (busigrp_id, instance_id)
);

-- 策略表
drop table if exists om_strategy;
create table om_strategy (
   id                     varchar(40)          not null,   -- 策略ID
   name                   varchar(100)         not null,   -- 策略名称
   description            varchar(300)         not null,   -- 策略描述
   cpu_rel                int                  not null,   -- CPU条件，0: <=, 1: >=, 2: =
   cpu_rel_val            int                  not null,   -- CPU条件, 10-100，代表10% - 100%
   mem_rel                int                  not null,   -- 内存条件，0: <=, 1: >=, 2: =
   mem_rel_val            int                  not null,   -- 内存条件, 10-100，代表10% - 100%
   cpu_mem_rel            int                  not null,   -- CPU条件和内存条件逻辑关系，0: AND, 1: OR
   duration               int                  not null,   -- 间隔时间，单位分钟
   times                  int                  not null,   -- 连续次数
   action_type            int                  not null,   -- 动作类型，0: 扩容，1: 减容
   cool_time              int                  not null,   -- 冷却时间，单位分钟
   priority               text                 not null,   -- 优先级
   create_time            datetime             not null,   -- 策略创建时间
   cool_status            int     default 0    not null,   -- 0不冷却 1冷却 
   last_result            tinyint              null,
   last_time              datetime             null,
   next_time              datetime             null, 
   count_num              int     default 0    null,-- 连续几个粒度当量超过阀值再调度
   busigrp_id             varchar(40)          not null,   -- 业务组ID
   primary key (id)
);

-- 策略执行表
drop table if exists om_strategy_exec;
create table om_strategy_exec (
  id                     varchar(40)           not null,   -- ID
  strategy_id	         int                   not null,     -- 策略编号 
  server_ip              varchar(100)          null,     -- 被调度服务器的IP
  server_id              varchar(100)          null,     -- 被调度的服务器的ID
  status                 tinyint               not null,     -- 状态 0 完成 1 执行中
  start_time	         datetime              not null,     -- 执行开始时间
  end_time	             datetime              null,     -- 执行结束时间
  result	             tinyint               null,     -- 执行结果：0-新建 1-成功 2-失败 3-跳过
  info	                 varchar(200)          null,     -- 描述,失败原因等
  primary key (id)
);

drop table if exists common_identity;
CREATE TABLE common_identity ( 
	tablename						varchar(50) 	NOT NULL,
	idvalue						int 	NULL,		
    PRIMARY KEY(tablename)
);

drop table if exists t_dc;
CREATE TABLE t_dc ( 
	dc_id							varchar(100) 	NOT NULL,
	dc_name							varchar(100) 	NOT NULL,
    dc_desc							varchar(999) 	NULL,
	common_url						varchar(100)	NULL,
	admin_url						varchar(100)	NULL,
	vmware_datacenter				varchar(100)	NULL,
	power_domainid					varchar(100)	NULL,
	power_projectname				varchar(100)	NULL,
	power_ip						varchar(64)		NULL,
	admin_username					varchar(100)	NULL,
	admin_password					varchar(100)	NULL,
	domain_id						varchar(100)	NOT NULL,
	dc_type							int				NOT NULL,
	status							int				NOT NULL,	
	extra							text	NULL,
    PRIMARY KEY(dc_id)
);


drop table if exists om_irai_quota;
CREATE TABLE om_irai_quota ( 
	id						varchar(64)				not null, 	-- id
	create_date				datetime				not null, 	-- 创建时间
	update_date				datetime				not null, 	-- 更新时间
	dc_id					varchar(64)				not null, 	-- dc_id
	dc_type					int						not null,	-- dc类型，3是vmware，4是power，
	tenant_id				varchar(64)				not null, 	-- 租户id
	vdc_id					numeric					not null,
	resource_id				varchar(64)				not null,	-- 配额id
	resource				varchar(100)			not null,	-- 配额名称
	in_use					numeric					default 0		not null, 	-- 已使用
	hard_limit				numeric					not null, 	-- 上限
	PRIMARY KEY(id)
);

drop table if exists om_user_info;
CREATE TABLE om_user_info ( 
	vdcid   	int NOT NULL,
	username	varchar(100) NOT NULL,
	password	varchar(128) NOT NULL,
	email   	varchar(100) NULL,
	userid  	int 		 NOT NULL,
	phone   	varchar(64)  NULL,
	orgid		varchar(64)  NULL,
	type		int 		 NULL,
	status		int 		 NULL,
	description	text,
	opinion		text,
	extra		varchar(1024) NULL,
	createdtime	datetime 		NULL,
	auditedtime	datetime 		NULL,
	PRIMARY KEY(userid)
);

drop table if exists om_user_dc_rel;
CREATE TABLE om_user_dc_rel ( 
	userid  			int NULL,
	dcid				varchar(100) NOT NULL,
	zoneid				varchar(100) NOT NULL,
	computenodeid   	varchar(100) NULL
);

drop table if exists om_vdc;
CREATE TABLE om_vdc ( 
	vdcid   	numeric NOT NULL,
	vdcname 	varchar(64) NOT NULL,
	vdcdesc 	varchar(256) NULL,
	domainid	varchar(100) DEFAULT 0 NOT NULL,
	tenantid	varchar(64) NULL 
);

drop table if exists om_vdc_dc_rel;
CREATE TABLE om_vdc_dc_rel ( 
	vdcid        	numeric NOT NULL,
	dcid         	varchar(100) NOT NULL,
	projectid    	varchar(100) NOT NULL
);

drop table if exists om_vdc_admin_rel;
CREATE TABLE om_vdc_admin_rel ( 
	vdcid        	numeric NOT NULL,
	dcid         	varchar(100) NOT NULL,
	adminuserid  	varchar(100) NOT NULL,
	ommpuserid   	numeric NULL
);

drop table if exists om_vdc_computenode_rel;
CREATE TABLE om_vdc_computenode_rel ( 
	vdcid        	numeric NULL,
	dcid         	varchar(100) NULL,
	zoneid       	varchar(100) NULL,
	computenodeid	varchar(100) NULL 
);


drop table if exists om_service_config;
CREATE TABLE om_service_config (
   id                     varchar(40)          not null,   
   name                   varchar(100)         not null,   
   admin_url              varchar(200)         not null,   
   public_url             varchar(200)         not null,   
   internal_url           varchar(200)         not null,   
   description            varchar(300)         null, 
   service_type           varchar(100)         not null,   
   extra				  text	       null,   
   PRIMARY KEY(id)
);

use zxinsys;
call proc_res_op_paratype(0, 1, 3961, '云管理');

use iros;
drop table if exists om_res_template;
CREATE TABLE om_res_template
(
   id                   varchar(64) not null,
   dcid                 varchar(64) not null,
   name                 varchar(200) null,
   flavorid            varchar(64) null,
   imageid              varchar(64) null,
   status               varchar(10) null,
   description          varchar(400) null,
   PRIMARY KEY(id)
);

drop table if exists om_vm_info_task ;
CREATE TABLE om_vm_info_task ( 
	id							varchar(64) 	NOT NULL,   -- ID
	dc_id						varchar(64) 	NULL,   -- dcID
	dc_name						varchar(100) 	NULL,   -- dc名称
	dc_type						varchar(2) 		NULL,   -- dc类型
	domain_id					varchar(64) 	NULL,   -- domain ID
	domain_name					varchar(100) 	NULL,   -- domain name
	zone_name					varchar(100) 	NULL,   -- 集群名称
	host_name					varchar(100) 	NULL,   -- 主机名称
	name						varchar(100) 	NULL,   -- 虚机名称
	created						varchar(32) 	NULL,   -- 创建时间
	user_id						varchar(100) 	NULL,   -- 用户id
	user_name					varchar(100) 	NULL,   -- 用户名称
	tenant_id					varchar(100) 	NULL,   -- 租户id
	tenant_name					varchar(100) 	NULL,   -- 租户名称
	image_id					varchar(100) 	NULL,   -- 镜像id
	image_name					varchar(100) 	NULL,   -- 镜像名称
	addresses					varchar(100) 	NULL,   -- mac地址
	flavor_id					varchar(200) 	NULL,   -- 规格id
	flavor_info					varchar(200) 	NULL,   -- 规格
	ip_info						varchar(1000) 	NULL,   -- IP
	task_state					varchar(100) 	NULL,   -- 当前任务
	power_state					varchar(2) 		NULL,   -- 电源状态
	vm_state					varchar(100) 	NULL,   -- 虚机状态
	servergroup_info			varchar(100) 	NULL,   -- 云主机组
	is_volume_attached			varchar(64) 	NULL,   
	
    PRIMARY KEY(id)
);


drop table if exists om_dc_info_task ;
CREATE TABLE om_dc_info_task ( 
	dc_id							varchar(64) 	NOT NULL,   -- ID
	dc_name							varchar(100) 	NOT NULL,   -- 名称
	dc_type							varchar(2) 		NULL,   -- dc类型
	domain_id						varchar(64) 	NULL,   -- domain ID
	domain_name						varchar(100) 	NULL,   -- domain name
	zone_count						int 	 NULL,		-- 集群数
	host_count						int 	 NULL,		-- 主机数
	vm_count						int 	 NULL,	-- 虚机数	
	cpu_used						int		 NULL,	-- cpu使用量(个)
	cpu_all							int		 NULL,		-- cpu总量(个)
	mem_used						bigint 	 NULL,   -- 内存使用量(MB)
	mem_all							bigint      NULL,   -- 内存总量(MB)
	disk_used						int	     NULL,		-- 存储使用量(GB)
	disk_all						int 	 NULL,	-- 存储总量	(GB)
	volume_count					int			NULL,	-- 云硬盘个数
	image_count						int			NULL,	-- 镜像个数
	network_count					int			NULL,	-- 网络个数
	shared_network_count			int			NULL,	-- 共享网络个数
	external_network_count			int			NULL,	-- 外部网络个数
	extra							varchar(1000)	NULL,		-- 扩展字段
    PRIMARY KEY(dc_id)
);

drop table if exists om_host_info_task ;
CREATE TABLE om_host_info_task ( 
	id							varchar(64) 	NOT NULL,   -- ID
	dc_id						varchar(64) 	NULL,   -- dcID
	dc_name						varchar(100) 	NULL,   -- dc名称
	dc_type						varchar(2) 		NULL,   -- dc类型
	zone_name					varchar(100) 	NULL,   -- 集群名称
	host_name					varchar(100) 	NULL,   -- 主机名称
	host_ip						varchar(64) 	NULL,   -- 主机IP
	status						varchar(32) 	NULL,   -- 状态
	hypervisor_type				varchar(32)		NULL,   -- 类型
	vcpus						int		 NULL,		-- 虚拟内核（总计）
	vcpus_used					int 	 NULL,   -- 虚拟内核（已使用）
	memory_mb					bigint   NULL,   -- 内存总计
	memory_mb_used				bigint	 NULL,		-- 内存已使用
	local_gb					int 	 NULL,	-- 存储总计
	local_gb_used				int	NULL,		-- 存储已使用
	running_vms					int	NULL,		-- 云主机个数
    PRIMARY KEY(id)
);

drop table if exists om_zone_info_task;
CREATE TABLE om_zone_info_task ( 
	id							varchar(64) 	NOT NULL, 
	dc_id						varchar(64) 	NULL, 
	dc_name						varchar(100) 	NULL,  
	dc_type						varchar(2) 		NULL, 
	name						varchar(100) 	NULL,   
	created						varchar(64) 	NULL,
	updated						varchar(64) 	NULL
);

drop table if exists om_base_tree ;
CREATE TABLE om_base_tree ( 
	id						varchar(64) 	NOT NULL,   -- ID
	name						varchar(100) 	NOT NULL,   -- 名称
	description						varchar(250) 	NULL,		-- 描述
	parent_id						varchar(100) 	NOT NULL,	-- 父节点	
	type							int		NOT NULL,	-- 类型（0、资源 1、组织）
	extra							varchar(500)	NULL,		-- 扩展字段
    PRIMARY KEY(id)
);



drop table if exists om_oper_res_rel;
CREATE TABLE om_oper_res_rel ( 
	rel_id						varchar(64) 	NOT NULL,   -- 关联id
	oper_id					decimal(10) 	NOT NULL,   -- 用户id（ommp的用户id）
	type						int		NOT NULL,	-- 关联节点类型（1、tree节点 2、dc节点）当关联的是tree节点，则默认为此tree节点下所有节点都关联
	resource_id					varchar(100) 	NOT NULL,	-- 关联的资源节点id
    PRIMARY KEY(rel_id)
);



drop table if exists om_oper_org_rel;
CREATE TABLE om_oper_org_rel ( 
	rel_id						varchar(64) 	NOT NULL,   -- 关联id
	oper_id					decimal(10) 	NOT NULL,   -- 用户id（ommp的用户id）
	type						int		NOT NULL,	-- 关联节点类型（1、tree节点 2、vdc节点）当关联的是tree节点，则默认为此tree节点下所有节点都关联
	resource_id					varchar(100) 	NOT NULL,	-- 关联的资源节点id
    PRIMARY KEY(rel_id)
);



drop table if exists om_org_res_rel;
CREATE TABLE om_org_res_rel ( 
	rel_id						varchar(64) 	NOT NULL,   -- 关联id
	org_id					varchar(100) 	NOT NULL,   -- 组织id
	type						int		NOT NULL,	-- 关联节点类型（1、domain节点 2、dc节点）当关联的是domain，则默认为此domain下所有节点都能看到
	resource_id					varchar(100) 	NOT NULL,	-- 关联的资源节点id
    PRIMARY KEY(rel_id)
);

drop table if exists oandmconfig;
CREATE TABLE oandmconfig (
	id						varchar(64)			not null,
	name					varchar(255)		not null,	
	type					int					not null, -- 1.M 2.O
	description				text				null,
	url						varchar(255)		not null,
	dc_id					varchar(64)			not null,
	username				varchar(50)			not null,
	password				varchar(100)		not null,
	primary key (id)
);


DROP FUNCTION IF EXISTS getBaseChildren;
DELIMITER &&
CREATE FUNCTION `getBaseChildren`(parentId VARCHAR(64))
RETURNS varchar(10000)
BEGIN
	DECLARE sTemp VARCHAR(10000);
	DECLARE sTempChd VARCHAR(10000);

	SET sTemp = '$';
	SET sTempChd =parentId;

	SELECT group_concat(id) INTO sTempChd FROM om_base_tree where FIND_IN_SET(parent_id,sTempChd)>0;
	WHILE sTempChd is not null DO
		SET sTemp = concat(sTemp,',',sTempChd);
		SELECT group_concat(id) INTO sTempChd FROM om_base_tree where FIND_IN_SET(parent_id,sTempChd)>0;
	END WHILE;
	RETURN sTemp;
end&& 
DELIMITER ; 
commit;

use zxinsys;
call proc_add_res_definition('IROSOWNER', '资源属主', 'ROOT', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_owner', '', null);
call proc_add_res_definition('IROSDC', '数据中心', 'IROSOWNER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_dc', '', null);
call proc_add_res_definition('IROSCLUSTER', '集群', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_cluster', '', null);
call proc_add_res_definition('IROSHOST', '主机', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host', '', null);
call proc_add_res_definition('IROSVM', '云主机', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm', '', null);
call proc_add_res_definition('IROS_REPOS_GRP', '存储组', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp', '', null);
call proc_add_res_definition('IROS_REPOS_GRP_MANAGE', '存储组', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_manage', '', null);
call proc_add_res_definition('IROS_REPOS_GRP_PUB', '存储组', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_pub', '', null);
call proc_add_res_definition('IROS_REPOS', '存储', 'IROS_REPOS_GRP', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos', '', null);
call proc_add_res_definition('IROS_REPOS_MANAGE', '存储', 'IROS_REPOS_GRP_MANAGE', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_manage', '', null);
call proc_add_res_definition('IROS_REPOS_PUB', '存储', 'IROS_REPOS_GRP_PUB', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_pub', '', null);
call proc_add_res_definition('IROS_HOSTNIC', '主机网卡', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host_nic', '', null);
call proc_add_res_definition('IROS_VMNIC', '云主机网卡', 'IROSVM', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm_nic', '', null);

call proc_add_oper_rmenu('IROSOWNER', 0, '同步资源', '/irosopsm/resourcemanage/tree/syncOmmpResource.action',null,1,0);

use iros;
drop table if exists ent_res_owner;
create table ent_res_owner(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_dc;
create table ent_res_dc(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_cluster;
create table ent_res_cluster(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_host;
create table ent_res_host(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_vm;
create table ent_res_vm(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_grp;
create table ent_res_repos_grp(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_grp_manage;
create table ent_res_repos_grp_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_grp_pub;
create table ent_res_repos_grp_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos;
create table ent_res_repos(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_manage;
create table ent_res_repos_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_pub;
create table ent_res_repos_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_host_nic;
create table ent_res_host_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_vm_nic;
create table ent_res_vm_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);
-- iros根
delete from ent_res_owner where entid = '1';
insert into ent_res_owner values ('1', 'iROS资源', 'IROSOWNER', 'ROOT', 'ROOT', '', 0, '', 0);

drop table if exists dc_ommp_restype_rel;
create table dc_ommp_restype_rel (
   dc_type           integer                   not null,
   dc_restype        varchar(50)               not null,
   ommp_restype      varchar(50)               not null, 
   primary key (dc_type, dc_restype)
);

-- iECS 
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP', 'IROS_REPOS_GRP');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_MANAGE', 'IROS_REPOS_GRP_MANAGE');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_PUB', 'IROS_REPOS_GRP_PUB');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS', 'IROS_REPOS');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_MANAGE', 'IROS_REPOS_MANAGE');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_PUB', 'IROS_REPOS_PUB');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMC', 'IROSDC');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VM', 'IROSVM');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'HOST', 'IROSHOST');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'POOL', 'IROSCLUSTER');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'NIC', 'IROS_HOSTNIC');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMNETCARD', 'IROS_VMNIC');

use zxinsys;
call proc_res_op_function(0, 1, 1396, 139605,'订单审批');
call proc_res_op_function(0, 1, 1396, 139617,'流程配置');
call proc_res_op_function(0, 1, 1396, 139630,'租期统计');
-- 新增菜单 VDC审批
call proc_res_op_function(0, 1, 1396, 139643,'VDC审批');

delete from portal_sysparam where param_name = 'order_task_count';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('order_task_count','3','订单创建资源重试最大次数','iROS','订单创建资源重试最大次数',
             2,1000,0,'',1,
             '','','','','');

use iros;

drop table if exists om_order_task;
drop table if exists om_order_detail;
drop table if exists om_order_audit;
drop table if exists om_order;
drop table if exists om_order_process;
drop table if exists om_order_process_config;
drop table if exists om_order_sequence;
drop table if exists om_res_order_process_rel;
drop table if exists om_order_res_rel;
drop table if exists om_order_forceendservers;

create table om_order
(
   order_id             int not null,
   order_code           varchar(64) not null,
   dc_id                varchar(64),
   city_id              varchar(100),
   vdc_id               varchar(64),
   user_id              int not null,
   res_type             tinyint not null,
   oper_type            tinyint not null comment '1-申请资源 2-变更资源 3-回收资源',
   process_id           int not null,
   current_step         int not null,
   start_date           datetime not null,
   end_date             datetime,
   quantity             int not null,
   primary key (order_id)
);

create table om_order_audit
(
   order_audit_id       int not null,
   order_id             int not null,
   auditor_id           int not null,
   audit_date           datetime not null,
   audit_content        varchar(500) not null,
   primary key (order_audit_id)
);

create table om_order_forceendservers
(
   id       			varchar(64) not null,
   order_id             varchar(64) not null,
   instance_id          varchar(64) not null,
   dc_id           		varchar(64) not null, 
   status        		tinyint, -- 1-待删除 2-删除中 3-删除失败
   primary key (id)
);

create table om_order_detail
(
   order_detail_id      int not null,
   order_id             int not null,
   order_params         text not null,
   primary key (order_detail_id)
);

create table om_order_process
(
   process_id           int not null,
   name                 varchar(50) not null,
   description          text,
   auto_step            int not null,
   is_use               tinyint not null comment '0:  不启用   1:  启用',
   is_auto_deliver      tinyint not null comment '0:  手工交付 1:  自动交付',
   primary key (process_id)
);

insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(2, '云资源申请审批流程', '适用于云主机、云桌面、防火墙、负载均衡资源的申请审批流程', 2, 0, 0);
-- 新增 VDC审批流程
insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(4, 'VDC申请审批流程', '适用于VDC的申请审批流程', 1, 0, 0);
commit;

create table om_order_process_config
(
   process_id           int not null,
   step                 int not null,
   description          text,
   role_id              int,
   current_status       varchar(50) not null,
   next_status          varchar(50) not null,
   is_rollback          tinyint not null comment '0：不可以回退 1：可以回退'
);


insert into om_order_process_config values ('2', '1', '审批', null, '已提交', '待创建', '0');
insert into om_order_process_config values ('2', '2', '系统创建', null, '待创建', '待交付', '0');
insert into om_order_process_config values ('2', '3', '交付', null, '待交付', '正常关闭', '0');
insert into om_order_process_config values ('2', '-2', '异常结束', null, '异常结束', '异常结束', '0');
insert into om_order_process_config values ('2', '-1', '审批拒绝', null, '审批拒绝', '审批拒绝', '0');
insert into om_order_process_config values ('2', '0', '正常关闭', null, '正常关闭', '正常关闭', '0');

-- 新增 VDC的审批流程配置
insert into om_order_process_config values ('4', '1', '一级审批', null, '待处理', '处理中', '0');
insert into om_order_process_config values ('4', '2', '二级审批', null, '处理中', '正常关闭', '0');
insert into om_order_process_config values ('4', '-3', '异常结束', null, '异常结束', '异常结束', '0');
insert into om_order_process_config values ('4', '-2', '二级审批拒绝', null, '二级审批拒绝', '审批拒绝', '0');
insert into om_order_process_config values ('4', '-1', '一级审批拒绝', null, '一级审批拒绝', '审批拒绝', '0');
insert into om_order_process_config values ('4', '0', '正常关闭', null, '正常关闭', '正常关闭', '0');
commit;

create table om_res_order_process_rel
(
   res_type             tinyint not null,
   process_id           int not null
);

create table om_order_sequence
(
   cur_month            int not null,
   cur_value            int not null
);

create table om_order_task
(
   order_detail_id      int not null,
   task_id              int not null,
   task_step            tinyint not null,
   task_status          tinyint not null comment '1-成功 2-失败 3-处理中',
   retry_num            int not null default 0,
   req_params           text,
   resp_params          text,
   primary key (task_id)
);

insert into om_res_order_process_rel (res_type, process_id) values(1, 2);
insert into om_res_order_process_rel (res_type, process_id) values(3, 2);
insert into om_res_order_process_rel (res_type, process_id) values(4, 2);
insert into om_res_order_process_rel (res_type, process_id) values(9, 2);
-- 新增 VDC和审批流程的对应关系
insert into om_res_order_process_rel (res_type, process_id) values(10, 4);
commit;

create table om_order_res_rel 
(
   id          varchar(64) not null,
   dc_id       varchar(64) not null,
   vdc_id      int not null,
   user_id     int not null,
   order_id    int not null,
   res_type    tinyint not null, -- 1、云主机 3、防火墙 4、负载均衡
   deliver_time    datetime null, 
   expire_time     datetime null,
   primary key (id)
);

use iros;
drop table if exists om_ticket_process;
create table om_ticket_process
(
   process_id           int not null,
   ticket_id            int not null,
   step                 int not null,
   oper_type            int not null, -- 1创建 2指派 3拒绝 4接受处理 5转移 6回退 7 处理
   opinion              text null,
   handler_id           int null,
   handler              varchar(50) not null,
   handle_time          datetime not null,
   attachment_path      varchar(255) null,
   attachment           varchar(1000) null,
   attachmentids        varchar(200) null,   
   primary key (process_id)
);

drop table if exists om_ticket;
create table om_ticket
(
   ticket_id            int not null,
   code                 varchar(64) not null,
   title                varchar(64) not null,
   description          text not null,
   category             tinyint not null,
   status               tinyint not null, -- 1、待处理 2、已响应 3、处理中 4、正常结束 5、异常结束 6、转移处理中 
   creator_id           int not null,
   creator              varchar(64) not null,
   phone                varchar(20) not null,
   create_time          datetime not null,
   step                 int not null,
   handler_id           int null,
   handler              varchar(64) null,
   respond_time         datetime,
   update_time          datetime,
   close_time           datetime,
   extra                text,
   order_id             int null,
   order_detail_id      int null,
   city_id              varchar(100) null,
   computerroom_id      varchar(100) null,
   primary key (ticket_id)
);
	  
	  
drop table if exists om_bak_vm_policy;
create table om_bak_vm_policy
(
   vdc_id   	numeric NOT NULL,
   bak_cycle 	tinyint not null, -- 0、天1、周2、月
   bak_day		tinyint not null, -- 天
   bak_time		varchar(5),  -- 时间
   primary key (vdc_id)
);


drop table if exists om_bak_vm;
create table om_bak_vm
(
   bak_id		int not null,
   vdc_id   	numeric NOT NULL,
   dc_id        varchar(64) NOT NULL,
   project_id   varchar(64) NOT NULL,
   vm_id		varchar(64) NOT NULL,
   vm_name		varchar(200),
   vm_type		tinyint null, -- 1、openstack
   image_id		varchar(64) NOT NULL,
   image_name 	varchar(200),
   type			tinyint not null, -- 1、自动 2、手动
   update_date  datetime not null,
   extra		text,
   
   primary key (bak_id)
);	  

drop table if exists om_resource_statistic;
create table om_resource_statistic
(
   vdc_id   	   int not null,
   dc_id   	       varchar(100),
   year            varchar(10) not null,
   yearmonth       varchar(10) not null,
   date            varchar(10) not null,
   type            int not null, -- 1.instance 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
   resource_id     varchar(100) not null,
   resource_name   varchar(100) not null,
   usagetime       int          not null,
   
   primary key (type, resource_id, resource_name, date)
);

drop table if exists om_compute_threshold;
create table om_compute_threshold
(
	dc_id				varchar(64)		not null,
	compute				varchar(100)	not null,
	cpu					int				not null,
	mem					int				not null,
	primary key (dc_id, compute)
);

drop table if exists om_compute_migrate;
create table om_compute_migrate
(
	task_id				varchar(64)		not null,
	dc_id				varchar(64)		not null,
	compute				varchar(100)	not null,
	server_id			varchar(64)		not null,
	server_name			varchar(64)		not null,
	migrate_result		int				not null,
	migrate_detail		text			null,
	migrate_time		datetime		not null,
	primary key (task_id)
);

drop table if exists om_dci;
CREATE TABLE om_dci ( 
	dci_id        	int NOT NULL,
	dci_name        varchar(255) NOT NULL,
	vdc_id        	int NOT NULL,	
	export_rt       varchar(100)  NOT NULL,
	import_rt       varchar(100)  NOT NULL,
	rd              varchar(100)  NOT NULL,
	vni        	    varchar(100)  NOT NULL,
	tag				varchar(100)   NULL,
	tag_type		varchar(100)   NULL,
	dscp			int 	NULL,
	primary key (dci_id)
);

drop table if exists om_dci_sub;
CREATE TABLE om_dci_sub ( 
	dci_id        	int NOT NULL,	
	dc_id         	varchar(100)  NOT NULL,
	tenant_id       varchar(100)  NOT NULL,
	net_id        	varchar(100)  NOT NULL,	
	sub_id        	varchar(100)  NOT NULL,
    sub_ipmask      varchar(100)  NOT NULL	
);

drop table if exists om_base_service;
CREATE TABLE om_base_service ( 
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64) NOT NULL,
	rel_id      varchar(500) NOT NULL,
	description varchar(500) NULL,
	dc_type 	varchar(500) NULL,
	primary key (id)
);

drop table if exists om_service_directory;
CREATE TABLE om_service_directory ( 
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64)  NULL,
	dc_id      varchar(100) NOT NULL,
	template_id  int  NULL,
	vdc_id   	numeric  NULL,
	type        tinyint NOT NULL,
	parent_id      int  NULL,
	is_use        tinyint NOT NULL,
	is_publish      tinyint NOT NULL,
	extra        text  NULL,
	primary key (id)
);

drop table if exists om_service_rel;
CREATE TABLE om_service_rel ( 
	id        	int NOT NULL,
	rel_id      int NOT NULL,
	dc_id  varchar(100) NOT NULL,
	type  tinyint  NOT NULL 
);

insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (1, 'VPN', 'switch_vpn', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (2, '负载均衡', 'switch_lb', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (3, '防火墙', 'switch_firewall', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (4, 'DCI', 'switch_dci', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (5, '安全组', 'switch_sg', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (6, '基础虚拟化功能', 'switch_base', '','',',1,2,3,4,5,6,7,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (7, '业务自动编排', 'switch_adt', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (8, '业务环境', 'switch_service', '7','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (9, '增量备份', 'switch_backup_add', '6','',',2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (10, '全量备份', 'switch_backup_all', '6','',',2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (11, '端口流统计', 'switch_flow', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (13, '备份', 'switch_dpmbackup', '6','',',1,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (14, '机架租赁', 'switch_rackrent', '','提供机架整体对外出租的功能，同时提供高质量带宽宽带，互联网IP的接入，方便企业的接入。',',1,2,3,4,5,6,7,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (16, '云桌面', 'switch_irai', '','',',1,');
commit;

drop table if exists om_ade_template;
create table om_ade_template (
   id                     int         not null,   -- 模板ID
   name                   varchar(100)         not null,   -- 名称
   type                   tinyint         not null,   -- 类型
   description                   text         null,       -- 描述
   status                 tinyint    default 0 not null,   -- 是否发布,0:未发布,1:已发布
   dc_id	              varchar(100)         not null,   -- 模板归属的dc
   tenant_id              varchar(100)         not null,   -- 租户ID
   delete_flag			  tinyint    default 0 not null,   -- 默认0,0:未删除,1:已删除
   creator_id             numeric         		NOT NULL,       -- 创建者id
   create_time            datetime             null,       -- 创建时间
   delete_time            datetime             null,       -- 删除时间
   update_time            datetime             null,       -- 修改时间
   extra				  text         null,       -- 扩展信息
   primary key (id)
);



drop table if exists om_ade_instance;
CREATE TABLE om_ade_instance ( 
	id								int 	NOT NULL,  -- 实例化id
	name							varchar(100) 	NOT NULL,  -- 实例化名称
    description							text 	NULL,		-- 实例化描述
	vdc_id							numeric	NOT NULL,  -- vdcid
	dc_id							varchar(100)	NULL,  -- dcid
	status							tinyint    NULL,   -- 1:成功,2:失败，3：创建中
	template_id						varchar(100)	NOT NULL,  -- 模板id
	stack_id						varchar(100)	NULL,  -- stack id
	delete_flag			  			tinyint    default 0 not null,   -- 默认0,0:未删除,1:已删除
	create_time            			datetime        NOT NULL,  -- 创建时间
	delete_time            			datetime        null,       -- 删除时间
	update_time            			datetime        null,       -- 删除时间
	creator_id						numeric	NOT NULL,  -- 创建者
	extra							text	NULL,   
    PRIMARY KEY(id)
);


drop table if exists om_ade_traffic_steering;
CREATE TABLE om_ade_traffic_steering ( 
	instance_id						int 	NOT NULL,  -- instance_id
	classfier						varchar(100) 	NOT NULL,  -- 过滤规则ID
	portChain						varchar(100) 	NOT NULL  -- 过滤规则对应的业务端口链ID
    
);

drop table if exists om_instance_backup;
CREATE TABLE om_instance_backup (
    id                              int(11) NOT NULL AUTO_INCREMENT,
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
    parent_id						int(11)     NULL,
	instance_uuid				    varchar(255)	NOT NULL,
	instance_name				    varchar(255)	NULL,
	backup_type 				    tinyint	NOT NULL, 
	root_disk_file			  		varchar(255) NULL, 
	data_disk_file            		varchar(1000) NULL,
	memory_file            		    varchar(255) NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
	description						text  		NULL,
	related_id						int(11)     NULL,
	current		 				    tinyint	 	NULL, 
    PRIMARY KEY(id)
);
drop table if exists om_backup_task;
CREATE TABLE om_backup_task (
    id                              int(11) NOT NULL AUTO_INCREMENT,
	backup_id						int(11)      	NOT NULL,
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
	instance_uuid				    varchar(255)   NOT NULL,
	instance_name				    varchar(255)   NULL,
    backup_type 				    tinyint	NOT NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
	process						    int(11) NOT NULL, 
	sync	        			    tinyint	NOT NULL, 
	extra							text	NULL,
    PRIMARY KEY(id)	
);
drop table if exists om_backup_policy;
CREATE TABLE om_backup_policy ( 
	uuid	                        varchar(100) 	NOT NULL, 
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
	name         				    varchar(255)	NOT NULL,
	policy       			  		varchar(255) NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	last_exec_date            	    datetime  NULL, 
	enable 				            tinyint	NOT NULL, 
	policy_type						int	NULL,   
    PRIMARY KEY(uuid)
);
drop table if exists om_backup_policy_association;
CREATE TABLE om_backup_policy_association(  
    instance_uuid				    varchar(255) NOT NULL,
	backup_policy_id				varchar(100) 	NOT NULL
);

drop table if exists om_backup_quota;
CREATE TABLE om_backup_quota ( 
    uuid							varchar(100) 	NOT NULL,  
	dc_id							varchar(100) 	NULL, 
    vdc_id							numeric	NOT NULL,	 
	quota						    int	default 0 not null,   
	backup_type					    tinyint	NOT NULL, 
    PRIMARY KEY(uuid)
);

drop table if exists om_backup_path;
CREATE TABLE om_backup_path ( 
	uuid							varchar(100) NOT NULL, 
	dc_id							varchar(100) 	NOT NULL,   
	compute_host					varchar(255) 	NULL,
	path_type 				        tinyint	NOT NULL, 
	backup_path					    varchar(255) 	NULL,
    PRIMARY KEY(uuid)
);

--  DRS begin
drop table if exists drs_config;
create table drs_config (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(100)                      not null  ,  -- 资源池id dcid@zoneid
	reposstype				          		numeric(10)					 default  1  not null  ,  -- 存储策略
	enable                          numeric(10)          default  1  not null  ,  -- 是否启动
	mode                     		    numeric(10)          default  1  null  ,	    -- 策略模式
	autorun                        	numeric(10)                    	 null  ,	    -- 是否自动执行
	constraint PK_DRS_CONFIG_ID primary key (id)
);

drop table if exists drs_config_detail;
create table drs_config_detail (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  , -- 资源池id 集群名称@dcid
	cpuup                       		varchar(100)                     null  ,	-- CPU上限
	cpudown                     		varchar(100)                     null  ,	-- CPU下限
	memup                         	varchar(100)                     null  ,	-- 内存上限
	memdown                       	varchar(100)                     null  ,	-- 内存下限
	active                          numeric(10)          default  1  not null  ,-- 是否有效
	starttime                      	varchar(10)                      null  ,	-- 开始时间
	endtime                     		varchar(10)                      null  ,	-- 结束时间
	constraint PK_DRS_CONFIG_DETAIL_ID primary key (id)
);

drop table if exists drs_suggest;
create table drs_suggest (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(255)                      not null  ,-- 资源池id
	operation                       numeric(10)                      not null  ,-- 执行动作
	hostid                          varchar(255)                      null  ,	-- 最佳被迁主机
	hostid2                         varchar(255)                      null  ,	-- 最佳目标主机
	vmid                            varchar(255)                      null  ,	-- 最佳被迁虚机
	hostname                        varchar(255)                      null  ,	-- 最佳被迁主机名
	hostname2                       varchar(255)                      null  ,	-- 最佳目标主机名
	vmname                          varchar(255)                      null  ,	-- 最佳被迁虚机名
	description                     varchar(256)                     null  ,	-- 描述
	inserttime                      datetime                         null  ,	-- 产生时间
	status                          numeric(10)                      null  ,	-- 状态
	maintainStatus                  numeric(10)                      null  ,	-- 主机维护时，任务执行状态
	primary key (id)
);

drop table if exists drs_suggest_history;
create table drs_suggest_history (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(255)                      not null  ,-- 资源池id
	suggestid                       varchar(64)                      not null  ,-- 建议ID
	operation                       int                              not null  ,-- 执行动作
	hostid                          varchar(255)                      null  ,	-- 最佳被迁主机
	hostid2                         varchar(255)                      null  ,	-- 最佳目标主机
	vmid                            varchar(255)                      null  ,	-- 最佳被迁虚机
	hostname                        varchar(255)                      null  ,	-- 最佳被迁主机名
	hostname2                       varchar(255)                      null  ,	-- 最佳目标主机名
	vmname                          varchar(255)                      null  ,	-- 最佳被迁虚机名
	description                     varchar(256)                     null  ,	-- 描述
	inserttime                      datetime                         null  ,	-- 产生时间
	status                          int                              null  ,	-- 状态
	exetime 						datetime                         null  ,	-- 执行时间
	maintainStatus                  int                              null  ,	-- 主机维护时，任务执行状态
	taskid                          varchar(64)                      null  ,	-- 该任务执行时，任务对象返回的任务ID
	constraint PK_DRS_SUGGEST_HISTORY_ID primary key (id)
);

drop table if exists drs_storage_config;
create table drs_storage_config (
	poolid                          varchar(64)                      not null  ,-- 资源池id
	reposstype						int					 DEFAULT  1  not null  ,-- 存储策略
	enable                          int                  DEFAULT  1  not null  ,-- 是否启动
	mode                     		int                  DEFAULT  1  null  ,	-- 策略模式
	autorun                     	int                         	 null  ,	-- 是否自动执行
	maxrate                         int                              not null,  -- 设置的最大阈值   
	ext1                           int                               null,  -- 扩展1  
	ext2                           int                                null,  -- 扩展2
	ext3                           varchar(64)                                null,  -- 扩展3
	ext4                           varchar(64)                                null,  -- 扩展4
	constraint PK_drs_storage_config_ID primary key (poolid)
);

drop table if exists drs_storage_suggest;
create table drs_storage_suggest (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  ,-- 资源池id
	operation                       int                              not null  ,-- 执行动作
	hostid                          varchar(64)                      null  ,	-- 最佳被迁主机
	hostid2                         varchar(64)                      null  ,	-- 最佳目标主机
	vmid                            varchar(64)                      null  ,	-- 最佳被迁虚机
	hostname                        varchar(64)                      null  ,	-- 最佳被迁主机名
	hostname2                       varchar(64)                      null  ,	-- 最佳目标主机名
	vmname                          varchar(64)                      null  ,	-- 最佳被迁虚机名
	description                     varchar(256)                     null  ,	-- 描述
	inserttime                      datetime                         null  ,	-- 产生时间
	status                          int                              null  ,	-- 状态
	maintainStatus                  int                              null  ,	-- 主机维护时，任务执行状态
	constraint PK_DRS_STORAGE_SUGGEST_ID primary key (id)
);

drop table if exists om_compute_ipmi;
create table om_compute_ipmi
(
    dc_id			varchar(64)		not null,
	compute			varchar(100)	not null,
	ip			    varchar(64)		null,
	user_name		varchar(255)	null,
	user_pwd		varchar(255)    null,
	primary key (dc_id, compute)
);
--  DRS end

drop table if exists om_a10_vlantag;
CREATE TABLE om_a10_vlantag (
    vlan_tag                int        				not null,
	status   	            tinyint    default 0 	not null,
	a10_vm_uuid          	varchar(64)				not null,
	network_id              varchar(64)        		null,
	a10_port_id             varchar(64)        		null,  
	vnetid           		varchar(64)      		null,    
    vip_list             	text                	null
);

drop procedure if exists p_insert_vlantag;
DELIMITER &&
create procedure p_insert_vlantag(IN vmUuid varchar(64))
begin
  declare i int;
	declare vsql text; 
	set i=4094;	   
	set vsql=concat('insert into om_a10_vlantag (vlan_tag,a10_vm_uuid) values ');
	while i>=0 do
	 if (i%1000 = 0) THEN
		SET @sql_txt = substring(vsql,1,length(vsql)-1); 
        PREPARE stmt FROM @sql_txt; 
        EXECUTE stmt; 
        set vsql=concat('insert into om_a10_vlantag (vlan_tag,a10_vm_uuid) values ');
    end if;
    set vsql=concat(vsql,'(''',i,''',''',vmUuid,'''),');
    set i=i-1;
  end while;
	SET @delsql='delete from om_a10_vlantag where vlan_tag = 1';
	PREPARE stmt FROM @delsql; 
  EXECUTE stmt; 	
end&& 
DELIMITER ; 
commit;


drop table if exists om_a10_dvsport;
CREATE TABLE om_a10_dvsport (
	a10_vm_uuid			   varchar(64)      null,
    device_id              varchar(64)      null,
	port_id   	           varchar(64)    	null
);

drop table if exists om_a10_tenant;
CREATE TABLE om_a10_tenant (
    tenant_id              varchar(64)      null,
	dc_id   	           varchar(64)    	null,
	a10_vm_uuid			   varchar(64)      null
);

drop table if exists om_task_instance_port;
CREATE TABLE om_task_instance_port ( 
	instance_id   	varchar(64) NOT NULL,
	dc_id 	varchar(64) NOT NULL,
	port_id 	varchar(1024) NOT NULL
);

drop table if exists om_vdc_srvdir;
create table om_vdc_srvdir
(
	id				int		not null,
	srvdir_id		int 	null,
	dc_id			varchar(64)		not null,
	vdc_id           decimal	not null,
	is_publish      tinyint    not null,
	parent_id		int   		null,
	template_id		int 		null,
	extra			text		null,
	primary key (id)
);

drop table if exists om_net_vdc_rel;
create table om_net_vdc_rel
(
	networkid varchar(100) not null,
	vdcid decimal(10,0) not null,
	dcid varchar(100) not null,
	projectid varchar(100) not null
);

drop table if exists om_resize_flavor_record;
create table om_resize_flavor_record
(
	instanceid varchar(100) NOT NULL,
	vdcid varchar(10) NOT NULL,
	dcid varchar(100) NOT NULL,
	flag int(11) NOT NULL,
	operation varchar(20) DEFAULT NULL,
	vcpus int(11) NOT NULL,
	memory bigint(20) NOT NULL,
	disk int(11) NOT NULL,
	created datetime DEFAULT NULL,
	updated datetime DEFAULT NULL
);

drop table if exists om_ip_rel;
CREATE TABLE om_ip_rel ( 
	id							varchar(64) 	NOT NULL,-- UUID
	internet_ip				    varchar(100) 	NULL,-- 互联网IP
    float_ip	                varchar(100) 	NULL,-- 浮动IP
    extnet_id	                varchar(100) 	NULL,-- 外部网络Id
	subnet_id	                varchar(100) 	NULL,-- 子网Id
	dc_id						varchar(100) 	NULL,
    vdc_id                      numeric		    NULL,
    tenant_id				    varchar(100) 	NULL, 	
	vm_id	                    varchar(100) 	NULL,
	extra						varchar(500) 	NULL
);

drop table if exists om_history_records;
CREATE TABLE om_history_records ( 
	dc_id						varchar(64) 	NOT NULL, 
	instance_id					varchar(100) 	NOT NULL,  
	oper_type					int 		    NOT NULL,  
	created						varchar(64) 	NULL,
	status						int     		NULL,
	detail						text 			NULL
);

-- 新增 VDC申请表
drop table if exists om_vdc_apply;
create table om_vdc_apply
(
   apply_id             int NOT NULL,
   vdcname 				varchar(64) NOT NULL,
   vdcdesc 				varchar(256) NULL,
   vdcid   				numeric NULL,
   dcids				varchar(512) NOT NULL,
   dctypes				varchar(64) NOT NULL,
   quotas				varchar(2048) NOT NULL,
   operators			varchar(64) NOT NULL,
   operatoroles			varchar(256) NOT NULL,
   dcids_audited		varchar(512) NULL,
   dctypes_audited		varchar(64) NULL,
   quotas_audited		varchar(2048) NULL,
   creatorid			int NOT NULL,
   tenantid				varchar(64) NOT NULL,
   current_step         int NOT NULL,
   apply_date           datetime NOT NULL,
   primary key (apply_id)
);

-- 新增 服务评价表
drop table if exists om_service_evaluation;
create table om_service_evaluation
(
   order_id             int NOT NULL,
   type 				int NOT NULL,
   user_id 				int NOT NULL,
   evaluation   		int NOT NULL,
   comment				varchar(512) NULL,
   evaluate_date        datetime NOT NULL
);

-- 新增 系统评价表
drop table if exists om_system_evaluation;
create table om_system_evaluation
(
  id                int NOT NULL,
  user_id 			int NOT NULL,
  vdc_id            int NOT NULL,
  usability 		int NOT NULL,
  systemic_fluency  int NOT NULL,
  processing_rate   int NOT NULL,
  comment			varchar(512) NULL,
  evaluate_date     datetime NOT NULL,
  primary key (id)
);