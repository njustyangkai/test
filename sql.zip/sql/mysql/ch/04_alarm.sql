﻿use iros;

drop table if exists alarm_snmp_address;
CREATE TABLE alarm_snmp_address (
   name              varchar(200)    not null,   
   port              int             not null,   
   ip                varchar(50)     not null,  
   community         varchar(200)    not null, 
   type              varchar(50)     not null,
   localip           varchar(50)     null,
   localport         int             null,
   PRIMARY KEY(name)
);

drop table if exists alarm_oid;
CREATE TABLE alarm_oid (
     name            varchar(100)                   not null,     
     oid             varchar(100)                   not null,  
   primary key (name)  
);

insert into alarm_oid(oid, name) values('1.3.6.1.6.3.1.1.4.1.0','alarmType');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.1','alarmReport');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.2','alarmRestore');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.3','alarmEventTime');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.2','sendNotificationId');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.4','lastSendNotificationId');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.3','systemDN');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.11','alarmCode');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.2','alarmManagedObjectInstance');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.4','alarmEventType');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.5','alarmProbableCause');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.6','alarmPerceivedSeverity');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.7','alarmSpecificProblem');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.8','alarmAdditionalText');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.12','alarmNetype');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.9','alarmIndex');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.1','alarmId');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.14','alarmCodeName');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.15','alarmManagedObjectInstanceName');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.16','alarmSystemType');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.17','alarmNeIP');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.18','alarmACK');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.19','cleiCode');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.20','timeZoneID');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.21','timeZoneOffset');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.22','dSTSaving');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.23','aid');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.24','id');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.26','alarmMocObjectInstatance');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.10','alarmComment');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.25','alarmOtherInfo');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.2.0','opencos_snmpTrapCommunity');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.3.0','opencos_snmpTrapVersion');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.2.1.3','opencos_trapIpaddressPort');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.4.2.1.1','heartbeatNotification');
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3','currentAlarmTable');

use zxinalarm;
-- 告警系统类型
call proc_alm_systypedic(1,22537,'iROS');

-- 告警码

-- Openstack
call proc_alm_code_new(1,46087,'镜像服务器存储空间使用率较高',2,13,1,22537);
call proc_alm_code_new(1,46112,'计算服务不可用',1,13,1,22537);
call proc_alm_code_new(1,46114,'主机内存故障',1,13,1,22537);
call proc_alm_code_new(1,46115,'主机硬盘故障',2,13,1,22537);
call proc_alm_code_new(1,46119,'以太网口down',2,13,1,22537);
call proc_alm_code_new(1,46124,'内存不足',3,13,1,22537);
call proc_alm_code_new(1,46126,'主机硬盘故障(WARN)',3,13,1,22537);
call proc_alm_code_new(1,46127,'根分区使用率超额',3,13,1,22537);
call proc_alm_code_new(1,46146,'交换端口down',3,13,1,22537);
call proc_alm_code_new(1,46160,'存储离线',3,13,1,22537);
call proc_alm_code_new(1,46161,'共享存储空间不足',4,13,1,22537);
call proc_alm_code_new(1,46176,'虚拟机状态异常',4,13,1,22537);
call proc_alm_code_new(1,46178,'虚拟机状态不一致',4,13,1,22537);

-- iECS
call proc_alm_code_new(1,1000001,'主机离线告警',1,13,1,22537);
call proc_alm_code_new(1,1000002,'虚拟机关闭告警',1,13,1,22537);
call proc_alm_code_new(1,1000003,'VMC数据库异常',1,13,1,22537);
call proc_alm_code_new(1,1000004,'存储库状态异常',1,13,1,22537);
call proc_alm_code_new(1,1000005,'存储库使用率超过阈值',1,13,1,22537);
call proc_alm_code_new(1,1000008,'虚机崩溃告警',8,13,1,22537);
call proc_alm_code_new(1,1000009,'虚机重启告警',8,13,1,22537);
call proc_alm_code_new(1,1000014,'存储库代理状态异常',1,13,1,22537);
call proc_alm_code_new(1,1000016,'存储库单元可访问异常',1,13,1,22537);
call proc_alm_code_new(1,1000017,'主机访问存储库目录异常',1,13,1,22537);
call proc_alm_code_new(1,1000018,'主机网络异常',1,13,1,22537);
call proc_alm_code_new(1,1000020,'虚拟机故障切换资源',1,13,1,22537);
call proc_alm_code_new(1,1000021,'光纤告警',1,13,1,22537);
call proc_alm_code_new(1,1000025,'日志空间超限',1,13,1,22537);
call proc_alm_code_new(1,1000026,'MCE硬件异常',1,13,1,22537);
call proc_alm_code_new(1,1000000,'VMC异常',1,13,1,22537);
call proc_alm_code_new(1,1000100,'DRS批量迁移失败', 8,13,1,22537);
call proc_alm_code_new(1,1000041,'主机磁盘异常', 1,13,1,22537);

-- 告警原因

-- Openstack
call proc_alm_reason_new(1,46087,'镜像服务器存储空间使用率较高',22537);
call proc_alm_reason_new(1,46112,'计算服务不可用',22537);
call proc_alm_reason_new(1,46114,'主机内存故障',22537);
call proc_alm_reason_new(1,46115,'主机硬盘故障',22537);
call proc_alm_reason_new(1,46119,'以太网口down',22537);
call proc_alm_reason_new(1,46124,'内存不足',22537);
call proc_alm_reason_new(1,46126,'主机硬盘故障(WARN)',22537);
call proc_alm_reason_new(1,46127,'根分区使用率超额',22537);
call proc_alm_reason_new(1,46146,'交换端口down',22537);
call proc_alm_reason_new(1,46160,'存储离线',22537);
call proc_alm_reason_new(1,46161,'共享存储空间不足',22537);
call proc_alm_reason_new(1,46176,'虚拟机状态异常',22537);
call proc_alm_reason_new(1,46178,'虚拟机状态不一致',22537);

-- iECS
call proc_alm_reason_new(1,1000001,'主机离线告警',22537);
call proc_alm_reason_new(1,1000002,'虚拟机关闭告警',22537);
call proc_alm_reason_new(1,1000003,'VMC数据库异常',22537);
call proc_alm_reason_new(1,1000004,'存储库状态异常',22537);
call proc_alm_reason_new(1,1000005,'存储库使用率超过阈值',22537);
call proc_alm_reason_new(1,1000008,'虚机崩溃告警',22537);
call proc_alm_reason_new(1,1000009,'虚机重启告警',22537);
call proc_alm_reason_new(1,1000014,'存储库代理状态异常',22537);
call proc_alm_reason_new(1,1000016,'存储库单元可访问异常',22537);
call proc_alm_reason_new(1,1000017,'主机访问存储库目录异常',22537);
call proc_alm_reason_new(1,1000018,'主机网络异常',22537);
call proc_alm_reason_new(1,1000020,'虚拟机故障切换资源',22537);
call proc_alm_reason_new(1,1000021,'光纤告警',22537);
call proc_alm_reason_new(1,1000025,'日志空间超限',22537);
call proc_alm_reason_new(1,1000026,'MCE硬件异常',22537);
call proc_alm_reason_new(1,1000000,'VMC异常',22537);
call proc_alm_reason_new(1,1000100,'DRS批量迁移失败',22537);
call proc_alm_reason_new(1,1000041,'主机磁盘异常', 22537);