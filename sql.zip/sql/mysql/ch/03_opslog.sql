use opslog;

drop table if exists t_cost;
CREATE TABLE t_cost (
    id                      varchar(100)        not null,
	vdc_id   	            int                 not null,
	dc_id                   varchar(100)        not null,
	tenant_id               varchar(100)        not null,
	resource_id             varchar(100)        not null,  
	resource_name           varchar(100)        null,    
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
	price                   numeric(20, 5)      not null,
	cost  			        numeric(20, 5) 		not null,
    status                  varchar(100)        null,
    is_submit               int     default 1   not null,
    begin_time              datetime            not null,
    end_time                datetime            not null,
    description             text                null,
	flavor                  varchar(500)       null,
    primary key (id)
    
);

drop procedure if exists p_create_cost;
DELIMITER &&
create procedure p_create_cost()
begin
    declare i int;
	declare mmdd varchar(4);
	declare tabname varchar(20);
	declare vsql varchar(1000); 
	set i=24;	   
	while i>=1 do
	    set mmdd=right(concat('0', i), 2);
	    set tabname=concat('t_cost_',mmdd);
		SET @sql_txt = concat('drop table if exists ', tabname); 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;

		set vsql=concat('create table ', tabname,
		                  '(id                   varchar(100)        not null,',
                          'vdc_id         		 int                 not null,',
                          'dc_id                 varchar(100)        not null,',
                          'tenant_id             varchar(100)        not null,',
                          'resource_id           varchar(100)        not null,',  
                          'resource_name         varchar(100)        null,',    
                          'type                  int                 not null,',
                          'price                 numeric(20, 5)      not null,',
                          'cost  			     numeric(20, 5) 	 not null,',
                          'status                varchar(100)        null,',
                          'begin_time            datetime            not null,',
                          'end_time              datetime            not null,',
                          'duration              numeric(20, 0)      not null,',
                          'description           text                null,',
                          'is_deduct             int default 0       not null,',
                          'deduct_time           datetime            null,',
						  'flavor                varchar(500)       null,',
                          'primary key (id))');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt; 
		
		set vsql=concat('create index idx_vdcid_',mmdd,' on ',tabname,'(vdc_id)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt; 
        set vsql=concat('create index idx_dcid_',mmdd,' on ',tabname,'(dc_id)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
		set vsql=concat('create index idx_dcid_tenantid_',mmdd,' on ',tabname,'(dc_id, tenant_id)');
	    SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;
        set vsql=concat('create index idx_resourceid_',mmdd,' on ',tabname,'(resource_id)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;                 
		set vsql=concat('create index idx_instances_begintime_',mmdd,' on ',tabname,'(begin_time)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt; 
		set vsql=concat('create index idx_instances_endtime_',mmdd,' on ',tabname,'(end_time)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;            
	   	set i=i-1;
    end while;
end&& 
DELIMITER ; 
commit;

call p_create_cost();

drop table if exists t_deduct;
CREATE TABLE t_deduct (
    id                      varchar(100)        not null,
	vdc_id   	            int                 not null,
	value                   numeric(20, 5)      not null,
	update_time  			datetime     		not null,
	deduct_time  			datetime     		null,    --  deduct_time为最早欠费时间点
    description             text                null,
    primary key (id)
);

drop procedure if exists p_create_deduct;
DELIMITER &&
create procedure p_create_deduct()
begin
    declare i int;
	declare mmdd varchar(4);
	declare tabname varchar(20);
	declare vsql varchar(1000); 
	set i=24;	   
	while i>=1 do
	    set mmdd=right(concat('0', i), 2);
	    set tabname=concat('t_deduct_',mmdd);
		SET @sql_txt = concat('drop table if exists ', tabname); 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;       
        
        set vsql=concat('create table ', tabname,
		                  '(id                   varchar(100)        not null,',
                          'vdc_id         		 int                 not null,',                          
                          'old_value             numeric(20, 5)      not null,',  
                          'value                 numeric(20, 5)      not null,',                       
                          'type                  int                 null,',
                          'update_time           datetime            not null,', 
                          'description           text                null,',
                          'primary key (id))');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt; 
		
		set vsql=concat('create index idx_vdcid_',mmdd,' on ',tabname,'(vdc_id)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;     
		set vsql=concat('create index idx_instances_updatetime_',mmdd,' on ',tabname,'(update_time)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;     
	   	set i=i-1;
    end while;
end&& 
DELIMITER ; 
commit;

call p_create_deduct();

drop procedure if exists p_create_operlog;
DELIMITER &&
create procedure p_create_operlog()
begin
	   declare i int;
	   declare mmdd varchar(4);
	   declare tabname varchar(20);
	   declare vsql varchar(1000);
 
	   set i=24;
	   while i>=1 do
			set mmdd=right(concat('0', i), 2);
			set tabname=concat('oper_log',mmdd);
            SET @sql_txt = concat('drop table if exists ', tabname); 
            PREPARE stmt FROM @sql_txt; 
		    EXECUTE stmt;
			  
			set vsql=concat('create table ',tabname,
		             '(id					numeric(20)				not null,',
					 'domainid				varchar(100)			null,',
					 'dcid					varchar(64)			null,',
					 'orgid					varchar(64)			null,',
					 'vdcid					varchar(64)			null,',
	        	     'servicekey			varchar(10)			not null,',
	        	     'code					int					not null,',	
	        	     'taskid				varchar(50)			null,',        	    
					 'targettype			varchar(20)			null,',
					 'targetid				varchar(64)			null,',
	        	     'targetname			varchar(256)			null,',
	        	     'description			varchar(256)		null,',
	        	     'details				text        		null,',
	        	     'status				int					not null,',
	        	     'starttime				datetime			not null,',
	        	     'endtime				datetime			null,',
	        	     'operid				varchar(64)			null,',
	        	     'opername				varchar(64)			null,',
					 'operip				varchar(100)		null,',
	        	     'extra					varchar(1000)		null)');
		
			    SET @sql_txt = vsql; 
				PREPARE stmt FROM @sql_txt; 
				EXECUTE stmt; 
		
		       
			   set vsql=concat('create index idx_operlog_targetid_',mmdd,' on ',tabname,'(targetid, dcid)');
			   SET @sql_txt = vsql; 
			   PREPARE stmt FROM @sql_txt; 
			   EXECUTE stmt;
			   set vsql=concat('create index idx_operlog_starttime_',mmdd,' on ',tabname,'(starttime)');
			   SET @sql_txt = vsql; 
			   PREPARE stmt FROM @sql_txt; 
			   EXECUTE stmt;
			   set vsql=concat('create index idx_operlog_endtime_',mmdd,' on ',tabname,'(endtime)');
			   SET @sql_txt = vsql; 
			   PREPARE stmt FROM @sql_txt; 
			   EXECUTE stmt;
	   	set i=i-1;
	   end while;
end&& 
DELIMITER ; 
commit;

call p_create_operlog();

drop procedure if exists p_create_operlog_view;
DELIMITER &&
create procedure p_create_operlog_view()
begin   
	   declare i int;
	   declare dd1 varchar(4);
	   declare dd0 varchar(4);
	   declare viewname varchar(20);
	   declare vname varchar(20); 
	   declare vsql varchar(1000);
	   
	   
	   set i=24;
	   set vname='oper_log';
	   while i>=1 do
	      set dd1=right(concat('0', i), 2);
		  set dd0=right(concat('0', i-1), 2);
	       
  		  if i=1 then
            set dd0='24';
          end if;

			set viewname=concat(vname,'_v',dd1);
            
            SET @sql_txt = concat('drop view if exists ', viewname); 
            PREPARE stmt FROM @sql_txt; 
		    EXECUTE stmt;
			  
			set vsql=concat('create view ',viewname,
		                     ' as ',
						     ' select * from ',vname,dd1,
						     ' union all ',
						     ' select * from ',vname,dd0);
			SET @sql_txt = vsql; 
			PREPARE stmt FROM @sql_txt; 
			EXECUTE stmt; 
	   		set i=i-1;
	   end while;
end&& 
DELIMITER ; 
commit;

call p_create_operlog_view();
