use zxinsys;

call proc_res_op_function(0, 1, 1396, 139621,'Physical Device');

update oper_function set allowflag=0 where funcgrpid=1396 and funcid=139621 and servicekey='uniportal';

call proc_add_res_definition ('PH_DEVICE', 'iROS DEVICE', 'ROOT', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_iros_phdevice', '', null);
call proc_add_res_definition ('IROS_VDC', 'VDC', 'PH_DEVICE', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_iros_irosvdc', '', null);
call proc_add_res_definition ('PH_COMPANY', 'COMPANY', 'IROS_VDC', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_phcompany', '', null);
call proc_add_res_definition ('PH_MACHINE', 'MACHINE', 'PH_COMPANY', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_phmachine', '', null);
use iros;
drop table if exists common_dict_catalog;
create table common_dict_catalog
(
  typeid        varchar(100)  not null, 
  typename      varchar(200)  not null, 
  parenttypeid      varchar(100)  null,   
  visiableflag      varchar(10) default '1' null,   
  editflag          varchar(10) default '0' null,   
  constraint PK_COMMON_DICT_CATALOG primary key clustered (typeid)
);

drop table if exists common_dict_item;
create table common_dict_item
(
  typeid        varchar(100)  not null, 
  dataid        varchar(100)  not null, 
  dataname        varchar(200)  not null, 
  parenttypeid    varchar(100)  null,  
  parentdataid      varchar(100)  null,   
  visiableflag      varchar(10) default '1' null,  
  editflag          varchar(10) default '0' null,   
  constraint PK_COMMON_DICT_ITEM primary key clustered (dataid)
);
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('9','Rack Flavor','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-0','1U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-1','2U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-2','4U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-3','8U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-4','16U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-5','32U','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-6','64U','','');
-- "os-1", "1007" 
-- "os-2", "1006" 
-- "os-4", "1001"  
-- "os-5", "1002"  
-- "os-7", "1005"  
-- "os-8", "1004"  
-- "os-9", "1003" 

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('7','OS','');
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('8','OS Version','7');

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-1','Microsoft Windows','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-2','SUSELINUX','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-3','TURBOLINUX','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-4','AIX','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-5','HPUNIX','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-6','HPIA','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-7','SOLARIS','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-8','REDHATLINUX','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-9','CGSL','','');

-- Microsoft Windows 1
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800101','Windowsxp','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800102','Windows7','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800103','Windows8','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800104','Windows2000','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800105','Windows2003','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800106','Windows2008','7','os-1');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800107','Windows2012','7','os-1');
-- SUSELINUX 2
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800201','Suse Linux Enterprise 10','7','os-2');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800202','Suse Linux Enterprise 11','7','os-2');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800203','Other Linux','7','os-2');
-- TURBOLINUX 3
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800301','Suse Linux Enterprise 10','7','os-3');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800302','Suse Linux Enterprise 11','7','os-3');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800303','Other Linux','7','os-3');
-- AIX  4
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800401','AIX','7','os-4');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800402','Other AIX','7','os-4');
-- HPUNIX 5
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800501','HPUNIX','7','os-5');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800502','Other HPUNIX','7','os-5');
-- HPIA 6
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800601','AIX','7','os-6');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800602','Other AIX','7','os-6');
-- SOLARIS 7
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800701','SOLARIS','7','os-7');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800702','SOLARIS10','7','os-7');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800703','SOLARIS11','7','os-7');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800704','Other SOLARIS','7','os-7');
-- REDHATLINUX 8
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800801','REDHATLINUX','7','os-8');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800802','REDHATLINUX4.2','7','os-8');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800803','REDHATLINUX6.5','7','os-8');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800804','REDHATLINUX9','7','os-8');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800805','Other REDHATLINUX','7','os-8');
-- CGSL 9
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800901','CGSL','7','os-9');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800902','CGSL V3','7','os-9');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800903','CGSL V4','7','os-9');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800904','Other CGSL','7','os-9');


insert into common_dict_catalog(typeid,typename,parenttypeid) values ('4','Device Type','');

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('4','104001','Physical Machine','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('4','104002','PC','','');

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('5','Physical Machine Type','');

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105001','Blade servers','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105002','Minicomputer','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105003','PC SERVER','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105004','PC','','');
-- insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105005','Thin','','');

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('6','Company','');

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106001','Lenovo','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106002','DELL','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106003','Founder','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106004','SUN','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106005','HP','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106007','IBM','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106008','ZTE','','');
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106010','Intel','','');

 
drop table if exists om_device_info;
create table om_device_info
(
  devicemospecid     varchar(100)                    not null,  
  devicemospecname   varchar(200)                    not null,  
  deviceid           varchar(100)                    null,      
  devicemodel        varchar(100)                    not null,  
  specidnum          int          default 0          not null,
  devicestatus       tinyint      default 0          not null    
);

create unique index i_om_device_info_specid on om_device_info(devicemospecid);

drop table if exists om_devicespec_info;
create table om_devicespec_info
(
  devicemospecid   varchar(100)                     not null,  
  devicetype       varchar(100)                     null,   
  servertype       varchar(100)                     null,   
  devdisk          varchar(50)                      null,  
  memeory          varchar(50)                      null,  
  nicmodel         varchar(100)                     null,   
  niunum           int                              null,  
  cpumodel         varchar(100)                     null,  
  cpumohz          varchar(10)                      null,  
  cpunum           int                              null, 
  cpucores         int                              null,  
  hbamodel         varchar(100)                     null,  
  hbanum           int                              null, 
  cost             decimal(20,5)                    default 0           null  
);

create unique index i_om_devicespec_info_specid on om_devicespec_info(devicemospecid);


drop table if exists om_phydevice_user_his;
create table om_phydevice_user_his
(
  entid            varchar(100)                    not null,   
  userid           int           default 0         null,       
  order_id         int           default 0         null,   
  order_code       varchar(64)                     null,  
  hostname         varchar(64)                     null,   
  desciption       varchar(100)                    null,   
  purchasedate     datetime                        null,   
  enddate          datetime                        null,  
  opertiondivid    varchar(10)                     null,  
  opertiongroupid  varchar(10)                     null,   
  userip           varchar(100)                    null,   
  managername      varchar(50)                     null,  
  managerpwd       varchar(50)                     null,   
  operid           varchar(50)                     null,  
  opertime         datetime                        null,   
  vdcid            varchar(64)                     not null   
 );


drop table if exists om_phydevice_info;
create table om_phydevice_info
(
  computerroom_id      varchar(100),
  city_id              varchar(100),
  rack_id              varchar(100),
  dc_id                varchar(100),
  entid            varchar(100)                    not null,  
  entname          varchar(100)                    not null,   
  devicemospecid   varchar(100)                    null,   
  -- areaid           varchar(200)                    null,  
  -- dcid             varchar(200)                    null,  
  deviceid         varchar(200)                    null,  
  fixedassetnum    varchar(200)                    null,   
  systemnum        varchar(200)                    null,  
  productmnum      varchar(200)                    null,   
  purchasedate     date                            null,   
  assurancetime    int                             null,   
  assurancedesc    varchar(200)                    null,   
  location         varchar(200)                    null,  
  locationdesc     varchar(50)                     null,   
  upframenum       varchar(50)                     null,   
  roundframenum    varchar(50)                     null,  
  slotnum          varchar(50)                     null,  
  ipmiip           varchar(100)                    null,  
  ipmiuser         varchar(50)                     null,  
  ipmipwd          varchar(50)                     null,   
  status           int             default 0       null,   
  phstatus         int             default 0       null,  
  operid           varchar(50)                     null,   
  opertime         date                            null,   
  hand_over        varchar(10)                     null,   
  uuid             varchar(100)                    null,  
  is_measure       int             default 0       null    
);


create index i_om_phydevice_info_specid on om_phydevice_info(devicemospecid);

create unique index i_om_phydevice_info_entid on om_phydevice_info(entid);


drop table if exists om_phydevice_user;
create table om_phydevice_user
(
  entid            varchar(100)                    not null,   
  userid           int           default 0         null,      
  order_id         int           default 0         null, 
  order_code       varchar(64)                     null,  
  hostname         varchar(64)                     null,  
  desciption       varchar(100)                    null,  
  purchasedate     datetime                        null,   
  enddate          datetime                        null,  
  opertiondivid    varchar(10)                     null,   
  opertiongroupid  varchar(10)                     null,   
  userip           varchar(100)                    null,  
  managername      varchar(50)                     null,   
  managerpwd       varchar(50)                     null,   
  operid           varchar(50)                     null,   
  opertime         datetime                        null,  
  vdcid            varchar(64)                     not null  
  
);

create unique index i_om_phydevice_user_entid on om_phydevice_user(entid);

create index i_om_phydevice_user_order_id on om_phydevice_user(order_id);
 

drop table if exists ent_iros_phdevice;
create table ent_iros_phdevice
(	
    entid                varchar(200)                    not null,  
    entname              varchar(200)                    null,      
    entrid               varchar(200)                    not null,  
    parentrid            varchar(100)                    not null,  
    parententid          varchar(200)                    not null,  
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
);

create unique index i_ent_iros_phdevice_entid on ent_iros_phdevice(entid);


delete from ent_iros_phdevice;

insert into ent_iros_phdevice (entid,entname,entrid,parentrid,parententid) values ('101','iROS DEVICE','PH_DEVICE','ROOT','ROOT');



drop table if exists ent_iros_irosvdc;
create table ent_iros_irosvdc 
(
    entid                varchar(200)                    not null,  
    entname              varchar(200)                    null,      
    entrid               varchar(200)                    not null,  
    parentrid            varchar(100)                    not null,  
    parententid          varchar(200)                    not null,  
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
);
create unique index i_ent_iros_irosvdc_entid on ent_iros_irosvdc(entid);



drop table if exists ent_phcompany;
create table ent_phcompany
(
    entid                varchar(200)                    not null,  
    entname              varchar(200)                    null,      
    entrid               varchar(200)                    not null,  
    parentrid            varchar(100)                    not null,  
    parententid          varchar(200)                    not null,  
    entip                varchar(100)                    null,      
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
);

create unique index i_ent_phcompany_entid on ent_phcompany(entid);



drop table if exists ent_phmachine;
-- ostype 1:NT 2:SUSELINUX 3:TURBOLINUX 4:AIX 5:HPUNIX 6:HPIA 7:SOLARIS 8 REDHATLINUX 9:CGSL
create table ent_phmachine  
(
    entid                varchar(200)                    not null,  
    entname              varchar(200)                    null,      
    entrid               varchar(200)                    not null,  
    parentrid            varchar(100)                    not null,  
    parententid          varchar(200)                    not null,  
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null,
	  ostype               numeric(10)                     null,
    phyid                varchar(100)                    null   -- physicial id assiociate with table ent_phmachine	  
);

create unique index i_ent_phmachine_entid on ent_phmachine(entid);

delete from om_order_process where process_id = 3;
delete from om_order_process_config where process_id = 3;
delete from om_res_order_process_rel where res_type in (2,5,6,7,8);
commit;

insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(3, 'Physical Resource approval process', 'It applies to physical machines, racks, Internet IP, LAN IP, bandwidth approval process', 1, 1, 0);
commit;

insert into om_order_process_config values ('3', '1', 'Approve', null, 'Submitted', 'To be delivered', '0');
insert into om_order_process_config values ('3', '2', 'Deliver', null, 'To be delivered', 'Close', '0');
insert into om_order_process_config values ('3', '-2', 'Abnormal', null, 'Abnormal', 'Abnormal', '0');
insert into om_order_process_config values ('3', '-1', 'Approval rejected', null, 'Approval rejected', 'Approval rejected', '0');
insert into om_order_process_config values ('3', '0', 'Close', null, 'Close', 'Close', '0');
commit;

insert into om_res_order_process_rel (res_type, process_id) values(2, 3);
insert into om_res_order_process_rel (res_type, process_id) values(5, 3);
insert into om_res_order_process_rel (res_type, process_id) values(6, 3);
insert into om_res_order_process_rel (res_type, process_id) values(7, 3);
insert into om_res_order_process_rel (res_type, process_id) values(8, 3);
commit;  
 
 
drop procedure if exists sp_web_add_deviceinfo;
DELIMITER //
create procedure sp_web_add_deviceinfo
(
   in v_i_deviceid           varchar(100),   
   in v_i_devicemodel        varchar(100),   
   in v_i_devicemospecid     varchar(100),  
   in v_i_devicemospecname   varchar(200),   
   in v_i_devicetype         varchar(10),   
   in v_i_servertype         varchar(10),   
   in v_i_devdisk            varchar(50),   
   in v_i_memeory            varchar(50),   
   in v_i_nicmodel           varchar(100),  
   in v_i_niunum             int        , 
   in v_i_cpumodel           varchar(100),   
   in v_i_cpumohz            varchar(10),  
   in v_i_cpunum             int        ,   
   in v_i_cpucores           int        ,   
   in v_i_hbamodel           varchar(100),  
   in v_i_hbanum             int,            
   in v_i_cost               decimal(20,5),   
   out v_i_ret               int
)
begin
  declare  v_devicemospecid      varchar(100);
  declare  v_devicestatus        int;     
  declare  v_specidnum           int;         

  set  v_devicemospecid = trim(v_i_devicemospecid);
  set  v_devicestatus = 0;
  set  v_specidnum = 0;
  if exists(select 1 from om_devicespec_info where devicemospecid = v_devicemospecid)
    || exists(select 1 from om_devicespec_info where devicemospecid = v_devicemospecid)
    || exists(select 1 from om_device_info where deviceid = v_i_deviceid and devicemodel = v_i_devicemodel and devicemospecname = v_i_devicemospecname)
  then
    set v_i_ret = 1011;
  else
    start transaction;
    insert into om_device_info( devicemospecid, deviceid, devicemodel,devicemospecname ,specidnum,devicestatus)
         values(v_devicemospecid, v_i_deviceid, v_i_devicemodel,  v_i_devicemospecname, v_specidnum ,v_devicestatus);

    insert into om_devicespec_info (devicemospecid ,devicetype ,servertype ,devdisk ,memeory ,nicmodel ,niunum ,
             cpumodel ,cpumohz ,cpunum ,cpucores ,hbamodel ,hbanum, cost)
         values (v_i_devicemospecid ,v_i_devicetype ,v_i_servertype ,v_i_devdisk ,v_i_memeory ,v_i_nicmodel ,v_i_niunum ,
            v_i_cpumodel ,v_i_cpumohz ,v_i_cpunum ,v_i_cpucores ,v_i_hbamodel ,v_i_hbanum, v_i_cost);
    if @@warning_count <> 0 || @@error_count > 0 then
      rollback;
      set v_i_ret = 1001;
    else
      commit;
      set v_i_ret = 1;
    end if;
  end if;
end //
DELIMITER ;


drop procedure if exists sp_web_mod_deviceinfo;
DELIMITER //
create procedure sp_web_mod_deviceinfo
(
   v_i_deviceid           varchar(100), 
   v_i_devicemodel        varchar(100),  
   v_i_devicemospecid     varchar(100), 
   v_i_devicemospecname   varchar(200),  
   v_i_devicetype         varchar(10),  
   v_i_servertype         varchar(10),  
   v_i_devdisk            varchar(50),  
   v_i_memeory            varchar(50),  
   v_i_nicmodel           varchar(10),   
   v_i_niunum             int        ,   
   v_i_cpumodel           varchar(10),  
   v_i_cpumohz            varchar(10),   
   v_i_cpunum             int        ,   
   v_i_cpucores           int        ,   
   v_i_hbamodel           varchar(10),   
   v_i_hbanum             int,           
   v_i_cost               decimal(20,5),         
   out v_i_ret            int
)
begin
  declare  v_devicemospecid      varchar(100);
  set  v_devicemospecid = trim(v_i_devicemospecid);

  if not exists(select 1 from om_devicespec_info where devicemospecid = v_devicemospecid)
    || not exists(select 1 from om_device_info where devicemospecid = v_devicemospecid)
  then
    set v_i_ret = 1012;
  else
    update om_devicespec_info set devicetype = v_i_devicetype, servertype = v_i_servertype, devdisk = v_i_devdisk,
           memeory = v_i_memeory, nicmodel = v_i_nicmodel, niunum = v_i_niunum, cpumodel = v_i_cpumodel,
           cpumohz = v_i_cpumohz, cpunum = v_i_cpunum, cpucores = v_i_cpucores, hbamodel = v_i_hbamodel,
           hbanum = v_i_hbanum, cost = v_i_cost
         where devicemospecid = v_devicemospecid;
    If @@warning_count <> 0 || @@error_count > 0 then
      set v_i_ret = 1001;
    Else
      set v_i_ret = 1;
    End if;
  End if;
end //
DELIMITER ;


drop procedure if exists sp_web_del_deviceinfo;
DELIMITER //
create procedure sp_web_del_deviceinfo
(
   v_i_devicemospecid     varchar(100),   
   out v_i_ret            int
)
begin
  declare  v_devicemospecid      varchar(100);
  declare  v_specidnum           int;      
  set  v_devicemospecid = trim(v_i_devicemospecid);
  set  v_specidnum = 0;

  select specidnum into v_specidnum from om_device_info where devicemospecid = v_devicemospecid;

  if v_specidnum = -1
  then
    set v_specidnum = 0;
  end if;

  if v_specidnum = 0 then
    start transaction;
    delete from om_device_info where devicemospecid = v_devicemospecid;
    delete from om_devicespec_info where devicemospecid = v_devicemospecid;

    if @@warning_count <> 0 || @@error_count > 0 then
      rollback;
      set v_i_ret = 1001;
    else
      commit;
      set v_i_ret = 1;
    end if;
  else
 
    update om_device_info set devicestatus = 1  where devicemospecid = v_devicemospecid;

    if @@warning_count <> 0 || @@error_count > 0 then
      set v_i_ret = 1001;
    else
      set v_i_ret = 1;
    end if;
  end if;
end //
DELIMITER ;


drop procedure if exists sp_web_add_phymachineinfo;
DELIMITER //
create procedure sp_web_add_phymachineinfo
(
  in v_i_entid            varchar(100), 
  in v_i_devicemospecid   varchar(100),
  -- in v_i_areaid           varchar(200),
  -- in v_i_dcid           varchar(200), 
  in v_i_fixedassetnum    varchar(200), 
  in v_i_systemnum        varchar(200), 
  in v_i_productmnum      varchar(200), 
  in v_i_purchasedate     date,        
  in v_i_assurancetime    int,         
  in v_i_assurancedesc    varchar(200), 
  in v_i_location         varchar(200), 
  in v_i_locationdesc     varchar(50) , 
  in v_i_upframenum       varchar(50) , 
  in v_i_roundframenum    varchar(50) , 
  in v_i_slotnum          varchar(50) , 
  in v_i_ipmiip           varchar(100), 
  in v_i_ipmiuser         varchar(50) , 
  in v_i_ipmipwd          varchar(50) , 
  in v_i_status           int         , 
  in v_i_operid           varchar(50) , 
  in v_i_entname          varchar(200), 
  in v_i_ommpid           varchar(200),
  in v_i_rack_id          varchar(100),
  in v_i_computerroom_id  varchar(100),
  in v_i_city_id          varchar(100),
  in v_i_dc_id            varchar(100),  
  out v_i_ret            int
)
begin
  declare  v_entid               varchar(100);
  declare  v_devicemospecid      varchar(100);
  declare  v_opertime            date;
  declare  v_deviceid            varchar(200);  
  declare  v_devicename          varchar(200);  
  declare  v_phstatus            int;           
  set v_entid = trim(v_i_entid);
  set v_devicemospecid = trim(v_i_devicemospecid);
  set v_opertime = now();
  set v_phstatus = 7;


  select deviceid into v_deviceid from om_device_info where devicemospecid = v_i_devicemospecid;

  if FOUND_ROWS() = 0
    || exists(select 1 from om_phydevice_info where entid = v_entid)
    || exists(select 1 from om_phydevice_info where entname = v_i_entname  and status <>9) then
    set v_i_ret = 3001;
  elseif exists(select 1 from om_phydevice_info where fixedassetnum = v_i_fixedassetnum  and status <>9) then
    set v_i_ret = 3003;
  elseif exists(select 1 from om_phydevice_info where systemnum = v_i_systemnum  and status <>9) then
    set v_i_ret = 3004;
  elseif exists(select 1 from om_phydevice_info where productmnum = v_i_productmnum  and status <>9) then
    set v_i_ret = 3005;
  else
    select dataname into v_devicename from common_dict_item where dataid = v_deviceid;

    if FOUND_ROWS() = 0 then
      set v_i_ret = 3006;
    else
      start transaction;
      insert into om_phydevice_info (rack_id, computerroom_id, city_id, dc_id, entid, entname,devicemospecid ,deviceid ,fixedassetnum ,systemnum ,productmnum ,purchasedate ,
                       assurancetime ,assurancedesc ,location ,locationdesc ,upframenum ,roundframenum ,
                      slotnum ,ipmiip ,ipmiuser ,ipmipwd ,status ,phstatus ,operid , opertime)
           values((v_i_rack_id, v_i_computerroom_id, v_i_city_id, v_i_dc_id, v_entid, v_i_entname, v_devicemospecid, v_deviceid, v_i_fixedassetnum, v_i_systemnum, v_i_productmnum, v_i_purchasedate,
                  v_i_assurancetime, v_i_assurancedesc, v_i_location, v_i_locationdesc, v_i_upframenum, v_i_roundframenum,
                  v_i_slotnum, v_i_ipmiip, v_i_ipmiuser, v_i_ipmipwd, v_i_status, v_phstatus, v_i_operid, v_opertime);
      if @@warning_count <> 0 || @@error_count > 0 then
        rollback;
        set v_i_ret = 1001;
      else
        commit;
        update om_device_info set specidnum = specidnum + 1  where devicemospecid = v_devicemospecid;
        if @@warning_count <> 0 || @@error_count > 0 then
          set v_i_ret = 1001;
        else
          set v_i_ret = 1;
        end if;
      end if;
    end if;
  end if;
end //
DELIMITER ;

drop procedure if exists sp_web_mod_phymachineinfo;
DELIMITER //
create procedure sp_web_mod_phymachineinfo
(
  in v_i_entid            varchar(100), 
  in v_i_devicemospecid   varchar(100),
  -- in v_i_areaid           varchar(200), 
  -- in v_i_dcid          varchar(200), 
  in v_i_fixedassetnum    varchar(200),
  in v_i_systemnum        varchar(200), 
  in v_i_productmnum      varchar(200), 
  in v_i_purchasedate     date,         
  in v_i_assurancetime    int,         
  in v_i_assurancedesc    varchar(200), 
  in v_i_location         varchar(200), 
  in v_i_locationdesc     varchar(50) , 
  in v_i_upframenum       varchar(50) , 
  in v_i_roundframenum    varchar(50) , 
  in v_i_slotnum          varchar(50) , 
  in v_i_ipmiip           varchar(100), 
  in v_i_ipmiuser         varchar(50) , 
  in v_i_ipmipwd          varchar(50) , 
  in v_i_status           int         , 
  in v_i_operid           varchar(50) , 
  in v_i_entname          varchar(200),
  out v_i_ret             int
)
begin
  declare  v_entid               varchar(100);
  declare  v_devicemospecid      varchar(100);
  declare  v_opertime            date;
  set v_entid = trim(v_i_entid);
  set v_devicemospecid = trim(v_i_devicemospecid);
  set v_opertime = now();

  if not exists(select 1 from om_phydevice_info where entid = v_entid) then
    set v_i_ret = 3011;
   elseif exists(select 1 from om_phydevice_info where (entid <> v_entid and entname = v_i_entname and status <>9 )) then
     set v_i_ret = 3001;
  elseif exists(select 1 from om_phydevice_info where (entid <> v_entid and fixedassetnum = v_i_fixedassetnum and status <>9)) then
     set v_i_ret = 3003;
  elseif exists(select 1 from om_phydevice_info where (entid <> v_entid and systemnum = v_i_systemnum and status <>9)) then
     set v_i_ret = 3004;
  elseif exists(select 1 from om_phydevice_info where (entid <> v_entid and productmnum = v_i_productmnum and status <>9)) then
     set v_i_ret = 3005;
   else
    update om_phydevice_info set devicemospecid = v_devicemospecid, fixedassetnum = v_i_fixedassetnum, systemnum = v_i_systemnum,
               productmnum = v_i_productmnum, purchasedate = v_i_purchasedate,  assurancetime = v_i_assurancetime,
                assurancedesc = v_i_assurancedesc,  location = v_i_location, locationdesc = v_i_locationdesc, upframenum = v_i_upframenum,
                roundframenum = v_i_roundframenum ,  slotnum = v_i_slotnum,  ipmiip = v_i_ipmiip, ipmiuser = v_i_ipmiuser,
                ipmipwd = v_i_ipmipwd, operid = v_i_operid,entname = v_i_entname, opertime = v_opertime, deviceid=(select deviceid from om_device_info where devicemospecid=v_devicemospecid)
                where entid = v_entid;
    set v_i_ret = 1;
  end if;
end //
DELIMITER ;

drop procedure if exists sp_web_del_phydevice;
DELIMITER //
create procedure sp_web_del_phydevice
(
  in v_i_entid           varchar(100), -- physicial id
  out v_i_ret            int
)
begin
  declare  v_entid               varchar(100);
  declare  v_parentrid           varchar(100); 
  declare  v_status              int;          
  declare  v_devicemospecid      varchar(100); 
  set v_entid = trim(v_i_entid);
  set v_status = 0; 

  select status, devicemospecid into v_status, v_devicemospecid from om_phydevice_info where entid = v_entid;
  if FOUND_ROWS() = 0 then
    set v_i_ret = 3023;
  else if v_status = 1 || v_status = 2 || v_status = 9 || @v_status = 10 then
    set v_i_ret = 3022;
  else
    if v_status = 0 then
      start transaction;
      delete from om_phydevice_info  where entid = v_entid;

      if @@warning_count <> 0 || @@error_count > 0 then
        rollback;
        set v_i_ret = 1001;
      else
        delete from ent_phmachine where phyid = v_entid;

        if @@warning_count <> 0 || @@error_count > 0 then
          rollback;
          set v_i_ret = 1001;
        else
          commit;
          update om_device_info set specidnum = specidnum - 1  where devicemospecid = v_devicemospecid;

          if @@warning_count <> 0 || @@error_count > 0 then
            set v_i_ret = 1001;
          else
            set v_i_ret = 1;
          end if;
        end if;
      end if;
    else
      update om_phydevice_info set status = 9 where entid = v_entid;

      if @@warning_count <> 0 || @@error_count > 0 then
        set v_i_ret = 1001;
      else
        update om_device_info set specidnum = specidnum - 1  where devicemospecid = v_devicemospecid;

        if @@warning_count <> 0 || @@error_count > 0 then
          set v_i_ret = 1001;
        else
          set v_i_ret = 1;
        end if;
      end if;
    end if;
  end if;
   end if;
end //
DELIMITER ;

drop procedure if exists sp_web_audit_order;
DELIMITER //
create procedure sp_web_audit_order
(
  in v_i_orderid          int,
  in v_i_entid            varchar(100),
  in v_i_purchasedate     datetime,
  in v_i_enddate          datetime,
  in v_i_opertiongroupid  varchar(10),
  in v_i_operid           varchar(50),
  out v_o_ret            int
)
begin
    declare  v_vdcid              varchar(64);
    declare  v_order_code         varchar(64);
    declare  v_opertime           date;
    declare  v_applicant_id       int;
    declare  v_opertiondivid      varchar(10);
	set  v_opertime = now();
	set  v_opertiondivid = '1';
	   
    select order_code, user_id into v_order_code, v_applicant_id from om_order where order_id = v_i_orderid;   
    if FOUND_ROWS() = 0 then
         set v_o_ret = 4001;
    else
        select vdcid into v_vdcid from om_user_info where userid = v_applicant_id;
        if FOUND_ROWS() = 0 then
            set v_o_ret = 4001;
        else
	        select parentdataid into v_opertiondivid from common_dict_item where dataid = v_i_opertiongroupid;
	        if FOUND_ROWS() = 0 then
		        set v_o_ret = 5001;
	        else
		        if exists(select 1 from om_phydevice_user where entid = v_i_entid) then
			       set v_o_ret = 5002;
		        else
			        insert into om_phydevice_user (entid ,userid ,order_id,order_code ,hostname ,desciption ,purchasedate ,enddate ,opertiondivid ,
							 opertiongroupid ,userip ,managername ,managerpwd ,operid ,opertime, vdcid)
					 values(v_i_entid ,v_applicant_id,v_i_orderid, v_order_code,'' ,'' ,v_i_purchasedate  ,
							v_i_enddate ,v_opertiondivid ,v_i_opertiongroupid ,'' ,
							'' ,'' ,v_i_operid ,v_opertime, v_vdcid);
			        if @@warning_count <> 0 || @@error_count > 0 then
				        set v_o_ret = 1001;
			        else
				        update om_phydevice_info set status = 1 where entid = v_i_entid;
				        if @@warning_count <> 0 || @@error_count > 0 then
				           set v_o_ret = 1001;
				        else
				           set v_o_ret = 1;
				        end if;
			        end if;
		        end if;
	        end if;
        end if;
    end if;
end
//
DELIMITER ;

drop procedure if exists sp_web_reject_orderphymachine;
DELIMITER //
create procedure sp_web_reject_orderphymachine
(
  in  v_i_order_id       int,
  out v_o_ret           int
)
begin
  declare v_status   int;
  set     v_status = 0;
  update om_phydevice_info set status = v_status where entid in (select entid from om_phydevice_user where order_id = v_i_order_id);
  if @@warning_count <> 0 || @@error_count > 0 then
	set v_o_ret = 2001;
  else
	delete from om_phydevice_user where order_id = v_i_order_id;
	if @@warning_count <> 0 || @@error_count > 0 then
	  set v_o_ret = 2001;
	else
	  set v_o_ret = 1;
	end if;
  end if;
end
//
DELIMITER ;

use iros;
drop table if exists om_itmp_devicetype_def;
create table om_itmp_devicetype_def
(
    type_id              varchar(50)   not null,  
    parent_type_id       varchar(50)   not null, 
    name                 varchar(50)   not null,
    related_ommp_type_id      varchar(50)   null, 
    primary key (type_id)
);

insert into om_itmp_devicetype_def values ('server_grp', 'dc', 'Server', 'ostype');
insert into om_itmp_devicetype_def values ('storage_grp', 'dc', 'Storage', 'storage');
insert into om_itmp_devicetype_def values ('network_grp', 'dc', 'Network', '');
insert into om_itmp_devicetype_def values ('router_grp', 'network_grp', 'Router', 'router');
insert into om_itmp_devicetype_def values ('switch_grp', 'network_grp', 'Switch', 'switch');

drop table if exists om_itmp_device;
create table om_itmp_device
(
    id            varchar(100)  not null,
    related_ommp_type_id       varchar(50)   not null,
    parent_id     varchar(50)   not null,
    name          varchar(255)  not null, 
    ip 	          varchar(50)   not null,
	create_time   datetime     not null,
	update_time   datetime     not null,
    extra         text          null,  
    primary key (id)
);