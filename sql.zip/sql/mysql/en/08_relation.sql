-- irosrelation
create database if not exists irosrelation DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
grant all privileges on irosrelation.* to 'irosrelation'@'localhost' identified by 'db10$ZTE';
commit;

use irosrelation;
drop table if exists om_relation_instance;
create table om_relation_instance (
	res_id				varchar(64) 	not null,
	tenant_id			varchar(64)		not null,
	user_id				int				not null,
	dc_id				varchar(64) 	not null,
	dc_type				int				not null,
	extra				text			null,
	primary key (res_id)
);

drop table if exists om_relation_network;
create table om_relation_network (
	res_id				varchar(64) 	not null,
	tenant_id			varchar(64)		not null,
	user_id				int				not null,
	dc_id				varchar(64) 	not null,
	dc_type				int				not null,
	extra				text			null,
	primary key (res_id)
);

drop table if exists om_relation_subnet;
create table om_relation_subnet (
	res_id				varchar(64) 	not null,
	tenant_id			varchar(64)		not null,
	user_id				int				not null,
	dc_id				varchar(64) 	not null,
	dc_type				int				not null,
	extra				text			null,
	primary key (res_id)
);

drop table if exists om_relation_image;
create table om_relation_image (
	res_id				varchar(64) 	not null,
	tenant_id			varchar(64)		not null,
	user_id				int				not null,
	dc_id				varchar(64) 	not null,
	dc_type				int				not null,
	extra				text			null,
	primary key (res_id)
);

drop table if exists om_relation_volume;
create table om_relation_volume (
	res_id				varchar(64) 	not null,
	tenant_id			varchar(64)		not null,
	user_id				int				not null,
	dc_id				varchar(64) 	not null,
	dc_type				int				not null,
	extra				text			null,
	primary key (res_id)
);

drop table if exists om_relation_backup;
create table om_relation_backup (
	res_id				varchar(64) 	not null,	
	tenant_id			varchar(64)		not null,	
	user_id				int				not null,	
	dc_id				varchar(64) 	not null,	
	dc_type				int				not null,	
	extra				text			null,
	primary key (res_id)
);

drop table if exists om_relation_snapshot;
create table om_relation_snapshot (
	res_id				varchar(64) 	not null,	
	tenant_id			varchar(64)		not null,	
	user_id				int				not null,	
	dc_id				varchar(64) 	not null,
	dc_type				int				not null,
	extra				text			null,
	primary key (res_id)
);

drop table if exists om_relation_tenant;
create table om_relation_tenant(
  id 					varchar(64)		not null,
  name 					varchar(64)		not null,
  extra 				text,
  description 			text,
  enabled 				tinyint(1)		default null,
  dc_id					varchar(64) 	not null,
  dc_type				int				not null,
  primary key (id)
);

drop table if exists om_relation_user;
create table om_relation_user (
  id					varchar(64) 	not null,
  name 					varchar(255)	not null,
  extra 				text,
  password 				varchar(128) 	default null,
  enabled 				tinyint(1) 		default null,
  is_admin				int				default 0		not null,
  email					varchar(100)	default null,
  dc_id					varchar(64) 	not null,
  dc_type				int				not null,
  primary key (id)
);

drop table if exists om_relation_assignment;
create table om_relation_assignment (
  user_id					varchar(64) 	not null,
  tenant_id 				varchar(64)		not null
);

drop table if exists om_quota_class;
CREATE TABLE om_quota_class (
	id						varchar(64)					not null,
	create_date				datetime					not null,
	update_date				datetime					not null,
	name					varchar(100)				not null,
	resource_id				varchar(64)					not null,
	resource				varchar(100)				not null,
	resource_type			varchar(50)					null,
	hard_limit				numeric						not null,
	deleted					numeric						not null,
	delete_date				datetime					null,
	dc_type					int							not null,
	primary key(id)
);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('1', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'Instances', 'nova_instances', 50, 0, null, 'Compute', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('2', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'VCPUs', 'nova_cores', 50, 0, null, 'Compute', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('3', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'RAM(MB)', 'nova_ram', 51200, 0, null, 'Compute', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('4', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'Networks', 'neutron_networks', 50, 0, null, 'Network', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('5', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'Volumes', 'cinder_volumes', 50, 0, null, 'Volume', 4);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('6', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'Total Size of Volumes(GB)', 'cinder_gigabytes', 100, 0, null, 'Volume', 4);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('7', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'Backups', 'nova_backup', 50, 0, null, 'Backup', -1);

insert into om_quota_class (`id`, `create_date`, `update_date`, `name`, `resource`,`resource_id`, `hard_limit`, `deleted`, `delete_date`, `resource_type`, `dc_type`)
values('8', '2015-03-23 00:00:00.0', '2015-03-23 00:00:00.0', 'default', 'Snapshots', 'nova_snapshot', 50, 0, null, 'Snapshot', -1);


drop table if exists om_quotas;
CREATE TABLE om_quotas (
	id						varchar(64)				not null,
	create_date				datetime				not null,
	update_date				datetime				not null,
	dc_id					varchar(64)				not null,
	dc_type					int						not null,
	tenant_id				varchar(64)				not null,
	resource_id				varchar(64)				not null,
	resource				varchar(100)			not null,
	resource_type			varchar(50)				null,
	in_use					numeric					default 0	not null,
	hard_limit				numeric					not null,
	PRIMARY KEY(id)
);

drop table if exists vmware_flavors;
create table vmware_flavors (
	name			varchar(255)		not null,
	id				varchar(64)			not null,
	memory_mb		int(11)				not null,
	vcpus			int(11)				not null,
	root_gb			int(11)				default null,
	disabled		tinyint(1)			default 0		not null,
	is_public		tinyint(1)			default 1		not null,
	dc_id			varchar(64) 		not null,
	dc_type			int					not null,
	deleted			int					default 0		not null
);

drop table if exists t_zone;
create table t_zone
(
	dc_id              varchar(100) not null,
	id                 varchar(100) not null,
	name               varchar(100) not null,
	primary key (id, dc_id)
);

drop table if exists t_aggregate;
create table t_aggregate
(
	dc_id              varchar(100)  not null,
	zone_id            varchar(100)  not null,
	id                 varchar(100)  not null,
	name               varchar(100)  not null,
    metadata           varchar(1000) null,
    created_at         varchar(50)   null,
    deleted            varchar(10)   null,
    deleted_at         varchar(50)   null,
	primary key (id, dc_id)
);

drop table if exists t_host;
create table t_host
(
	dc_id              varchar(100)  not null,
	zone_id            varchar(100)  not null,
	aggregate_id       varchar(100)  not null,
	id                 varchar(100)  not null,
	name               varchar(100)  not null,
    ip                 varchar(100)  not null,
    status             varchar(50)   null,
    hypervisor_type    varchar(50)   null,
    vcpus              int           null,
    vcpusused          int           null,
    memory             int           null,
    memoryused         int           null,
    memoryfree         int           null,    
    runningvms         int           null,
	primary key (id, name, dc_id)
);

drop table if exists t_vm;
create table t_vm
(
	dc_id              varchar(100)   not null,
	zone_id            varchar(100)   null,
	aggregate_id       varchar(100)   null,
    host_id            varchar(100)   null,
	id                 varchar(100)   not null,
	name               varchar(100)   not null,
    power_state        varchar(50)    null,
    status             varchar(50)    null,
    address            text           null,
    memory             int            null,
    cpu_count          int            null,
    flavor             varchar(1000)  null,
    os_name            varchar(100)   null,
    disk_size          int            null,
    vnc_enable         varchar(10)    null,
    vnc_port           varchar(10)    null,
    vnc_password       varchar(100)   null,
    imgage             varchar(1000)  null,
    task_state         varchar(50)    null,
    availability_zone  varchar(100)   null,
    host               varchar(100)   null,
    hypervisorname     varchar(100)   null,
    tenant_id          varchar(100)   null,
	primary key (id, dc_id)    
);
