use zxinsys;

-- OMMP6.01.10U1 bug
delete from portal_sysparam where param_name='FLOOTMSG';
insert into portal_sysparam(param_name,param_value, param_desc, paramgroup, description, field_type, max_value, min_value, visiblelevel) values('FLOOTMSG','','Add description at bottom of Home', 'System Configuration','Description information (such as: Contact: xxxx Phone: xxxx)', 2, 100, 0, 1);



-- update logo
update portal_sysparam set param_value = 'iROS' where param_name = 'LOGINMSG';

-- Join Menu not By ID
-- update portal_sysparam set param_value = '0' where param_name = 'IsJoinMenuByID';

-- edit homepage
update portal_sysparam set param_value = '2' where param_name = 'IS_SET_HOMEPAGE';
update portal_sysparam set param_value = '/pages/irosopsm/pages/frame/rms-homepage.jsp' where param_name = 'HOMEPAGE_URL';
-- hide left view
update portal_sysparam set param_value = '2' where param_name = 'IS_NEED_HEADER_LEFT';
-- delete “Resource” and “Configuration” menus
delete from oper_funcgrp2 where funcgrpid in ( 2, 4, 12);
delete from oper_function where funcgrpid in ( 2, 4, 12);
delete from oper_grpdef where servicekey = 'uniportal';
insert into oper_grpdef select 1000,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal';
insert into oper_grpdef select 1001,funcgrpid,funcid,'uniportal' from oper_function   where servicekey='uniportal' and funcgrpid not in (2);

-- delete alarm and measure menus
-- delete from oper_funcgrp2 where funcgrpid =1 and servicekey='uniportal';
-- delete from oper_funcgrp2 where funcgrpid =3 and servicekey='uniportal';
delete from oper_funcgrp2 where funcgrpid =10 and servicekey='uniportal';

-- delete from oper_function where funcgrpid=1 and servicekey='uniportal';
-- delete from oper_function where funcgrpid=3 and servicekey='uniportal';
delete from oper_function where funcgrpid=10 and servicekey='uniportal';

-- delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =1;
-- delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =3;
delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =10;


-- call proc_res_op_paratype(0 ,2, 101, '');		-- remove restype of operlog [fault]
-- call proc_res_op_paratype(0 ,2, 102, '');		-- remove restype of operlog [measure]
call proc_res_op_paratype(0 ,2, 103, '');		-- remove restype of operlog [resource_manage]
call proc_res_op_paratype(0 ,2, 105, '');		-- remove restype of operlog [log_manage]

-- ***********************************************************************************************
-- *       Initialization Part                                                                   *
-- ***********************************************************************************************
-- use zxinsys
-- go
-- exec OMMP procedure to create role and user group
-- ***********************************************************************************************
-- *       Role and user group Initialization Part                                               *
-- ***********************************************************************************************

-- Create new role：
-- proc_res_op_grpscript2 product ID，update type(add-1,del-2)，role id，role name

call proc_res_op_grpscript2(0, 1, 102, 'DC Management', 'DC Management');
call proc_res_op_grpscript2(0, 1, 103, 'Tenant Management', 'Tenant Management');
call proc_res_op_grpscript2(0, 1, 104, 'VDC Management', 'VDC Management'); 
call proc_res_op_grpscript2(0, 1, 105, 'Ticket Management', 'Ticket Management'); 
call proc_res_op_grpscript2(0, 1, 106, 'Compute Room Management', 'Compute Room Management');
call proc_res_op_grpscript2(0, 1, 107, 'Compute Room Ticket Management', 'Compute Room Ticket Management');
call proc_res_op_grpscript2(0, 1, 108, 'Compute Room Ticket handler', 'Compute Room Ticket handler');
call proc_res_op_grpscript2(0, 1, 110, 'VDC Auditor', 'VDC Auditor');

-- Grand right to new role：
-- DC Management：
-- proc_res_op_grpdef product ID，update type(add-1,del-2)，role id， right group id，right id
call proc_res_op_grpdef(0, 1, 102, 11, 18102);
call proc_res_op_grpdef(0, 1, 102, 1396, 139615);
call proc_res_op_grpdef(0, 1, 102, 1396, 139620);
call proc_res_op_grpdef(0, 1, 102, 1396, 139604);
-- Tenant Management：
-- proc_res_op_grpdef product ID，update type(add-1,del-2)，role id， right group id，right id
call proc_res_op_grpdef(0, 1, 103, 11, 18102);
call proc_res_op_grpdef(0, 1, 103, 1396, 139602);

-- VDC Management：
-- proc_res_op_grpdef product ID，update type(add-1,del-2)，role id， right group id，right id
call proc_res_op_grpdef(0, 1, 104, 1396, 139602);
call proc_res_op_grpdef(0, 1, 104, 1396, 139616);

call proc_res_op_grpdef(0, 1, 105, 1396, 139618);
call proc_res_op_grpdef(0, 1, 105, 11, 18102);
call proc_res_op_grpdef(0, 1, 105, 1396, 139610);

call proc_res_op_grpdef(0, 1, 106, 11, 18102);
call proc_res_op_grpdef(0, 1, 106, 1396, 139640);
call proc_res_op_grpdef(0, 1, 106, 1396, 139610);
call proc_res_op_grpdef(0, 1, 106, 1396, 139605);

call proc_res_op_grpdef(0, 1, 107, 11, 18102);
call proc_res_op_grpdef(0, 1, 107, 1396, 139610);
call proc_res_op_grpdef(0, 1, 107, 1396, 139618);

call proc_res_op_grpdef(0, 1, 108, 11, 18102);
call proc_res_op_grpdef(0, 1, 108, 1396, 139610);
call proc_res_op_grpdef(0, 1, 108, 1396, 139618);

-- Ticket Management:
call proc_res_op_grpdef(0, 1, 105, 1396, 139618);
call proc_res_op_grpdef(0, 1, 105, 11, 18102);
call proc_res_op_grpdef(0, 1, 105, 1396, 139610);

-- Compute Room Management:
call proc_res_op_grpdef(0, 1, 106, 11, 18102);
call proc_res_op_grpdef(0, 1, 106, 1396, 139640);
call proc_res_op_grpdef(0, 1, 106, 1396, 139610);
call proc_res_op_grpdef(0, 1, 106, 1396, 139605);

-- Compute Room Ticket Management:
call proc_res_op_grpdef(0, 1, 107, 11, 18102);
call proc_res_op_grpdef(0, 1, 107, 1396, 139610);
call proc_res_op_grpdef(0, 1, 107, 1396, 139618);

-- Compute Room Ticket handler:
call proc_res_op_grpdef(0, 1, 108, 11, 18102);
call proc_res_op_grpdef(0, 1, 108, 1396, 139610);
call proc_res_op_grpdef(0, 1, 108, 1396, 139618);

-- VDC Auditor
call proc_res_op_grpdef(0, 1, 110, 11, 18102);
call proc_res_op_grpdef(0, 1, 110, 1396, 139610);
call proc_res_op_grpdef(0, 1, 110, 1396, 139643);

-- Create new user group：
-- proc_res_op_v_grpdef product ID，update type(add-1,del-2)，user group id， group desc

call proc_res_op_v_grpscript(0, 1, 6102, 'DC Manager Group');
call proc_res_op_v_grpscript(0, 1, 6103, 'Tenant Manager Group');
call proc_res_op_v_grpscript(0, 1, 6104, 'VDC Manager Group');
call proc_res_op_v_grpscript(0, 1, 6122, 'Ticket Manager Group');
call proc_res_op_v_grpscript(0, 1, 6123, 'Ticket Handler Group');
call proc_res_op_v_grpscript(0, 1, 6124, 'Compute Room Manager Group');
call proc_res_op_v_grpscript(0, 1, 6125, 'Compute Room Ticket Manager Group');
call proc_res_op_v_grpscript(0, 1, 6126, 'Compute Room Ticket Handler Group');
call proc_res_op_v_grpscript(0, 1, 6142, 'First Level VDC Auditor Group');
call proc_res_op_v_grpscript(0, 1, 6143, 'Second Level VDC Auditor Group');

-- Grand role to new user group：
-- proc_res_op_v_grpdef product ID，update type(add-1,del-2)，user group id， role id

call proc_res_op_v_grpdef(0, 1, 6102, 102);
call proc_res_op_v_grpdef(0, 1, 6103, 103);
call proc_res_op_v_grpdef(0, 1, 6104, 104);
call proc_res_op_v_grpdef(0, 1, 6122, 105);
call proc_res_op_v_grpdef(0, 1, 6123, 105);
call proc_res_op_v_grpdef(0, 1, 6124, 106);
call proc_res_op_v_grpdef(0, 1, 6125, 107);
call proc_res_op_v_grpdef(0, 1, 6126, 108);
call proc_res_op_v_grpdef(0, 1, 6142, 110);
call proc_res_op_v_grpdef(0, 1, 6143, 110);

-- Grand role to super's user group：
-- proc_res_op_v_grpdef product ID，update type(add-1,del-2)，user group id， role id

call proc_res_op_v_grpdef(0,1,1000,102);
call proc_res_op_v_grpdef(0,1,1001,102);
call proc_res_op_v_grpdef(0,1,1000,103);
call proc_res_op_v_grpdef(0,1,1001,103);
call proc_res_op_v_grpdef(0,1,1000,104);
call proc_res_op_v_grpdef(0,1,1001,104);
call proc_res_op_v_grpdef(0,1,1000,105);
call proc_res_op_v_grpdef(0,1,1001,105);
call proc_res_op_v_grpdef(0,1,1000,106);
call proc_res_op_v_grpdef(0,1,1001,106);
call proc_res_op_v_grpdef(0,1,1000,107);
call proc_res_op_v_grpdef(0,1,1001,107);
call proc_res_op_v_grpdef(0,1,1000,108);
call proc_res_op_v_grpdef(0,1,1001,108);
call proc_res_op_v_grpdef(0,1,1000,110);
call proc_res_op_v_grpdef(0,1,1001,110);

delete from oper_rights2 where operid = 1 and servicekey = 'uniportal' and opergrpid = 6122;
insert into oper_rights2 (operid, servicekey, opergrpid) values(1, 'uniportal', 6122);
delete from oper_rights2 where operid = 1 and servicekey = 'uniportal' and opergrpid = 6123;
insert into oper_rights2 (operid, servicekey, opergrpid) values(1, 'uniportal', 6123);

delete from opergrp_homepage where v_opergrpid = 6122 and servicekey = 'uniportal' and homepage = '';
insert into opergrp_homepage (v_opergrpid, servicekey, homepage) values (6122, 'uniportal','');
delete from opergrp_homepage where v_opergrpid = 6123 and servicekey = 'uniportal' and homepage = '';
insert into opergrp_homepage (v_opergrpid, servicekey, homepage) values (6123, 'uniportal','');

delete from oper_information2 where operid in(3,4);
insert into oper_information2 (operid,opername,operpwd,operdescription,operallname ,creatorid,pwdhintday,pwdhintnum,initpwd,trait) 
    values  (3,'level1','!@#$%^SXrlgdxUjGmM9b4P8f/GaA==','First Level VDC Auditor','First Level VDC Auditor',1,0,5,' ','a');
insert into oper_information2 (operid,opername,operpwd,operdescription,operallname ,creatorid,pwdhintday,pwdhintnum,initpwd,trait) 
    values  (4,'level2','!@#$%^rdDNMAnl/Z1lM+gtF9zs6A==','Second Level VDC Auditor','Second Level VDC Auditor',1,0,5,' ','a');
	
delete from oper_rights2 where operid in(3,4);
insert into oper_rights2 (operid, servicekey,opergrpid,param1,param2,param3,param4) values(3,'uniportal',6142,0,0,-1,-1);
insert into oper_rights2 (operid, servicekey,opergrpid,param1,param2,param3,param4) values(4,'uniportal',6143,0,0,-1,-1);

call proc_res_op_funcgrp2(0 ,1, 1396, 'Cloud Management');
call proc_res_op_function(0, 1, 1396, 139602,'User Management');
call proc_res_op_function(0, 1, 1396, 139603,'Price Management');
call proc_res_op_function(0, 1, 1396, 139604,'Resource Management');
call proc_res_op_function(0, 1, 1396, 139606,'Operation Log');
call proc_res_op_function(0, 1, 1396, 139610,'Operation Maintenance');
call proc_res_op_function(0, 1, 1396, 139612,'Security Log');
call proc_res_op_function(0, 1, 1396, 139613,'Log Backup Configuration');
call proc_res_op_function(0, 1, 1396, 139607,'Backup Management');
call proc_res_op_function(0, 1, 1396, 139608,'Alarm Address Config');
call proc_res_op_function(0, 1, 1396, 139618,'Ticket Management');
call proc_res_op_function(0, 1, 1396, 139615,'Template Management');
call proc_res_op_function(0, 1, 1396, 139616,'instance Management');
call proc_res_op_function(0, 1, 1396, 139619,'Function Control');
call proc_res_op_function(0, 1, 1396, 139624,'Log Collect');
call proc_res_op_function(0, 1, 1396, 139620,'Device Monitor');
call proc_res_op_function(0, 1, 1396, 139640,'Compute Room Management');
call proc_res_op_function(0, 1, 1396, 139642,'License Management');
call proc_res_op_function(0, 1, 1396, 139644,'Antivirus');
call proc_res_op_function(0, 1, 1396, 139645,'Evaluation');
call proc_res_op_function(0, 1, 1396, 139646,'Advanced');

update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139615 and servicekey='uniportal';
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139616 and servicekey='uniportal';

delete from portal_sysparam where param_name = 'default_admin_rolename';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('default_admin_rolename','admin','Default admin role type name','iROS','Default admin role type name',
             2,100,0,'',1,
             '','','','','');

delete from portal_sysparam where param_name = 'default_member_rolename';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('default_member_rolename','_member_','Default member role type name','iROS','Default member role type name',
             2,100,0,'',1,
             '','','','','');

delete from portal_sysparam where param_name = 'admin_portal_ftp_username';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('admin_portal_ftp_username','root','The SFTP Username of Admin Portal Server','iROS','The SFTP Username of Admin Portal Server',
             2,100,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'admin_portal_ftp_password';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('admin_portal_ftp_password','!@#$%^CHLGT/zyq2aAWUc1bEeChQ==','The SFTP Password of Admin Portal Server','iROS','The SFTP Password of Admin Portal Server',
             5,100,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'admin_portal_ftp_port';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('admin_portal_ftp_port','22','The SFTP Port of Admin Portal Server','iROS','The SFTP Port of Admin Portal Server',
             2,100,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'remote_syn_user';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_syn_user','','The 4A synchronization user information call address','iROS','The 4A synchronization user information call address',
             2,100,0,' ',1,
             '','','','','');

delete from portal_sysparam where param_name = 'remote_idcim_host';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_idcim_host','','To obtain the physical host list call address','iROS','To obtain the physical host list call address',
             2,100,0,' ',1,
             '','','','','');			 
			 			 
delete from portal_sysparam where param_name = 'iros_backup_shell_path';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_backup_shell_path','/home/iros/db_bak','backup shell file directory','iROS','backup shell file directory',
             2,100,0,'/home/iros/db_bak',0,
             '','','','','');

delete from portal_sysparam where param_name = 'volume_upper_limit';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('volume_upper_limit','500','Upper Limit of Volume(GB)','iROS','Upper Limit of Volume(GB)',
             2,100,0,' ',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'om_support_hr';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('om_support_hr', '0', 'Is support hr authentication', 'iROS', 'Is support hr authentication', 
			4, null, null, '1-yes,0-no', 1, 
			'', '', '', '', '');
			
delete from portal_sysparam where param_name = 'hr_server_url';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('hr_server_url', 'http://tech.zte.com.cn/tech/xmlrpc', 'hr auth url', 'iROS', 'hr auth url', 
			2, 100, 0, '', 0, 
			'', '', '', '', '');

delete from portal_sysparam where param_name = 'BAK_TASK_DAY';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('BAK_TASK_DAY','1','Management Data Backup Day','System Configuration','Management Data Backup Day, when back up interval is week, please input 1-7, 1 is monday，7 is sunday, when more then 7, then the backup day is sunday. When back up interval is month, please input 1-31, 1 is first day of month, 31 is last day of month.',
             1,31,1,'1',1,
             '','','','','');

delete from portal_sysparam where param_name = 'eazy_cloud_ip';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_ip','','Eazy Cloud Data synchronization IP address','iROS','Eazy Cloud Data synchronization IP address',
             2,1000,0,'',1,
             '','','','','');	

delete from portal_sysparam where param_name = 'eazy_cloud_port';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_port','','Eazy Cloud Data synchronization Port','iROS','Eazy Cloud Data synchronization Port',
             2,1000,0,'',1,
             '','','','','');	

delete from portal_sysparam where param_name = 'eazy_cloud_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_control','0','Eazy Cloud Control','iROS','Eazy Cloud Control',
             4,1000,1,'0-close, 1-open',1,
             '','','','','');	

-- delete from portal_sysparam where param_name = 'charge_tip_day';
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('charge_tip_day','3','Day of Balance Warning','iROS','The config day bigger than the day of the balance to maintain the resource, then the system warn the user',
--              1,1000,1,'3',1,
--              '','','','','');   
--              
-- delete from portal_sysparam where param_name = 'charge_mail_control';
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('charge_mail_control','1','Balance Warning Mail switch','iROS','Is send the warning mail when the balance is insufficient',
--              4,1000,1,'0-Not warn, 1-warn',1,
--              '','','','',''); 
-- 
-- delete from portal_sysparam where param_name = 'charge_switch_control';
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('charge_switch_control','0','Charge Switch','iROS','Charge Switch',
--              4,1000,1,'0-close, 1-open',1,
--              '','','','','');
--              
-- delete from portal_sysparam where param_name = 'resource_close_day';
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('resource_close_day','10','the resource keep running days when tenant arrearage','iROS','the resource keep running days when tenant arrearage',
--              1,1000,1,'10',1,
--              '','','','',''); 
-- 			 			 
-- delete from portal_sysparam where param_name = 'iros_ticket_attachment_path';
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('iros_ticket_attachment_path','/home/zxin10/was/tomcat/webapps/workorder/attachment','Ticket attachment path','iROS','Ticket attachment path',
--              2,100,0,'/home/zxin10/was/tomcat/webapps/workorder/attachment',1,
--              '','','','','');
-- 			 
-- delete from portal_sysparam where param_name = 'ticket_switch_control';
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('ticket_switch_control','0','Ticket Switch','iROS', 'Ticket Switch',
--              4,1000,1,'0-close, 1-open',1,
--              '','','','','');
			 
delete from portal_sysparam where param_name = 'compute_threshold';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('compute_threshold', '0', 'The Switch of Compute Threshold Configuration', 'iROS', 'The Switch of Compute Threshold Configuration', 
			4, null, null, '1-ON,0-OFF', 0, 
			'', '', '', '', '');

delete from portal_sysparam where param_name = 'idcim_switch_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_switch_control','0','Mix IDCIM Switch','iROS','Mix IDCIM Switch',
             4,1000,1,'1-ON,0-OFF',1,
             '','','','','');
             
delete from portal_sysparam where param_name = 'idcim_restful_url';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_restful_url','http://127.0.0.1:21180','Common URL of IDCIM Restful','iROS','Common URL of IDCIM Restful',
             2,1000,0,'',1,
             '','','','','');

			 
			 
delete from portal_sysparam where param_name = 'res_tree_root_title';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('res_tree_root_title','Computing Center','The Root Node Label of Resource Tree','iROS','The Root Node Label of Resource Tree',
             2,100,0,' ',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'org_tree_root_title';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('org_tree_root_title','Tenant Center','The Root Node Label of Tenant Tree','iROS','The Root Node Label of Tenant Tree',
             2,100,0,' ',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'ade_path';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('ade_path','','ADE ADDRESS','iROS','ADE ADDRESS',
             2,1000,0,'',1,
             '','','','','');	

delete from portal_sysparam where param_name = 'cmdb_switch_control';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('cmdb_switch_control','0','CMDB Control Switch','iROS','CMDB Control Switch',
             4,1000,1,'1-ON,0-OFF',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'corePoolSize';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('corePoolSize','100','Core pool size','iROS','Core pool size',
             2,1000,0,'',0,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'keepAliveTime';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('keepAliveTime','3','Keep alive time','iROS','Keep alive time,unit:seconds',
             2,100,0,'',0,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'keepMonths';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('keepMonths','6','Performance data retention time','iROS','Performance data retention time,unit:Monthly',
             2,100,0,'',1,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'maximumPoolSize';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('maximumPoolSize','200','Maximum pool size','iROS','Maximum pool size',
             2,100,0,'',0,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'workQueueSize';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('workQueueSize','200','Work queue size','iROS','Work queue size',
             2,100,0,'',0,
             '','','','','');
			 
delete from portal_sysparam where param_name = 'bandwidthUtilizationKeepMonths';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('bandwidthUtilizationKeepMonths','6','Bandwidth utilization statistics retention time','iROS','Bandwidth utilization statistics retention time,unit:Monthly',
             2,100,0,'',1,
             '','','','','');
             
delete from portal_sysparam where param_name = 'iros_overdue_res_email_tip_days';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_overdue_res_email_tip_days','7','Several days in advance to send the email when resource expired.','iROS','Several days in advance to send the email when resource expired.',
             2,100,0,'',1,
             '','','','','');
             
delete from portal_sysparam where param_name = 'iros_overdue_res_close';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('iros_overdue_res_close', '0', 'Close the resource when the resource expired.', 'iROS', 'Close the resource when the resource expired.', 
			4, null, null, '1-close, 0-not close', 1, 
			'', '', '', '', '');
           
delete from portal_sysparam where param_name = 'image_delete_interval';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('image_delete_interval','180','Default compare time of delete downloaded image','iROS','Default compare time of delete downloaded image(MINUTE)',
             2,100,0,'',0,
             '','','','','');


			
use iros;

drop table if exists iros_version_info;
CREATE TABLE iros_version_info ( 
	name						varchar(100) 	NOT NULL,
	version				        varchar(200) 	NULL,
	extra						varchar(500) 	NULL
);
insert into iros_version_info (name, version, extra) values('iROS', 'ZXCLOUD-iROSV4.04.06T04', '');
insert into iros_version_info (name, version, extra) values('OMMP', 'ZXCLOUD-OMMPV6.01.13', '');

drop table if exists om_control_function;
CREATE TABLE om_control_function ( 
	id      varchar(64) NOT NULL,
	name    varchar(64) NULL,
	control varchar(200) NULL,  
	primary key (id)
);
insert into om_control_function values ('order_switch_control', 'Order Switch','1');
insert into om_control_function values ('ticket_switch_control','Ticket Switch', '1');
insert into om_control_function values ('iros_ticket_attachment_path', 'Ticket accessory storage path','/home/zxin10/was/tomcat/webapps/workorder/attachment');
insert into om_control_function values ('ade_switch_control','ADE Switch', '0');
insert into om_control_function values ('ade_path','ADE Interface address', 'http://10.129.172.20:8103/ade');
insert into om_control_function values ('charge_switch_control', 'Billing Switch','0');
insert into om_control_function values ('charge_system', 'Charge System','0');
insert into om_control_function values ('jm_url_path', 'JiangMen Port Address','http://127.0.0.1:8780/csm');
insert into om_control_function values ('charge_mail_control','Balance insufficient e-mail alert switch', '0');
insert into om_control_function values ('charge_tip_day','Insufficient balance reminder', '3');
insert into om_control_function values ('resource_close_day','Resource reservation a few days after the arrears', '10');
insert into om_control_function values ('drs_switch_control','DRS Switch', '0');
insert into om_control_function values ('nubosh_switch_control', 'Cloud Security Switch','1');
insert into om_control_function values ('antivurs_url', 'Antivirus Service URL','https://127.0.0.1:8443');
insert into om_control_function values ('antivurs_user', 'Antivirus Service User','extapiuser');
insert into om_control_function values ('antivurs_password', 'Antivirus Service Password','vMsec#1.');
insert into om_control_function values ('antivurs_sso_aes_password', 'Nubosh Single Sign On AES Key','ZTE&nubosh#T0en');
insert into om_control_function values ('phydevice_switch_control', 'Physical Device Switch','0'); 
insert into om_control_function values ('evaluate_switch_control','Evaluation Switch', '0');
insert into om_control_function values ('evaluate_period','Evaluate Month(s)', '');
insert into om_control_function values ('vdc_user_register_control','User Register Switch', '0');

drop table if exists os_name_config;
create table os_name_config 
( 
	os_id        			varchar(100) 		not null,		
	os_type        			varchar(20) 		not null,		
	os_name        			varchar(100) 		not null,		
    primary key(os_id)
);

insert into os_name_config(os_id, os_type, os_name) values('1','Windows','Microsoft Windows 7(32)');
insert into os_name_config(os_id, os_type, os_name) values('2','Windows','Microsoft Windows 7(64)');
insert into os_name_config(os_id, os_type, os_name) values('3','Windows','Microsoft Windows Server 2003,Enterprise Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('4','Windows','Microsoft Windows Server 2003,Enterprise Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('5','Windows','Microsoft Windows Server 2003,Datacenter Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('6','Windows','Microsoft Windows Server 2003,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('7','Windows','Microsoft Windows Server 2003,Standard Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('8','Windows','Microsoft Windows Server 2003,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('9','Windows','Microsoft Windows Server 2003,Web Edition');
insert into os_name_config(os_id, os_type, os_name) values('10','Windows','Microsoft Windows XP Professional(32)');
insert into os_name_config(os_id, os_type, os_name) values('11','Windows','Microsoft Windows XP Professional(64)');
insert into os_name_config(os_id, os_type, os_name) values('12','Linux','Suse Linux Enterprise 11(32)');
insert into os_name_config(os_id, os_type, os_name) values('13','Linux','Suse Linux Enterprise 11(64)');
insert into os_name_config(os_id, os_type, os_name) values('14','Linux','Suse Linux Enterprise 10(32)');
insert into os_name_config(os_id, os_type, os_name) values('15','Linux','Suse Linux Enterprise 10(64)');
insert into os_name_config(os_id, os_type, os_name) values('16','Linux','Carrier Grade SERVER Linux 3(32)');
insert into os_name_config(os_id, os_type, os_name) values('17','Linux','Carrier Grade SERVER Linux 3(64)');
insert into os_name_config(os_id, os_type, os_name) values('18','Linux','Carrier Grade SERVER Linux 4(32)');
insert into os_name_config(os_id, os_type, os_name) values('19','Linux','Carrier Grade SERVER Linux 4(64)');
insert into os_name_config(os_id, os_type, os_name) values('20','Linux','Red Hat Enterprise Linux 5.5(64)');
insert into os_name_config(os_id, os_type, os_name) values('21','Linux','Red Hat Enterprise Linux 5.5(32)');
insert into os_name_config(os_id, os_type, os_name) values('22','Linux','CentOS Linux 5.6(64)');
insert into os_name_config(os_id, os_type, os_name) values('23','Linux','CentOS Linux 5.6(32)');
insert into os_name_config(os_id, os_type, os_name) values('24','Linux','Other Linux');
insert into os_name_config(os_id, os_type, os_name) values('25','Windows','Other Windows');
insert into os_name_config(os_id, os_type, os_name) values('26','Windows','Microsoft Windows Server 2008,Enterprise Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('27','Windows','Microsoft Windows Server 2008,Enterprise Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('28','Windows','Microsoft Windows Server 2008,Datacenter Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('29','Windows','Microsoft Windows Server 2008,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('30','Windows','Microsoft Windows Server 2008,Standard Edition(32)');
insert into os_name_config(os_id, os_type, os_name) values('31','Windows','Microsoft Windows Server 2008,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('32','Linux','Red Hat Enterprise Linux 6(64)');
insert into os_name_config(os_id, os_type, os_name) values('33','Linux','Red Hat Enterprise Linux 6(32)');
insert into os_name_config(os_id, os_type, os_name) values('34','Linux','CentOS Linux 6(64)');
insert into os_name_config(os_id, os_type, os_name) values('35','Linux','CentOS Linux 6(32)');
insert into os_name_config(os_id, os_type, os_name) values('36','Windows','Microsoft Windows Server 2012,Enterprise Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('37','Linux','CentOS Linux 6.5(64)');
insert into os_name_config(os_id, os_type, os_name) values('38','Linux','CentOS Linux 6.5(32)');
insert into os_name_config(os_id, os_type, os_name) values('39','Windows','Microsoft Windows Server 2012,Foundation Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('40','Linux','Ubuntu 12.04(64)');
insert into os_name_config(os_id, os_type, os_name) values('41','Linux','Ubuntu 12.04(32)');
insert into os_name_config(os_id, os_type, os_name) values('42','Linux','Red Hat Enterprise Linux 5.8(64)');
insert into os_name_config(os_id, os_type, os_name) values('43','Linux','Red Hat Enterprise Linux 5.8(32)');
insert into os_name_config(os_id, os_type, os_name) values('44','Linux','CentOS Linux 6.4(64)');
insert into os_name_config(os_id, os_type, os_name) values('45','Linux','CentOS Linux 6.4(32)');
insert into os_name_config(os_id, os_type, os_name) values('46','Linux','Carrier Grade SERVER Linux 5(32)');
insert into os_name_config(os_id, os_type, os_name) values('47','Linux','Carrier Grade SERVER Linux 5(64)');
insert into os_name_config(os_id, os_type, os_name) values('48','Linux','CentOS Linux 7.0(64)');
insert into os_name_config(os_id, os_type, os_name) values('49','Linux','Red Hat Enterprise Linux 6.5(64)');
insert into os_name_config(os_id, os_type, os_name) values('50','Linux','Red Hat Enterprise Linux 6.5(32)');
insert into os_name_config(os_id, os_type, os_name) values('51','Linux','Red Hat Enterprise Linux 7.0(64)');
insert into os_name_config(os_id, os_type, os_name) values('52','Windows','Microsoft Windows 8(32)');
insert into os_name_config(os_id, os_type, os_name) values('53','Windows','Microsoft Windows 8(64)');
insert into os_name_config(os_id, os_type, os_name) values('54','Windows','Microsoft Windows 8.1(32)');
insert into os_name_config(os_id, os_type, os_name) values('55','Windows','Microsoft Windows 8.1(64)');
insert into os_name_config(os_id, os_type, os_name) values('56','Linux','Ubuntu 14.04 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('57','Linux','CentOS Linux 6.3 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('58','Linux','CentOS Linux 6.4 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('59','Linux','CentOS Linux 6.5 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('60','Linux','CentOS Linux 4(64)');
insert into os_name_config(os_id, os_type, os_name) values('61','Linux','CentOS Linux 4(32)');
insert into os_name_config(os_id, os_type, os_name) values('62','Linux','CentOS Linux 5(64)');
insert into os_name_config(os_id, os_type, os_name) values('63','Linux','CentOS Linux 5(32)');
insert into os_name_config(os_id, os_type, os_name) values('64','Linux','NewStart Destop Linux Office Editon(64)');
insert into os_name_config(os_id, os_type, os_name) values('65','Linux','Red Hat Enterprise Linux 5.8 Enterprise Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('66','Linux','Red Hat Enterprise Linux 6.3 Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('67','Linux','Red Hat Enterprise Linux 5(64)');
insert into os_name_config(os_id, os_type, os_name) values('68','Linux','Red Hat Enterprise Linux 5(32)');
insert into os_name_config(os_id, os_type, os_name) values('69','Linux','Red Hat Enterprise Linux 4(64)');
insert into os_name_config(os_id, os_type, os_name) values('70','Linux','Red Hat Enterprise Linux 4(32)');
insert into os_name_config(os_id, os_type, os_name) values('71','Linux','Suse Linux Enterprise 12(32)');
insert into os_name_config(os_id, os_type, os_name) values('72','Linux','Suse Linux Enterprise 12(64)');
insert into os_name_config(os_id, os_type, os_name) values('73','Windows','Microsoft Windows 10(32)');
insert into os_name_config(os_id, os_type, os_name) values('74','Windows','Microsoft Windows 10(64)');
insert into os_name_config(os_id, os_type, os_name) values('75','Windows','Microsoft Windows Server 2008 R2,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('76','Windows','Microsoft Windows Server 2008 R2,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('77','Windows','Microsoft Windows Server 2012 R2,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('78','Windows','Microsoft Windows Server 2012 R2,Standard Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('79','Windows','Microsoft Windows Server 2012,Datacenter Edition(64)');
insert into os_name_config(os_id, os_type, os_name) values('80','Windows','Microsoft Windows Server 2012,Standard Edition(64)');

drop table if exists resource_price;
CREATE TABLE resource_price (
	name        			varchar(100) 		not null,	
    groups        			int         		not null,
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
    unit                    varchar(50)         not null,
	sub_type                varchar(100)        null,
	price  			        numeric(20, 5) 		not null,
	description             varchar(100)        null   
);

insert into resource_price (name, groups, type, unit, description, price) values ('CPU', 1, 2, 'Dollar/Core', 'price of 1 core in period time', 0.05);
insert into resource_price (name, groups, type, unit, description, price) values ('Momory', 1, 3, 'Dollar/GB', 'price of 1GB in period time', 0.05);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('AIX System Disk', 1, 4, 'Dollar/GB', 'AIX', 'price of AIX os disk per GB in period time', 0.002);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Linux System Disk', 1, 4, 'Dollar/GB', 'Linux', 'price of Linux os disk per GB in period time', 0.001);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Windows System Disk', 1, 4, 'Dollar/GB', 'Windows', 'price of Windows os disk per GB in period time', 0.002);
insert into resource_price (name, groups, type, unit, description, price) values ('Volume', 1, 7, 'Dollar/GB', 'price of 1GB in period time', 0.0006);
insert into resource_price (name, groups, type, unit, description, price) values ('Individual Image', 1, 8, 'Dollar/GB', 'price of 1GB in period time', 0.0006);

insert into resource_price (name, groups, type, unit, description, price) values ('Global IP', 3, 5, 'Dollar/each', 'price of one global Ip in period time', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('Router', 3, 6, 'Dollar/each', 'price of one router in period time', 0.01);
insert into resource_price (name, groups, type, unit, description, price) values ('Firewall', 3, 9, 'Dollar/Set', '1 set in period time', 0.1);
insert into resource_price (name, groups, type, unit, description, price) values ('LoadBalance', 3, 10, 'Dollar/Set', 'price of 1 set in period time', 0.1);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Up Bandwidth', 3, 13, 'Dollar/Mbps', 'up',  'price of 1Mbps in period time', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Down Bandwidth', 3, 13, 'Dollar/Mbps', 'down',  'price of 1Mbps in period time', 0.01);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Unlimit Up Bandwidth', 3, 13, 'Dollar', 'unlimit up',  'price of unlimit up bandwidth in period time', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Unlimit Down Bandwidth', 3, 13, 'Dollar',  'unlimit down', 'price of unlimit down bandwidth in period time', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('1U', 5, 14, 'Dollar/hour',  'Rack-0', '', 0.02);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('2U', 5, 14, 'Dollar/hour',  'Rack-1', '', 0.04);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('4U', 5, 14, 'Dollar/hour',  'Rack-2', '', 0.08);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('8U', 5, 14, 'Dollar/hour',  'Rack-3', '', 0.16);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('16U', 5, 14, 'Dollar/hour',  'Rack-4', '', 0.32);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('32U', 5, 14, 'Dollar/hour',  'Rack-5', '', 0.64);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('64U', 5, 14, 'Dollar/hour',  'Rack-6', '', 1.28);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Bandwidth', 5, 15, 'Dollar/Mbps',  '', 'price of 1Mbps in period time', 2);
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Internet IP', 5, 16, 'Dollar/each',  '', 'price of one Internet IP in period time', 2);

drop table if exists resource_cost;
CREATE TABLE resource_cost (
	vdc_id   	            int                 not null,
	tenant_id               varchar(100)        not null,
	dc_id                   varchar(100)        not null,
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
	year                    int                 not null,
	month                   int                 not null,
	cost  			        numeric(20, 5) 		not null,
    resource_number         int                 not null,
	date  			        varchar(20) 		not null   
);
create index idx_resource_cost on resource_cost(vdc_id, tenant_id, dc_id, type, date);

drop table if exists t_task;
create table t_task
(
    id               varchar(64)   not null,
    dc_id            varchar(64)   not null,
    vdc_id           int           not null,
    tenant_id        varchar(100)  not null,
    resource_name    varchar(100)  not null,
    resource_id      varchar(100)  not null,
    resource_type    int           not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
    task_type        int           not null, -- 1.add 2.update 3.delete  
    status           int           not null, -- 1.begin 2.end 3.error    
    start_time       datetime      not null,
    end_time         datetime      null,
    operator         varchar(100)  null,
	operator_ip		 varchar(100)  null,
    description      text          null,
    primary key (id)
);

drop table if exists om_business_grp;
create table om_business_grp (
   id                     varchar(40)          not null,
   name                   varchar(100)         not null,
   description            varchar(300)         not null,
   image_id               varchar(40)          not null,
   flavor_id              varchar(40)          not null,
   network_id             varchar(40)          not null,
   primary key (id)
);


drop table if exists om_busigrp_instance;
create table om_busigrp_instance (
   busigrp_id             varchar(40)          not null,
   instance_id            varchar(40)          not null,
   primary key (busigrp_id, instance_id)
);


drop table if exists om_strategy;
create table om_strategy (
   id                     varchar(40)          not null,
   name                   varchar(100)         not null,
   description            varchar(300)         not null,
   cpu_rel                int                  not null,
   cpu_rel_val            int                  not null,
   mem_rel                int                  not null,
   mem_rel_val            int                  not null,
   cpu_mem_rel            int                  not null,
   duration               int                  not null,
   times                  int                  not null,
   action_type            int                  not null,
   cool_time              int                  not null,
   priority               text                 not null,
   create_time            datetime             not null,
   cool_status            int     default 0    not null,
   last_result            tinyint              null,
   last_time              datetime             null,
   next_time              datetime             null, 
   count_num              int     default 0    null,
   busigrp_id             varchar(40)          not null,
   primary key (id)
);


drop table if exists om_strategy_exec;
create table om_strategy_exec (
  id                     varchar(40)           not null,
  strategy_id	         int                   not null,
  server_ip              varchar(100)          null,
  server_id              varchar(100)          null,
  status                 tinyint               not null,
  start_time	         datetime              not null,
  end_time	             datetime              null,
  result	             tinyint               null,
  info	                 varchar(200)          null,
  primary key (id)
);

drop table if exists common_identity;
CREATE TABLE common_identity ( 
	tablename						varchar(50) 	NOT NULL,
	idvalue						int 	NULL,		
    PRIMARY KEY(tablename)
);

drop table if exists t_dc;
CREATE TABLE t_dc ( 
	dc_id							varchar(100) 	NOT NULL,
	dc_name							varchar(100) 	NOT NULL,
    dc_desc							varchar(999) 	NULL,
	common_url						varchar(100)	NULL,
	admin_url						varchar(100)	NULL,
	vmware_datacenter				varchar(100)	NULL,
	power_domainid					varchar(100)	NULL,
	power_projectname				varchar(100)	NULL,
	power_ip						varchar(64)		NULL,
	admin_username					varchar(100)	NULL,
	admin_password					varchar(100)	NULL,
	domain_id						varchar(100)	NOT NULL,
	dc_type							int				NOT NULL,
	status							int				NOT NULL,	
	extra							text	NULL,
    PRIMARY KEY(dc_id)
);

drop table if exists common_organization;

CREATE TABLE common_organization ( 
	id         	numeric(18,0) NOT NULL,
	parentid   	numeric(18,0) NOT NULL,
	name       	varchar(128) NOT NULL,
	description	varchar(256) NULL,
	creator    	numeric(18,0) NULL,
	createtime 	datetime NULL,
	tenantid   	numeric(18,0) NULL 
	);

drop table if exists om_user_info;
CREATE TABLE om_user_info ( 
	vdcid   	int NOT NULL,
	username	varchar(100) NOT NULL,
	password	varchar(128) NOT NULL,
	email   	varchar(100) NULL,
	userid  	int 		 NOT NULL,
	phone   	varchar(64)  NULL,
	orgid		varchar(64)  NULL,
	type		int 		 NULL,
	status		int 		 NULL,
	description	text,
	opinion		text,
	extra		varchar(1024) NULL,
	createdtime	datetime 		NULL,
	auditedtime	datetime 		NULL,
	PRIMARY KEY(userid) 
);

drop table if exists om_user_dc_rel;
CREATE TABLE om_user_dc_rel ( 
	userid  			int NULL,
	dcid				varchar(100) NOT NULL,
	zoneid				varchar(100) NOT NULL,
	computenodeid   	varchar(100) NULL
);

drop table if exists om_vdc;
CREATE TABLE om_vdc ( 
	vdcid   	numeric NOT NULL,
	vdcname 	varchar(64) NOT NULL,
	vdcdesc 	varchar(256) NULL,
	domainid	varchar(100) DEFAULT 0 NOT NULL,
	tenantid	varchar(64)  NULL
);

drop table if exists om_vdc_dc_rel;
CREATE TABLE om_vdc_dc_rel ( 
	vdcid        	numeric NOT NULL,
	dcid         	varchar(100) NOT NULL,
	projectid    	varchar(100) NOT NULL
);

drop table if exists om_vdc_admin_rel;
CREATE TABLE om_vdc_admin_rel ( 
	vdcid        	numeric NOT NULL,
	dcid         	varchar(100) NOT NULL,
	adminuserid  	varchar(100) NOT NULL,
	ommpuserid   	numeric NULL
);

drop table if exists om_vdc_computenode_rel;
CREATE TABLE om_vdc_computenode_rel ( 
	vdcid        	numeric NULL,
	dcid         	varchar(100) NULL,
	zoneid       	varchar(100) NULL,
	computenodeid	varchar(100) NULL 
);

drop table if exists om_service_config;
CREATE TABLE om_service_config (
   id                     varchar(40)          not null,   
   name                   varchar(100)         not null,   
   admin_url              varchar(200)         not null,   
   public_url             varchar(200)         not null,   
   internal_url           varchar(200)         not null,   
   description            varchar(300)         null, 
   service_type           varchar(100)          not null, 
   extra				  text	      null,      
    PRIMARY KEY(id)
);

use zxinsys;
call proc_res_op_paratype(0, 1, 3961, 'Cloud Management');

use iros;
drop table if exists om_res_template;
CREATE TABLE om_res_template
(
   id                   varchar(64) not null,
   dcid                 varchar(64) not null,
   name                 varchar(200) null,
   flavorid            varchar(64) null,
   imageid              varchar(64) null,
   status               varchar(10) null,
   description          varchar(400) null,
   PRIMARY KEY(id)
);

drop table if exists om_base_tree ;
CREATE TABLE om_base_tree ( 
	id						varchar(64) 	NOT NULL,   
	name						varchar(100) 	NOT NULL,   
	description						varchar(250) 	NULL,		
	parent_id						varchar(100) 	NOT NULL,
	type							int		NOT NULL,	
	extra							varchar(500)	NULL,		
    PRIMARY KEY(id)
);


drop table if exists om_oper_res_rel;
CREATE TABLE om_oper_res_rel ( 
	rel_id						varchar(64) 	NOT NULL,   
	oper_id					decimal(10) 	NOT NULL,  
	type						int		NOT NULL,	
	resource_id					varchar(100) 	NOT NULL,	
    PRIMARY KEY(rel_id)
);


drop table if exists om_oper_org_rel;
CREATE TABLE om_oper_org_rel ( 
	rel_id						varchar(64) 	NOT NULL,  
	oper_id					decimal(10) 	NOT NULL,   
	type						int		NOT NULL,
	resource_id					varchar(100) 	NOT NULL,	
    PRIMARY KEY(rel_id)
);


drop table if exists om_org_res_rel;
CREATE TABLE om_org_res_rel ( 
	rel_id						varchar(64) 	NOT NULL,  
	org_id					varchar(100) 	NOT NULL,  
	type						int		NOT NULL,	
	resource_id					varchar(100) 	NOT NULL,	
    PRIMARY KEY(rel_id)
);

drop table if exists om_vm_info_task ;
CREATE TABLE om_vm_info_task ( 
	id							varchar(64) 	NOT NULL,
	dc_id						varchar(64) 	NULL,
	dc_name						varchar(100) 	NULL,
	dc_type						varchar(2) 		NULL,
	domain_id					varchar(64) 	NULL,
	domain_name					varchar(100) 	NULL,
	zone_name					varchar(100) 	NULL,
	host_name					varchar(100) 	NULL,
	name						varchar(100) 	NULL,
	created						varchar(32) 	NULL,
	user_id						varchar(100) 	NULL,
	user_name					varchar(100) 	NULL,
	tenant_id					varchar(100) 	NULL,
	tenant_name					varchar(100) 	NULL,
	image_id					varchar(100) 	NULL,
	image_name					varchar(100) 	NULL,
	addresses					varchar(100) 	NULL,
	flavor_id					varchar(200) 	NULL,
	flavor_info					varchar(200) 	NULL,
	ip_info						varchar(1000) 	NULL,
	task_state					varchar(100) 	NULL,
	power_state					varchar(2) 		NULL,
	vm_state					varchar(100) 	NULL,
	servergroup_info			varchar(100) 	NULL,
	is_volume_attached			varchar(64) 	NULL,
	
    PRIMARY KEY(id)
);


drop table if exists om_dc_info_task ;
CREATE TABLE om_dc_info_task ( 
	dc_id							varchar(64) 	NOT NULL,
	dc_name							varchar(100) 	NOT NULL,
	dc_type							varchar(2) 		NULL,
	domain_id						varchar(64) 	NULL,
	domain_name						varchar(100) 	NULL,
	zone_count						int 	 NULL,
	host_count						int 	 NULL,
	vm_count						int 	 NULL,
	cpu_used						int		 NULL,
	cpu_all							int		 NULL,
	mem_used						bigint 	 NULL,
	mem_all							bigint      NULL,
	disk_used						int	     NULL,
	disk_all						int 	 NULL,
	volume_count					int			NULL,
	image_count						int			NULL,
	network_count					int			NULL,
	shared_network_count			int			NULL,
	external_network_count			int			NULL,
	extra							varchar(1000)	NULL,
    PRIMARY KEY(dc_id)
);

drop table if exists om_host_info_task ;
CREATE TABLE om_host_info_task ( 
	id							varchar(64) 	NOT NULL, 
	dc_id						varchar(64) 	NULL, 
	dc_name						varchar(100) 	NULL,  
	dc_type						varchar(2) 		NULL,   
	zone_name					varchar(100) 	NULL,   
	host_name					varchar(100) 	NULL,   
	host_ip						varchar(64) 	NULL,   
	status						varchar(32) 	NULL,  
	hypervisor_type				varchar(32)		NULL,   
	vcpus						int		 NULL,
	vcpus_used					int 	 NULL,
	memory_mb					bigint   NULL, 
	memory_mb_used				bigint	 NULL,
	local_gb					int 	 NULL,
	local_gb_used				int	NULL,
	running_vms					int	NULL,
    PRIMARY KEY(id)
);

drop table if exists om_zone_info_task;
CREATE TABLE om_zone_info_task ( 
	id							varchar(64) 	NOT NULL, 
	dc_id						varchar(64) 	NULL, 
	dc_name						varchar(100) 	NULL,  
	dc_type						varchar(2) 		NULL, 
	name						varchar(100) 	NULL,   
	created						varchar(64) 	NULL,
	updated						varchar(64) 	NULL
);

drop table if exists oandmconfig;
CREATE TABLE oandmconfig (
	id						varchar(64)			not null,
	name					varchar(255)		not null,	
	type					int					not null, -- 1.M 2.O
	description				text				null,
	url						varchar(255)		not null,
	dc_id					varchar(64)			not null,
	username				varchar(50)			not null,
	password				varchar(100)		not null,
	primary key (id)
);

DROP FUNCTION IF EXISTS getBaseChildren;
DELIMITER &&
CREATE FUNCTION `getBaseChildren`(parentId VARCHAR(64))
RETURNS varchar(10000)
BEGIN
	DECLARE sTemp VARCHAR(10000);
	DECLARE sTempChd VARCHAR(10000);

	SET sTemp = '$';
	SET sTempChd =parentId;

	SELECT group_concat(id) INTO sTempChd FROM om_base_tree where FIND_IN_SET(parent_id,sTempChd)>0;
	WHILE sTempChd is not null DO
		SET sTemp = concat(sTemp,',',sTempChd);
		SELECT group_concat(id) INTO sTempChd FROM om_base_tree where FIND_IN_SET(parent_id,sTempChd)>0;
	END WHILE;
	RETURN sTemp;
end&& 
DELIMITER ; 
commit;


use zxinsys;
call proc_add_res_definition('IROSOWNER', 'RESOURCE OWNER', 'ROOT', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_owner', '', null);
call proc_add_res_definition('IROSDC', 'DATA CENTER', 'IROSOWNER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_dc', '', null);
call proc_add_res_definition('IROSCLUSTER', 'CLUSTER', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_cluster', '', null);
call proc_add_res_definition('IROSHOST', 'HOST', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host', '', null);
call proc_add_res_definition('IROSVM', 'VM', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm', '', null);
call proc_add_res_definition('IROS_REPOS_GRP', 'Storage group', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp', '', null);
call proc_add_res_definition('IROS_REPOS_GRP_MANAGE', 'Storage group', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_manage', '', null);
call proc_add_res_definition('IROS_REPOS_GRP_PUB', 'Storage group', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_pub', '', null);
call proc_add_res_definition('IROS_REPOS', 'Storage', 'IROS_REPOS_GRP', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos', '', null);
call proc_add_res_definition('IROS_REPOS_MANAGE', 'Storage', 'IROS_REPOS_GRP_MANAGE', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_manage', '', null);
call proc_add_res_definition('IROS_REPOS_PUB', 'Storage', 'IROS_REPOS_GRP_PUB', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_pub', '', null);
call proc_add_res_definition('IROS_HOSTNIC', 'Host nic', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host_nic', '', null);
call proc_add_res_definition('IROS_VMNIC', 'VM nic', 'IROSVM', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm_nic', '', null);

call proc_add_oper_rmenu('IROSOWNER', 0, 'Sync Resource', '/irosopsm/resourcemanage/tree/syncOmmpResource.action',null,1,0);

use iros;
drop table if exists ent_res_owner;
create table ent_res_owner(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_dc;
create table ent_res_dc(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_cluster;
create table ent_res_cluster(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_host;
create table ent_res_host(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_vm;
create table ent_res_vm(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);


drop table if exists ent_res_repos_grp;
create table ent_res_repos_grp(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_grp_manage;
create table ent_res_repos_grp_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_grp_pub;
create table ent_res_repos_grp_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos;
create table ent_res_repos(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_manage;
create table ent_res_repos_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_repos_pub;
create table ent_res_repos_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_host_nic;
create table ent_res_host_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);

drop table if exists ent_res_vm_nic;
create table ent_res_vm_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
);


delete from ent_res_owner where entid = '1';
insert into ent_res_owner values ('1', 'iROS RESOURCE', 'IROSOWNER', 'ROOT', 'ROOT', '', 0, '', 0);

drop table if exists dc_ommp_restype_rel;
create table dc_ommp_restype_rel (
   dc_type           integer                   not null,
   dc_restype        varchar(50)               not null,
   ommp_restype      varchar(50)               not null, 
   primary key (dc_type, dc_restype)
);

-- iECS 
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP', 'IROS_REPOS_GRP');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_MANAGE', 'IROS_REPOS_GRP_MANAGE');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_PUB', 'IROS_REPOS_GRP_PUB');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS', 'IROS_REPOS');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_MANAGE', 'IROS_REPOS_MANAGE');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_PUB', 'IROS_REPOS_PUB');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMC', 'IROSDC');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VM', 'IROSVM');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'HOST', 'IROSHOST');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'POOL', 'IROSCLUSTER');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'NIC', 'IROS_HOSTNIC');
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMNETCARD', 'IROS_VMNIC');

use zxinsys;
call proc_res_op_function(0, 1, 1396, 139605,'Order Approval');
call proc_res_op_function(0, 1, 1396, 139617,'Workflow Configuration');
call proc_res_op_function(0, 1, 1396, 139630,'Lease Statistics');
call proc_res_op_function(0, 1, 1396, 139643,'VDC Approval');

delete from portal_sysparam where param_name = 'order_task_count';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('order_task_count','3','Order creation resource retry maximum number of times','iROS','Order creation resource retry maximum number of times',
             2,1000,0,'',1,
             '','','','','');

delete from portal_sysparam where param_name = 'log_collect_upper_limit';
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('log_collect_upper_limit','300','Upper limit of the number of files for Log Collection(Num)','iROS','Upper limit of the number of files for Log Collection(Num)',
             2,300,0,' ',1,
             '','','','','');
use iros;

drop table if exists om_order_task;
drop table if exists om_order_detail;
drop table if exists om_order_audit;
drop table if exists om_order;
drop table if exists om_order_process;
drop table if exists om_order_process_config;
drop table if exists om_order_sequence;
drop table if exists om_res_order_process_rel;
drop table if exists om_order_res_rel;
drop table if exists om_order_forceendservers;

create table om_order
(
   order_id             int not null,
   order_code           varchar(64) not null,
   dc_id                varchar(64),
   city_id              varchar(100),
   vdc_id               varchar(64),
   user_id              int not null,
   res_type             tinyint not null,
   oper_type            tinyint not null comment '1-Application for resources 2-Change resources 3-Recycling resources',
   process_id           int not null,
   current_step         int not null,
   start_date           datetime not null,
   end_date             datetime,
   quantity             int not null,
   primary key (order_id)
);

create table om_order_audit
(
   order_audit_id       int not null,
   order_id             int not null,
   auditor_id           int not null,
   audit_date           datetime not null,
   audit_content        varchar(500) not null,
   primary key (order_audit_id)
);

create table om_order_forceendservers
(
   id       			varchar(64) not null,
   order_id             varchar(64) not null,
   instance_id          varchar(64) not null,
   dc_id           		varchar(64) not null, 
   status        		tinyint, -- 1-Wait Delete 2-Deleting 3-Delete Failed
   primary key (id)
);

create table om_order_detail
(
   order_detail_id      int not null,
   order_id             int not null,
   order_params         text not null,
   primary key (order_detail_id)
);

create table om_order_process
(
   process_id           int not null,
   name                 varchar(50) not null,
   description          text,
   auto_step            int not null,
   is_use               tinyint not null comment '0:  Not enabled   1:  enabled',
   is_auto_deliver      tinyint not null comment '0:  Manual delivery 1:  Automatic delivery',
   primary key (process_id)
);

insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(2, 'Cloud resources application approval process', 'Suitable for instance, desktop, firewall, loadbalancer resources application approval process', 2, 0, 0);
insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(4, 'VDC application approval process', 'Suitable for VDC application approval process', 1, 0, 0);
commit;

create table om_order_process_config
(
   process_id           int not null,
   step                 int not null,
   description          text,
   role_id              int,
   current_status       varchar(50) not null,
   next_status          varchar(50) not null,
   is_rollback          tinyint not null comment '0：Can not retreat 1：Can retreat'
);


insert into om_order_process_config values ('2', '1', 'Approve', null, 'Submitted', 'To be created', '0');
insert into om_order_process_config values ('2', '2', 'System creation', null, 'To be created', 'To be delivered', '0');
insert into om_order_process_config values ('2', '3', 'Deliver', null, 'To be delivered', 'Close', '0');
insert into om_order_process_config values ('2', '-2', 'Abnormal', null, 'Abnormal', 'Abnormal', '0');
insert into om_order_process_config values ('2', '-1', 'Approval rejected', null, 'Approval rejected', 'Approval rejected', '0');
insert into om_order_process_config values ('2', '0', 'Close', null, 'Close', 'Close', '0');

insert into om_order_process_config values ('4', '1', 'First Level Approve', null, 'To be handled', 'Handling', '0');
insert into om_order_process_config values ('4', '2', 'Second Level Approve', null, 'Handling', 'Close', '0');
insert into om_order_process_config values ('4', '-3', 'Abnormal', null, 'Abnormal', 'Abnormal', '0');
insert into om_order_process_config values ('4', '-2', 'Second Level Approval rejected', null, 'Second Level Approval rejected', 'Approval rejected', '0');
insert into om_order_process_config values ('4', '-1', 'First Level Approval rejected', null, 'First Level Approval rejected', 'Approval rejected', '0');
insert into om_order_process_config values ('4', '0', 'Close', null, 'Close', 'Close', '0');

commit;

create table om_res_order_process_rel
(
   res_type             tinyint not null,
   process_id           int not null
);

create table om_order_sequence
(
   cur_month            int not null,
   cur_value            int not null
);

create table om_order_task
(
   order_detail_id      int not null,
   task_id              int not null,
   task_step            tinyint not null,
   task_status          tinyint not null,
   retry_num            int not null default 0,
   req_params           text,
   resp_params          text,
   primary key (task_id)
);

insert into om_res_order_process_rel (res_type, process_id) values(1, 2);
insert into om_res_order_process_rel (res_type, process_id) values(3, 2);
insert into om_res_order_process_rel (res_type, process_id) values(4, 2);
insert into om_res_order_process_rel (res_type, process_id) values(9, 2);
insert into om_res_order_process_rel (res_type, process_id) values(10, 4);
commit;


create table om_order_res_rel 
(
   id          varchar(64) not null,
   dc_id       varchar(64) not null,
   vdc_id      int not null,
   user_id     int not null,
   order_id    int not null,
   res_type    tinyint not null,
   deliver_time    datetime null,
   expire_time     datetime null, 
   primary key (id)
);

use iros;
drop table if exists om_ticket_process;
create table om_ticket_process
(
   process_id           int not null,
   ticket_id            int not null,
   step                 int not null,
   oper_type            int not null, 
   opinion              text null,
   handler_id           int null,
   handler              varchar(50) not null,
   handle_time          datetime not null,
   attachment_path      varchar(255) null,
   attachment           varchar(1000) null,
   attachmentids        varchar(200) null, 
   primary key (process_id)
);

drop table if exists om_ticket;
create table om_ticket
(
   ticket_id            int not null,
   code                 varchar(64) not null,
   title                varchar(64) not null,
   description          text not null,
   category             tinyint not null,
   status               tinyint not null, 
   creator_id           int not null,
   creator              varchar(64) not null,
   phone                varchar(20) not null,
   create_time          datetime not null,
   step                 int not null,
   handler_id           int null,
   handler              varchar(64) null,
   respond_time         datetime,
   update_time          datetime,
   close_time           datetime,
   extra                text,
   order_id             int null,
   order_detail_id      int null,
   city_id              varchar(100) null,
   computerroom_id      varchar(100) null,
   primary key (ticket_id)
);
	  
drop table if exists om_irai_quota;
CREATE TABLE om_irai_quota ( 
	id						varchar(64)				not null, 	-- id
	create_date				datetime				not null, 	-- 创建时间
	update_date				datetime				not null, 	-- 更新时间
	dc_id					varchar(64)				not null, 	-- dc_id
	dc_type					int						not null,	-- dc类型，3是vmware，4是power，
	tenant_id				varchar(64)				not null, 	-- 租户id
	vdc_id					numeric				not null,
	resource_id				varchar(64)				not null,	-- 配额id
	resource				varchar(100)			not null,	-- 配额名称
	in_use					numeric					default 0		not null, 	-- 已使用
	hard_limit				numeric					not null, 	-- 上限
	PRIMARY KEY(id)
);
	 
drop table if exists om_bak_vm_policy;
create table om_bak_vm_policy
(
   vdc_id   	numeric NOT NULL,
   bak_cycle 	tinyint not null, 
   bak_day		tinyint not null, 
   bak_time		varchar(5),  
   primary key (vdc_id)
);


drop table if exists om_bak_vm;
create table om_bak_vm
(
   bak_id		int not null,
   vdc_id   	numeric NOT NULL,
   dc_id        varchar(64) NOT NULL,
   project_id   varchar(64) NOT NULL,
   vm_id		varchar(64) NOT NULL,
   vm_name		varchar(200),
   vm_type		tinyint null, 
   image_id		varchar(64) NOT NULL,
   image_name 	varchar(200),
   type			tinyint not null,
   update_date  datetime not null,
   extra		text,
   
   primary key (bak_id)
);	  

drop table if exists om_resource_statistic;
create table om_resource_statistic
(
   vdc_id   	   int not null,
   dc_id   	       varchar(100),
   year            varchar(10) not null,
   yearmonth       varchar(10) not null,
   date            varchar(10) not null,
   type            int not null, -- 1.instance 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
   resource_id     varchar(100) not null,
   resource_name   varchar(100) not null,
   usagetime       int          not null,
   
   primary key (type, resource_id, resource_name, date)
);

drop table if exists om_compute_threshold;
create table om_compute_threshold
(
	dc_id				varchar(64)		not null,
	compute				varchar(100)	not null,
	cpu					int				not null,
	mem					int				not null,
	primary key (dc_id, compute)
);

drop table if exists om_compute_migrate;
create table om_compute_migrate
(
	task_id				varchar(64)		not null,
	dc_id				varchar(64)		not null,
	compute				varchar(100)	not null,
	server_id			varchar(64)		not null,
	server_name			varchar(64)		not null,
	migrate_result		int				not null,
	migrate_detail		text			null,
	migrate_time		datetime		not null,
	primary key (task_id)
);

drop table if exists om_dci;
CREATE TABLE om_dci ( 
	dci_id        	int NOT NULL,
	dci_name        varchar(255) NOT NULL,
	vdc_id        	int NOT NULL,	
	export_rt       varchar(100)  NOT NULL,
	import_rt       varchar(100)  NOT NULL,
	rd              varchar(100)  NOT NULL,
	vni        	    varchar(100)  NOT NULL,
	tag				varchar(100)   NULL,
	tag_type		varchar(100)   NULL,
	dscp			int 	NULL,
	primary key (dci_id)
);
drop table if exists om_dci_sub;
CREATE TABLE om_dci_sub ( 
	dci_id        	int NOT NULL,	
	dc_id         	varchar(100)  NOT NULL,
	tenant_id       varchar(100)  NOT NULL,
	net_id        	varchar(100)  NOT NULL,	
	sub_id        	varchar(100)  NOT NULL,
    sub_ipmask      varchar(100)  NOT NULL		
);

drop table if exists om_base_service;
CREATE TABLE om_base_service ( 
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64) NOT NULL,
	rel_id      varchar(500) NOT NULL,
	description varchar(500) NULL,
	dc_type 	varchar(500) NULL,
	primary key (id)
);

drop table if exists om_service_directory;
CREATE TABLE om_service_directory ( 
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64)  NULL,
	dc_id      varchar(100) NOT NULL,
	template_id  int  NULL,
	vdc_id   	numeric  NULL,
	type        tinyint NOT NULL,
	parent_id      int  NULL,
	is_use        tinyint NOT NULL,
	is_publish      tinyint NOT NULL,
	extra        text  NULL,
	primary key (id)
);

drop table if exists om_service_rel;
CREATE TABLE om_service_rel ( 
	id        	int NOT NULL,
	rel_id      int NOT NULL,
	dc_id  varchar(100) NOT NULL,
	type  tinyint  NOT NULL 

);

insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (1, 'VPN', 'switch_vpn', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (2, 'Load balancers', 'switch_lb', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (3, 'Firewall', 'switch_firewall', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (4, 'DCI', 'switch_dci', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (5, 'Security group', 'switch_sg', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (6, 'Basic virtualization', 'switch_base', '','',',1,2,3,4,5,6,7,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (7, 'Business automatic arrangement', 'switch_adt', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (8, 'Business environment', 'switch_service', '7','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (9, 'Incremental backup', 'switch_backup_add', '6','',',2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (10, 'Full backup', 'switch_backup_all', '6','',',2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (11, 'Flow', 'switch_flow', '6','',',1,2,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (13, 'Backup', 'switch_dpmbackup', '6','',',1,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (14, 'Rack rental', 'switch_rackrent', '','Provid rack lease function,While providing high-quality bandwidth and Internet access to facilitate business access.',',1,2,3,4,5,6,7,');
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (16, 'Cloud Desktop', 'switch_irai', '','',',1,');
commit;

drop table if exists om_ade_template;
create table om_ade_template (
   id                     int         not null,   
   name                   varchar(100)         not null,  
   type                   tinyint         not null,  
   description                   text         null,       
   status                 tinyint    default 0 not null,   
   dc_id	              varchar(100)         not null,   
   tenant_id              varchar(100)         not null,  
   delete_flag			  tinyint    default 0 not null,  
   creator_id             numeric         		NOT NULL,       
   create_time            datetime             null,      
   delete_time            datetime             null,       
   update_time            datetime             null,      
   extra				  text         null,      
   primary key (id)
);



drop table if exists om_ade_instance;
CREATE TABLE om_ade_instance ( 
	id								int 	NOT NULL,  
	name							varchar(100) 	NOT NULL,  
    description							text 	NULL,		
	vdc_id							numeric	NOT NULL, 
	dc_id							varchar(100)	NULL,  
	status							tinyint    NULL,
	template_id						varchar(100)	NOT NULL,  
	stack_id						varchar(100)	NULL,  
	delete_flag			  			tinyint    default 0 not null,   
	create_time            			datetime        NOT NULL,  
	delete_time            			datetime        null,     
	update_time            			datetime        null,	
	creator_id						numeric	NOT NULL,  
	extra							text	NULL,   
    PRIMARY KEY(id)
);


drop table if exists om_ade_traffic_steering;
CREATE TABLE om_ade_traffic_steering ( 
	instance_id						int 	NOT NULL,  
	classfier						varchar(100) 	NOT NULL,  
	portChain						varchar(100) 	NOT NULL  
    
);

drop table if exists om_instance_backup;
CREATE TABLE om_instance_backup (
    id                              int(11) NOT NULL AUTO_INCREMENT,
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
    parent_id						int(11)     NULL,
	instance_uuid				    varchar(255)	NOT NULL,
	instance_name				    varchar(255)	NULL,
	backup_type 				    tinyint	NOT NULL, 
	root_disk_file			  		varchar(255) NULL, 
	data_disk_file            		varchar(1000) NULL,
	memory_file            		    varchar(255) NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
	description						text  		NULL,
	related_id						int(11)     NULL,
	current		 				    tinyint	 	NULL, 
    PRIMARY KEY(id)
);
drop table if exists om_backup_task;
CREATE TABLE om_backup_task (
    id                              int(11) NOT NULL AUTO_INCREMENT,
	backup_id						int(11)     	NOT NULL,
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
	instance_uuid				    varchar(255)   NOT NULL,
	instance_name				    varchar(255)   NULL,
    backup_type 				    tinyint	NOT NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
	process						    int(11) NOT NULL, 
	sync	        			    tinyint	NOT NULL, 
	extra							text	NULL,
    PRIMARY KEY(id,backup_id)	
);
drop table if exists om_backup_policy;
CREATE TABLE om_backup_policy ( 
	uuid	                        varchar(100) 	NOT NULL, 
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
	name         				    varchar(255)	NOT NULL,
	policy       			  		varchar(255) NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	last_exec_date            	    datetime  NULL, 
	enable 				            tinyint	NOT NULL, 
	policy_type						int	NULL,   
    PRIMARY KEY(uuid)
);
drop table if exists om_backup_policy_association;
CREATE TABLE om_backup_policy_association(  
    instance_uuid				    varchar(255) NOT NULL,
	backup_policy_id				varchar(100) 	NOT NULL
);

drop table if exists om_backup_quota;
CREATE TABLE om_backup_quota ( 
    uuid							varchar(100) 	NOT NULL,  
	dc_id							varchar(100) 	NULL, 
    vdc_id							numeric	NOT NULL,	 
	quota						    int	default 0 not null,   
	backup_type					    tinyint	NOT NULL, 
    PRIMARY KEY(uuid)
);

drop table if exists om_backup_path;
CREATE TABLE om_backup_path ( 
	uuid							varchar(100) NOT NULL, 
	dc_id							varchar(100) 	NOT NULL,   
	compute_host					varchar(255) 	NULL,
	path_type 				        tinyint	NOT NULL, 
	backup_path					    varchar(255) 	NULL,
    PRIMARY KEY(uuid)
);

--  DRS begin
drop table if exists drs_config;
create table drs_config (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(100)                      not null  ,  
	reposstype				          		numeric(10)					 default  1  not null  , 
	enable                          numeric(10)          default  1  not null  ,  
	mode                     		    numeric(10)          default  1  null  ,	 
	autorun                        	numeric(10)                    	 null  ,	   
	constraint PK_DRS_CONFIG_ID primary key (id)
);

drop table if exists drs_config_detail;
create table drs_config_detail (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  , 
	cpuup                       		varchar(100)                     null  ,	
	cpudown                     		varchar(100)                     null  ,	
	memup                         	varchar(100)                     null  ,
	memdown                       	varchar(100)                     null  ,	
	active                          numeric(10)          default  1  not null  ,
	starttime                      	varchar(10)                      null  ,	
	endtime                     		varchar(10)                      null  ,	
	constraint PK_DRS_CONFIG_DETAIL_ID primary key (id)
);

drop table if exists drs_suggest;
create table drs_suggest (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(255)                      not null  ,
	operation                       numeric(10)                      not null  ,
	hostid                          varchar(255)                      null  ,	
	hostid2                         varchar(255)                      null  ,	
	vmid                            varchar(255)                      null  ,	
	hostname                        varchar(255)                      null  ,	
	hostname2                       varchar(255)                      null  ,	
	vmname                          varchar(255)                      null  ,	
	description                     varchar(256)                     null  ,	
	inserttime                      datetime                         null  ,	
	status                          numeric(10)                      null  ,	
	maintainStatus                  numeric(10)                      null  ,	
	primary key (id)
);

drop table if exists drs_suggest_history;
create table drs_suggest_history (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(255)                      not null  ,
	suggestid                       varchar(64)                      not null  ,
	operation                       int                              not null  ,
	hostid                          varchar(255)                      null  ,	
	hostid2                         varchar(255)                      null  ,	
	vmid                            varchar(255)                      null  ,	
	hostname                        varchar(255)                      null  ,	
	hostname2                       varchar(255)                      null  ,	
	vmname                          varchar(255)                      null  ,	
	description                     varchar(256)                     null  ,	
	inserttime                      datetime                         null  ,	
	status                          int                              null  ,	
	exetime 						datetime                         null  ,	
	maintainStatus                  int                              null  ,	
	taskid                          varchar(64)                      null  ,	
	constraint PK_DRS_SUGGEST_HISTORY_ID primary key (id)
);

drop table if exists drs_storage_config;
create table drs_storage_config (
	poolid                          varchar(64)                      not null  ,
	reposstype						int					 DEFAULT  1  not null  ,
	enable                          int                  DEFAULT  1  not null  ,
	mode                     		int                  DEFAULT  1  null  ,	
	autorun                     	int                         	 null  ,	
	maxrate                         int                              not null, 
	ext1                           int                               null, 
	ext2                           int                                null, 
	ext3                           varchar(64)                                null,  
	ext4                           varchar(64)                                null, 
	constraint PK_drs_storage_config_ID primary key (poolid)
);

drop table if exists drs_storage_suggest;
create table drs_storage_suggest (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  ,
	operation                       int                              not null  ,
	hostid                          varchar(64)                      null  ,	
	hostid2                         varchar(64)                      null  ,	
	vmid                            varchar(64)                      null  ,	
	hostname                        varchar(64)                      null  ,	
	hostname2                       varchar(64)                      null  ,	
	vmname                          varchar(64)                      null  ,	
	description                     varchar(256)                     null  ,	
	inserttime                      datetime                         null  ,	
	status                          int                              null  ,	
	maintainStatus                  int                              null  ,	
	constraint PK_DRS_STORAGE_SUGGEST_ID primary key (id)
);

drop table if exists om_compute_ipmi;
create table om_compute_ipmi
(
    dc_id			varchar(64)		not null,
	compute			varchar(100)	not null,
	ip			    varchar(64)		null,
	user_name		varchar(255)	null,
	user_pwd		varchar(255)    null,
	primary key (dc_id, compute)
);
--  DRS end


drop table if exists om_a10_vlantag;
CREATE TABLE om_a10_vlantag (
    vlan_tag                int        				not null,
	status   	            tinyint    default 0 	not null,
	a10_vm_uuid          	varchar(64)				not null,
	network_id              varchar(64)        		null,
	a10_port_id             varchar(64)        		null,  
	vnetid           		varchar(64)      		null,    
    vip_list             	text                	null
);

drop procedure if exists p_insert_vlantag;
DELIMITER &&
create procedure p_insert_vlantag(IN vmUuid varchar(64))
begin
  declare i int;
	declare vsql text; 
	set i=4094;	   
	set vsql=concat('insert into om_a10_vlantag (vlan_tag,a10_vm_uuid) values ');
	while i>=0 do
	 if (i%1000 = 0) THEN
		SET @sql_txt = substring(vsql,1,length(vsql)-1); 
        PREPARE stmt FROM @sql_txt; 
        EXECUTE stmt; 
        set vsql=concat('insert into om_a10_vlantag (vlan_tag,a10_vm_uuid) values ');
    end if;
    set vsql=concat(vsql,'(''',i,''',''',vmUuid,'''),');
    set i=i-1;
  end while;
	SET @delsql='delete from om_a10_vlantag where vlan_tag = 1';
	PREPARE stmt FROM @delsql; 
  EXECUTE stmt; 	
end&& 
DELIMITER ; 
commit;


drop table if exists om_a10_dvsport;
CREATE TABLE om_a10_dvsport (
	a10_vm_uuid			   varchar(64)      null,
    device_id              varchar(64)      null,
	port_id   	           varchar(64)    	null
);

drop table if exists om_a10_tenant;
CREATE TABLE om_a10_tenant (
    tenant_id              varchar(64)      null,
	dc_id   	           varchar(64)    	null,
	a10_vm_uuid			   varchar(64)      null
);

drop table if exists om_task_instance_port;
CREATE TABLE om_task_instance_port ( 
	instance_id   	varchar(64) NOT NULL,
	dc_id 	varchar(64) NOT NULL,
	port_id 	varchar(1024) NOT NULL
);

drop table if exists om_vdc_srvdir;
create table om_vdc_srvdir
(
	id				int		not null,
	srvdir_id		int 	null,
	dc_id			varchar(64)		not null,
	vdc_id           decimal	not null,
	is_publish      tinyint    not null,
	parent_id		int   		null,
	template_id		int 		null,
	extra			text		null,
	primary key (id)
);

drop table if exists om_net_vdc_rel;
create table om_net_vdc_rel
(
	networkid varchar(100) not null,
	vdcid decimal(10,0) not null,
	dcid varchar(100) not null,
	projectid varchar(100) not null
);

drop table if exists om_resize_flavor_record;
create table om_resize_flavor_record
(
	instanceid varchar(100) NOT NULL,
	vdcid varchar(10) NOT NULL,
	dcid varchar(100) NOT NULL,
	flag int(11) NOT NULL,
	operation varchar(20) DEFAULT NULL,
	vcpus int(11) NOT NULL,
	memory bigint(20) NOT NULL,
	disk int(11) NOT NULL,
	created datetime DEFAULT NULL,
	updated datetime DEFAULT NULL
);

drop table if exists om_ip_rel;
CREATE TABLE om_ip_rel ( 
	id							varchar(64) 	NOT NULL,
	internet_ip				    varchar(100) 	NULL,
    float_ip	                varchar(100) 	NULL,
    extnet_id	                varchar(100) 	NULL,
	subnet_id	                varchar(100) 	NULL,
	dc_id						varchar(100) 	NULL,
    vdc_id                      numeric		    NULL,
    tenant_id				    varchar(100) 	NULL, 	
	vm_id	                    varchar(100) 	NULL,
	extra						varchar(500) 	NULL
);

drop table if exists om_history_records;
CREATE TABLE om_history_records ( 
	dc_id						varchar(64) 	NOT NULL, 
	instance_id					varchar(100) 	NOT NULL,  
	oper_type					int 		    NOT NULL,  
	created						varchar(64) 	NULL,
	status						int     		NULL,
	detail						text 			NULL
);

drop table if exists om_vdc_apply;
create table om_vdc_apply
(
   apply_id             int NOT NULL,
   vdcname 				varchar(64) NOT NULL,
   vdcdesc 				varchar(256) NULL,
   vdcid   				numeric NULL,
   dcids				varchar(512) NOT NULL,
   dctypes				varchar(64) NOT NULL,
   quotas				varchar(2048) NOT NULL,
   operators			varchar(64) NOT NULL,
   operatoroles			varchar(256) NOT NULL,
   dcids_audited		varchar(512) NULL,
   dctypes_audited		varchar(64) NULL,
   quotas_audited		varchar(2048) NULL,
   creatorid			int NOT NULL,
   tenantid				varchar(64) NOT NULL,
   current_step         int NOT NULL,
   apply_date           datetime NOT NULL,
   primary key (apply_id)
);

drop table if exists om_service_evaluation;
create table om_service_evaluation
(
   order_id             int NOT NULL,
   type 				int NOT NULL,
   user_id 				int NOT NULL,
   evaluation   		int NOT NULL,
   comment				varchar(512) NULL,
   evaluate_date        datetime NOT NULL
);

drop table if exists om_system_evaluation;
create table om_system_evaluation
(
  id                int NOT NULL,
  user_id 			int NOT NULL,
  vdc_id            int NOT NULL,
  usability 		int NOT NULL,
  systemic_fluency  int NOT NULL,
  processing_rate   int NOT NULL,
  comment			varchar(512) NULL,
  evaluate_date     datetime NOT NULL,
  primary key (id)
);