﻿drop database if exists iros;  
create database iros DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
grant all privileges on iros.* to 'iros'@'localhost' identified by 'db10$ZTE';
commit;

drop database if exists opslog;  
create database opslog DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
grant all privileges on opslog.* to 'opslog'@'localhost' identified by 'db10$ZTE';
commit;

/*
drop database if exists zxinsys;  
create database zxinsys DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
commit;
drop database if exists zxin;
create database zxin DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
commit;
drop database if exists zxinalarm;
create database zxinalarm DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
commit;
drop database if exists zxinmeasure;
create database zxinmeasure DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
commit;
grant all privileges on zxinsys.* to 'zxinsys'@'%' identified by 'db10$ZTE';
commit;
grant all privileges on zxin.* to 'zxin'@'%' identified by 'db10$ZTE';
commit;
grant all privileges on zxinalarm.* to 'zxinalarm'@'%' identified by 'db10$ZTE';
commit;
grant all privileges on zxinmeasure.* to 'zxinmeasure'@'%' identified by 'db10$ZTE';
commit;
*/