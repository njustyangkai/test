use iros
go
if (exists(select 1 from sysobjects where name = 'om_city'))
	drop table om_city
go
create table om_city 
(
	dc_id   			varchar(100)	not null,	
	city_id				varchar(100)	not null,	
	name   			    varchar(100)	not null,	
	description         text            null,
	primary key(city_id)
)
go
if (exists(select 1 from sysobjects where name = 'om_computerroom'))
	drop table om_computerroom
go
create table om_computerroom 
(
   city_id              varchar(100) not null,
   computerroom_id      varchar(100) not null,
   name                 varchar(100) not null,
   address              varchar(500) not null,
   area                 numeric(10,2) not null,
   rack_num             int not null,
   rack_rows            int not null,
   rack_columns         int not null,
   port_num             int not null,
   bandwidth            int not null,
   lease                tinyint not null,
   primary key (computerroom_id)
)
go
if (exists(select 1 from sysobjects where name = 'om_rack'))
	drop table om_rack
go
create table om_rack
(
   computerroom_id      varchar(100) not null,
   rack_id              varchar(100) not null,
   rack_code            varchar(100) not null,
   rack_spec            varchar(100) not null,
   power_num            int not null, 
   assign               tinyint not null,
   status               tinyint not null,
   rack_row             int not null,
   rack_column          int not null,
   tenantid             varchar(100),
   userid               varchar(100),
   lease                tinyint not null,
   primary key (rack_id)
)
go
if (exists(select 1 from sysobjects where name = 'om_rack_lease_history'))
	drop table om_rack_lease_history
go
create table om_rack_lease_history
(
   id                   varchar(100) not null,
   computerroom_id      varchar(100) not null,
   rack_id              varchar(100) not null,
   rack_code            varchar(100) not null,
   rack_spec            varchar(100) not null,
   power_num            int not null,
   rack_row             int not null,
   rack_column          int not null,
   tenantid             varchar(100) not null,
   userid               varchar(100) not null,
   startdate            datetime,
   enddate              datetime,
   order_id             int,
   status               tinyint
)
go
if (exists(select 1 from sysobjects where name = 'om_room_admin'))
	drop table om_room_admin
go
create table om_room_admin
(
   oper_id              decimal not null,
   dc_id                varchar(100) not null,
   city_id              varchar(100),
   computerroom_id      varchar(100)
)
go
if (exists(select 1 from sysobjects where name = 'om_ipsection'))
	drop table om_ipsection
go
create table om_ipsection
(
   name                 varchar(64)   not null, 
   id                   varchar(100)  not null,
   computerroom_id      varchar(100)  not null,
   cidr                 varchar(64)   not null,
   subnetmask           varchar(64)   not null,
   gateway              varchar(64)    null,
   dns                  varchar(255)   null,
   iptype               tinyint  not null, 
   primary key (id)
)
go
if (exists(select 1 from sysobjects where name = 'om_ippool'))
	drop table om_ippool
go
create table om_ippool
(
   id                   varchar(100)  not null,
   ipstart              varchar(50)   not null,
   ipend                varchar(50)   not null
)
go
if (exists(select 1 from sysobjects where name = 'om_ip_usage'))
	drop table om_ip_usage
go
create table om_ip_usage
(
   computerroom_id      varchar(100)  not null, 
   id                   varchar(100)  not null,
   ip                   varchar(50)   not null,
   status               tinyint not null,
   tenantid             varchar(100) null,
   userid               varchar(100) null,
   restype              tinyint null,
   resid                varchar(50) null,
   startdate            datetime null,
   enddate              datetime null,
   section_id           varchar(100) not null
)
go
if (exists(select 1 from sysobjects where name = 'om_bandwidth_config'))
	drop table om_bandwidth_config
go
create table om_bandwidth_config
(
   id                   varchar(100) not null,
   up_bandwidth         int not null,
   down_bandwidth		int not null,
   computerroom_id      varchar(100) not null,
   primary key (id)
)
go
if (exists(select 1 from sysobjects where name = 'om_bandwidth_usage'))
	drop table om_bandwidth_usage
go
create table om_bandwidth_usage
(
   computerroom_id      varchar(100) not null,
   id                   varchar(100) not null,
   bandwidth            int  not null,
   bw_mode              tinyint not null,
   bw_type              tinyint not null,
   status               tinyint not null,
   tenantid             varchar(100) not null,
   userid               varchar(100) not null,
   rack_id              varchar(100) not null,
   startdate            datetime  null,
   enddate              datetime  null,
   ips                  text not null,
   primary key (id)
)
go
if (exists(select 1 from sysobjects where name = 'om_networkdevice_info'))
	drop table om_networkdevice_info
go
create table om_networkdevice_info
(
   computerroom_id      varchar(100),  
   city_id              varchar(100),   
   rack_id              varchar(100),
   dc_id                varchar(100),
   entid                varchar(100),
   entname              varchar(100),
   devicetype           varchar(100),
   devicemodel          varchar(100),
   fixedassetnum        varchar(200),
   systemnum            varchar(200),
   productnum           varchar(200),
   purchasedate         datetime,
   assurancetime        int,
   assurancedesc        varchar(200),
   location             varchar(200),
   locationdesc         varchar(50),
   roundframenum        varchar(50),
   slotnum              varchar(50),
   is_measure           int
)
go
if (exists(select 1 from sysobjects where name = 'om_storedevice_info'))
	drop table om_storedevice_info
go
create table om_storedevice_info
(
   computerroom_id      varchar(100),  
   city_id              varchar(100),   
   rack_id              varchar(100),
   dc_id                varchar(100),
   entid                varchar(100),
   entname              varchar(100),
   devicetype           varchar(100),
   devicemodel          varchar(100),
   fixedassetnum        varchar(200),
   systemnum            varchar(200),
   productnum           varchar(200),
   purchasedate         datetime,
   assurancetime        int,
   assurancedesc        varchar(200),
   location             varchar(200),
   locationdesc         varchar(50),
   roundframenum        varchar(50),
   slotnum              varchar(50),
   is_measure           int
)
go

