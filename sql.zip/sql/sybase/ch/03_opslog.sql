use opslog
go

if(exists(select 1 from sysobjects where name='t_cost'))
  drop table t_cost
go
CREATE TABLE t_cost (
    id                      varchar(100)        not null,
	vdc_id   	            int                 not null,
	dc_id                   varchar(100)        not null,
	tenant_id               varchar(100)        not null,
	resource_id             varchar(100)        not null,  
	resource_name           varchar(100)        null,    
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
	price                   numeric(20, 5)      not null,
	cost  			        numeric(20, 5) 		not null,
    status                  varchar(100)        null,
    is_submit               int     default 1   not null,
    begin_time              datetime            not null,
    end_time                datetime            not null,
    description             text                null,
	flavor                  varchar(500)       null,
    primary key (id)
    
)
go

if exists (select * from sysobjects where id = object_id('dbo.p_create_cost'))
    drop procedure dbo.p_create_cost
go

create procedure p_create_cost
as
begin
	   declare @i int
	   declare @mmdd varchar(4)
	   declare @tabname varchar(20)
	   declare @sql varchar(1000)  
	   set @i=24	   
	   while @i>=1
	   begin 	      
	      set @mmdd=right('0'+cast(@i as varchar(2)),2) 
            begin 		   
              
                  set @tabname='t_cost_'+@mmdd 
                  set @sql='if exists(select 1 from sysobjects where name = '''+@tabname+''') '+
                               ' drop table '+@tabname
                      execute (@sql)
                      
                      set @sql='create table '+@tabname+ 
                          '(id                   varchar(100)        not null,'+
                          'vdc_id         		 int                 not null,'+
                          'dc_id                 varchar(100)        not null,'+
                          'tenant_id             varchar(100)        not null,'+
                          'resource_id           varchar(100)        not null,'+  
                          'resource_name         varchar(100)        null,'+    
                          'type                  int                 not null,'+
                          'price                 numeric(20, 5)      not null,'+
                          'cost  			     numeric(20, 5) 	 not null,'+
                          'status                varchar(100)        null,'+
                          'begin_time            datetime            not null,'+
                          'end_time              datetime            not null,'+
                          'duration              numeric(20, 0)      not null,'+
                          'description           text                null,'+
                          'is_deduct             int default 0       not null,'+
                          'deduct_time           datetime            null,'+
						  'flavor                varchar(500)       null,'+
                          'primary key(id))'
                
                     execute (@sql)
                
                       set @sql='create index idx_vdcid_'+@mmdd+' on '+@tabname+'(vdc_id)'
                       execute (@sql)
                       set @sql='create index idx_dc_tenantid_'+@mmdd+' on '+@tabname+'(dc_id, tenant_id)'
                       execute (@sql)
                       set @sql='create index idx_resourceid_'+@mmdd+' on '+@tabname+'(resource_id)'
                       execute (@sql)
                       set @sql='create index idx_begintime_'+@mmdd+' on '+@tabname+'(begin_time)'
                       execute (@sql)
                       set @sql='create index idx_endtime_'+@mmdd+' on '+@tabname+'(end_time)'
                       execute (@sql)
            end 
	   	set @i=@i-1
	   end
end
go

exec p_create_cost

if(exists(select 1 from sysobjects where name='t_deduct'))
  drop table t_deduct
go
CREATE TABLE t_deduct (
    id                      varchar(100)        not null,
	vdc_id   	            int                 not null,
	value                   numeric(20, 5)      not null,
	update_time  			datetime     		not null,
	deduct_time  			datetime     		null,
    description             text                null,
    primary key (id)
)
go

if exists (select * from sysobjects where id = object_id('dbo.p_create_deduct'))
    drop procedure dbo.p_create_deduct
go

create procedure p_create_deduct
as
begin	
	   declare @i int
	   declare @mmdd varchar(4)
	   declare @tabname varchar(20)
	   declare @sql varchar(1000)  
	   set @i=24	   
	   while @i>=1
	   begin 
	      
			set @mmdd=right('0'+cast(@i as varchar(2)),2) 
			begin 
			set @tabname='t_deduct_'+@mmdd         
			set @sql='if exists(select 1 from sysobjects where name = '''+@tabname+''') '+
			           ' drop table '+@tabname
			  execute (@sql)
			  
			  set @sql='create table '+@tabname+
		            '(id                   varchar(100)        not null,'+
                    'vdc_id         		 int                 not null,'+                          
                    'old_value             numeric(20, 5)      not null,'+  
                    'value                 numeric(20, 5)      not null,'+                       
                    'type                  int                 null,'+
                    'update_time           datetime            not null,'+ 
                    'description           text                null,'+
                    'primary key (id))'
		
			execute (@sql)
            
			   set @sql='create index idx_vdcid_'+@mmdd+' on '+@tabname+'(vdc_id)'
			   execute (@sql)
			   set @sql='create index idx_updatetime_'+@mmdd+' on '+@tabname+'(update_time)'
			   execute (@sql)
			end
 
	   	set @i=@i-1
	   end
end
go
exec p_create_deduct

if exists (select * from sysobjects where id = object_id('dbo.p_create_operlog'))
    drop procedure dbo.p_create_operlog
go

create procedure p_create_operlog
as
begin
	/**
	*  create log
	*  E.g exec p_create_operlog
	* @author wmt 
	* @create date 2014-08-11
	* @mod date 
	*/  
	
	   declare @i int
	   declare @mmdd varchar(4)
	   declare @tabname varchar(20)
	   declare @sql varchar(1000) 
 
	   set @i=24
	   
	   while @i>=1
	   begin 
	      
			set @mmdd=right('0'+cast(@i as varchar(2)),2) 
	                
			begin 		   
	      
			set @tabname='oper_log'+@mmdd         
			set @sql='if exists(select 1 from sysobjects where name = '''+@tabname+''') '+
			           ' drop table '+@tabname
			  execute (@sql)
			  
			  set @sql='create table '+@tabname+
		             '(id					numeric				not null,'+
					 'domainid				varchar(100)		null,'+
					 'dcid					varchar(64)			null,'+
					 'orgid					varchar(64)			null,'+
					 'vdcid					varchar(64)			null,'+
	        	     'servicekey			varchar(10)			not null,'+
	        	     'code					int					not null,'+	
	        	     'taskid				varchar(50)			null,'+        	    
					 'targettype			varchar(20)			null,'+
					 'targetid				varchar(64)			null,'+
	        	     'targetname			varchar(256)			null,'+
	        	     'description			varchar(256)		null,'+
	        	     'details				text        		null,'+
	        	     'status				int					not null,'+
	        	     'starttime				datetime			not null,'+
	        	     'endtime				datetime			null,'+
	        	     'operid				varchar(64)			null,'+
	        	     'opername				varchar(64)			null,'+
					 'operip				varchar(100)		null,'+
	        	     'extra					varchar(1000)		null)'
		
			execute (@sql)
		
		       
			   set @sql='create index idx_operlog_targetid_'+@mmdd+' on '+@tabname+'(targetid, dcid)'
			   execute (@sql)
			   set @sql='create index idx_operlog_starttime_'+@mmdd+' on '+@tabname+'(starttime)'
			   execute (@sql)
			   set @sql='create index idx_operlog_endtime_'+@mmdd+' on '+@tabname+'(endtime)'
			   execute (@sql)
			end
 
	   	set @i=@i-1
	   end
end
go
exec p_create_operlog

if exists (select * from sysobjects where id = object_id('dbo.p_create_operlog_view'))
    drop procedure dbo.p_create_operlog_view
go
create procedure p_create_operlog_view
as
begin
	/**
	*  create view for log table  
	*  
	* @author wmt 
	* @create date 2014-08-11
	* @mod date 
	*/       
       
	   declare @i int
	   declare @dd1 varchar(4)
	   declare @dd0 varchar(4)
	   declare @viewname varchar(20) 
	   declare @vname varchar(20) 
	   declare @sql varchar(1000)
	   
	   
	   set @i=24
	   set @vname='oper_log'
	   
	   while @i>=1
	   begin
	     
	      
	      set @dd1=right('0'+cast(@i as varchar),2)
		  set @dd0=right('0'+cast(@i-1 as varchar),2)
	       
  		   if @i=1 set @dd0='24'
			  
		 -------------   -------------
			set @viewname=@vname+'_v'+@dd1
		 
			set @sql='if exists (select 1 from  sysobjects where id = object_id('''+@viewname+''') )'+
			' drop view '+@viewname
			execute (@sql)
			  
			set @sql='create view '+@viewname+
		                     ' as '+
						     ' select * from '+@vname+@dd1+
						     ' union all '+
						     ' select * from '+@vname+@dd0
						     
						     
			execute (@sql)
			  
		   
			  
	   		set @i=@i-1
	   end
end 
go

exec p_create_operlog_view
