--���RCS�����û�ֱ����Ȩ�޹������ƿ��ش򿪣�ǰ����ommp����������Ӧ�İ汾

use zxinsys
go
delete from oper_funcgrp2 where funcgrpid = 4
insert into oper_funcgrp2 values (4, '4', 'Ȩ�޹���', 'uniportal', 0)


delete from oper_function where funcdescription in ('����Ա����','��ɫ��Ϣ','����Ϣ','��ȫ�ȼ�','��ȫ��������','����Ա��Ϣ�༭','��ɫ��Ϣ�༭','����Ϣ�༭','��ȫ�ȼ��༭','��ȫ�������ñ༭','����ɾ����Դ')
insert into oper_function values (4, 13001, '1301' , '����Ա����'  ,       0, 'uniportal')
insert into oper_function values (4, 13003, '1303' , '��ɫ��Ϣ'    ,       0, 'uniportal')
insert into oper_function values (4, 13005, '1305' , '����Ϣ'      ,       0, 'uniportal')
insert into oper_function values (4, 13007, '1307' , '��ȫ�ȼ�'     ,      0, 'uniportal')
insert into oper_function values (4, 13008, '1308' , '��ȫ��������'  ,      0, 'uniportal') 
insert into oper_function values (4, 13009, '1309' , '����Ա��Ϣ�༭'  ,      0, 'uniportal')
insert into oper_function values (4, 13011, '1311' , '��ɫ��Ϣ�༭'  ,      0, 'uniportal')
insert into oper_function values (4, 13014, '1314' , '����Ϣ�༭'  ,       0, 'uniportal') 
insert into oper_function values (4, 13016, '1316' , '��ȫ�ȼ��༭'  ,       0, 'uniportal') 
insert into oper_function values (4, 13017, '1317' , '��ȫ�������ñ༭'  ,       0, 'uniportal')
insert into oper_function values (4, 13020, '1320' , '����ɾ����Դ'  ,       0, 'uniportal') 
go

delete from oper_grpdef where funcgrpid=4 and opergrpid=1000  and servicekey='uniportal'
insert into oper_grpdef select 1000,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4 
delete from oper_grpdef where funcgrpid=4 and opergrpid=1001  and servicekey='uniportal'
insert into oper_grpdef select 1001,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal' and  funcgrpid=4 
go


-- �����µĽ�ɫ��
-- proc_res_op_grpscript2 ��ƷID���޸ı�ʶ(add-1,del-2)����ɫ��ʶ����ɫ����
proc_res_op_grpscript2 0, 1, 201, '����Ա��ɫ' 
go
proc_res_op_grpscript2 0, 1, 202, '����Ա��ɫ' 
go
proc_res_op_grpscript2 0, 1, 203, 'ά��Ա��ɫ' 
go
proc_res_op_grpscript2 0, 1, 204, '���Ա��ɫ' 
go
proc_res_op_grpscript2 0, 1, 205, '�Զ����ɫ' 
go


--�������ӵĽ�ɫ������Ӧ��Ȩ�ޣ�
--����Ա��ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 201, 1,  10001
go
proc_res_op_grpdef 0, 1, 201, 1,  10003
go
proc_res_op_grpdef 0, 1, 201, 1,  10006 
go
proc_res_op_grpdef 0, 1, 201, 1,  10007
go
proc_res_op_grpdef 0, 1, 201, 3,  12001 
go
proc_res_op_grpdef 0, 1, 201, 3,  12002 
go
proc_res_op_grpdef 0, 1, 201, 3,  12003   
go
proc_res_op_grpdef 0, 1, 201, 3,  12007 
go
proc_res_op_grpdef 0, 1, 201, 3,  12008 
go
proc_res_op_grpdef 0, 1, 201, 3,  12010 
go
proc_res_op_grpdef 0, 1, 201, 4,  13001 
go
proc_res_op_grpdef 0, 1, 201, 4,  13003  
go
proc_res_op_grpdef 0, 1, 201, 4,  13005  
go
proc_res_op_grpdef 0, 1, 201, 4,  13007  
go
proc_res_op_grpdef 0, 1, 201, 4,  13008  
go
proc_res_op_grpdef 0, 1, 201, 4,  13009  
go
proc_res_op_grpdef 0, 1, 201, 4,  13011  
go
proc_res_op_grpdef 0, 1, 201, 4,  13014  
go
proc_res_op_grpdef 0, 1, 201, 4,  13016  
go
proc_res_op_grpdef 0, 1, 201, 4,  13017  
go
proc_res_op_grpdef 0, 1, 201, 4,  13020  
go
proc_res_op_grpdef 0, 1, 201, 10, 15001  
go
proc_res_op_grpdef 0, 1, 201, 10, 15005  
go
proc_res_op_grpdef 0, 1, 201, 10, 15007  
go
proc_res_op_grpdef 0, 1, 201, 11, 18005  
go
proc_res_op_grpdef 0, 1, 201, 11, 18102  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139603  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139605  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139607  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 201, 1396, 139609  
go
proc_res_op_grpdef 0, 1, 201, 1396, 139610     
go

--����Ա��ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 202, 1,  10001
go
proc_res_op_grpdef 0, 1, 202, 1,  10003
go
proc_res_op_grpdef 0, 1, 202, 1,  10006 
go
proc_res_op_grpdef 0, 1, 202, 1,  10007
go
proc_res_op_grpdef 0, 1, 202, 3,  12001 
go
proc_res_op_grpdef 0, 1, 202, 3,  12002 
go
proc_res_op_grpdef 0, 1, 202, 3,  12003   
go
proc_res_op_grpdef 0, 1, 202, 3,  12007 
go
proc_res_op_grpdef 0, 1, 202, 3,  12008 
go
proc_res_op_grpdef 0, 1, 202, 3,  12010 
go
proc_res_op_grpdef 0, 1, 202, 4,  13001 
go
proc_res_op_grpdef 0, 1, 202, 4,  13003  
go
proc_res_op_grpdef 0, 1, 202, 4,  13005  
go
proc_res_op_grpdef 0, 1, 202, 4,  13007  
go
proc_res_op_grpdef 0, 1, 202, 4,  13008  
go
proc_res_op_grpdef 0, 1, 202, 4,  13009  
go
proc_res_op_grpdef 0, 1, 202, 4,  13011  
go
proc_res_op_grpdef 0, 1, 202, 4,  13014  
go
proc_res_op_grpdef 0, 1, 202, 4,  13016  
go
proc_res_op_grpdef 0, 1, 202, 4,  13017  
go
proc_res_op_grpdef 0, 1, 202, 4,  13020  
go
proc_res_op_grpdef 0, 1, 202, 10, 15001  
go
proc_res_op_grpdef 0, 1, 202, 10, 15005  
go
proc_res_op_grpdef 0, 1, 202, 10, 15007  
go
proc_res_op_grpdef 0, 1, 202, 11, 18005  
go
proc_res_op_grpdef 0, 1, 202, 11, 18102  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139603  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139605  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139607  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 202, 1396, 139609  
go
proc_res_op_grpdef 0, 1, 202, 1396, 139610     
go

--ά��Ա��ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 203, 1,  10001
go
proc_res_op_grpdef 0, 1, 203, 1,  10003
go
proc_res_op_grpdef 0, 1, 203, 1,  10006 
go
proc_res_op_grpdef 0, 1, 203, 1,  10007
go
proc_res_op_grpdef 0, 1, 203, 3,  12001 
go
proc_res_op_grpdef 0, 1, 203, 3,  12002 
go
proc_res_op_grpdef 0, 1, 203, 3,  12003   
go
proc_res_op_grpdef 0, 1, 203, 3,  12007 
go
proc_res_op_grpdef 0, 1, 203, 3,  12008 
go
proc_res_op_grpdef 0, 1, 203, 3,  12010 
go
proc_res_op_grpdef 0, 1, 203, 4,  13001 
go
proc_res_op_grpdef 0, 1, 203, 4,  13003  
go
proc_res_op_grpdef 0, 1, 203, 4,  13005  
go
proc_res_op_grpdef 0, 1, 203, 4,  13007  
go
proc_res_op_grpdef 0, 1, 203, 4,  13008  
go
proc_res_op_grpdef 0, 1, 203, 4,  13009  
go
proc_res_op_grpdef 0, 1, 203, 4,  13011  
go
proc_res_op_grpdef 0, 1, 203, 4,  13014  
go
proc_res_op_grpdef 0, 1, 203, 4,  13016  
go
proc_res_op_grpdef 0, 1, 203, 4,  13017  
go
proc_res_op_grpdef 0, 1, 203, 4,  13020  
go
proc_res_op_grpdef 0, 1, 203, 10, 15001  
go
proc_res_op_grpdef 0, 1, 203, 10, 15005  
go
proc_res_op_grpdef 0, 1, 203, 10, 15007  
go
proc_res_op_grpdef 0, 1, 203, 11, 18005  
go
proc_res_op_grpdef 0, 1, 203, 11, 18102  
go

--���Ա��ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 204, 1,  10001
go
proc_res_op_grpdef 0, 1, 204, 1,  10003
go
proc_res_op_grpdef 0, 1, 204, 1,  10006 
go
proc_res_op_grpdef 0, 1, 204, 1,  10007
go
proc_res_op_grpdef 0, 1, 204, 3,  12001 
go
proc_res_op_grpdef 0, 1, 204, 3,  12002 
go
proc_res_op_grpdef 0, 1, 204, 3,  12003   
go
proc_res_op_grpdef 0, 1, 204, 3,  12007 
go
proc_res_op_grpdef 0, 1, 204, 3,  12008 
go
proc_res_op_grpdef 0, 1, 204, 3,  12010 
go
proc_res_op_grpdef 0, 1, 204, 4,  13001 
go
proc_res_op_grpdef 0, 1, 204, 4,  13003  
go
proc_res_op_grpdef 0, 1, 204, 4,  13005  
go
proc_res_op_grpdef 0, 1, 204, 4,  13007  
go
proc_res_op_grpdef 0, 1, 204, 4,  13008  
go
proc_res_op_grpdef 0, 1, 204, 4,  13009  
go
proc_res_op_grpdef 0, 1, 204, 4,  13011  
go
proc_res_op_grpdef 0, 1, 204, 4,  13014  
go
proc_res_op_grpdef 0, 1, 204, 4,  13016  
go
proc_res_op_grpdef 0, 1, 204, 4,  13017  
go
proc_res_op_grpdef 0, 1, 204, 4,  13020  
go
proc_res_op_grpdef 0, 1, 204, 10, 15001  
go
proc_res_op_grpdef 0, 1, 204, 10, 15005  
go
proc_res_op_grpdef 0, 1, 204, 10, 15007  
go
proc_res_op_grpdef 0, 1, 204, 11, 18005  
go
proc_res_op_grpdef 0, 1, 204, 11, 18102  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139603  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139605  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139607  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 204, 1396, 139609  
go
proc_res_op_grpdef 0, 1, 204, 1396, 139610     
go

--�Զ����ɫ��
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 205, 1,  10001
go
proc_res_op_grpdef 0, 1, 205, 1,  10003
go
proc_res_op_grpdef 0, 1, 205, 1,  10006 
go
proc_res_op_grpdef 0, 1, 205, 1,  10007
go
proc_res_op_grpdef 0, 1, 205, 3,  12001 
go
proc_res_op_grpdef 0, 1, 205, 3,  12002 
go
proc_res_op_grpdef 0, 1, 205, 3,  12003   
go
proc_res_op_grpdef 0, 1, 205, 3,  12007 
go
proc_res_op_grpdef 0, 1, 205, 3,  12008 
go
proc_res_op_grpdef 0, 1, 205, 3,  12010 
go
proc_res_op_grpdef 0, 1, 205, 4,  13001 
go
proc_res_op_grpdef 0, 1, 205, 4,  13003  
go
proc_res_op_grpdef 0, 1, 205, 4,  13005  
go
proc_res_op_grpdef 0, 1, 205, 4,  13007  
go
proc_res_op_grpdef 0, 1, 205, 4,  13008  
go
proc_res_op_grpdef 0, 1, 205, 4,  13009  
go
proc_res_op_grpdef 0, 1, 205, 4,  13011  
go
proc_res_op_grpdef 0, 1, 205, 4,  13014  
go
proc_res_op_grpdef 0, 1, 205, 4,  13016  
go
proc_res_op_grpdef 0, 1, 205, 4,  13017  
go
proc_res_op_grpdef 0, 1, 205, 4,  13020  
go
proc_res_op_grpdef 0, 1, 205, 10, 15001  
go
proc_res_op_grpdef 0, 1, 205, 10, 15005  
go
proc_res_op_grpdef 0, 1, 205, 10, 15007  
go
proc_res_op_grpdef 0, 1, 205, 11, 18005  
go
proc_res_op_grpdef 0, 1, 205, 11, 18102  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139602     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139603  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139604     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139605  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139606     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139607  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139608     
go
proc_res_op_grpdef 0, 1, 205, 1396, 139609  
go
proc_res_op_grpdef 0, 1, 205, 1396, 139610     
go


if exists (select * from sysobjects where id = object_id('proc_rcs_updateRole'))
     
     update portal_sysparam set param_value='1'  where param_name='RCS'

     exec proc_rcs_updateRole
go

