use zxinsys
go


-- OMMP6.01.10U1�ű�bug�����ṩ��������Ϊ�˱��ڰ�װ����������OMMP�Ĳ����ű�����iros�Ľű��У���������OMMP6.01.10U1
delete from portal_sysparam where param_name='FLOOTMSG'
go
insert into portal_sysparam(param_name,param_value, param_desc, paramgroup, description, field_type, max_value, min_value, visiblelevel) values('FLOOTMSG','','Add description at bottom of Home', 'System Configuration','Description information (such as: Contact: xxxx Phone: xxxx)', 2, 100, 0, 1)
go


-- �޸�logo
update portal_sysparam set param_value = 'iROS' where param_name = 'LOGINMSG'
go

-- ����ID�ϲ��˵�
-- update portal_sysparam set param_value = '0' where param_name = 'IsJoinMenuByID'
-- go

-- �޸���ҳ
update portal_sysparam set param_value = '2' where param_name = 'IS_SET_HOMEPAGE'
update portal_sysparam set param_value = '/pages/irosopsm/pages/frame/rms-homepage.jsp' where param_name = 'HOMEPAGE_URL'
-- ��������ͼ
update portal_sysparam set param_value = '2' where param_name = 'IS_NEED_HEADER_LEFT'
go

--ȥ������Դ��,�����á�,"����Ա����"�����˵�
delete from oper_funcgrp2 where funcgrpid in ( 2, 4, 12)
go
delete from oper_function where funcgrpid in ( 2, 4, 12)
go
delete from oper_grpdef where servicekey = 'uniportal'
go
insert into oper_grpdef select 1000,funcgrpid,funcid,'uniportal' from oper_function  where servicekey='uniportal'
go
insert into oper_grpdef select 1001,funcgrpid,funcid,'uniportal' from oper_function   where servicekey='uniportal' and funcgrpid not in (2)
go


-- ɾ�����ܺ͹��������˵�
-- delete from oper_funcgrp2 where funcgrpid =1 and servicekey='uniportal'
-- delete from oper_funcgrp2 where funcgrpid =3 and servicekey='uniportal'
delete from oper_funcgrp2 where funcgrpid =10 and servicekey='uniportal'

-- delete from oper_function where funcgrpid=1 and servicekey='uniportal'
-- delete from oper_function where funcgrpid=3 and servicekey='uniportal'
delete from oper_function where funcgrpid=10 and servicekey='uniportal'

-- delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =1
-- delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =3
delete from oper_grpdef where servicekey = 'uniportal' and funcgrpid =10
go

-- exec proc_res_op_paratype 0 ,2, 101, ''			-- ȥ�������Ϲ�����������־ͳ������
-- go
-- exec proc_res_op_paratype 0 ,2, 102, '' 		-- ȥ��������ͳ�ơ�������־ͳ������
-- go
exec proc_res_op_paratype 0 ,2, 103, '' 		-- ȥ������Դ������������־ͳ������
go
exec proc_res_op_paratype 0 ,2, 105, ''		    -- ȥ������־������������־ͳ������
go

--***********************************************************************************************
--*       Initialization Part                                                                   *
--***********************************************************************************************
--use zxinsys
--go
--ִ�� OMMP ������ɫ���û���
--***********************************************************************************************
--*       Role and user group Initialization Part                                               *
--***********************************************************************************************

--�����µĽ�ɫ��
-- proc_res_op_grpscript2 ��ƷID���޸ı�ʶ(add-1,del-2)����ɫ��ʶ����ɫ����

proc_res_op_grpscript2 0, 1, 102, '��Դ����' 
go
proc_res_op_grpscript2 0, 1, 103, '��֯����' 
go
proc_res_op_grpscript2 0, 1, 104, 'VDC����' 
go
proc_res_op_grpscript2 0, 1, 105, '��������', '��������'
go
proc_res_op_grpscript2 0, 1, 106, '��������Ա', '��������Ա'
go
proc_res_op_grpscript2 0, 1, 107, '������������Ա', '������������Ա'
go
proc_res_op_grpscript2 0, 1, 108, '��������������', '��������������'
go
proc_res_op_grpscript2 0, 1, 110, 'VDC����Ա', 'VDC����Ա'
go

--�������ӵĽ�ɫ������Ӧ��Ȩ�ޣ�

--DC������
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 102, 11, 18102
go
proc_res_op_grpdef 0, 2, 102, 1396, 139615
go
proc_res_op_grpdef 0, 2, 102, 1396, 139620
go
proc_res_op_grpdef 0, 2, 102, 1396, 139604
go

--�⻧������
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
   
proc_res_op_grpdef 0, 1, 103, 11, 18102      
go     
proc_res_op_grpdef 0, 1, 103, 1396, 139602     
go

--VDC������
-- proc_res_op_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)����ɫid�� Ȩ����id��Ȩ��id
proc_res_op_grpdef 0, 1, 104, 1396, 139602  
go
proc_res_op_grpdef 0, 2, 104, 1396, 139616
go

-- ��������
proc_res_op_grpdef 0, 1, 105, 1396, 139618
go
proc_res_op_grpdef 0, 1, 105, 11, 18102
go
proc_res_op_grpdef 0, 1, 105, 1396, 139610
go

-- ��������Ա
proc_res_op_grpdef 0, 1, 106, 11, 18102
go
proc_res_op_grpdef 0, 1, 106, 1396, 139640
go
proc_res_op_grpdef 0, 1, 106, 1396, 139610
go
proc_res_op_grpdef 0, 1, 106, 1396, 139605
go

-- ������������Ա
proc_res_op_grpdef 0, 1, 107, 11, 18102
go
proc_res_op_grpdef 0, 1, 107, 1396, 139610
go
proc_res_op_grpdef 0, 1, 107, 1396, 139618
go

-- ��������������
proc_res_op_grpdef 0, 1, 108, 11, 18102
go
proc_res_op_grpdef 0, 1, 108, 1396, 139610
go
proc_res_op_grpdef 0, 1, 108, 1396, 139618
go

-- VDC����Ա
proc_res_op_grpdef 0, 1, 110, 11, 18102
go
proc_res_op_grpdef 0, 1, 110, 1396, 139610
go
proc_res_op_grpdef 0, 1, 110, 1396, 139643
go

--�����ĸ���ɫ��Ӧ�Ĳ���Ա�飺
-- proc_res_op_v_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)���������Ա���ʶ�� ������
proc_res_op_v_grpscript 0, 1, 6102, '��Դ����Ա��'
go
proc_res_op_v_grpscript 0, 1, 6103, '��֯����Ա��'
go
proc_res_op_v_grpscript 0, 1, 6104, 'VDC����Ա��'
go
proc_res_op_v_grpscript 0, 1, 6122, '��������Ա��'
go
proc_res_op_v_grpscript 0, 1, 6123, '��������Ա��'
go
proc_res_op_v_grpscript 0, 1, 6124, '��������Ա��'
go
proc_res_op_v_grpscript 0, 1, 6125, '������������Ա��'
go
proc_res_op_v_grpscript 0, 1, 6126, '����������������'
go
proc_res_op_v_grpscript 0, 1, 6142, 'VDCһ������Ա��'
go
proc_res_op_v_grpscript 0, 1, 6143, 'VDC��������Ա��'
go

--�������Ĳ���Ա�鸳���µĽ�ɫ��
-- proc_res_op_v_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)���������Ա���ʶ�� ��ɫ��ʶ
proc_res_op_v_grpdef 0, 1, 6102, 102
go
proc_res_op_v_grpdef 0, 1, 6103, 103
go
proc_res_op_v_grpdef 0, 1, 6104, 104
go
proc_res_op_v_grpdef 0, 1, 6122, 105
go
proc_res_op_v_grpdef 0, 1, 6123, 105
go
proc_res_op_v_grpdef 0, 1, 6124, 106
go
proc_res_op_v_grpdef 0, 1, 6125, 107
go
proc_res_op_v_grpdef 0, 1, 6126, 108
go
proc_res_op_v_grpdef 0, 1, 6142, 110
go
proc_res_op_v_grpdef 0, 1, 6143, 110
go

--����ʼ���û�super���ڵ��鸳��������ɫ��
-- proc_res_op_v_grpdef ��ƷID�� �޸ı�ʶ(add-1,del-2)���������Ա���ʶ�� ��ɫ��ʶ
proc_res_op_v_grpdef 0,1,1000,102
go
proc_res_op_v_grpdef 0,1,1001,102
go
proc_res_op_v_grpdef 0,1,1000,103
go
proc_res_op_v_grpdef 0,1,1001,103
go
proc_res_op_v_grpdef 0,1,1000,104
go
proc_res_op_v_grpdef 0,1,1001,104
go
proc_res_op_v_grpdef 0,1,1000,105
go
proc_res_op_v_grpdef 0,1,1001,105
go
proc_res_op_v_grpdef 0,1,1000,106
go
proc_res_op_v_grpdef 0,1,1001,106
go
proc_res_op_v_grpdef 0,1,1000,107
go
proc_res_op_v_grpdef 0,1,1001,107
go
proc_res_op_v_grpdef 0,1,1000,108
go
proc_res_op_v_grpdef 0,1,1001,108
go
proc_res_op_v_grpdef 0,1,1000,110
go
proc_res_op_v_grpdef 0,1,1001,110
go

delete from oper_rights2 where operid = 1 and servicekey = 'uniportal' and opergrpid = 6122
go
insert into oper_rights2 (operid, servicekey, opergrpid) values(1, 'uniportal', 6122)
go
delete from oper_rights2 where operid = 1 and servicekey = 'uniportal' and opergrpid = 6123
go
insert into oper_rights2 (operid, servicekey, opergrpid) values(1, 'uniportal', 6123)
go

delete from opergrp_homepage where v_opergrpid = 6122 and servicekey = 'uniportal' and homepage = ''
go
insert into opergrp_homepage (v_opergrpid, servicekey, homepage) values (6122, 'uniportal','')
go
delete from opergrp_homepage where v_opergrpid = 6123 and servicekey = 'uniportal' and homepage = ''
go
insert into opergrp_homepage (v_opergrpid, servicekey, homepage) values (6123, 'uniportal','')
go
    
-- ��������Ա:VDCһ������Ա���VDC��������Ա���µĲ���Ա level1/1 level2/2
delete from oper_information2 where operid in(3,4)
go
insert into oper_information2 (operid,opername,operpwd,operdescription,operallname ,creatorid,pwdhintday,pwdhintnum,initpwd,trait) 
    values  (3,'level1','!@#$%^SXrlgdxUjGmM9b4P8f/GaA==','VDCһ������Ա','VDCһ������Ա',1,0,5,' ','a')
insert into oper_information2 (operid,opername,operpwd,operdescription,operallname ,creatorid,pwdhintday,pwdhintnum,initpwd,trait) 
    values  (4,'level2','!@#$%^rdDNMAnl/Z1lM+gtF9zs6A==','VDC��������Ա','VDC��������Ա',1,0,5,' ','a')
go
	
delete from oper_rights2 where operid in(3,4)
go
insert into oper_rights2 (operid, servicekey,opergrpid,param1,param2,param3,param4) values(3,'uniportal',6142,0,0,-1,-1)
insert into oper_rights2 (operid, servicekey,opergrpid,param1,param2,param3,param4) values(4,'uniportal',6143,0,0,-1,-1)
go

exec proc_res_op_funcgrp2 0 ,1, 1396, '�ƹ���'
go
exec proc_res_op_function 0, 1, 1396, 139602,'�û�����'
go
exec proc_res_op_function 0, 1, 1396, 139603,'�۸����'
go
exec proc_res_op_function 0, 1, 1396, 139604,'��Դ����'
go
exec proc_res_op_function 0, 1, 1396, 139610,'��Ӫά��'
go
exec proc_res_op_function 0, 1, 1396, 139606,'������־'
go
exec proc_res_op_function 0, 1, 1396, 139612,'��ȫ��־'
go
exec proc_res_op_function 0, 1, 1396, 139613,'��־��������'
go
exec proc_res_op_function 0, 1, 1396, 139607,'���ݹ���'
go
exec proc_res_op_function 0, 1, 1396, 139608,'�澯��ַ����'
go
exec proc_res_op_function 0, 1, 1396, 139618,'��������'
go
exec proc_res_op_function 0, 1, 1396, 139615,'ģ�����'
go
exec proc_res_op_function 0, 1, 1396, 139616,'ʵ��������'
go
exec proc_res_op_function 0, 1, 1396, 139619,'���ܿ���'
go
exec proc_res_op_function 0, 1, 1396, 139624,'��־�ռ�'
go
exec proc_res_op_function 0, 1, 1396, 139620,'�豸���'
go
exec proc_res_op_function 0, 1, 1396, 139640,'��������'
go
exec proc_res_op_function 0, 1, 1396, 139642,'License����'
go
exec proc_res_op_function 0, 1, 1396, 139644,'ɱ��'
go
exec proc_res_op_function 0, 1, 1396, 139645,'ϵͳ����'
go
exec proc_res_op_function 0, 1, 1396, 139646,'�߼�'
go

update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139615 and servicekey='uniportal'
update oper_function set allowflag=1 where funcgrpid=1396 and funcid=139616 and servicekey='uniportal'
go

-- �ֶ�˵����field_type  --�ڵ�����  1-���� 2-�ַ��� 3-ip 4-������ 5-���� 6-�ʼ� 7-URL 

delete from portal_sysparam where param_name = 'default_admin_rolename'
go  
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('default_admin_rolename','admin','Ĭ�Ϲ�����ɫ����','iROS','Ĭ�Ϲ�����ɫ����',
             2,100,0,'',1,
             '','','','','')
go 

delete from portal_sysparam where param_name = 'default_member_rolename'
go  
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('default_member_rolename','_member_','Ĭ�ϳ�Ա��ɫ����','iROS','Ĭ�ϳ�Ա��ɫ����',
             2,100,0,'',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'admin_portal_ftp_username'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('admin_portal_ftp_username','root','�����Ż�������SFTP�û���','iROS','�����Ż�������SFTP�û���',
             2,100,0,' ',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'admin_portal_ftp_password'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('admin_portal_ftp_password','!@#$%^CHLGT/zyq2aAWUc1bEeChQ==','�����Ż�������SFTP����','iROS','�����Ż�������SFTP����',
             5,100,0,' ',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'admin_portal_ftp_port'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('admin_portal_ftp_port','22','�����Ż�������SFTP�˿�','iROS','�����Ż�������SFTP�˿�',
             2,100,0,' ',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'remote_syn_user'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_syn_user','','4Aͬ���û���Ϣ���õ�ַ','iROS','4Aͬ���û���Ϣ���õ�ַ',
             2,100,0,' ',1,
             '','','','','')
go
delete from portal_sysparam where param_name = 'remote_idcim_host'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('remote_idcim_host','','��ȡ���������б����õ�ַ','iROS','��ȡ���������б����õ�ַ',
             2,100,0,' ',1,
             '','','','','')
go
delete from portal_sysparam where param_name = 'iros_backup_shell_path'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_backup_shell_path','/home/iros/db_bak','����shell�ű�����·��','iROS','����shell�ű�����·��',
             2,100,0,'/home/iros/db_bak',0,
             '','','','','')
go

delete from portal_sysparam where param_name = 'volume_upper_limit'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('volume_upper_limit','500','��Ӳ�̴�С����(GB)','iROS','��Ӳ�̴�С����(GB)',
             2,100,0,' ',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'om_support_hr'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('om_support_hr', '0', '�Ƿ�֧��hr��Ȩ', 'iROS', '�Ƿ�֧��hr��Ȩ', 
			4, null, null, '1-֧��,0-��֧��', 1, 
			'', '', '', '', '')
go

delete from portal_sysparam where param_name = 'hr_server_url'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('hr_server_url', 'http://tech.zte.com.cn/tech/xmlrpc', 'hr��Ȩurl', 'iROS', 'hr��Ȩurl', 
			2, 100, 0, '', 0, 
			'', '', '', '', '')
go

delete from portal_sysparam where param_name = 'BAK_TASK_DAY'
go 
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('BAK_TASK_DAY','1','�������ݱ�����','ƽ̨ϵͳ����','���ݵ��죬����������Ϊ��ʱ��������1-7����һ���֣�1��������һ��7���������գ�������7����Ϊ���ձ��ݣ�����������Ϊ�£�������1-31����һ����,1����1�ţ�31����31��',
             1,31,1,'1',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'eazy_cloud_ip'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_ip','','��������ͬ��IP��ַ','iROS','��������ͬ��IP��ַ',
             2,1000,0,'',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'eazy_cloud_port'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_port','','��������ͬ���˿ں�','iROS','��������ͬ���˿ں�',
             2,1000,0,'',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'eazy_cloud_control'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('eazy_cloud_control','0','���ƿ��ƿ���','iROS','���ƿ��ƿ���',
             4,1000,1,'0-�ر�, 1-����',1,
             '','','','','')
go

-- delete from portal_sysparam where param_name = 'charge_tip_day'
-- go
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('charge_tip_day','3','��������','iROS','���ݵ�ǰ�����ѣ���������ʹ����������ʱ�����������',
--              1,1000,1,'3',1,
--              '','','','','')
-- go
--              
-- delete from portal_sysparam where param_name = 'charge_mail_control'
-- go
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('charge_mail_control','1','�����ʼ����ѿ���','iROS','����ʱ�Ƿ��ʼ�֪ͨ�û�',
--              4,1000,1,'0-��֪ͨ, 1-֪ͨ',1,
--              '','','','','')
-- go
--              
-- delete from portal_sysparam where param_name = 'resource_close_day'
-- go
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('resource_close_day','10','Ƿ�Ѻ���ԴԤ������','iROS','Ƿ�Ѻ���ԴԤ������',
--              1,1000,1,'10',1,
--              '','','','','')
-- go
-- 
-- delete from portal_sysparam where param_name = 'charge_switch_control'
-- go
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('charge_switch_control','0','�Ʒѿ��ƿ���','iROS','�Ʒѿ��ƿ���',
--              4,1000,1,'0-�ر�, 1-����',1,
--              '','','','','')
-- go
-- 
-- delete from portal_sysparam where param_name = 'iros_ticket_attachment_path'
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('iros_ticket_attachment_path','/home/zxin10/was/tomcat/webapps/workorder/attachment','�����������·��','iROS','�����������·��',
--              2,100,0,'/home/zxin10/was/tomcat/webapps/workorder/attachment',1,
--              '','','','','')
-- go
-- 
-- delete from portal_sysparam where param_name = 'ticket_switch_control'
-- go
-- insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
--              field_type,max_value,min_value,default_value,visiblelevel,
--              check_script,ext1,ext2,ext3,ext4)
--        values
--             ('ticket_switch_control','0','�������ƿ���','iROS','�������ƿ���',
--              4,1000,1,'0-�ر�, 1-����',1,
--              '','','','','')
-- go

delete from portal_sysparam where param_name = 'compute_threshold'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('compute_threshold', '0', '�Ƿ�֧�ַ�������ֵ����', 'iROS', '��������ֵ���ÿ���', 
			4, null, null, '1-֧��,0-��֧��', 0, 
			'', '', '', '', '')
go

delete from portal_sysparam where param_name = 'idcim_switch_control'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_switch_control','0','IDCIM�ںϿ��ƿ���','iROS','IDCIM�ںϿ��ƿ���',
             4,1000,1,'0-�ر�, 1-����',1,
             '','','','','')
go
     
delete from portal_sysparam where param_name = 'idcim_restful_url'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('idcim_restful_url','http://127.0.0.1:21180','IDCIM Restful ��ͨ����URL','iROS','IDCIM Restful ��ͨ����URL',
             2,1000,0,'',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'res_tree_root_title'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('res_tree_root_title','��������','��Դ�����ڵ��ǩ����','iROS','��Դ�����ڵ��ǩ����',
             2,100,0,' ',1,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'org_tree_root_title'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('org_tree_root_title','��֯����','��֯�����ڵ��ǩ����','iROS','��֯�����ڵ��ǩ����',
             2,100,0,' ',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'ade_path'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('ade_path','','ADE�ӿڵ�ַ','iROS','ADE�ӿڵ�ַ',
             2,1000,0,'',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'cmdb_switch_control'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('cmdb_switch_control','0','CMDB���ƿ���','iROS','CMDB���ƿ���',
             4,1000,1,'0-�ر�, 1-����',1,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'corePoolSize'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('corePoolSize','100','���ĳش�С','iROS','���ĳش�С',
             2,1000,0,'',0,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'keepAliveTime'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('keepAliveTime','3','�����̱߳���ʱ��','iROS','�����̱߳���ʱ������λ����',
             2,100,0,'',0,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'keepMonths'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('keepMonths','6','�������ݱ���ʱ��','iROS','�������ݱ���ʱ������λ����',
             2,100,0,'',1,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'maximumPoolSize'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('maximumPoolSize','200','�̳߳�����߳���','iROS','�̳߳�����߳���',
             2,100,0,'',0,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'workQueueSize'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('workQueueSize','200','������������߳���','iROS','������������߳���',
             2,100,0,'',0,
             '','','','','')
go
			 
delete from portal_sysparam where param_name = 'bandwidthUtilizationKeepMonths'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('bandwidthUtilizationKeepMonths','6','����������ͳ�����ݱ���ʱ��','iROS','����������ͳ�����ݱ���ʱ������λ����',
             2,100,0,'',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'iros_overdue_res_email_tip_days'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('iros_overdue_res_email_tip_days','7','��Դ����������ǰ����','iROS','��Դ����������ǰ��������λ����',
             2,100,0,'',1,
             '','','','','')
go
             
delete from portal_sysparam where param_name = 'iros_overdue_res_close'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
		values
			('iros_overdue_res_close', '0', '��Դ���ں��Ƿ�ر���Դ', 'iROS', '��Դ���ں��Ƿ�ر���Դ', 
			4, null, null, '1-�ر�, 0-���ر�', 1, 
			'', '', '', '', '')
go

delete from portal_sysparam where param_name = 'image_delete_interval'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('image_delete_interval','180','ɾ�����ؾ�������Ĭ�ϱȽ�ʱ��','iROS','ɾ�����ؾ�������Ĭ�ϱȽ�ʱ�䣬��λ������',
             2,100,0,'',0,
             '','','','','')
go

			 

use iros
go

if exists(select 1 from sysobjects where id = object_id('om_control_function'))
    drop table om_control_function
go
CREATE TABLE om_control_function ( 
	id      varchar(64) NOT NULL,
	name    varchar(64) NULL,
	control varchar(200) NULL,  
	primary key (id)
)
go
insert into om_control_function values ('order_switch_control', '��������','1')
insert into om_control_function values ('ticket_switch_control','��������', '1')
insert into om_control_function values ('iros_ticket_attachment_path', '�����������·��','/home/zxin10/was/tomcat/webapps/workorder/attachment')
insert into om_control_function values ('ade_switch_control','ADE����', '0')
insert into om_control_function values ('ade_path','ADE�ӿڵ�ַ', 'http://10.129.172.20:8103/ade')
insert into om_control_function values ('charge_switch_control', '�Ʒѿ���','0')
insert into om_control_function values ('charge_system', '�Ʒ�ϵͳ','0')
insert into om_control_function values ('jm_url_path', '��Žӿڵ�ַ','http://127.0.0.1:8780/csm')
insert into om_control_function values ('charge_mail_control','�����ʼ����ѿ���', '0')
insert into om_control_function values ('charge_tip_day','��������', '3')
insert into om_control_function values ('resource_close_day','Ƿ�Ѻ���ԴԤ������', '10')
insert into om_control_function values ('drs_switch_control','DRS����', '0')
insert into om_control_function values ('nubosh_switch_control', '�ư�ȫ����','1')
insert into om_control_function values ('antivurs_url', 'ɱ������URL','https://127.0.0.1:8443')
insert into om_control_function values ('antivurs_user', 'ɱ�������û���','extapiuser')
insert into om_control_function values ('antivurs_password', 'ɱ����������','vMsec#1.')
insert into om_control_function values ('antivurs_sso_aes_password', '���͵����¼AES��Կ','ZTE&nubosh#T0en')
insert into om_control_function values ('phydevice_switch_control', '�ʲ���������','0')
insert into om_control_function values ('evaluate_switch_control','ϵͳ�ͷ������ۿ���', '0')
insert into om_control_function values ('evaluate_period','����ʱ��', '')
insert into om_control_function values ('vdc_user_register_control','vdc�û�ע�Ὺ��', '0') -- 0���ر� 1������
go

if exists(select 1 from sysobjects where id = object_id('os_name_config'))
    drop table os_name_config
go
CREATE TABLE os_name_config ( 
	os_id        			varchar(100) 		NOT NULL,		
	os_type        			varchar(20) 		NOT NULL,		
	os_name        			varchar(100) 		NOT NULL,		
    PRIMARY KEY(os_id)
)
go
insert into os_name_config(os_id, os_type, os_name) values('1','Windows','Microsoft Windows 7(32)')
insert into os_name_config(os_id, os_type, os_name) values('2','Windows','Microsoft Windows 7(64)')
insert into os_name_config(os_id, os_type, os_name) values('3','Windows','Microsoft Windows Server 2003,Enterprise Edition(32)')
insert into os_name_config(os_id, os_type, os_name) values('4','Windows','Microsoft Windows Server 2003,Enterprise Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('5','Windows','Microsoft Windows Server 2003,Datacenter Edition(32)')
insert into os_name_config(os_id, os_type, os_name) values('6','Windows','Microsoft Windows Server 2003,Datacenter Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('7','Windows','Microsoft Windows Server 2003,Standard Edition(32)')
insert into os_name_config(os_id, os_type, os_name) values('8','Windows','Microsoft Windows Server 2003,Standard Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('9','Windows','Microsoft Windows Server 2003,Web Edition')
insert into os_name_config(os_id, os_type, os_name) values('10','Windows','Microsoft Windows XP Professional(32)')
insert into os_name_config(os_id, os_type, os_name) values('11','Windows','Microsoft Windows XP Professional(64)')
insert into os_name_config(os_id, os_type, os_name) values('12','Linux','Suse Linux Enterprise 11(32)')
insert into os_name_config(os_id, os_type, os_name) values('13','Linux','Suse Linux Enterprise 11(64)')
insert into os_name_config(os_id, os_type, os_name) values('14','Linux','Suse Linux Enterprise 10(32)')
insert into os_name_config(os_id, os_type, os_name) values('15','Linux','Suse Linux Enterprise 10(64)')
insert into os_name_config(os_id, os_type, os_name) values('16','Linux','Carrier Grade SERVER Linux 3(32)')
insert into os_name_config(os_id, os_type, os_name) values('17','Linux','Carrier Grade SERVER Linux 3(64)')
insert into os_name_config(os_id, os_type, os_name) values('18','Linux','Carrier Grade SERVER Linux 4(32)')
insert into os_name_config(os_id, os_type, os_name) values('19','Linux','Carrier Grade SERVER Linux 4(64)')
insert into os_name_config(os_id, os_type, os_name) values('20','Linux','Red Hat Enterprise Linux 5.5(64)')
insert into os_name_config(os_id, os_type, os_name) values('21','Linux','Red Hat Enterprise Linux 5.5(32)')
insert into os_name_config(os_id, os_type, os_name) values('22','Linux','CentOS Linux 5.6(64)')
insert into os_name_config(os_id, os_type, os_name) values('23','Linux','CentOS Linux 5.6(32)')
insert into os_name_config(os_id, os_type, os_name) values('24','Linux','Other Linux')
insert into os_name_config(os_id, os_type, os_name) values('25','Windows','Other Windows')
insert into os_name_config(os_id, os_type, os_name) values('26','Windows','Microsoft Windows Server 2008,Enterprise Edition(32)')
insert into os_name_config(os_id, os_type, os_name) values('27','Windows','Microsoft Windows Server 2008,Enterprise Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('28','Windows','Microsoft Windows Server 2008,Datacenter Edition(32)')
insert into os_name_config(os_id, os_type, os_name) values('29','Windows','Microsoft Windows Server 2008,Datacenter Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('30','Windows','Microsoft Windows Server 2008,Standard Edition(32)')
insert into os_name_config(os_id, os_type, os_name) values('31','Windows','Microsoft Windows Server 2008,Standard Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('32','Linux','Red Hat Enterprise Linux 6(64)')
insert into os_name_config(os_id, os_type, os_name) values('33','Linux','Red Hat Enterprise Linux 6(32)')
insert into os_name_config(os_id, os_type, os_name) values('34','Linux','CentOS Linux 6(64)')
insert into os_name_config(os_id, os_type, os_name) values('35','Linux','CentOS Linux 6(32)')
insert into os_name_config(os_id, os_type, os_name) values('36','Windows','Microsoft Windows Server 2012,Enterprise Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('37','Linux','CentOS Linux 6.5(64)')
insert into os_name_config(os_id, os_type, os_name) values('38','Linux','CentOS Linux 6.5(32)')
insert into os_name_config(os_id, os_type, os_name) values('39','Windows','Microsoft Windows Server 2012,Foundation Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('40','Linux','Ubuntu 12.04(64)')
insert into os_name_config(os_id, os_type, os_name) values('41','Linux','Ubuntu 12.04(32)')
insert into os_name_config(os_id, os_type, os_name) values('42','Linux','Red Hat Enterprise Linux 5.8(64)')
insert into os_name_config(os_id, os_type, os_name) values('43','Linux','Red Hat Enterprise Linux 5.8(32)')
insert into os_name_config(os_id, os_type, os_name) values('44','Linux','CentOS Linux 6.4(64)')
insert into os_name_config(os_id, os_type, os_name) values('45','Linux','CentOS Linux 6.4(32)')
insert into os_name_config(os_id, os_type, os_name) values('46','Linux','Carrier Grade SERVER Linux 5(32)')
insert into os_name_config(os_id, os_type, os_name) values('47','Linux','Carrier Grade SERVER Linux 5(64)')
insert into os_name_config(os_id, os_type, os_name) values('48','Linux','CentOS Linux 7.0(64)')
insert into os_name_config(os_id, os_type, os_name) values('49','Linux','Red Hat Enterprise Linux 6.5(64)')
insert into os_name_config(os_id, os_type, os_name) values('50','Linux','Red Hat Enterprise Linux 6.5(32)')
insert into os_name_config(os_id, os_type, os_name) values('51','Linux','Red Hat Enterprise Linux 7.0(64)')
insert into os_name_config(os_id, os_type, os_name) values('52','Windows','Microsoft Windows 8(32)')
insert into os_name_config(os_id, os_type, os_name) values('53','Windows','Microsoft Windows 8(64)')
insert into os_name_config(os_id, os_type, os_name) values('54','Windows','Microsoft Windows 8.1(32)')
insert into os_name_config(os_id, os_type, os_name) values('55','Windows','Microsoft Windows 8.1(64)')
insert into os_name_config(os_id, os_type, os_name) values('56','Linux','Ubuntu 14.04 Standard Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('57','Linux','CentOS Linux 6.3 Standard Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('58','Linux','CentOS Linux 6.4 Standard Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('59','Linux','CentOS Linux 6.5 Standard Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('60','Linux','CentOS Linux 4(64)')
insert into os_name_config(os_id, os_type, os_name) values('61','Linux','CentOS Linux 4(32)')
insert into os_name_config(os_id, os_type, os_name) values('62','Linux','CentOS Linux 5(64)')
insert into os_name_config(os_id, os_type, os_name) values('63','Linux','CentOS Linux 5(32)')
insert into os_name_config(os_id, os_type, os_name) values('64','Linux','NewStart Destop Linux Office Editon(64)')
insert into os_name_config(os_id, os_type, os_name) values('65','Linux','Red Hat Enterprise Linux 5.8 Enterprise Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('66','Linux','Red Hat Enterprise Linux 6.3 Standard Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('67','Linux','Red Hat Enterprise Linux 5(64)')
insert into os_name_config(os_id, os_type, os_name) values('68','Linux','Red Hat Enterprise Linux 5(32)')
insert into os_name_config(os_id, os_type, os_name) values('69','Linux','Red Hat Enterprise Linux 4(64)')
insert into os_name_config(os_id, os_type, os_name) values('70','Linux','Red Hat Enterprise Linux 4(32)')
insert into os_name_config(os_id, os_type, os_name) values('71','Linux','Suse Linux Enterprise 12(32)')
insert into os_name_config(os_id, os_type, os_name) values('72','Linux','Suse Linux Enterprise 12(64)')
insert into os_name_config(os_id, os_type, os_name) values('73','Windows','Microsoft Windows 10(32)')
insert into os_name_config(os_id, os_type, os_name) values('74','Windows','Microsoft Windows 10(64)')
insert into os_name_config(os_id, os_type, os_name) values('75','Windows','Microsoft Windows Server 2008 R2,Datacenter Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('76','Windows','Microsoft Windows Server 2008 R2,Standard Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('77','Windows','Microsoft Windows Server 2012 R2,Datacenter Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('78','Windows','Microsoft Windows Server 2012 R2,Standard Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('79','Windows','Microsoft Windows Server 2012,Datacenter Edition(64)')
insert into os_name_config(os_id, os_type, os_name) values('80','Windows','Microsoft Windows Server 2012,Standard Edition(64)')
go

if exists(select 1 from sysobjects where id = object_id('resource_price'))
    drop table resource_price
go
CREATE TABLE resource_price (
	name        			varchar(100) 		not null,	
	groups        			int         		not null, -- 1.������Դ 2.������Դ 3.������Դ 4.������os
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance 11.iecs os 12.physical 13.network bandwidth
    unit                    varchar(50)         not null,
	sub_type                varchar(100)        null,
	price  			        numeric(20, 5) 		not null,
	description             varchar(100)        null   
)
go

insert into resource_price (name, groups, type, unit, description, price) values ('CPU', 1, 2, 'Ԫ/��', '1�˵�λʱ��۸�', 0.05)
insert into resource_price (name, groups, type, unit, description, price) values ('�ڴ�', 1, 3, 'Ԫ/GB', '1GB��λʱ��۸�', 0.05)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('AIXϵͳ��', 1, 4, 'Ԫ/GB', 'AIX', 'AIXϵͳ��ÿGB��λʱ��۸�', 0.002)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Linuxϵͳ��', 1, 4, 'Ԫ/GB', 'Linux', 'Linuxϵͳ��ÿGB��λʱ��۸�', 0.001)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('Windowsϵͳ��', 1, 4, 'Ԫ/GB', 'Windows', 'Windowsϵͳ��ÿGB��λʱ��۸�', 0.002)
insert into resource_price (name, groups, type, unit, description, price) values ('��', 1, 7, 'Ԫ/GB', '1GB��λʱ��۸�', 0.0006)
insert into resource_price (name, groups, type, unit, description, price) values ('˽�о���', 1, 8, 'Ԫ/GB', '1GB��λʱ��۸�', 0.0006)
insert into resource_price (name, groups, type, unit, description, price) values ('����IP', 3, 5, 'Ԫ/��', '1������IP��λʱ��۸�', 0.01)
insert into resource_price (name, groups, type, unit, description, price) values ('·����', 3, 6, 'Ԫ/��', '1��·�ɵ�λʱ��۸�', 0.01)
insert into resource_price (name, groups, type, unit, description, price) values ('����ǽ', 3, 9, 'Ԫ/��', '1�׵�λʱ��۸�', 0.1)
insert into resource_price (name, groups, type, unit, description, price) values ('���ؾ���', 3, 10, 'Ԫ/��', '1�׵�λʱ��۸�', 0.1)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('���д���', 3, 13, 'Ԫ/Mbps', 'up',  '1Mbps���д�����λʱ��۸�', 0.01)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('���д���', 3, 13, 'Ԫ/Mbps', 'down',  '1Mbps���д�����λʱ��۸�', 0.01)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('���д���������', 3, 13, 'Ԫ', 'unlimit up',  '���д��������Ƶ�λʱ��۸�', 0.02)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('���д���������', 3, 13, 'Ԫ',  'unlimit down', '���д��������Ƶ�λʱ��۸�', 0.02)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('1U', 5, 14, 'Ԫ/ʱ',  'Rack-0', '', 0.02)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('2U', 5, 14, 'Ԫ/ʱ',  'Rack-1', '', 0.04)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('4U', 5, 14, 'Ԫ/ʱ',  'Rack-2', '', 0.08)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('8U', 5, 14, 'Ԫ/ʱ',  'Rack-3', '', 0.16)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('16U', 5, 14, 'Ԫ/ʱ',  'Rack-4', '', 0.32)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('32U', 5, 14, 'Ԫ/ʱ',  'Rack-5', '', 0.64)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('64U', 5, 14, 'Ԫ/ʱ',  'Rack-6', '', 1.28)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('����', 5, 15, 'Ԫ/Mbps',  '', 'ÿM��λʱ��۸�', 2)
insert into resource_price (name, groups, type, unit, sub_type, description, price) values ('������IP', 5, 16, 'Ԫ/��',  '', 'һ��������IP��λʱ��۸�', 2)
go

if exists(select 1 from sysobjects where id = object_id('resource_cost'))
    drop table resource_cost
go
CREATE TABLE resource_cost (
	vdc_id   	            int                 not null,
	tenant_id               varchar(100)        not null,
	dc_id                   varchar(100)        not null,
	type                    int                 not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
	year                    int                 not null,
	month                   int                 not null,
	cost  			        numeric(20, 5) 		not null,
    resource_number         int                 not null,
	date  			        varchar(20) 		not null   
)
go
create index idx_resource_cost on resource_cost(vdc_id, tenant_id, dc_id, type, date)
go

if exists(select 1 from sysobjects where id = object_id('t_task'))
    drop table t_task
go
create table t_task
(
    id               varchar(64)   not null,
    dc_id            varchar(64)   not null,
    vdc_id           int           not null,
    tenant_id        varchar(100)  not null,
    resource_name    varchar(100)  not null,
    resource_id      varchar(100)  not null,
    resource_type    int           not null, -- 1.instance 2.cpu 3.memory 4.disk 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
    task_type        int           not null, -- 1.add 2.update 3.delete  
    status           int           not null, -- 1.begin 2.end 3.error    
    start_time       datetime      not null,
    end_time         datetime      null,
    operator         varchar(100)  null,
	operator_ip		 varchar(100)  null,
    description      text          null,
    primary key (id)
)
go

--ҵ�����
if(exists(select 1 from sysobjects where name='om_business_grp'))
  drop table om_business_grp
go
create table om_business_grp (
   id                     varchar(40)          not null,   --ҵ����ID
   name                   varchar(100)         not null,   --ҵ��������
   description            varchar(300)         not null,   --ҵ��������
   image_id               varchar(40)          not null,   --ҵ���龵��ID
   flavor_id              varchar(40)          not null,   --ҵ������ID
   network_id             varchar(40)          not null,   --ҵ��������ID
   constraint PK_OM_BUSINESS_GRP primary key (id)
)
go

--ҵ����������ϵ��
if(exists(select 1 from sysobjects where name='om_busigrp_instance'))
  drop table om_busigrp_instance
go
create table om_busigrp_instance (
   busigrp_id             varchar(40)          not null,   --ҵ����ID
   instance_id            varchar(40)          not null,   --���ID
   constraint PK_OM_BUSIGRP_INSTANCE primary key (busigrp_id, instance_id)
)
go

--���Ա�
if(exists(select 1 from sysobjects where name='om_strategy'))
  drop table om_strategy
go
create table om_strategy (
   id                     varchar(40)          not null,   --����ID
   name                   varchar(100)         not null,   --��������
   description            varchar(300)         not null,   --��������
   cpu_rel                int                  not null,   --CPU������0: <=, 1: >=, 2: =
   cpu_rel_val            int                  not null,   --CPU����, 10-100������10% - 100%
   mem_rel                int                  not null,   --�ڴ�������0: <=, 1: >=, 2: =
   mem_rel_val            int                  not null,   --�ڴ�����, 10-100������10% - 100%
   cpu_mem_rel            int                  not null,   --CPU�������ڴ������߼���ϵ��0: AND, 1: OR
   duration               int                  not null,   --���ʱ�䣬��λ����
   times                  int                  not null,   --��������
   action_type            int                  not null,   --�������ͣ�0: ���ݣ�1: ����
   cool_time              int                  not null,   --��ȴʱ�䣬��λ����
   priority               text                 not null,   --���ȼ�
   create_time            datetime             not null,   --���Դ���ʱ��
   cool_status            int     default 0    not null,   --0����ȴ 1��ȴ 
   last_result            tinyint              null,
   last_time              datetime             null,
   next_time              datetime             null, 
   count_num              int     default 0    null,--�����������ȵ���������ֵ�ٵ���
   busigrp_id             varchar(40)          not null,   --ҵ����ID
   constraint PK_OM_STRATEGY primary key (id)
)
go

--����ִ�б�
if(exists(select 1 from sysobjects where name='om_strategy_exec'))
  drop table om_strategy_exec
go
create table om_strategy_exec (
  id                     varchar(40)           not null,   --ID
  strategy_id	         int                   not null,     --���Ա�� 
  server_ip              varchar(100)          null,     --�����ȷ�������IP
  server_id              varchar(100)          null,     --�����ȵķ�������ID
  status                 tinyint               not null,     --״̬ 0 ��� 1 ִ����
  start_time	         datetime              not null,     --ִ�п�ʼʱ��
  end_time	             datetime              null,     --ִ�н���ʱ��
  result	             tinyint               null,     --ִ�н����0-�½� 1-�ɹ� 2-ʧ�� 3-����
  info	                 varchar(200)          null,     --����,ʧ��ԭ���
  constraint PK_OM_STRATEGY_EXEC primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('common_identity'))
    drop table common_identity
go
CREATE TABLE common_identity ( 
	tablename						varchar(50) 	NOT NULL,
	idvalue						int 	NULL,		
    PRIMARY KEY(tablename)
)
go


if exists(select 1 from sysobjects where id = object_id('t_dc'))
    drop table t_dc
go
CREATE TABLE t_dc ( 
	dc_id							varchar(100) 	NOT NULL,
	dc_name							varchar(100) 	NOT NULL,
    dc_desc							varchar(999) 	NULL,
	common_url						varchar(100)	NULL,
	admin_url						varchar(100)	NULL,
	vmware_datacenter				varchar(100)	NULL,
	power_domainid					varchar(100)	NULL,
	power_projectname				varchar(100)	NULL,
	power_ip						varchar(64)		NULL,
	admin_username					varchar(100)	NULL,
	admin_password					varchar(100)	NULL,
	domain_id						varchar(100)	NOT NULL,
	dc_type							int				NOT NULL,
	status							int				NOT NULL,	
	extra							text			NULL,
    PRIMARY KEY(dc_id)
)
go


if exists(select 1 from sysobjects where id = object_id('om_user_info'))
    drop table om_user_info
go
CREATE TABLE om_user_info ( 
	vdcid   	int NOT NULL,
	username	varchar(100) NOT NULL,
	password	varchar(128) NOT NULL,
	email   	varchar(100) NULL,
	userid  	int          NOT NULL,
	phone   	varchar(64)  NULL,
	orgid		varchar(64)  NULL,
	type		int 		 NULL,
	status		int 		 NULL,
	description	text,
	opinion		text,
	extra		varchar(1024) NULL,
	createdtime	datetime 		NULL,
	auditedtime	datetime 		NULL,
	PRIMARY KEY(userid)
)
go

if exists(select 1 from sysobjects where id = object_id('om_user_dc_rel'))
    drop table om_user_dc_rel
go
CREATE TABLE om_user_dc_rel ( 
	userid  			int NULL,
	dcid				varchar(100) NOT NULL,
	zoneid				varchar(100) NOT NULL,
	computenodeid   	varchar(100) NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_vdc'))
    drop table om_vdc
go
CREATE TABLE om_vdc ( 
	vdcid   	numeric NOT NULL,
	vdcname 	varchar(64) NOT NULL,
	vdcdesc 	varchar(256) NULL,
	domainid	varchar(100) DEFAULT 0 NOT NULL,
	tenantid	varchar(64) NULL 
	)
go

if exists(select 1 from sysobjects where id = object_id('om_irai_quota'))
    drop table om_irai_quota
go
CREATE TABLE om_irai_quota ( 
	id						varchar(64)				not null, 	-- id
	create_date				datetime				not null, 	-- ����ʱ��
	update_date				datetime				not null, 	-- ����ʱ��
	dc_id					varchar(64)				not null, 	-- dc_id
	dc_type					int						not null,	-- dc���ͣ�3��vmware��4��power��
	tenant_id				varchar(64)				not null, 	-- �⻧id
	vdc_id					numeric				not null,
	resource_id				varchar(64)				not null,	-- ���id
	resource				varchar(100)			not null,	-- �������
	in_use					numeric					default 0		not null, 	-- ��ʹ��
	hard_limit				numeric					not null, 	-- ����
	PRIMARY KEY(id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_vdc_dc_rel'))
    drop table om_vdc_dc_rel
go
CREATE TABLE om_vdc_dc_rel ( 
	vdcid        	numeric NOT NULL,
	dcid         	varchar(100) NOT NULL,
	projectid    	varchar(100) NOT NULL
	)
go

if exists(select 1 from sysobjects where id = object_id('om_vdc_admin_rel'))
    drop table om_vdc_admin_rel
go
CREATE TABLE om_vdc_admin_rel ( 
	vdcid        	numeric NOT NULL,
	dcid         	varchar(100) NOT NULL,
	adminuserid  	varchar(100) NOT NULL,
	ommpuserid   	numeric NULL
	)
go

if exists(select 1 from sysobjects where id = object_id('om_vdc_computenode_rel'))
    drop table om_vdc_computenode_rel
go
CREATE TABLE om_vdc_computenode_rel ( 
	vdcid        	numeric NULL,
	dcid         	varchar(100) NULL,
	zoneid       	varchar(100) NULL,
	computenodeid	varchar(100) NULL 
	)
go


if(exists(select 1 from sysobjects where name='om_service_config'))
  drop table om_service_config
go
create table om_service_config (
   id                     varchar(40)          not null,   
   name                   varchar(100)         not null,   
   admin_url              varchar(200)         not null,   
   public_url             varchar(200)         not null,   
   internal_url           varchar(200)         not null,   
   description            varchar(300)         null, 
   service_type           varchar(100)          not null,   
   extra                  text			       null,
   constraint PK_OM_BUSINESS_GRP primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_cidr'))
    drop table om_cidr
go
CREATE TABLE om_cidr ( 
    vdcid						varchar(100)				NULL,	-- vdcid
	cidr						varchar(100)				NOT NULL,	-- �����ַ
	vlan						varchar(10)					NULL,		-- vlan id
	PRIMARY KEY(cidr)
)
go

use zxinsys
go
--OMMP���������־�� 3961~3970 
exec proc_res_op_paratype 0, 1, 3961, '�ƹ���'
go

use iros
go
if exists(select 1 from sysobjects where id = object_id('om_res_template'))
    drop table om_res_template
go
create table om_res_template
(
   id                   varchar(64) not null,
   dcid                 varchar(64) not null,
   name                 varchar(200) null,
   flavoroid            varchar(64) null,
   imageid              varchar(64) null,
   status               varchar(10) null,
   description          varchar(400) null,
   primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_vm_info_task'))
    drop table om_vm_info_task
go
CREATE TABLE om_vm_info_task ( 
	id							varchar(64) 	NOT NULL,   -- ID
	dc_id						varchar(64) 	NULL,   -- dcID
	dc_name						varchar(100) 	NULL,   -- dc����
	dc_type						varchar(2) 		NULL,   -- dc����
	domain_id					varchar(64) 	NULL,   -- domain ID
	domain_name					varchar(100) 	NULL,   -- domain name
	zone_name					varchar(100) 	NULL,   -- ��Ⱥ����
	host_name					varchar(100) 	NULL,   -- ��������
	name						varchar(100) 	NULL,   -- �������
	created						varchar(32) 	NULL,   -- ����ʱ��
	user_id						varchar(100) 	NULL,   -- �û�id
	user_name					varchar(100) 	NULL,   -- �û�����
	tenant_id					varchar(100) 	NULL,   -- �⻧id
	tenant_name					varchar(100) 	NULL,   -- �⻧����
	image_id					varchar(100) 	NULL,   -- ����id
	image_name					varchar(100) 	NULL,   -- ��������
	addresses					varchar(100) 	NULL,   -- mac��ַ
	flavor_id					varchar(200) 	NULL,   -- ���id
	flavor_info					varchar(200) 	NULL,   -- ���
	ip_info						varchar(1000) 	NULL,   -- IP
	task_state					varchar(100) 	NULL,   -- ��ǰ����
	power_state					varchar(2) 		NULL,   -- ��Դ״̬
	vm_state					varchar(100) 	NULL,   -- ���״̬
	servergroup_info			varchar(100) 	NULL,   -- ��������
	is_volume_attached			varchar(64) 	NULL,   
	
    PRIMARY KEY(id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_dc_info_task'))
    drop table om_dc_info_task
go
CREATE TABLE om_dc_info_task ( 
	dc_id							varchar(64) 	NOT NULL,   -- ID
	dc_name							varchar(100) 	NOT NULL,   -- ����
	dc_type							varchar(2) 		NULL,   -- dc����
	domain_id						varchar(64) 	NULL,   -- domain ID
	domain_name						varchar(100) 	NULL,   -- domain name
	zone_count						int 	 NULL,		-- ��Ⱥ��
	host_count						int 	 NULL,		-- ������
	vm_count						int 	 NULL,	-- �����	
	cpu_used						int		 NULL,	-- cpuʹ����(��)
	cpu_all							int		 NULL,		-- cpu����(��)
	mem_used						bigint 	 NULL,   -- �ڴ�ʹ����(MB)
	mem_all							bigint      NULL,   -- �ڴ�����(MB)
	disk_used						int	     NULL,		-- �洢ʹ����(GB)
	disk_all						int 	 NULL,	-- �洢����	(GB)
	volume_count					int			NULL,	-- ��Ӳ�̸���
	image_count						int			NULL,	-- �������
	network_count					int			NULL,	-- �������
	shared_network_count			int			NULL,	-- �����������
	external_network_count			int			NULL,	-- �ⲿ�������
	extra							varchar(1000)	NULL,		-- ��չ�ֶ�
    PRIMARY KEY(dc_id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_host_info_task'))
    drop table om_host_info_task
go
CREATE TABLE om_host_info_task ( 
	id							varchar(64) 	NOT NULL,   -- ID
	dc_id						varchar(64) 	NULL,   -- dcID
	dc_name						varchar(100) 	NULL,   -- dc����
	dc_type						varchar(2) 		NULL,   -- dc����
	zone_name					varchar(100) 	NULL,   -- ��Ⱥ����
	host_name					varchar(100) 	NULL,   -- ��������
	host_ip						varchar(64) 	NULL,   -- ����IP
	status						varchar(32) 	NULL,   -- ״̬
	hypervisor_type				varchar(32)		NULL,   -- ����
	vcpus						int		 NULL,		-- �����ںˣ��ܼƣ�
	vcpus_used					int 	 NULL,   -- �����ںˣ���ʹ�ã�
	memory_mb					bigint   NULL,   -- �ڴ��ܼ�
	memory_mb_used				bigint	 NULL,		-- �ڴ���ʹ��
	local_gb					int 	 NULL,	-- �洢�ܼ�
	local_gb_used				int	NULL,		-- �洢��ʹ��
	running_vms					int	NULL,		-- ����������
    PRIMARY KEY(id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_zone_info_task'))
    drop table om_zone_info_task
go
CREATE TABLE om_zone_info_task ( 
	id							varchar(64) 	NOT NULL, 
	dc_id						varchar(64) 	NULL, 
	dc_name						varchar(100) 	NULL,  
	dc_type						varchar(2) 		NULL, 
	name						varchar(100) 	NULL,   
	created						varchar(64) 	NULL,
	updated						varchar(64) 	NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_base_tree'))
    drop table om_base_tree
go
CREATE TABLE om_base_tree ( 
	id						varchar(64) 	NOT NULL,   -- ID
	name						varchar(100) 	NOT NULL,   -- ����
	description						varchar(250) 	NULL,		-- ����
	parent_id						varchar(100) 	NOT NULL,	-- ���ڵ�	
	type							int		NOT NULL,	-- ���ͣ�1����Դ 2����֯��
	extra							varchar(500)	NULL,		-- ��չ�ֶ�
    PRIMARY KEY(id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_oper_res_rel'))
    drop table om_oper_res_rel
go
CREATE TABLE om_oper_res_rel ( 
	rel_id						varchar(64) 	NOT NULL,   -- ����id
	oper_id					decimal(10) 	NOT NULL,   -- �û�id��ommp���û�id��
	type						int		NOT NULL,	-- �����ڵ����ͣ�1��tree�ڵ� 2��dc�ڵ㣩����������tree�ڵ㣬��Ĭ��Ϊ��tree�ڵ������нڵ㶼����
	resource_id					varchar(100) 	NOT NULL,	-- ��������Դ�ڵ�id
    PRIMARY KEY(rel_id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_oper_org_rel'))
    drop table om_oper_org_rel
go
CREATE TABLE om_oper_org_rel ( 
	rel_id						varchar(64) 	NOT NULL,   -- ����id
	oper_id					decimal(10) 	NOT NULL,   -- �û�id��ommp���û�id��
	type						int		NOT NULL,	-- �����ڵ����ͣ�1��tree�ڵ� 2��vdc�ڵ㣩����������tree�ڵ㣬��Ĭ��Ϊ��tree�ڵ������нڵ㶼����
	resource_id					varchar(100) 	NOT NULL,	-- ��������Դ�ڵ�id
    PRIMARY KEY(rel_id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_org_res_rel'))
    drop table om_org_res_rel
go
CREATE TABLE om_org_res_rel ( 
	rel_id						varchar(64) 	NOT NULL,   -- ����id
	org_id					varchar(100) 	NOT NULL,   -- ��֯id
	type						int		NOT NULL,	-- �����ڵ����ͣ�1��domain�ڵ� 2��dc�ڵ㣩����������domain����Ĭ��Ϊ��domain�����нڵ㶼�ܿ���
	resource_id					varchar(100) 	NOT NULL,	-- ��������Դ�ڵ�id
    PRIMARY KEY(rel_id)
)
go

if exists(select 1 from sysobjects where id = object_id('oandmconfig'))
    drop table oandmconfig
go

CREATE TABLE oandmconfig (
	id						varchar(64)			not null,
	name					varchar(255)		not null,	
	type					int					not null, -- 1.M 2.O
	description				text				null,
	url						varchar(255)		not null,
	dc_id					varchar(64)			not null,
	username				varchar(50)			not null,
	password				varchar(100)		not null,
	primary key (id)
)
go


use zxinsys
go
exec proc_add_res_definition 'IROSOWNER', '��Դ����', 'ROOT', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_owner', '', null
exec proc_add_res_definition 'IROSDC', '��������', 'IROSOWNER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_dc', '', null
exec proc_add_res_definition 'IROSCLUSTER', '��Ⱥ', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_cluster', '', null
exec proc_add_res_definition 'IROSHOST', '����', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host', '', null
exec proc_add_res_definition 'IROSVM', '������', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm', '', null
exec proc_add_res_definition 'IROS_REPOS_GRP', '�洢��', 'IROSCLUSTER', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp', '', null
exec proc_add_res_definition 'IROS_REPOS_GRP_MANAGE', '�洢��', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_manage', '', null
exec proc_add_res_definition 'IROS_REPOS_GRP_PUB', '�洢��', 'IROSDC', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_grp_pub', '', null
exec proc_add_res_definition 'IROS_REPOS', '�洢', 'IROS_REPOS_GRP', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos', '', null
exec proc_add_res_definition 'IROS_REPOS_MANAGE', '�洢', 'IROS_REPOS_GRP_MANAGE', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_manage', '', null
exec proc_add_res_definition 'IROS_REPOS_PUB', '�洢', 'IROS_REPOS_GRP_PUB', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_repos_pub', '', null
exec proc_add_res_definition 'IROS_HOSTNIC', '��������', 'IROSHOST', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_host_nic', '', null
exec proc_add_res_definition 'IROS_VMNIC', '����������', 'IROSVM', 'RESOURCE', 'MM,AM', 0, 'irosrms', 'iros', 'ent_res_vm_nic', '', null

exec proc_add_oper_rmenu 'IROSOWNER', 0, 'SYNCHRONOUS RESOURCE', '/irosopsm/resourcemanage/tree/syncOmmpResource.action',null,1,0
go

use iros
go

if exists(select 1 from sysobjects where id = object_id('iros_version_info'))
    drop table iros_version_info
go
create table iros_version_info 
( 
	name						varchar(100) 	NOT NULL,
	version				        varchar(200) 	NULL,
	extra						varchar(500) 	NULL
)

go

insert into iros_version_info(name, version, extra) values('iROS', 'ZXCLOUD-iROSV4.04.06T04', '')
insert into iros_version_info(name, version, extra) values('OMMP', 'ZXCLOUD-OMMPV6.01.13', '')

if exists(select 1 from sysobjects where id = object_id('ent_res_owner'))
    drop table ent_res_owner
go
create table ent_res_owner(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_dc'))
    drop table ent_res_dc
go
create table ent_res_dc(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_cluster'))
    drop table ent_res_cluster
go
create table ent_res_cluster(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_host'))
    drop table ent_res_host
go
create table ent_res_host(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_vm'))
    drop table ent_res_vm
go
create table ent_res_vm(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos_grp'))
    drop table ent_res_repos_grp
go
create table ent_res_repos_grp(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos_grp_manage'))
    drop table ent_res_repos_grp_manage
go
create table ent_res_repos_grp_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos_grp_pub'))
    drop table ent_res_repos_grp_pub
go
create table ent_res_repos_grp_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos'))
    drop table ent_res_repos
go
create table ent_res_repos(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos_manage'))
    drop table ent_res_repos_manage
go
create table ent_res_repos_manage(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_repos_pub'))
    drop table ent_res_repos_pub
go
create table ent_res_repos_pub(
   entid                varchar(100)                    not null,
   entname              varchar(50)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_host_nic'))
    drop table ent_res_host_nic
go
create table ent_res_host_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

if exists(select 1 from sysobjects where id = object_id('ent_res_vm_nic'))
    drop table ent_res_vm_nic
go
create table ent_res_vm_nic(
   entid                varchar(100)                    not null,
   entname              varchar(255)                     null,
   entrid               varchar(100)                    not null,
   parentrid            varchar(100)                    not null,
   parententid          varchar(100)                    not null,
   entip                varchar(100)                    null,
   msgtype              numeric(1)                      null,
   msgattrs             varchar(100)                    null,
   entstatus            numeric(1)                      null,
   primary key (entid)
)
go

-- iros��
delete from ent_res_owner where entid = '1'
insert into ent_res_owner values ('1', 'iROS RESOURCE', 'IROSOWNER', 'ROOT', 'ROOT', '', 0, '', 0)
go

if exists(select 1 from sysobjects where id = object_id('dc_ommp_restype_rel'))
    drop table dc_ommp_restype_rel
go
create table dc_ommp_restype_rel (
   dc_type           integer                   not null,
   dc_restype        varchar(50)               not null,
   ommp_restype      varchar(50)               not null, 
   primary key (dc_type, dc_restype)
)
go

-- iECS 
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP', 'IROS_REPOS_GRP')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_MANAGE', 'IROS_REPOS_GRP_MANAGE')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_GRP_PUB', 'IROS_REPOS_GRP_PUB')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS', 'IROS_REPOS')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_MANAGE', 'IROS_REPOS_MANAGE')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'REPOS_PUB', 'IROS_REPOS_PUB')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMC', 'IROSDC')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VM', 'IROSVM')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'HOST', 'IROSHOST')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'POOL', 'IROSCLUSTER')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'NIC', 'IROS_HOSTNIC')
insert into dc_ommp_restype_rel(dc_type, dc_restype, ommp_restype) values(1, 'VMNETCARD', 'IROS_VMNIC')
go

use zxinsys
go


exec proc_res_op_function 0, 1, 1396, 139605,'��������'
go
exec proc_res_op_function 0, 1, 1396, 139617,'��������'
go
exec proc_res_op_function 0, 1, 1396, 139630,'����ͳ��'
go
exec proc_res_op_function 0, 1, 1396, 139643,'VDC����'
go

delete from portal_sysparam where param_name = 'order_task_count'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('order_task_count','3','����������Դ����������','iROS','����������Դ����������',
             2,1000,0,'',1,
             '','','','','')
go

delete from portal_sysparam where param_name = 'log_collect_upper_limit'
go
insert into portal_sysparam (param_name,param_value,param_desc,paramgroup,description,
             field_type,max_value,min_value,default_value,visiblelevel,
             check_script,ext1,ext2,ext3,ext4)
       values
            ('log_collect_upper_limit','300','��־һ���ռ��ļ���������(��)','iROS','��־һ���ռ��ļ���������(��)',
             2,300,0,' ',1,
             '','','','','')
go

use iros
go

if exists(select 1 from sysobjects where id = object_id('om_order'))
    drop table om_order
go
create table om_order
(
   order_id             int not null,
   order_code           varchar(64) not null,
   dc_id                varchar(64),
   city_id              varchar(100),
   vdc_id               varchar(64),
   user_id              int not null,
   res_type             tinyint not null,
   oper_type            tinyint not null , -- 1-������Դ 2-�����Դ 3-������Դ
   process_id           int not null,
   current_step         int not null,
   start_date           datetime not null,
   end_date             datetime,
   quantity             int not null,
   primary key (order_id)
)
go


if exists(select 1 from sysobjects where id = object_id('om_order_audit'))
    drop table om_order_audit
go
create table om_order_audit
(
   order_audit_id       int not null,
   order_id             int not null,
   auditor_id           int not null,
   audit_date           datetime not null,
   audit_content        varchar(500) not null,
   primary key (order_audit_id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_order_forceendservers'))
    drop table om_order_forceendservers
go
create table om_order_forceendservers
(
   id       			varchar(64) not null,
   order_id             varchar(64) not null,
   instance_id          varchar(64) not null,
   dc_id           		varchar(64) not null, 
   status        		tinyint, -- 1-��ɾ�� 2-ɾ���� 3-ɾ��ʧ��
   primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_order_detail'))
    drop table om_order_detail
go
create table om_order_detail
(
   order_detail_id      int not null,
   order_id             int not null,
   order_params         text not null,
   primary key (order_detail_id)
)
go


if exists(select 1 from sysobjects where id = object_id('om_order_process'))
    drop table om_order_process
go
create table om_order_process
(
   process_id           int not null,
   name                 varchar(50) not null,
   description          text,
   auto_step            int not null,
   is_use               tinyint not null , --0:  ������   1:  ����
   is_auto_deliver      tinyint not null , --0:  �ֹ����� 1:  �Զ�����
   primary key (process_id)
)
go

insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(2, '����Դ������������', '�������������������桢����ǽ�����ؾ�����Դ��������������', 2, 0, 0)
insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(4, 'VDC������������', '������VDC��������������', 1, 0, 0)
go

if exists(select 1 from sysobjects where id = object_id('om_order_process_config'))
    drop table om_order_process_config
go
create table om_order_process_config
(
   process_id           int not null,
   step                 int not null,
   description          text,
   role_id              int null ,
   current_status       varchar(50) not null,
   next_status          varchar(50) not null,
   is_rollback          tinyint not null   --0�������Ի��� 1�����Ի���
)
go

insert into om_order_process_config values (2, 1, '����', null, '���ύ', '������', 0)
insert into om_order_process_config values (2, 2, 'ϵͳ����', null, '������', '������', 0)
insert into om_order_process_config values (2, 3, '����', null, '������', '�����ر�', 0)
insert into om_order_process_config values (2, -2, '�쳣����', null, '�쳣����', '�쳣����', 0)
insert into om_order_process_config values (2, -1, '�����ܾ�', null, '�����ܾ�', '�����ܾ�', 0)
insert into om_order_process_config values (2, 0, '�����ر�', null, '�����ر�', '�����ر�', 0)

insert into om_order_process_config values (4, 1, 'һ������', null, '������', '������', 0)
insert into om_order_process_config values (4, 2, '��������', null, '������', '�����ر�', 0)
insert into om_order_process_config values (4, -3, '�쳣����', null, '�쳣����', '�쳣����', 0)
insert into om_order_process_config values (4, -2, '���������ܾ�', null, '���������ܾ�', '�����ܾ�', 0)
insert into om_order_process_config values (4, -1, 'һ�������ܾ�', null, 'һ�������ܾ�', '�����ܾ�', 0)
insert into om_order_process_config values (4, 0, '�����ر�', null, '�����ر�', '�����ر�', 0)
go

if exists(select 1 from sysobjects where id = object_id('om_res_order_process_rel'))
    drop table om_res_order_process_rel
go
create table om_res_order_process_rel
(
   res_type             tinyint not null,
   process_id           int not null
)
go


if exists(select 1 from sysobjects where id = object_id('om_order_sequence'))
    drop table om_order_sequence
go
create table om_order_sequence
(
   cur_month            int not null,
   cur_value            int not null
)
go

if exists(select 1 from sysobjects where id = object_id('om_order_task'))
    drop table om_order_task
go
create table om_order_task
(
   order_detail_id      int not null,
   task_id              int not null,
   task_step            tinyint not null,
   task_status          tinyint not null , --1-�ɹ� 2-ʧ�� 3-������
   retry_num            int default 0 not null ,
   req_params           text,
   resp_params          text,
   primary key (task_id)
)
go


insert into om_res_order_process_rel (res_type, process_id) values(1, 2)
insert into om_res_order_process_rel (res_type, process_id) values(3, 2)
insert into om_res_order_process_rel (res_type, process_id) values(4, 2)
insert into om_res_order_process_rel (res_type, process_id) values(9, 2)
insert into om_res_order_process_rel (res_type, process_id) values(10, 4)

if exists(select 1 from sysobjects where id = object_id('om_order_res_rel'))
    drop table om_order_res_rel
go
create table om_order_res_rel
(
   id          varchar(64) not null,
   dc_id       varchar(64) not null,
   vdc_id      int not null,
   user_id     int not null,
   order_id    int not null,
   res_type    tinyint not null,
   deliver_time    datetime null, 
   expire_time     datetime null, 
   primary key (id)
)
go

use iros
go
if exists(select 1 from sysobjects where id = object_id('om_ticket_process'))
    drop table om_ticket_process
go
if exists(select 1 from sysobjects where id = object_id('om_ticket'))
    drop table om_ticket
go

create table om_ticket
(
   ticket_id            int not null,
   code                 varchar(64) not null,
   title                varchar(64) not null,
   description          text not null,
   category             tinyint not null,
   status               tinyint not null, 
   creator_id           int not null,
   creator              varchar(64) not null,
   phone                varchar(20) not null,
   create_time          datetime not null,
   step                 int not null,
   handler_id           int null,
   handler              varchar(64) null,
   respond_time         datetime,
   update_time          datetime,
   close_time           datetime,
   extra                text,
   order_id             int null,
   order_detail_id      int null,
   city_id              varchar(100) null,
   computerroom_id      varchar(100) null,
   primary key (ticket_id)
)
go

create table om_ticket_process
(
   process_id           int not null,
   ticket_id            int not null,
   step                 int not null,
   oper_type            int not null, 
   opinion              text null,
   handler_id           int null,
   handler              varchar(50) not null,
   handle_time          datetime not null,
   attachment_path      varchar(255) null,
   attachment           varchar(1000) null,
   attachmentids        varchar(200) null, 
   primary key (process_id)
)
go


if exists(select 1 from sysobjects where id = object_id('om_bak_vm_policy'))
    drop table om_bak_vm_policy
go
create table om_bak_vm_policy
(
   vdc_id   	numeric NOT NULL,
   bak_cycle 	tinyint not null, 
   bak_day		tinyint not null,
   bak_time		varchar(5),  
   primary key (vdc_id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_bak_vm'))
    drop table om_bak_vm
go
create table om_bak_vm
(
   bak_id		int not null,
   vdc_id   	numeric NOT NULL,
   dc_id        varchar(64) NOT NULL,
   project_id   varchar(64) NOT NULL,
   vm_id		varchar(64) NOT NULL,
   vm_name		varchar(200),
   vm_type		tinyint null, 
   image_id		varchar(64) NOT NULL,
   image_name 	varchar(200),
   type			tinyint not null, 
   update_date  datetime not null,
   extra		text,
   
   primary key (bak_id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_resource_statistic'))
    drop table om_resource_statistic
go
create table om_resource_statistic
(
   vdc_id   	   int not null,
   dc_id   	       varchar(100),
   year            varchar(10) not null,
   yearmonth       varchar(10) not null,
   date            varchar(10) not null,
   type            int not null, -- 1.instance 5.public ip 6.router 7.volume 8.snapshot 9.firewall 10.loadbalance
   resource_id     varchar(100) not null,
   resource_name   varchar(100) not null,
   usagetime       int          not null,
   
   primary key (type, resource_id, resource_name, date)
)
go

if exists(select 1 from sysobjects where id = object_id('om_compute_threshold'))
    drop table om_compute_threshold
go
create table om_compute_threshold
(
	dc_id				varchar(64)		not null,
	[compute]				varchar(100)	not null,
	cpu					int				not null,
	mem					int				not null,
	primary key (dc_id, [compute])
)
go

if exists(select 1 from sysobjects where id = object_id('om_compute_migrate'))
    drop table om_compute_migrate
go
create table om_compute_migrate
(
	task_id				varchar(64)		not null,
	dc_id				varchar(64)		not null,
	[compute]				varchar(100)	not null,
	server_id			varchar(64)		not null,
	server_name			varchar(64)		not null,
	migrate_result		int				not null,
	migrate_detail		text			null,
	migrate_time		datetime		not null,
	primary key (task_id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_dci'))
    drop table om_dci
go
create table om_dci
(
	dci_id        	int NOT NULL,
	dci_name        varchar(255) NOT NULL,
	vdc_id        	int NOT NULL,	
	export_rt       varchar(100)  NOT NULL,
	import_rt       varchar(100)  NOT NULL,
	rd              varchar(100)  NOT NULL,
	vni        	    varchar(100)  NOT NULL,
	tag				varchar(100)   NULL,
	tag_type		varchar(100)   NULL,
	dscp			int 	NULL,
	primary key (dci_id) 
)
go

if exists(select 1 from sysobjects where id = object_id('om_dci_sub'))
    drop table om_dci_sub
go
create table om_dci_sub
(
	dci_id        	int NOT NULL,	
	dc_id         	varchar(100)  NOT NULL,
	tenant_id       varchar(100)  NOT NULL,
	net_id        	varchar(100)  NOT NULL,	
	sub_id        	varchar(100)  NOT NULL,
    sub_ipmask      varchar(100)  NOT NULL		
)
go

if exists(select 1 from sysobjects where id = object_id('om_base_service'))
    drop table om_base_service
go
create table om_base_service
(
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64) NOT NULL,
	rel_id      varchar(500) NOT NULL,
	description  varchar(500) NULL,
	dc_type 	varchar(500) NULL,
	primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_service_directory'))
    drop table om_service_directory
go
create table om_service_directory
(
	id        	int NOT NULL,
	name        varchar(64) NOT NULL,
	switch_name  varchar(64)  NULL,
	dc_id      varchar(100) NOT NULL,
	template_id  int  NULL,
	vdc_id   	numeric  NULL,
	type        tinyint NOT NULL,
	parent_id      int  NULL,
	is_use        tinyint NOT NULL,
	is_publish      tinyint NOT NULL,
	extra        text  NULL,
	primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_service_rel'))
    drop table om_service_rel
go
create table om_service_rel
(
	id        	int NOT NULL,
	rel_id      int NOT NULL,
	dc_id  varchar(100) NOT NULL,
	type	tinyint NOT NULL
)
go

insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (1, 'VPN', 'switch_vpn', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (2, '���ؾ���', 'switch_lb', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (3, '����ǽ', 'switch_firewall', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (4, 'DCI', 'switch_dci', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (5, '��ȫ��', 'switch_sg', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (6, '�������⻯����', 'switch_base', '','',',1,2,3,4,5,6,7,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (7, 'ҵ���Զ�����', 'switch_adt', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (8, 'ҵ�񻷾�', 'switch_service', '7','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (9, '��������', 'switch_backup_add', '6','',',2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (10, 'ȫ������', 'switch_backup_all', '6','',',2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (11, '�˿���ͳ��', 'switch_flow', '6','',',1,2,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (13, '����', 'switch_dpmbackup', '6','',',1,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (14, '��������', 'switch_rackrent', '','�ṩ��������������Ĺ��ܣ�ͬʱ�ṩ����������������������IP�Ľ��룬������ҵ�Ľ��롣',',1,2,3,4,5,6,7,')
insert into om_base_service (id, name, switch_name, rel_id, description, dc_type) values (16, '������', 'switch_irai', '','',',1,')
go


if exists(select 1 from sysobjects where id = object_id('om_ade_template'))
    drop table om_ade_template
go
create table om_ade_template
(
	id                     int         not null,   
   name                   varchar(100)         not null,  
   type                   tinyint         not null,  
   description                   text         null,       
   status                 tinyint    default 0 not null,   
   dc_id	              varchar(100)         not null,   
   tenant_id              varchar(100)         not null,   
   delete_flag			  tinyint    default 0 not null,   
   creator_id             numeric         		NOT NULL,       
   create_time            datetime             null,      
   delete_time            datetime             null,       
   update_time            datetime             null,      
   extra				  text         null,      
   primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_ade_instance'))
    drop table om_ade_instance
go
create table om_ade_instance
(
	id								int 	NOT NULL,  
	name							varchar(100) 	NOT NULL,  
    description							text 	NULL,		
	vdc_id							numeric	NOT NULL,  
	dc_id							varchar(100)	NULL, 
	status							tinyint  NULL, 
	template_id						varchar(100)	NOT NULL,  
	stack_id						varchar(100)	NULL,  
	delete_flag			  			tinyint    default 0 not null,  
	create_time            			datetime        NOT NULL,  
	delete_time            			datetime        null,       
	update_time            			datetime        null,    
	creator_id						numeric	NOT NULL,  
	extra							text	NULL,   
    PRIMARY KEY(id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_ade_traffic_steering'))
    drop table om_ade_traffic_steering
go
create table om_ade_traffic_steering
(
	instance_id						int 	NOT NULL,  
	classfier						varchar(100) 	NOT NULL,  
	portChain						varchar(100) 	NOT NULL  
)
go


if exists(select 1 from sysobjects where id = object_id('om_instance_backup'))
    drop table om_instance_backup
go
CREATE TABLE om_instance_backup (
    id                              int  identity,
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
    parent_id						int     NULL,
	instance_uuid				    varchar(255)	NOT NULL,
	instance_name				    varchar(255)	NULL,
	backup_type 				    tinyint	NOT NULL, 
	root_disk_file			  		varchar(255) NULL, 
	data_disk_file            		varchar(1000) NULL,
	memory_file            		    varchar(255) NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
	description						text  		NULL,
	related_id						int    NULL,
	[current]		 				    tinyint	 	NULL, 
    PRIMARY KEY(id)
)with identity_gap=1
go

if exists(select 1 from sysobjects where id = object_id('om_backup_task'))
    drop table om_backup_task
go
CREATE TABLE om_backup_task (   
	id                              int  identity,
	backup_id						int 	NOT NULL,
	tenant_id                       varchar(100) 	NOT NULL,
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
	instance_uuid				    varchar(255)   NOT NULL,
	instance_name				    varchar(255)   NULL,
    backup_type 				    tinyint	NOT NULL,
	backup_date            		    datetime  NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	status 				            tinyint	NOT NULL, 
	process						    int NOT NULL, 
	sync	        			    tinyint	NOT NULL, 
	extra							text	NULL,
	PRIMARY KEY(id,backup_id)
)with identity_gap=1
go

if exists(select 1 from sysobjects where id = object_id('om_backup_policy'))
    drop table om_backup_policy
go
CREATE TABLE om_backup_policy ( 
	uuid	                        varchar(100) 	NOT NULL, 
	dc_id							varchar(100) 	NOT NULL, 
    vdc_id							numeric	NOT NULL,	
	name         				    varchar(255)	NOT NULL,
	policy       			  		varchar(255) NULL, 
	backup_mode 				    tinyint	NOT NULL, 
	last_exec_date            	    datetime  NULL, 
	enable 				            tinyint	NOT NULL, 
	policy_type						int	NULL,   
    PRIMARY KEY(uuid)
)
go



if exists(select 1 from sysobjects where id = object_id('om_backup_policy_association'))
    drop table om_backup_policy_association
go
CREATE TABLE om_backup_policy_association(  
    instance_uuid				    varchar(255) NOT NULL,
	backup_policy_id				varchar(100) 	NOT NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_backup_quota'))
    drop table om_backup_quota
go
CREATE TABLE om_backup_quota ( 
    uuid							varchar(100) 	NOT NULL,  
	dc_id							varchar(100) 	NULL, 
    vdc_id							numeric	NOT NULL,	 
	quota						    int	default 0 not null,   
	backup_type					    tinyint	NOT NULL, 
    PRIMARY KEY(uuid)
)

go

if exists(select 1 from sysobjects where id = object_id('om_backup_path'))
    drop table om_backup_path
go
CREATE TABLE om_backup_path ( 
	uuid							varchar(100) NOT NULL, 
	dc_id							varchar(100) 	NOT NULL,   
	compute_host					varchar(255) 	NULL,
	path_type 				        tinyint	NOT NULL, 
	backup_path					    varchar(255) 	NULL,
    PRIMARY KEY(uuid)
)

go

--DRS begin
--DRS���ñ�
if exists(select 1 from sysobjects where id = object_id('drs_config'))
    drop table drs_config
go
create table drs_config (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  ,--��Դ��id
	reposstype						int					 DEFAULT  1  not null  ,--�洢����
	enable                          int                  DEFAULT  1  not null  ,--�Ƿ�����
	mode                     		int                  DEFAULT  1  null  ,	--����ģʽ
	autorun                     	int                         	 null  ,	--�Ƿ��Զ�ִ��
	constraint PK_DRS_CONFIG_ID primary key (id)
)

go

--DRS������ϸ��
if exists(select 1 from sysobjects where id = object_id('drs_config_detail'))
    drop table drs_config_detail
go
create table drs_config_detail (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  ,--��Դ��id
	cpuup                      		varchar(100)                     null  ,	--CPU����
	cpudown                    		varchar(100)                     null  ,	--CPU����
	memup                         	varchar(100)                     null  ,	--�ڴ�����
	memdown                       	varchar(100)                     null  ,	--�ڴ�����
	active                          int                  DEFAULT  1  not null  ,--�Ƿ���Ч
	starttime                      	varchar(10)                      null  ,	--��ʼʱ��
	endtime                    		varchar(10)                      null  ,	--����ʱ��
	constraint PK_DRS_CONFIG_DETAIL_ID primary key (id)	
)
go

--DRS���Ƚ����
if exists(select 1 from sysobjects where id = object_id('drs_suggest'))
    drop table drs_suggest
go
create table drs_suggest (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(255)                      not null  ,--��Դ��id
	operation                       int                              not null  ,--ִ�ж���
	hostid                          varchar(255)                      null  ,	--��ѱ�Ǩ����
	hostid2                         varchar(255)                      null  ,	--���Ŀ������
	vmid                            varchar(255)                      null  ,	--��ѱ�Ǩ���
	hostname                        varchar(255)                      null  ,	--��ѱ�Ǩ������
	hostname2                       varchar(255)                      null  ,	--���Ŀ��������
	vmname                          varchar(255)                      null  ,	--��ѱ�Ǩ�����
	description                     varchar(256)                     null  ,	--����
	inserttime                      datetime                         null  ,	--����ʱ��
	status                          int                              null  ,	--״̬
	maintainStatus                  int                              null  ,	--����ά��ʱ������ִ��״̬
	constraint PK_DRS_SUGGEST_ID primary key (id)
)
go

--DRS����ִ����ʷ��
if exists(select 1 from sysobjects where id = object_id('drs_suggest_history'))
    drop table drs_suggest_history
go
create table drs_suggest_history (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(255)                      not null  ,--��Դ��id
	suggestid                       varchar(64)                      not null  ,--����ID
	operation                       int                              not null  ,--ִ�ж���
	hostid                          varchar(255)                      null  ,	--��ѱ�Ǩ����
	hostid2                         varchar(255)                      null  ,	--���Ŀ������
	vmid                            varchar(255)                      null  ,	--��ѱ�Ǩ���
	hostname                        varchar(255)                      null  ,	--��ѱ�Ǩ������
	hostname2                       varchar(255)                      null  ,	--���Ŀ��������
	vmname                          varchar(255)                      null  ,	--��ѱ�Ǩ�����
	description                     varchar(256)                     null  ,	--����
	inserttime                      datetime                         null  ,	--����ʱ��
	status                          int                              null  ,	--״̬
	exetime 						datetime                         null  ,	--ִ��ʱ��
	maintainStatus                  int                              null  ,	--����ά��ʱ������ִ��״̬
	taskid                          varchar(64)                      null  ,	--������ִ��ʱ��������󷵻ص�����ID
	constraint PK_DRS_SUGGEST_HISTORY_ID primary key (id)
)
go

--DRS���ñ�
if exists(select 1 from sysobjects where id = object_id('drs_storage_config'))
    drop table drs_storage_config
go
create table drs_storage_config (
	poolid                          varchar(64)                      not null  ,--��Դ��id
	reposstype						int					 DEFAULT  1  not null  ,--�洢����
	enable                          int                  DEFAULT  1  not null  ,--�Ƿ�����
	mode                     		int                  DEFAULT  1  null  ,	--����ģʽ
	autorun                     	int                         	 null  ,	--�Ƿ��Զ�ִ��
	maxrate                         int                              not null,  --���õ������ֵ   
	ext1                           int                               null,  --��չ1  
	ext2                           int                                null,  --��չ2
	ext3                           varchar(64)                                null,  --��չ3
	ext4                           varchar(64)                                null,  --��չ4
	constraint PK_drs_storage_config_ID primary key (poolid)
)
go

--DRS���Ƚ����
if exists(select 1 from sysobjects where id = object_id('drs_storage_suggest'))
    drop table drs_storage_suggest
go
create table drs_storage_suggest (
	id                              varchar(64)                      not null  ,
	poolid                          varchar(64)                      not null  ,--��Դ��id
	operation                       int                              not null  ,--ִ�ж���
	hostid                          varchar(64)                      null  ,	--��ѱ�Ǩ����
	hostid2                         varchar(64)                      null  ,	--���Ŀ������
	vmid                            varchar(64)                      null  ,	--��ѱ�Ǩ���
	hostname                        varchar(64)                      null  ,	--��ѱ�Ǩ������
	hostname2                       varchar(64)                      null  ,	--���Ŀ��������
	vmname                          varchar(64)                      null  ,	--��ѱ�Ǩ�����
	description                     varchar(256)                     null  ,	--����
	inserttime                      datetime                         null  ,	--����ʱ��
	status                          int                              null  ,	--״̬
	maintainStatus                  int                              null  ,	--����ά��ʱ������ִ��״̬
	constraint PK_DRS_STORAGE_SUGGEST_ID primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_compute_ipmi'))
    drop table om_compute_ipmi
go
create table om_compute_ipmi
(
    dc_id			varchar(64)		not null,
	[compute]			varchar(100)	not null,
	ip			    varchar(64)		null,
	user_name		varchar(255)	null,
	user_pwd		varchar(255)    null,
	constraint PK_OM_COMPUTE_IPMI primary key (dc_id, [compute])
)
go
--DRS end



if exists(select 1 from sysobjects where id = object_id('om_a10_vlantag'))
    drop table om_a10_vlantag
go
CREATE TABLE om_a10_vlantag (
    vlan_tag                int        				not null,
	status   	            tinyint    default 0 	not null,
	a10_vm_uuid          	varchar(64)				not null,
	network_id              varchar(64)        		null,
	a10_port_id             varchar(64)        		null,  
	vnetid           		varchar(64)      		null,    
    vip_list             	text                	null
)
go

IF EXISTS (SELECT id FROM sysobjects WHERE type='P' AND name='p_insert_vlantag')
DROP PROCEDURE p_insert_vlantag

go
CREATE PROCEDURE p_insert_vlantag
        @vmUuid VARCHAR(50)
AS
BEGIN
DECLARE 
        @i INTEGER,        --ѭ������
        @sql  VARCHAR(16300),
        @vsql  VARCHAR(16300),
        @dsql  VARCHAR(200)
SELECT @i = 4094
WHILE @i>= 0 
BEGIN 
IF (@i%235 = 0)
BEGIN
SELECT @vsql = @sql 
EXECUTE (@vsql)
SELECT @sql=''
END
SELECT @sql = @sql + 'insert into om_a10_vlantag (vlan_tag,a10_vm_uuid) values (' + cast( @i as varchar) + ','''+@vmUuid+''')'
SELECT @i = @i - 1
END
SELECT @dsql = 'delete from om_a10_vlantag where vlan_tag = 1'
EXECUTE (@dsql)
END

go

if exists(select 1 from sysobjects where id = object_id('om_a10_dvsport'))
    drop table om_a10_dvsport
go
CREATE TABLE om_a10_dvsport (
	a10_vm_uuid			   varchar(64)      null,
    device_id              varchar(64)      null,
	port_id   	           varchar(64)    	null
)
go


if exists(select 1 from sysobjects where id = object_id('om_a10_tenant'))
    drop table om_a10_tenant
go
CREATE TABLE om_a10_tenant (
    tenant_id              varchar(64)      null,
	dc_id   	           varchar(64)    	null,
	a10_vm_uuid			   varchar(64)      null
)
go

if exists(select 1 from sysobjects where id = object_id('om_task_instance_port'))
    drop table om_task_instance_port
go
CREATE TABLE om_task_instance_port (
    instance_id              varchar(64)      NOT NULL,
	dc_id   	           varchar(64)    	NOT NULL,
	port_id			   varchar(1024)      NOT NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_vdc_srvdir'))
    drop table om_vdc_srvdir
go
CREATE TABLE om_vdc_srvdir (
    id				int		not null,
	srvdir_id		int 	null,
	dc_id			varchar(64)		not null,
	vdc_id           numeric	not null,
	is_publish      tinyint    not null,
	parent_id		int   		null,
	template_id		int 		null,
	extra			text		null,
	primary key (id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_net_vdc_rel'))
	drop table om_net_vdc_rel
go
create table om_net_vdc_rel
(
	networkid varchar(100) not null,
	vdcid numeric not null,
	dcid varchar(100) not null,
	projectid varchar(100) not null
)
go

if exists(select 1 from sysobjects where id = object_id('om_resize_flavor_record'))
    drop table om_resize_flavor_record
go
create table om_resize_flavor_record
(
	instanceid varchar(100) NOT NULL,
	vdcid varchar(10) NOT NULL,
	dcid varchar(100) NOT NULL,
	flag int NOT NULL,
	operation varchar(20) DEFAULT NULL,
	vcpus int NOT NULL,
	memory bigint NOT NULL,
	[disk] int NOT NULL,
	created datetime DEFAULT NULL,
	updated datetime DEFAULT NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_ip_rel'))
    drop table om_ip_rel
go
create table om_ip_rel 
( 
	id							varchar(64) 	NOT NULL,
	internet_ip				    varchar(100) 	NULL,
    float_ip	                varchar(100) 	NULL,
    extnet_id	                varchar(100) 	NULL,
	subnet_id	                varchar(100) 	NULL,
	dc_id						varchar(100) 	NULL,
    vdc_id                      numeric		    NULL,
    tenant_id				    varchar(100) 	NULL, 	
	vm_id	                    varchar(100) 	NULL,
	extra						varchar(500) 	NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_history_records'))
    drop table om_history_records
go
create table om_history_records 
( 
	dc_id						varchar(64) 	NOT NULL, 
	instance_id					varchar(100) 	NOT NULL,  
	oper_type					int 		    NOT NULL,  
	created						varchar(64) 	NULL,
	status						int     		NULL,
	detail						text 			NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_vdc_apply'))
    drop table om_vdc_apply
go
create table om_vdc_apply
(
   apply_id             int NOT NULL,
   vdcname 				varchar(64) NOT NULL,
   vdcdesc 				varchar(256) NULL,
   vdcid   				numeric NULL,
   dcids				varchar(512) NOT NULL,
   dctypes				varchar(64) NOT NULL,
   quotas				varchar(2048) NOT NULL,
   operators			varchar(64) NOT NULL,
   operatoroles			varchar(256) NOT NULL,
   dcids_audited		varchar(512) NULL,
   dctypes_audited		varchar(64) NULL,
   quotas_audited		varchar(2048) NULL,
   creatorid			int NOT NULL,
   tenantid				varchar(64) NOT NULL,
   current_step         int NOT NULL,
   apply_date           datetime NOT NULL,
   primary key (apply_id)
)
go

if exists(select 1 from sysobjects where id = object_id('om_service_evaluation'))
    drop table om_service_evaluation
go
create table om_service_evaluation
(
   order_id             int NOT NULL,
   type 				int NOT NULL,
   user_id 				int NOT NULL,
   evaluation   		int NOT NULL,
   comment				varchar(512) NULL,
   evaluate_date        datetime NOT NULL
)
go

if exists(select 1 from sysobjects where id = object_id('om_system_evaluation'))
    drop table om_system_evaluation
go
create table om_system_evaluation
(
  id                int NOT NULL,
  user_id 			int NOT NULL,
  vdc_id            int NOT NULL,
  usability 		int NOT NULL,
  systemic_fluency  int NOT NULL,
  processing_rate   int NOT NULL,
  comment			varchar(512) NULL,
  evaluate_date     datetime NOT NULL,
  primary key (id)
)
go