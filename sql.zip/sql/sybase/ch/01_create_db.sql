use master
go

--sp_configure 'number of devices',30 
--go

setuser 'dbo'
go
if not exists (select 1 from master.dbo.sysdevices where name = 'iros')
begin
   disk init
   name='iros',
   physname='/home/sybase/data/iros.dat',
   size='512M',
   dsync=false
end
go

if not exists (select 1 from master.dbo.sysdevices where name = 'iros_log')
begin
   disk init
   name='iros_log',
   physname='/home/sybase/data/iros_log.dat',
   size='512M',
   dsync=false
end
go

if not exists (select 1 from master.dbo.sysdevices where name = 'opslog')
begin
   disk init
   name='opslog',
   physname='/home/sybase/data/opslog.dat',
   size='512M',
   dsync=false
end
go

if not exists (select 1 from master.dbo.sysdevices where name = 'opslog_log')
begin
   disk init
   name='opslog_log',
   physname='/home/sybase/data/opslog_log.dat',
   size='512M',
   dsync=false
end
go

if not exists (select 1 from master.dbo.sysdatabases where name = 'opslog')
begin
   create database opslog on opslog='512M' log on opslog_log='512M'
end
go

if not exists (select 1 from master.dbo.sysdatabases where name = 'iros')
begin
   create database iros on iros='512M' log on iros_log='512M'
end
go

use master
go

exec sp_dboption iros,'trunc log on chkpt',true
go
exec sp_dboption iros,'select into/bulkcopy/pllsort',true
go


exec sp_dboption opslog,'trunc log on chkpt',true
go
exec sp_dboption opslog,'select into/bulkcopy/pllsort',true
go

