-- **********************************************************************
-- * SQL Name: create_measuredb.sql 
-- * Version: for Sybase AS Enterprise 15.0  
-- * 2014-12-10
-- * Author: lb
-- **********************************************************************
-- use master
-- go

--sp_configure 'number of devices',30 
--go

--irosmeasure--
-- disk init name='irosmeasure',physname='/home/sybase/data/irosmeasure.dat',size='102400M',dsync=false
-- go
-- disk init name='irosmeasure_log',physname='/home/sybase/data/irosmeasure_log.dat',size='102400M',dsync=false
-- go
-- create database irosmeasure on irosmeasure = '102400M' log on irosmeasure_log='102400M'
-- go
-- 
-- 
-- dump tran irosmeasure with no_log
-- go
-- exec sp_dboption 'irosmeasure','trunc. log',true
-- go
-- exec sp_dboption 'irosmeasure', 'ddl', true
-- go
-- exec sp_dboption 'irosmeasure', 'null', false
-- go
-- exec sp_dboption 'irosmeasure', 'select into', true
-- checkpoint
-- go 


