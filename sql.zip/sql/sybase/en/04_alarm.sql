use iros
go

if(exists(select 1 from sysobjects where name='alarm_snmp_address'))
  drop table alarm_snmp_address
go
create table alarm_snmp_address (
   name             varchar(200)    not null,   
   port              int            not null,   
   ip               varchar(50)     not null,   
   community        varchar(200)    not null, 
   type             varchar(50)     not null,      
   localip          varchar(50)     null,
   localport        int             null,
   constraint PK_ALARM_SNMP_ADDRESS primary key (name)
)
go

-- alarmoid
if exists(select 1 from sysobjects where id = object_id('alarm_oid'))
    drop table alarm_oid
go
create table alarm_oid( 
    name            varchar(100)                   not null,     
    oid             varchar(100)                   not null,      
      constraint PK_ALARM_OID primary key (name)
)
go

insert into alarm_oid(oid, name) values('1.3.6.1.6.3.1.1.4.1.0','alarmType')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.1','alarmReport')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.4.1.2','alarmRestore')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.3','alarmEventTime')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.2','sendNotificationId')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.4','lastSendNotificationId')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.1.3','systemDN')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.11','alarmCode')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.2','alarmManagedObjectInstance')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.4','alarmEventType')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.5','alarmProbableCause')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.6','alarmPerceivedSeverity')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.7','alarmSpecificProblem')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.8','alarmAdditionalText')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.12','alarmNetype')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.9','alarmIndex')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.1','alarmId')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.14','alarmCodeName')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.15','alarmManagedObjectInstanceName')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.16','alarmSystemType')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.17','alarmNeIP')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.18','alarmACK')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.19','cleiCode')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.20','timeZoneID')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.21','timeZoneOffset')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.22','dSTSaving')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.23','aid')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.24','id')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.26','alarmMocObjectInstatance')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.10','alarmComment')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3.1.25','alarmOtherInfo')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.2.0','opencos_snmpTrapCommunity')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.1.3.0','opencos_snmpTrapVersion')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.6051.19.1.1.2.1.3','opencos_trapIpaddressPort')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.4.2.1.1','heartbeatNotification')
insert into alarm_oid(oid, name) values('1.3.6.1.4.1.3902.4101.1.3','currentAlarmTable')
go


use zxinalarm
go

-- Alarm System Type
exec proc_alm_systypedic 1,22537,'iROS'
go

-- Alarm Code

-- Openstack
exec proc_alm_code_new 1,46087,'Image service disk space used too much',2,13,1,22537
exec proc_alm_code_new 1,46112,'Nova-compute is not available',1,13,1,22537
exec proc_alm_code_new 1,46114,'Host memory error',1,13,1,22537
exec proc_alm_code_new 1,46115,'Host hard disk error',2,13,1,22537
exec proc_alm_code_new 1,46119,'Ethernet port is down',2,13,1,22537
exec proc_alm_code_new 1,46124,'The remaining memory shortage',3,13,1,22537
exec proc_alm_code_new 1,46126,'Host hard disk warn',3,13,1,22537
exec proc_alm_code_new 1,46127,'Root device usage is overstepped',3,13,1,22537
exec proc_alm_code_new 1,46146,'Switch port down',3,13,1,22537
exec proc_alm_code_new 1,46160,'Magnetic-matrix is not on-line',3,13,1,22537
exec proc_alm_code_new 1,46161,'Shared storage is insufficient',4,13,1,22537
exec proc_alm_code_new 1,46176,'Instance status error',4,13,1,22537
exec proc_alm_code_new 1,46178,'Instance status error',4,13,1,22537
go

-- iECS
exec proc_alm_code_new 1,1000001,'Host offline alarm',1,13,1,22537
exec proc_alm_code_new 1,1000002,'Virtual machine shut off alarm',1,13,1,22537
exec proc_alm_code_new 1,1000003,'VMC database abnormal',1,13,1,22537
exec proc_alm_code_new 1,1000004,'Abnormal state of the repository',1,13,1,22537
exec proc_alm_code_new 1,1000005,'Repository usage exceeds the threshold',1,13,1,22537
exec proc_alm_code_new 1,1000008,'Virtual machine breakdown alarm',8,13,1,22537
exec proc_alm_code_new 1,1000009,'Restart the virtual machine alarm',8,13,1,22537
exec proc_alm_code_new 1,1000014,'Repository agent abnormal state',1,13,1,22537
exec proc_alm_code_new 1,1000016,'To access the exception repository unit',1,13,1,22537
exec proc_alm_code_new 1,1000017,'Abnormal host access to the repository directory',1,13,1,22537
exec proc_alm_code_new 1,1000018,'Host network abnormal',1,13,1,22537
exec proc_alm_code_new 1,1000020,'Virtual machine failover resource',1,13,1,22537
exec proc_alm_code_new 1,1000021,'Abnormal host storage path',1,13,1,22537
exec proc_alm_code_new 1,1000025,'Log space more than limit',1,13,1,22537
exec proc_alm_code_new 1,1000026,'Abnormal MCE hardware',1,13,1,22537
exec proc_alm_code_new 1,1000000,'VMC abnormal',1,13,1,22537
exec proc_alm_code_new 1,1000100,'DRS batch transfer failure', 8,13,1,22537
exec proc_alm_code_new 1,1000041,'Host disk abnormal', 1,13,1,22537
go


-- Alarm Reason

-- Openstack
exec proc_alm_reason_new 1,46087,'Image service disk space used too much',22537
exec proc_alm_reason_new 1,46112,'Nova-compute is not available',22537
exec proc_alm_reason_new 1,46114,'Host memory error',22537
exec proc_alm_reason_new 1,46115,'Host hard disk error',22537
exec proc_alm_reason_new 1,46119,'Ethernet port is down',22537
exec proc_alm_reason_new 1,46124,'The remaining memory shortage',22537
exec proc_alm_reason_new 1,46126,'Host hard disk warn',22537
exec proc_alm_reason_new 1,46127,'Root device usage is overstepped',22537
exec proc_alm_reason_new 1,46146,'Switch port down',22537
exec proc_alm_reason_new 1,46160,'Magnetic-matrix is not on-line',22537
exec proc_alm_reason_new 1,46161,'Shared storage is insufficient',22537
exec proc_alm_reason_new 1,46176,'Instance status error',22537
exec proc_alm_reason_new 1,46178,'Instance status error',22537
go

-- iECS
exec proc_alm_reason_new 1,1000001,'Host offline alarm',22537 
exec proc_alm_reason_new 1,1000002,'Virtual machine shut off alarm',22537
exec proc_alm_reason_new 1,1000003,'VMC database abnormal',22537 
exec proc_alm_reason_new 1,1000004,'Abnormal state of the repository',22537 
exec proc_alm_reason_new 1,1000005,'Repository usage exceeds the threshold',22537 
exec proc_alm_reason_new 1,1000008,'Virtual machine breakdown alarm',22537 
exec proc_alm_reason_new 1,1000009,'Restart the virtual machine alarm',22537 
exec proc_alm_reason_new 1,1000014,'Repository agent abnormal state',22537 
exec proc_alm_reason_new 1,1000016,'To access the exception repository unit',22537 
exec proc_alm_reason_new 1,1000017,'Abnormal host access to the repository directory',22537 
exec proc_alm_reason_new 1,1000018,'Host network abnormal',22537 
exec proc_alm_reason_new 1,1000020,'Virtual machine failover resource',22537 
exec proc_alm_reason_new 1,1000021,'Abnormal host storage path',22537 
exec proc_alm_reason_new 1,1000025,'Log space more than limit',22537 
exec proc_alm_reason_new 1,1000026,'Abnormal MCE hardware',22537 
exec proc_alm_reason_new 1,1000000,'VMC abnormal',22537 
exec proc_alm_reason_new 1,1000100,'DRS batch transfer failure',22537 
exec proc_alm_reason_new 1,1000041,'Host disk abnormal',22537
go
