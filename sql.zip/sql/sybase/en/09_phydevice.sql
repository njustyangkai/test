use zxinsys
go
exec proc_res_op_function 0, 1, 1396, 139621,'Physical Device'
go

update oper_function set allowflag=0 where funcgrpid=1396 and funcid=139621 and servicekey='uniportal'
go

exec zxinsys..proc_add_res_definition 'PH_DEVICE', 'iROS DEVICE', 'ROOT', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_iros_phdevice', '', null
exec zxinsys..proc_add_res_definition 'IROS_VDC', 'VDC', 'PH_DEVICE', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_iros_irosvdc', '', null
exec zxinsys..proc_add_res_definition 'PH_COMPANY', 'COMPANY', 'IROS_VDC', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_phcompany', '', null
exec zxinsys..proc_add_res_definition 'PH_MACHINE', 'MACHINE', 'PH_COMPANY', 'RESOURCE', 'TOPO,MM,AM', 0, 'irosrms', 'iros', 'ent_phmachine', '', null

go

use iros
go

if (exists(select 1 from sysobjects where name = 'common_dict_catalog'))
	drop table common_dict_catalog
go
create table common_dict_catalog 
(
	typeid   			varchar(100)	not null,	
	typename			varchar(200)	not null,	
	parenttypeid   		varchar(100)	null,		
	visiableflag   		varchar(10)	default '1' null,		
	editflag      		varchar(10)	default '0' null,		
	constraint PK_COMMON_DICT_CATALOG primary key clustered (typeid)
)
go

if (exists(select 1 from sysobjects where name = 'common_dict_item'))
	drop table common_dict_item
go
create table common_dict_item 
(
	typeid   			varchar(100)	not null,	
	dataid				varchar(100)	not null,	
	dataname   			varchar(200)	not null,	
	parenttypeid		varchar(100)	null,		
	parentdataid   		varchar(100)	null,
    visiableflag        varchar(10)     default '1' null,  
    editflag            varchar(10)     default '0' null, 
	constraint PK_COMMON_DICT_ITEM primary key clustered (dataid)
)
go
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('9','Rack Flavor','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-0','1U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-1','2U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-2','4U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-3','8U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-4','16U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-5','32U','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('9','Rack-6','64U','','')

go
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('7','OS','')
insert into common_dict_catalog(typeid,typename,parenttypeid) values ('8','OS Version','7')

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-1','Microsoft Windows','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-2','SUSELINUX','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-3','TURBOLINUX','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-4','AIX','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-5','HPUNIX','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-6','HPIA','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-7','SOLARIS','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-8','REDHATLINUX','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('7','os-9','CGSL','','')

--Microsoft Windows 1 
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800101','Windowsxp','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800102','Windows7','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800103','Windows8','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800104','Windows2000','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800105','Windows2003','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800106','Windows2008','7','os-1')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800107','Windows2012','7','os-1')
--SUSELINUX 2 
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800201','Suse Linux Enterprise 10','7','os-2')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800202','Suse Linux Enterprise 11','7','os-2')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800203','Other Linux','7','os-2')
--TURBOLINUX 3
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800301','Suse Linux Enterprise 10','7','os-3')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800302','Suse Linux Enterprise 11','7','os-3')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800303','Other Linux','7','os-3')
--AIX  4 
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800401','AIX','7','os-4')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800402','Other AIX','7','os-4')
--HPUNIX 5
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800501','HPUNIX','7','os-5')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800502','Other HPUNIX','7','os-5')
--HPIA 6
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800601','AIX','7','os-6')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800602','Other AIX','7','os-6')
--SOLARIS 7
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800701','SOLARIS','7','os-7')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800702','SOLARIS10','7','os-7')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800703','SOLARIS11','7','os-7')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800704','Other SOLARIS','7','os-7')
--REDHATLINUX 8
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800801','REDHATLINUX','7','os-8')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800802','REDHATLINUX4.2','7','os-8')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800803','REDHATLINUX6.5','7','os-8')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800804','REDHATLINUX9','7','os-8')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800805','Other REDHATLINUX','7','os-8')
--CGSL 9
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800901','CGSL','7','os-9')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800902','CGSL V3','7','os-9')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800903','CGSL V4','7','os-9')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('8','800904','Other CGSL','7','os-9')
go

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('4','Device Type','')
go

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('4','104001','Physical Machine','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('4','104002','PC','','')
go

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('5','Physical Machine Type','')
go

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105001','Blade servers','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105002','Minicomputer','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105003','PC SERVER','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105004','PC','','')
--insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('5','105005','Thin','','')
go

insert into common_dict_catalog(typeid,typename,parenttypeid) values ('6','Company','')
go

insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106001','Lenovo','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106002','DELL','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106003','Founder','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106004','SUN','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106005','HP','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106007','IBM','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106008','ZTE','','')
insert into common_dict_item (typeid,dataid,dataname,parenttypeid,parentdataid) values('6','106010','Intel','','')
go

if exists (select 1 from sysobjects where id = object_id('om_device_info') )
  drop table om_device_info
go
create table om_device_info
(
  devicemospecid     varchar(100)                    not null,   
  devicemospecname   varchar(200)                    not null,   
  deviceid           varchar(100)                    null,       
  devicemodel        varchar(100)                    not null,    
  specidnum          int          default 0          not null,
  devicestatus       tinyint      default 0          not null    
)
go
create unique index i_om_device_info_specid on om_device_info(devicemospecid)
go

if exists (select 1 from sysobjects where id = object_id('om_devicespec_info') )
  drop table om_devicespec_info
go
create table om_devicespec_info
(
  devicemospecid   varchar(100)                     not null,  
  devicetype       varchar(100)                     null,  
  servertype       varchar(100)                     null,   
  devdisk          varchar(50)                      null,    
  memeory          varchar(50)                      null,   
  nicmodel         varchar(100)                     null,   
  niunum           int                              null,  
  cpumodel         varchar(100)                     null,  
  cpumohz          varchar(10)                      null,   
  cpunum           int                              null,   
  cpucores         int                              null,   
  hbamodel         varchar(100)                     null,  
  hbanum           int                              null,   
  cost              decimal(20,5)           default 0           null    
)
go
create unique index i_om_devicespec_info_specid on om_devicespec_info(devicemospecid)
go

if exists (select 1 from sysobjects where id = object_id('om_phydevice_user_his') )
  drop table om_phydevice_user_his
go
create table om_phydevice_user_his
(
  entid            varchar(100)                    not null,   
  userid           int           default 0         null,       
  order_id         int           default 0         null,   
  order_code       varchar(64)                     null,   
  hostname         varchar(50)                     null,   
  desciption       varchar(100)                    null,   
  purchasedate     datetime                        null,   
  enddate          datetime                        null,   
  opertiondivid    varchar(10)                     null,   
  opertiongroupid  varchar(10)                     null,   
  userip           varchar(100)                    null,   
  managername      varchar(50)                     null,   
  managerpwd       varchar(50)                     null,   
  operid           varchar(50)                     null,   
  opertime         datetime                        null,   
  vdcid            varchar(64)                     not null   
)
go

if exists (select 1 from sysobjects where id = object_id('om_phydevice_info') )
  drop table om_phydevice_info
go
create table om_phydevice_info
(
  computerroom_id      varchar(100),
  city_id              varchar(100),
  rack_id              varchar(100),
  dc_id                varchar(100),
  entid            varchar(100)                    not null,   
  entname          varchar(100)                    not null,   
  devicemospecid   varchar(100)                    not null,  
  --areaid           varchar(200)                    null,   
  deviceid         varchar(200)                    null,   
  fixedassetnum    varchar(200)                    null,   
  systemnum        varchar(200)                    null,  
  productmnum      varchar(200)                    null,   
  purchasedate     date                            null,  
  assurancetime    int                             null,  
  assurancedesc    varchar(200)                    null,      
  location         varchar(200)                    null,  
  locationdesc     varchar(50)                     null,  
  upframenum       varchar(50)                     null,      
  roundframenum    varchar(50)                     null,       
  slotnum          varchar(50)                     null,      
  ipmiip           varchar(100)                    null,   
  ipmiuser         varchar(50)                     null,   
  ipmipwd          varchar(50)                     null,   
  status           int             default 0       null,  
  phstatus         int             default 0       null,  
  operid           varchar(50)                     null,      
  opertime         date                            null,         
  hand_over        varchar(10)                     null,      
  uuid             varchar(100)                    null,  
  is_measure       int             default 0       null   
)
go
create index i_om_phydevice_info_specid on om_phydevice_info(devicemospecid)
go
create unique index i_om_phydevice_info_entid on om_phydevice_info(entid)
go

if exists (select 1 from sysobjects where id = object_id('om_phydevice_user') )
  drop table om_phydevice_user
go
create table om_phydevice_user
(
  entid            varchar(100)                    not null,   
  userid           int           default 0         null,       
  order_id         int           default 0         null,  
  order_code       varchar(64)                     null,   
  hostname         varchar(64)                     null,  
  desciption       varchar(100)                    null,  
  purchasedate     datetime                        null,   
  enddate          datetime                        null,  
  opertiondivid    varchar(10)                     null,   
  opertiongroupid  varchar(10)                     null,  
  userip           varchar(100)                    null,  
  managername      varchar(50)                     null,  
  managerpwd       varchar(50)                     null,  
  operid           varchar(50)                     null,   
  opertime         datetime                        null,   
  vdcid            varchar(64)                     not null   
)
go
create unique index i_om_phydevice_user_entid on om_phydevice_user(entid)
go
create index i_om_phydevice_user_order_id on om_phydevice_user(order_id)
go

if exists(select 1 from sysobjects where id = object_id('ent_iros_phdevice'))
   drop table ent_iros_phdevice 
go
create table ent_iros_phdevice
(	
    entid                varchar(200)                    not null, 
    entname              varchar(200)                    null,      
    entrid               varchar(200)                    not null,  
    parentrid            varchar(100)                    not null,  
    parententid          varchar(200)                    not null,  
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
)
go
create unique index i_ent_iros_phdevice_entid on ent_iros_phdevice(entid)
go

delete from ent_iros_phdevice
go

insert into ent_iros_phdevice (entid,entname,entrid,parentrid,parententid) values ('101','iROS DEVICE','PH_DEVICE','ROOT','ROOT')
go


if exists(select 1 from sysobjects where id = object_id('ent_iros_irosarea'))
drop table ent_iros_irosarea 
go
create table ent_iros_irosarea 
(
    entid                varchar(200)                    not null,  
    entname              varchar(200)                    null,     
    entrid               varchar(200)                    not null,  
    parentrid            varchar(100)                    not null,  
    parententid          varchar(200)                    not null,  
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
)
go
create unique index i_ent_iros_irosarea_entid on ent_iros_irosarea(entid)
go

if exists(select 1 from sysobjects where id = object_id('ent_phcompany'))
   drop table ent_phcompany 
go
create table ent_phcompany
(
    entid                varchar(200)                    not null,  
    entname              varchar(200)                    null,      
    entrid               varchar(200)                    not null,  
    parentrid            varchar(100)                    not null,  
    parententid          varchar(200)                    not null,  
    entip                varchar(100)                    null,      
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null
)
go
create unique index i_ent_phcompany_entid on ent_phcompany(entid)
go

delete from om_order_process where process_id = 3
delete from om_order_process_config where process_id = 3
delete from om_res_order_process_rel where res_type in (2,5,6,7,8)
go

insert into om_order_process (process_id, name, description, auto_step, is_use, is_auto_deliver) values(3, 'Physical Resource approval process', 'It applies to physical machines, racks, Internet IP, LAN IP, bandwidth approval process', 1, 1, 0)

insert into om_order_process_config values (3, 1, 'Approve', null, 'Submitted', 'To be delivered', 0)
insert into om_order_process_config values (3, 2, 'Deliver', null, 'To be delivered', 'Normal shutdown', 0)
insert into om_order_process_config values (3, -2, 'Abend', null, 'Abend', 'Abend', 0)
insert into om_order_process_config values (3, -1, 'Approval rejected', null, 'Approval rejected', 'Approval rejected', 0)
insert into om_order_process_config values (3, 0, 'Normal shutdown', null, 'Normal shutdown', 'Normal shutdown', 0)

insert into om_res_order_process_rel (res_type, process_id) values(2, 3)
insert into om_res_order_process_rel (res_type, process_id) values(5, 3)
insert into om_res_order_process_rel (res_type, process_id) values(6, 3)
insert into om_res_order_process_rel (res_type, process_id) values(7, 3)
insert into om_res_order_process_rel (res_type, process_id) values(8, 3)

if exists(select 1 from sysobjects where id = object_id('ent_phmachine'))
  drop table ent_phmachine 
go
-- ostype 1:NT 2:SUSELINUX 3:TURBOLINUX 4:AIX 5:HPUNIX 6:HPIA 7:SOLARIS 8 REDHATLINUX 9:CGSL
create table ent_phmachine  
(
    entid                varchar(200)                    not null,  
    entname              varchar(200)                    null,      
    entrid               varchar(200)                    not null,  
    parentrid            varchar(100)                    not null,  
    parententid          varchar(200)                    not null,  
    entip                varchar(100)                    null,
    msgtype              numeric(1)                      null,
    msgattrs             varchar(100)                    null,
    entstatus            numeric(1)                      null,
	  ostype               numeric(10)                     null,
    phyid                varchar(100)                    null   --physicial id assiociate with table ent_phmachine	  
)
go
create unique index i_ent_phmachine_entid on ent_iros_irosarea(entid)
go




if exists (select 1 from sysobjects where id = object_id('sp_web_add_deviceinfo'))
   drop procedure sp_web_add_deviceinfo
go
create procedure sp_web_add_deviceinfo
(
   @v_i_deviceid           varchar(100),  
   @v_i_devicemodel        varchar(100),   
   @v_i_devicemospecid     varchar(100),   
   @v_i_devicemospecname   varchar(200),   
   @v_i_devicetype         varchar(10),   
   @v_i_servertype         varchar(10),  
   @v_i_devdisk            varchar(50), 
   @v_i_memeory            varchar(50), 
   @v_i_nicmodel           varchar(100), 
   @v_i_niunum             int        ,   
   @v_i_cpumodel           varchar(100),   
   @v_i_cpumohz            varchar(10),  
   @v_i_cpunum             int        ,   
   @v_i_cpucores           int        ,  
   @v_i_hbamodel           varchar(100),   
   @v_i_hbanum             int,           
   @v_i_cost               decimal(20,5)   
)  
as
  declare  @v_devicemospecid      varchar(100)
  declare  @v_devicestatus        tinyint      
  declare  @v_specidnum           int        
begin  
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_devicestatus = 0
  select  @v_specidnum = 0
  if exists(select 1 from om_devicespec_info where devicemospecid = @v_devicemospecid)
  begin
    select 1011
    return
  end

  if exists(select 1 from om_devicespec_info where devicemospecid = @v_devicemospecid)
  begin
    select 1011
    return
  end
 
  if exists(select 1 from om_device_info where deviceid = @v_i_deviceid and devicemodel = @v_i_devicemodel and devicemospecname = @v_i_devicemospecname)
  begin
    select 1011
    return
  end

  begin tran
  	insert into om_device_info( devicemospecid, deviceid, devicemodel,devicemospecname ,specidnum,devicestatus)
  	       values(@v_i_devicemospecid, @v_i_deviceid, @v_i_devicemodel,  @v_i_devicemospecname, @v_specidnum ,@v_devicestatus)
    if @@error<>0
    begin
      rollback tran
      select 1001
      return
    end
    
    insert into om_devicespec_info (devicemospecid ,devicetype ,servertype ,devdisk ,memeory ,nicmodel ,niunum ,
                     cpumodel ,cpumohz ,cpunum ,cpucores ,hbamodel ,hbanum, cost)
           values (@v_devicemospecid ,@v_i_devicetype ,@v_i_servertype ,@v_i_devdisk ,@v_i_memeory ,@v_i_nicmodel ,@v_i_niunum ,
                  @v_i_cpumodel ,@v_i_cpumohz ,@v_i_cpunum ,@v_i_cpucores ,@v_i_hbamodel ,@v_i_hbanum, @v_i_cost)  
    if @@error<>0              
    begin
      rollback tran
      select 1001
      return
    end

  commit tran

  select  1
  return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_mod_deviceinfo'))
   drop procedure sp_web_mod_deviceinfo
go
create procedure sp_web_mod_deviceinfo
(
   @v_i_deviceid           varchar(100),   
   @v_i_devicemodel        varchar(100),   
   @v_i_devicemospecid     varchar(100),  
   @v_i_devicemospecname   varchar(200),  
   @v_i_devicetype         varchar(10),  
   @v_i_servertype         varchar(10),  
   @v_i_devdisk            varchar(50),   
   @v_i_memeory            varchar(50),  
   @v_i_nicmodel           varchar(10),   
   @v_i_niunum             int        ,   
   @v_i_cpumodel           varchar(10),  
   @v_i_cpumohz            varchar(10),    
   @v_i_cpunum             int        ,  
   @v_i_cpucores           int        ,  
   @v_i_hbamodel           varchar(10),  
   @v_i_hbanum             int,          
   @v_i_cost               decimal(20,5)  
)  
as
  declare  @v_devicemospecid      varchar(100)
begin  
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  if not exists(select 1 from om_devicespec_info where devicemospecid = @v_devicemospecid)
  begin
    select 1012
    return
  end

  if not exists(select 1 from om_device_info where devicemospecid = @v_devicemospecid)
  begin
    select 1012
    return
  end
  
  update om_devicespec_info set devicetype = @v_i_devicetype ,servertype = @v_i_servertype,devdisk = @v_i_devdisk,
           memeory = @v_i_memeory, nicmodel = @v_i_nicmodel, niunum = @v_i_niunum ,cpumodel = @v_i_cpumodel,
           cpumohz = @v_i_cpumohz, cpunum = @v_i_cpunum, cpucores = @v_i_cpucores,hbamodel = @v_i_hbamodel,
           hbanum = @v_i_hbanum, cost = @v_i_cost
         where devicemospecid = @v_devicemospecid
  if @@error<>0
  begin
    select 1001
    return
  end

  select  1
  return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_del_deviceinfo'))
   drop procedure sp_web_del_deviceinfo
go
create procedure sp_web_del_deviceinfo
(
   @v_i_devicemospecid     varchar(100)  
)  
as
  declare  @v_devicemospecid      varchar(100)
  declare  @v_specidnum           int        
begin  
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_specidnum = 0
    
  select @v_specidnum = specidnum from om_device_info where devicemospecid = @v_devicemospecid
  if @@rowcount = 0
  begin
    select  @v_specidnum = 0
  end 
  
  if (@v_specidnum = 0)
  begin
	    begin tran
	  	delete from om_device_info where devicemospecid = @v_devicemospecid
	    if @@error<>0
	    begin
	      rollback tran
	      select 1001
	      return
	    end
	    
	  	delete from om_devicespec_info where devicemospecid = @v_devicemospecid
	    if @@error<>0
	    begin
	      rollback tran
	      select 1001
	      return
	    end	
	  commit tran
  end
  else 
  begin
  	update om_device_info set devicestatus = 1  where devicemospecid = @v_devicemospecid
  	if @@error<>0
	  begin
	    select 1001
	    return
	  end	 	
  end	
	
  select  1
  return
end
go
if exists (select 1 from sysobjects where id = object_id('sp_web_add_phymachineinfo'))
   drop procedure sp_web_add_phymachineinfo
go
create procedure sp_web_add_phymachineinfo
(
  @v_i_entid            varchar(100), 
  @v_i_devicemospecid   varchar(100), 
  --@v_i_areaid           varchar(200), 
  @v_i_fixedassetnum    varchar(200),
  @v_i_systemnum        varchar(200), 
  @v_i_productmnum      varchar(200), 
  @v_i_purchasedate     date,        
  @v_i_assurancetime    int,          
  @v_i_assurancedesc    varchar(200), 
  @v_i_location         varchar(200), 
  @v_i_locationdesc     varchar(50) , 
  @v_i_upframenum       varchar(50) , 
  @v_i_roundframenum    varchar(50) , 
  @v_i_slotnum          varchar(50) , 
  @v_i_ipmiip           varchar(100), 
  @v_i_ipmiuser         varchar(50) , 
  @v_i_ipmipwd          varchar(50) , 
  @v_i_status           int         , 
  @v_i_operid           varchar(50) ,   
  @v_i_entname          varchar(200),           
  @v_i_ommpid           varchar(200),
  @v_i_rack_id          varchar(100),
  @v_i_computerroom_id  varchar(100),
  @v_i_city_id          varchar(100),
  @v_i_dc_id            varchar(100)  
)  
as
  declare  @v_entid               varchar(100)
  declare  @v_devicemospecid      varchar(100)
  declare  @v_opertime            date
  declare  @v_deviceid            varchar(200)  
  declare  @v_devicename          varchar(200)   
  declare  @v_phstatus            int          
begin  
  select  @v_entid = ltrim(rtrim(@v_i_entid))	
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_opertime = getdate()
  select  @v_phstatus = 7
  

  select @v_deviceid = deviceid from om_device_info where devicemospecid = @v_i_devicemospecid
  if @@rowcount = 0
  begin
    select 3001
    return
  end 
  select @v_devicename = dataname from common_dict_item where dataid = @v_deviceid
  if @@rowcount = 0
  begin
    select 3006
    return
  end 
   
  if exists(select 1 from om_phydevice_info where entid = @v_entid)
  begin
    select 3001
    return
  end  

  if exists(select 1 from om_phydevice_info where entname = @v_i_entname and status <>9)
  begin
    select 3001
    return
  end

  if exists(select 1 from om_phydevice_info where fixedassetnum = @v_i_fixedassetnum and status <>9)
  begin
    select 3003
    return
  end

  if exists(select 1 from om_phydevice_info where systemnum = @v_i_systemnum and status <>9)
  begin
    select 3004
    return
  end
  
    if exists(select 1 from om_phydevice_info where productmnum = @v_i_productmnum and status <>9)
  begin
    select 3005
    return
  end

  begin tran
  	insert into om_phydevice_info (rack_id, computerroom_id, city_id, dc_id,entid, entname,devicemospecid ,deviceid ,fixedassetnum ,systemnum ,productmnum ,purchasedate ,
                       assurancetime ,assurancedesc ,location ,locationdesc ,upframenum ,roundframenum ,
                      slotnum ,ipmiip ,ipmiuser ,ipmipwd ,status ,phstatus ,operid , opertime)
  	       values(@v_i_rack_id, @v_i_computerroom_id, @v_i_city_id, @v_i_dc_id,@v_entid ,@v_i_entname,@v_devicemospecid,@v_deviceid, @v_i_fixedassetnum ,@v_i_systemnum ,@v_i_productmnum,@v_i_purchasedate, 
                  @v_i_assurancetime ,@v_i_assurancedesc  ,@v_i_location ,@v_i_locationdesc ,@v_i_upframenum ,@v_i_roundframenum ,
                  @v_i_slotnum ,@v_i_ipmiip ,@v_i_ipmiuser ,@v_i_ipmipwd ,@v_i_status, @v_phstatus ,@v_i_operid,@v_opertime)
    if @@error<>0
    begin
      rollback tran
      select 1001
      return
    end
    
  commit tran

  begin
  	update om_device_info set specidnum = specidnum + 1  where devicemospecid = @v_devicemospecid
  	if @@error<>0
	  begin
	    select 1001
	    return
	  end	 	
  end	 

  select  1
  return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_mod_phymachineinfo'))
   drop procedure sp_web_mod_phymachineinfo
go
create procedure sp_web_mod_phymachineinfo
(
  @v_i_entid            varchar(100), 
  @v_i_devicemospecid   varchar(100), 
  --@v_i_areaid           varchar(200), 
  @v_i_fixedassetnum    varchar(200), 
  @v_i_systemnum        varchar(200), 
  @v_i_productmnum      varchar(200), 
  @v_i_purchasedate     date,       
  @v_i_assurancetime    int,         
  @v_i_assurancedesc    varchar(200), 
  @v_i_location         varchar(200), 
  @v_i_locationdesc     varchar(50) , 
  @v_i_upframenum       varchar(50) , 
  @v_i_roundframenum    varchar(50) , 
  @v_i_slotnum          varchar(50) , 
  @v_i_ipmiip           varchar(100),
  @v_i_ipmiuser         varchar(50) , 
  @v_i_ipmipwd          varchar(50) , 
  @v_i_status           int         ,
  @v_i_operid           varchar(50) ,   
  @v_i_entname          varchar(200)                            
)  
as
  declare  @v_entid               varchar(100)
  declare  @v_devicemospecid      varchar(100)
  declare  @v_opertime            date
begin  
  select  @v_entid = ltrim(rtrim(@v_i_entid))	
  select  @v_devicemospecid = ltrim(rtrim(@v_i_devicemospecid))	
  select  @v_opertime = getdate()
  if not exists(select 1 from om_phydevice_info where entid = @v_entid)
  begin
    select 3011
    return
  end
  
  if exists(select 1 from om_phydevice_info where entid <> @v_entid and entname = @v_i_entname and status <>9)
  begin
    select 3001
    return
  end

  if exists(select 1 from om_phydevice_info where entid <> @v_entid and fixedassetnum = @v_i_fixedassetnum and status <>9)
  begin
    select 3003
    return
  end

  if exists(select 1 from om_phydevice_info where entid <> @v_entid and systemnum = @v_i_systemnum and status <>9)
  begin
    select 3004
    return
  end
  
    if exists(select 1 from om_phydevice_info where entid <> @v_entid and productmnum = @v_i_productmnum and status <>9)
  begin
    select 3005
    return
  end
  
   update  om_phydevice_info set devicemospecid = @v_devicemospecid, fixedassetnum = @v_i_fixedassetnum, systemnum = @v_i_systemnum,
               productmnum = @v_i_productmnum, purchasedate = @v_i_purchasedate,  assurancetime = @v_i_assurancetime,
                assurancedesc = @v_i_assurancedesc,  location = @v_i_location, locationdesc = @v_i_locationdesc, upframenum = @v_i_upframenum,
                roundframenum = @v_i_roundframenum ,  slotnum = @v_i_slotnum,  ipmiip = @v_i_ipmiip, ipmiuser = @v_i_ipmiuser,
                ipmipwd = @v_i_ipmipwd, operid = @v_i_operid, opertime = @v_opertime
               where entid = @v_entid  
  select  1
  return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_del_phydevice'))
   drop procedure sp_web_del_phydevice
go
create procedure sp_web_del_phydevice
(
  @v_i_entid            varchar(100)                           
)  
as
  declare  @v_entid               varchar(100)
  declare  @v_parentrid           varchar(100)  
  declare  @v_status              int           
  declare  @v_devicemospecid      varchar(100)    
begin  
  select  @v_entid = ltrim(rtrim(@v_i_entid))	
  select  @v_status = 0 
  
  select @v_status = status ,@v_devicemospecid = devicemospecid from om_phydevice_info where entid = @v_entid 
  if @@rowcount = 0
  begin
    select 3023
    return  
  end	
  
  if (@v_status = 1 or @v_status = 2 or @v_status = 9 or @v_status = 10)
  begin
    select 3022
    return  
  end	
   
  if (@v_status = 0)
  begin
    begin tran
    delete from  om_phydevice_info  where entid = @v_entid  
    if @@error<>0
    begin
      rollback tran
      select 1001
      return
    end
     
    delete from  ent_phmachine where phyid = @v_entid 
    if @@error<>0                    
    begin
      rollback tran
      select 1001
      return
    end
    
    commit tran  
  end	
  else
  begin  
  	update om_phydevice_info set status = 9 where entid = @v_entid 
  	if @@error<>0                    
    begin
      select 1001
      return
    end
  end
   
  begin
  	update om_device_info set specidnum = specidnum - 1  where devicemospecid = @v_devicemospecid
  	if @@error<>0
	  begin
	    select 1001
	    return
	  end	 	
  end	 

  select  1
  return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_audit_order'))
   drop procedure sp_web_audit_order
go
create procedure sp_web_audit_order
(
  @v_i_orderid          int,             
  @v_i_entid            varchar(100),     
  @v_i_purchasedate     datetime,        
  @v_i_enddate          datetime,         
  @v_i_opertiongroupid  varchar(10),       
  @v_i_operid           varchar(50)       
)  
as
    declare  @v_vdcid              varchar(64)
    declare  @v_order_code         varchar(64)  
    declare  @v_opertime           date
    declare  @v_applicant_id       int
    declare  @v_opertiondivid      varchar(10)      
begin  
	select  @v_opertime = getdate()  
	select  @v_opertiondivid = '1'  
	  
    select  @v_order_code = order_code,@v_applicant_id = user_id from om_order where order_id = @v_i_orderid
    if @@rowcount = 0
    begin
        select 4001
        return
    end 
  
    select @v_opertiondivid = parentdataid from common_dict_item where dataid = @v_i_opertiongroupid
    if @@rowcount = 0
    begin
        select 5001
    end 
  
    if exists(select 1 from om_phydevice_user where entid = @v_i_entid)
    begin
        select 5002
        return
    end
  
    insert into om_phydevice_user (entid ,userid ,order_id,order_code ,hostname ,desciption ,purchasedate ,enddate ,opertiondivid ,
                 opertiongroupid ,userip ,managername ,managerpwd ,operid ,opertime, vdcid)
         values(@v_i_entid ,@v_applicant_id,@v_i_orderid, @v_order_code,'' ,'' ,@v_i_purchasedate  ,
                @v_i_enddate ,@v_opertiondivid ,@v_i_opertiongroupid ,'' ,
                '' ,'' ,@v_i_operid ,@v_opertime, @v_vdcid)
    if @@error<>0
    begin
        select 1001
        return
    end
  
    update om_phydevice_info set status = 1 where entid = @v_i_entid
    if @@error<>0
    begin
        select 1001
        return
    end                  
    select  1
    return
end
go

if exists (select 1 from sysobjects where id = object_id('sp_web_reject_orderphymachine'))
   drop procedure sp_web_reject_orderphymachine
go
create procedure sp_web_reject_orderphymachine
(
    @v_i_order_id       int        
)  
as
    declare  @v_status              int
begin  
	select  @v_status = 0
		
    update om_phydevice_info set status = @v_status from om_phydevice_info a
          where exists(select 1 from om_phydevice_user b where a.entid=b.entid and b.order_id = @v_i_order_id)
    if @@error<>0
    begin
       select 2001
       return
    end

    delete from om_phydevice_user where order_id = @v_i_order_id
    if @@error<>0
    begin
      select 2001
      return
    end
  
    select  1
    return
end
go

use iros
go

if exists (select 1 from sysobjects where id = object_id('om_itmp_devicetype_def'))
   drop table om_itmp_devicetype_def
go

create table om_itmp_devicetype_def
(
    type_id              varchar(50)   not null,  
    parent_type_id       varchar(50)   not null,  
    name                 varchar(50)   not null,
    related_ommp_type_id      varchar(50)   null,  
    primary key (type_id)
)
go

insert into om_itmp_devicetype_def values ('server_grp', 'dc', 'Server', 'ostype')
insert into om_itmp_devicetype_def values ('storage_grp', 'dc', 'Storage', 'storage')
insert into om_itmp_devicetype_def values ('network_grp', 'dc', 'Network', '')
insert into om_itmp_devicetype_def values ('router_grp', 'network_grp', 'Router', 'router')
insert into om_itmp_devicetype_def values ('switch_grp', 'network_grp', 'Switch', 'switch')
go


if exists (select 1 from sysobjects where id = object_id('om_itmp_device'))
   drop table om_itmp_device
go

create table om_itmp_device
(
    id            varchar(100)  not null,
    related_ommp_type_id       varchar(50)   not null,
    parent_id     varchar(50)   not null,
    name          varchar(255)  not null, 
    ip 	          varchar(50)   not null,
	create_time   datetime     not null,
	update_time   datetime     not null,
    extra         text          null,  
    primary key (id)
)
go
