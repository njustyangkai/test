create database operate charset utf8 collate utf8_general_ci;
use operate ;

drop table if exists version_info;
CREATE TABLE version_info ( 
	version      varchar(200) NULL,
	sql_version    varchar(12) NOT NULL
);
insert into version_info values (null, '000000000000'); 

DROP TABLE IF EXISTS service_directory;
CREATE TABLE `service_directory` (
   id varchar(64) NOT NULL,
   name varchar(64) NOT NULL,
   service_key varchar(64) NOT NULL,
   status  int,  -- 1-已发布 2-未发布
   description varchar(500) DEFAULT NULL,
   extra TEXT DEFAULT NULL,
   PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `service_directory`(id, name, service_key, status, description, extra) VALUES ('1000', '虚拟机', 'instance', 1, '', '');
INSERT INTO `service_directory`(id, name, service_key, status, description, extra) VALUES ('2000', '云硬盘', 'volume', 1, '', '');
INSERT INTO `service_directory`(id, name, service_key, status, description, extra) VALUES ('3000', '云路由器', 'router', 1, '', '');
INSERT INTO `service_directory`(id, name, service_key, status, description, extra) VALUES ('4000', '云防火墙', 'firewall', 1, '', '');
INSERT INTO `service_directory`(id, name, service_key, status, description, extra) VALUES ('5000', '云负载均衡', 'loadbalancer', 1, '', '');
INSERT INTO `service_directory`(id, name, service_key, status, description, extra) VALUES ('6000', '云桌面', 'desktop', 1, '', '');
INSERT INTO `service_directory`(id, name, service_key, status, description, extra) VALUES ('7000', '云连接', 'connection', 1, '', '');

DROP TABLE IF EXISTS  vdc_service_directory;
CREATE TABLE  vdc_service_directory (
   vdc_id  varchar(64) NOT NULL,
   extra TEXT DEFAULT NULL,
   PRIMARY KEY (vdc_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


drop table if exists charge_item;
create table charge_item
(
   service_directory_id varchar(64)  null, -- 服务目录ID
   id  varchar(64)  not null, -- 计费项ID
   name varchar(256)  not null, -- 计费项名称
   parent_id varchar(64)  null,   -- 父计费项ID
   price varchar(16)  null,   -- 价格
   status  int, -- 1-可用 2-禁用
   unit varchar(32)  null,   -- 单位
   isleaf int null,   -- 是否叶子节点 0-否；1-是
   description varchar(500) DEFAULT NULL,
   PRIMARY KEY (id)
);

DROP TABLE IF EXISTS  org_vdc_rel;
CREATE TABLE  org_vdc_rel (
   org_id    varchar(64),
   org_name  varchar(200),
   project_id    varchar(64),
   project_name  varchar(200),
   vdc_id    varchar(64),
   vdc_name  varchar(200),
   env_id    varchar(64),
   env_name  varchar(200),
   PRIMARY KEY (org_id, vdc_id, env_id)
);

insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('1000','1001','核心','','90',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('1000','1002','内存','','12',2,'GB',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('1000','1003','系统盘','','0.6',2,'GB',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('1000','1004','公网地址','','50',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('1000','1005','内网地址','','10',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('1000','1006','操作系统','','',1,'',0,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('','1007','Windows','1006','19',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('','1008','Linux','1006','12',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('','1009','WinSVer','1006','19',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('','1010','CentOS','1006','12',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('','1011','SUSE','1006','12',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('','1012','RedHat','1006','12',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('2000','2001','标准存储','','0.3',2,'GB',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('2000','2002','高性能存储','','0.6',2,'GB',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('3000','3001','网关版','','158',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('3000','3002','汇聚版','','272',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('3000','3003','企业版','','2580',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('4000','4001','安全版','','1280',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('4000','4002','高性能版','','3990',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('5000','5001','云负载均衡子产品','','612',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('6000','6001','独享终端','','268',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('6000','6002','共享终端','','218',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('6000','6003','应用终端','','168',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('6000','6004','物理终端','','120',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('6000','6005','打印终端','','516',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('6000','6006','刷卡终端','','120',2,'count',1,'');
insert into charge_item(service_directory_id,id,name,parent_id,price,status,unit,isleaf,description) values ('7000','7001','带宽（Mbps）','','3500',2,'port',1,'');

drop procedure if exists p_create_table;
DELIMITER &&
create procedure p_create_table(in tablename varchar(50))
BEGIN
   declare i int;
	declare mmdd varchar(4);
	declare tabname varchar(20);
	declare vsql varchar(1000); 
	set i=24;	   
	while i>=1 do
	    set mmdd=right(concat('0', i), 2);
	    set tabname=concat(tablename,mmdd);
		SET @sql_txt = concat('drop table if exists ', tabname); 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;

		set vsql=concat('create table if not exists ',tabname,
		                     '(org_id varchar(64) NOT NULL,'
		                     'org_name varchar(200) NOT NULL,'
		                     'vdc_id varchar(64),'
		                     'vdc_name varchar(200),'
		                     'project_id varchar(64),'
		                     'project_name varchar(200),'
		                     'env_id varchar(64),'
		                     'env_name varchar(200),'
		                     'tenant_id varchar(64),'
		                     'user_id varchar(128),'
		                     'resource_id varchar(64),'
		                     'resource_name varchar(200),'
		                     'status varchar(64),'
		                     'resource_type varchar(64),'
		                     'resource_info varchar(200),'
		                     'price numeric(20, 5),'
		                     'cost numeric(20, 5),'
		                     'description varchar(200),'
		                     'begin_time datetime,'
		                     'end_time datetime,'
		                     'record_time datetime,'
		                     'extra varchar(200),'
		                     'PRIMARY KEY (vdc_id, resource_id, begin_time))');
		
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;

		set vsql=concat('create index idx_',tabname,' on ',tabname,'(vdc_id, resource_id, begin_time)');
		SET @sql_txt = vsql; 
		PREPARE stmt FROM @sql_txt; 
		EXECUTE stmt;        
	   	
        set i=i-1;
    end while;
END&& 
DELIMITER ; 
commit;

call p_create_table('billing_vm_');
call p_create_table('billing_volume_');
call p_create_table('billing_vr_');
call p_create_table('billing_vfw_');
call p_create_table('billing_vlb_');
call p_create_table('billing_vdesk_');
call p_create_table('billing_vnet_');
