/**
 * 
 */
package com.zte.vdirector.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.openstack.OperateApI;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.auth.AccessBean;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.utils.Utils;

/**
 * <p>
 * 版权所有：中兴通讯股份有限公司
 * </p>
 * <p>
 * 项目名称：Operate
 * </p>
 * <p>
 * 类名称：NetworkService
 * </p>
 * <p>
 * 类描述：
 * </p>
 * <p>
 * 创建人：10138528
 * </p>
 * <p>
 * 创建时间：2016-11-14 下午3:23:49
 * </p>
 * <p>
 * 修改人：10138528
 * </p>
 * <p>
 * 修改时间：2016-11-14 下午3:23:49
 * </p>
 * <p>
 * 修改备注：
 * </p>
 * 
 * @version 1.0
 * 
 */
@Service
public class NetworkService
{
    public Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private AuthService authService;

    @Resource
    private OperateApI operateApI;

    @Resource
    private CommonService commonService;

    @Resource
    private ServiceBase serviceBase;

    @Resource
    private Environment env;

    public Map<String, Object> getSubnetPool(CloudEnvInfo cloudEnvInfo, int ipCount, boolean needLb) throws Exception
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new HashMap<String, Object>();
        }

        Map<String, Object> subnetPoolMap = new HashMap<String, Object>();
        JSONArray subnetPool = getSubnetPool(accessBean);
        if (null != subnetPool)
        {
            int prefix = getCidrPrefix(ipCount, needLb);
            if (prefix < 24)
            {
                throw new Exception("prefixlen " + prefix + " is smaller than 24.");
            }

            for (Object temp : subnetPool)
            {
                if (null != temp)
                {
                    JSONObject tempSubnetPool = (JSONObject) temp;
                    if (tempSubnetPool.getString("name").startsWith("pool-eni-"))
                    {
                        String ip = checkSubnetPool(accessBean, tempSubnetPool.getString("id"), prefix + "");
                        if (StringUtils.isNotBlank(ip) && !StringUtils.equals("0", ip))
                        {
                            subnetPoolMap.put("id", tempSubnetPool.getString("id"));
                            subnetPoolMap.put("name", tempSubnetPool.getString("name"));
                            subnetPoolMap.put("prefix", prefix);
                            subnetPoolMap.put("cidr", ip + "/" + prefix);
                            break;
                        }
                    }
                }
            }
        }

        return subnetPoolMap;
    }

    public JSONArray getSubnetPool(CloudEnvInfo cloudEnvInfo) throws Exception
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONArray();
        }

        return getSubnetPool(accessBean);
    }

    private int getCidrPrefix(int ipCount, boolean needLb)
    {
        int ip = 3;
        if (needLb)
        {
            ip += 3;
        }
        if (ipCount > 0)
        {
            ipCount += ip;

            for (int i = 0; i <= 16; i++)
            {
                if (ipCount <= Math.pow(2, i))
                {
                    return 16 + (16 - i);
                }
            }
        }
        return 16;
    }

    public JSONArray getSubnetPool(AccessBean accessBean)
    {
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.SUBNET_POOL;

        try
        {
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("subnetpools");
            }
            else
            {
                logger.error("getSubnetpool failed, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getSubnetpool error, ", e);
            return new JSONArray();
        }
    }

    /**
     * 
     * @return e
     */
    public Map<String, Object> createNetworkCN2AndEni(String type, String subnetPool, String vdcName, String vdcId,
            String cidr, CloudEnvInfo cloudEnvInfo)
    {
        Map<String, Object> result = new HashMap<String, Object>();
        String networkName = "net" + "-" + vdcName + "-" + type.toLowerCase();

        JSONObject network = getNetwork(cloudEnvInfo, networkName);
        if (null == network || !network.containsKey("id"))
        {
            network = createNetwork(cloudEnvInfo, networkName);
        }

        if (null != network && network.containsKey("id"))
        {
            // 关联vdc
            bindVdcNet(vdcId, network.getString("name"), network.getString("id"));

            result.put("networkName", networkName);
            result.put("networkId", network.getString("id"));
            long suffix = new Date().getTime();
            String subnetName = "subnet-" + "-" + vdcName + "-" + suffix + "-" + type.toLowerCase();
            JSONObject subNetwork = createSubNetwork(cloudEnvInfo, subnetName, network.getString("id"), subnetPool,
                    cidr);

            if (null != subNetwork && subNetwork.containsKey("id"))
            {
                result.put("subnetName", subnetName);
                result.put("subnetId", subNetwork.getString("id"));

                String routerName = "router" + "-" + vdcName + "-" + subnetPool + "-" + type.toLowerCase();
                JSONObject router = createRouter(cloudEnvInfo, routerName);
                if (null != router && router.containsKey("id"))
                {
                    result.put("routerName", routerName);
                    result.put("routerId", router.getString("id"));
                    JSONObject binding = bindSubNetworkToRouter(cloudEnvInfo, subNetwork.getString("id"), router
                            .getString("id"));

                    if (null != binding && binding.containsKey("id"))
                    {
                        result.put("routerbindId", router.getString("id"));
                        return result;
                    }
                }
            }
        }

        return new HashMap<String, Object>();
    }

    public JSONObject getNetwork(CloudEnvInfo cloudEnvInfo, String networkName)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NEUTRON_NETWORKS;

        try
        {
            if (StringUtils.isNotBlank(networkName))
            {
                url += "?name=" + networkName;
            }
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), "");
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                JSONArray networks = resources.getJSONArray("networks");
                if (null != networks && networks.size() > 0)
                {
                    return networks.getJSONObject(0);
                }
            }
            else
            {
                logger.error("getNetwork failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("getNetwork error, ", e);
        }

        return new JSONObject();
    }

    /**
     * 
     * @return
     */
    public JSONObject createNetwork(CloudEnvInfo cloudEnvInfo, String networkName)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NEUTRON_NETWORKS;

        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            Map<String, Object> network = new HashMap<String, Object>();
            network.put("name", networkName);
            network.put("tenant_id", cloudEnvInfo.getTenantId());
            params.put("network", network);
            RestfulRsp rsp = operateApI.post(url, Utils.getHeader(accessBean), params);
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONObject("network");
            }
            else
            {
                logger.error("createNetwork failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createNetwork error, ", e);
        }

        return new JSONObject();
    }

    /**
     * 
     * @return
     */
    public JSONObject createSubNetwork(CloudEnvInfo cloudEnvInfo, String subNetworkName, String networkId,
            String subnetPool, String cidr)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NEUTRON_SUBNETS;

        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            Map<String, Object> network = new HashMap<String, Object>();
            network.put("name", subNetworkName);
            network.put("tenant_id", cloudEnvInfo.getTenantId());
            network.put("network_id", networkId);
            network.put("ip_version", 4);
            network.put("cidr", cidr);
            network.put("subnetpool_id", subnetPool);

            params.put("subnet", network);

            RestfulRsp rsp = operateApI.post(url, Utils.getHeader(accessBean), params);
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONObject("subnet");
            }
            else
            {
                logger.error("createSubNetwork failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createSubNetwork error, ", e);
        }

        return new JSONObject();
    }

    /**
     * 
     * @return
     */
    public JSONObject createSubNetwork(CloudEnvInfo cloudEnvInfo, String subNetworkName, String networkId, String cidr)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NEUTRON_SUBNETS;

        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            Map<String, Object> network = new HashMap<String, Object>();
            network.put("name", subNetworkName);
            network.put("tenant_id", cloudEnvInfo.getTenantId());
            network.put("network_id", networkId);
            network.put("ip_version", 4);
            network.put("cidr", cidr);

            params.put("subnet", network);

            RestfulRsp rsp = operateApI.post(url, Utils.getHeader(accessBean), params);
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONObject("subnet");
            }
            else
            {
                logger.error("createSubNetwork failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createSubNetwork error, ", e);
        }

        return new JSONObject();
    }

    public JSONObject createRouter(CloudEnvInfo cloudEnvInfo, String routerName)
    {
        JSONObject router = getRouter(cloudEnvInfo, routerName);
        if (null != router && router.containsKey("id"))
        {
            return router;
        }

        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NEUTRON_ROUTERS;

        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            Map<String, Object> routerMap = new HashMap<String, Object>();
            routerMap.put("name", routerName);
            routerMap.put("tenant_id", cloudEnvInfo.getTenantId());
            params.put("router", routerMap);

            RestfulRsp rsp = operateApI.post(url, Utils.getHeader(accessBean), params);
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONObject("router");
            }
            else
            {
                logger.error("createRouter failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createRouter error, ", e);
        }

        return new JSONObject();
    }

    public JSONObject getRouter(CloudEnvInfo cloudEnvInfo, String routerName)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NEUTRON_ROUTERS;
        RestfulRsp rsp;
        try
        {
            rsp = operateApI.get(url, Utils.getHeader(accessBean), "");
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                JSONArray routers = resources.getJSONArray("routers");
                if (null != routers)
                {
                    for (Object temp : routers)
                    {
                        JSONObject router = (JSONObject) temp;
                        if (StringUtils.equalsIgnoreCase(router.getString("name"), routerName))
                        {
                            return router;
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            logger.error("getRouter error", e);
        }
        return new JSONObject();
    }

    public JSONObject bindSubNetworkToRouter(CloudEnvInfo cloudEnvInfo, String subnetId, String routerId)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NEUTRON_ROUTERS_BIND;
        url = url.replaceAll(CommonConstants.Neutron.ROUTER_ID, routerId);

        try
        {
            Map<String, Object> router = new HashMap<String, Object>();
            router.put("subnet_id", subnetId);

            RestfulRsp rsp = operateApI.put(url, Utils.getHeader(accessBean), router);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                return JSON.parseObject(rsp.getResponseBody());
            }
            else
            {
                logger.error("createRouter failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createRouter error, ", e);
        }

        return new JSONObject();
    }

    /**
     * 
     * @return e
     */
    public Map<String, Object> createNetworkB(String cidr, String vdcName, String vdcId, CloudEnvInfo cloudEnvInfo)
    {
        Map<String, Object> result = new HashMap<String, Object>();
        String networkName = "net-" + vdcName + "-b";

        JSONObject network = getNetwork(cloudEnvInfo, networkName);
        if (null == network || !network.containsKey("id"))
        {
            network = createNetwork(cloudEnvInfo, networkName);
        }

        if (null != network && network.containsKey("id"))
        {
            // 关联vdc
            bindVdcNet(vdcId, network.getString("name"), network.getString("id"));

            JSONObject subNetwork = getSubNetwork(cloudEnvInfo, network.getString("id"), cidr);
            if (null == subNetwork || !subNetwork.containsKey("id"))
            {
                result.put("networkName", networkName);
                result.put("networkId", network.getString("id"));
                long suffix = new Date().getTime();
                String subnetName = "subnet-" + vdcName + "-" + suffix + "-b";
                subNetwork = createSubNetwork(cloudEnvInfo, subnetName, network.getString("id"), cidr);
            }
            if (null != subNetwork && subNetwork.containsKey("id"))
            {
                result.put("subnetName", subNetwork.getString("name"));
                result.put("subnetId", subNetwork.getString("id"));

                String routerName = "router-" + vdcName + "-b";
                JSONObject router = createRouter(cloudEnvInfo, routerName);
                if (null != router && router.containsKey("id"))
                {
                    result.put("routerName", routerName);
                    result.put("routerId", router.getString("id"));
                    JSONObject binding = bindSubNetworkToRouter(cloudEnvInfo, subNetwork.getString("id"), router
                            .getString("id"));

                    if (null != binding && binding.containsKey("id"))
                    {
                        result.put("routerbindId", router.getString("id"));
                        return result;
                    }
                }
            }
        }

        return new HashMap<String, Object>();
    }

    public JSONObject getSubNetwork(CloudEnvInfo cloudEnvInfo, String networkId, String cidr)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NEUTRON_NETWORKS;

        try
        {
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), "");
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                JSONArray subnets = resources.getJSONArray("subnets");
                if (null != subnets && subnets.size() > 0)
                {
                    for (Object temp : subnets)
                    {
                        JSONObject subnet = (JSONObject) temp;
                        if (StringUtils.equalsIgnoreCase(networkId, subnet.getString("network_id"))
                                && StringUtils.equalsIgnoreCase(subnet.getString("cidr"), cidr))
                        {
                            return subnet;
                        }
                    }
                }
            }
            else
            {
                logger.error("getSubNet failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("getSubNet error, ", e);
        }

        return new JSONObject();
    }

    /**
     * 
     * @return e
     */
    public JSONObject createFirewall(String type, Map<String, Object> router, String vdcName, CloudEnvInfo cloudEnvInfo)
    {
        String firewallName = "firewall-" + vdcName + "-" + type;

        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALLS;
        try
        {
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                JSONArray firewalls = resources.getJSONArray("firewalls");
                if (null != firewalls)
                {
                    for (Object temp : firewalls)
                    {
                        if (null != temp)
                        {
                            JSONObject firewall = (JSONObject) temp;
                            if (StringUtils.equalsIgnoreCase(firewallName, firewall.getString("name")))
                            {
                                if (null != router && firewall.containsKey("router_ids"))
                                {
                                    JSONArray routers = firewall.getJSONArray("router_ids");

                                    if (null != routers)
                                    {
                                        url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALLS_ID;
                                        routers.add(router.get("routerId"));
                                        firewall.put("router_ids", routers);
                                        rsp = operateApI.put(url, Utils.getHeader(accessBean), firewall);
                                        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
                                        {
                                            resources = JSON.parseObject(rsp.getResponseBody());
                                            return resources.getJSONObject("firewall");
                                        }
                                    }
                                }
                                return firewall;
                            }
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            logger.error("get firewall failed", e);
        }

        // 不存在则创建新的防火墙
        url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALLS;

        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            Map<String, Object> firewall = new HashMap<String, Object>();
            firewall.put("name", firewallName);
            firewall.put("firewall_policy_id", null);
            List<String> routerIds = new ArrayList<String>();
            if (null != router && router.containsKey("routerId"))
            {
                routerIds.add(router.get("routerId").toString());
                firewall.put("router_ids ", routerIds);
            }
            firewall.put("tenant_id", cloudEnvInfo.getTenantId());

            params.put("firewall", firewall);
            RestfulRsp rsp = operateApI.post(url, Utils.getHeader(accessBean), params);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONObject("firewall");
            }
            else
            {
                logger.error("createFirewall failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createFirewall error, ", e);
        }

        return new JSONObject();
    }

    /**
     * 
     * @param type
     * @param vdcName
     * @param subnet
     * @param cloudEnvInfo
     * @return e
     */
    public JSONObject createLb(String type, Map<String, Object> subnet, String vdcName, CloudEnvInfo cloudEnvInfo)
    {
        String lbName = "lb-" + "-" + vdcName + "-" + type;// + new Date().getTime();

        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LOADBALANCERS;

        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            Map<String, Object> lb = new HashMap<String, Object>();
            lb.put("name", lbName);
            lb.put("description", "");
            lb.put("tenant_id", cloudEnvInfo.getTenantId());
            if (subnet.containsKey("subnetId"))
            {
                lb.put("vip_subnet_id", subnet.get("subnetId"));
            }
            params.put("loadbalancer", lb);
            RestfulRsp rsp = operateApI.post(url, Utils.getHeader(accessBean), params);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONObject("loadbalancer");
            }
            else
            {
                logger.error("createLb failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createLb error, ", e);
        }

        return new JSONObject();
    }

    /**
     * 
     * @param vdcName
     * @param cloudEnvInfo
     * @return e
     */
    public String createPrivateNetwork(String vdcName, CloudEnvInfo cloudEnvInfo)
    {
        // String cidr = "192.168.0.1/16";

        // 调用接口

        return "SUCCESS";
    }

    public String checkSubnetPool(AccessBean accessBean, String subnetPoolId, String prefix)
    {
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.SUBNET_POOL_IP_AVAILABILITY + "?subnetpool="
                + subnetPoolId + "&prefixlen=" + prefix;

        try
        {
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                if (resources.containsKey("subnetpool_ip_availabilities"))
                {
                    JSONArray ips = resources.getJSONArray("subnetpool_ip_availabilities");
                    if (null != ips && ips.size() > 0)
                    {
                        for (Object temp : ips)
                        {
                            JSONObject ip = (JSONObject) temp;
                            if (ip.containsKey("the_first_ip"))
                            {
                                return ip.getString("the_first_ip");
                            }
                        }
                    }
                }
            }
            else
            {
                logger.error("checkSubnetPool failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("checkSubnetPool error, ", e);
        }
        return "";
    }

    public JSONArray getNetworks(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONArray();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NETWORKS;

        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        else
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
        }

        try
        {
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), "");
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("networks");
            }
            else
            {
                logger.error("getNetworks failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("getNetworks error, ", e);
        }

        return new JSONArray();
    }

    public JSONArray getSubNetworks(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONArray();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.SUBNETS;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        else
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
        }
        try
        {
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("subnets");
            }
            else
            {
                logger.error("getSubnetList failed, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getSubnetList error, ", e);
            return new JSONArray();
        }
    }

    @SuppressWarnings("unused")
    private int getVlanId(AccessBean accessBean, String netType, String physicalNetwork)
    {
        List<String> vlanIds = new ArrayList<String>();
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.NEUTRON_NETWORKS;
        try
        {
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), "");
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                JSONArray networks = resources.getJSONArray("networks");
                if (null != networks)
                {
                    for (Object temp : networks)
                    {
                        if (null != temp)
                        {
                            JSONObject network = (JSONObject) temp;
                            if (network.containsKey("provider:network_type")
                                    && StringUtils
                                            .equalsIgnoreCase(network.getString("provider:network_type"), netType))
                            {
                                // vlan
                                if (network.containsKey("provider:physical_network")
                                        && StringUtils.equalsIgnoreCase(network.getString("provider:physical_network"),
                                                physicalNetwork))
                                {
                                    vlanIds.add("" + network.getIntValue("provider:segmentation_id"));
                                }
                                // vxlan
                                else
                                {
                                    vlanIds.add("" + network.getIntValue("provider:segmentation_id"));
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                logger.error("getVlanId failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("getVlanId error, ", e);
        }

        int vlanBegin = 2;
        int vlanEnd = 4094;
        try
        {
            vlanBegin = Integer.parseInt(env.getProperty("vlan_begin"));
            vlanEnd = Integer.parseInt(env.getProperty("vlan_end"));
        }
        catch (Exception e)
        {
            logger.error("error get vlanId range", e);
        }
        for (int i = vlanBegin; i <= vlanEnd; i++)
        {
            if (!vlanIds.contains(i + ""))
            {
                return i;
            }
        }
        return 0;
    }

    private String getPhysicalName(CloudEnvInfo cloudEnvInfo)
    {
        String physicalNet = "physnet1";
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return physicalNet;
        }

        if (StringUtils.equalsIgnoreCase(cloudEnvInfo.getType(), "vmware"))
        {
            physicalNet = "vSwitch1";
        }
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.GET_PHYSICAL_NETWORKS;
        try
        {
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), "");
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                JSONArray physnets = resources.getJSONArray("physnets");
                if (null != physnets)
                {
                    for (Object temp : physnets)
                    {
                        if (null != temp)
                        {
                            JSONObject physnet = (JSONObject) temp;
                            if (physnet.containsKey("type") && StringUtils.equals(physnet.getString("type"), "vlan"))
                            {
                                physicalNet = physnet.getString("name");
                                break;
                            }
                        }
                    }
                }
            }
            else
            {
                logger.error("createCloudEnvNet failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createCloudEnvNet error, ", e);
        }
        return physicalNet;
    }

    private JSONObject createCloudEnvNet(CloudEnvInfo cloudEnvInfo, String vdcId, String vdcName)
    {
        // AccessBean accessBean = null;
        // try
        // {
        // accessBean = authService.getAuthInfo(cloudEnvInfo);
        // }
        // catch (Exception e)
        // {
        // logger.error("Fail to getAuthInfo.", e);
        // return new JSONObject();
        // }

        try
        {
            String url = CommonConstants.Neutron.CREATE_NETWORK;
            Map<String, Object> request = new HashMap<String, Object>();
            Map<String, Object> networkMap = new HashMap<String, Object>();
            networkMap.put("name", "net-" + vdcName + "-private");
            networkMap.put("vdc_id", vdcId);
            String dcId = commonService.getDcId(cloudEnvInfo.getEnvId());
            if (StringUtils.isNotBlank(dcId))
            {
                networkMap.put("dc_id", dcId);
            }
            networkMap.put("cloudenv_id", cloudEnvInfo.getEnvId());
            networkMap.put("network_type", "vlan");
            String physicalNetwork = getPhysicalName(cloudEnvInfo);
            networkMap.put("physical_network", physicalNetwork);
            networkMap.put("network_type", "vlan");
            // int vlanId = getVlanId(accessBean, "vlan", physicalNetwork);
            // if (vlanId != 0)
            // {
            // networkMap.put("segmentation_id", vlanId);
            // }
            networkMap.put("shared", false);
            networkMap.put("tenant_id", cloudEnvInfo.getTenantId());
            request.put("network", networkMap);

            RestfulRsp rsp = serviceBase.post(request, url);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONObject("network");
            }
            else
            {
                logger.error("createCloudEnvNet failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createCloudEnvNet error, ", e);
        }
        return new JSONObject();
    }

    private JSONObject createCloudEnvSubNet(CloudEnvInfo cloudEnvInfo, JSONObject network, String vdcId, String vdcName)
    {
        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            Map<String, Object> networkMap = new HashMap<String, Object>();
            networkMap.put("name", "subnet-" + vdcName + "-private");
            networkMap.put("vdc_id", vdcId);
            String dcId = commonService.getDcId(cloudEnvInfo.getEnvId());
            if (StringUtils.isNotBlank(dcId))
            {
                networkMap.put("dc_id", dcId);
            }
            networkMap.put("cloudenv_id", cloudEnvInfo.getEnvId());
            networkMap.put("network_id", network.getString("id"));
            networkMap.put("cidr", "192.168.0.0/16");
            networkMap.put("gateway_ip", "192.168.0.1");

            List<Map<String, Object>> ipPools = new ArrayList<Map<String, Object>>();
            Map<String, Object> ipPool = new HashMap<String, Object>();
            ipPool.put("start", "192.168.0.2");
            ipPool.put("end", "192.168.0.254");
            ipPools.add(ipPool);
            networkMap.put("allocation_pools", ipPools);
            networkMap.put("ip_version", "4");
            networkMap.put("enable_dhcp", true);

            params.put("subnet", networkMap);
            RestfulRsp rsp = serviceBase.post(params, CommonConstants.Neutron.CREATE_SUB_NETWORK);
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONObject("subnet");
            }
            else
            {
                logger.error("createCloudEnvSubNet failed, response body = ", rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createCloudEnvSubNet error, ", e);
        }
        return new JSONObject();
    }

    public Map<String, Object> createNetwork(CloudEnvInfo cloudEnvInfo, String type, JSONObject params)
    {
        String subnetPool = params.getString("subnetPool");
        String cidr = params.getString("cidr");
        String vdcName = params.getString("vdcName");
        String vdcId = params.getString("vdcId");
        String ipCount = params.getString("ipCount");
        // String prefix = params.getString("prefix");
        boolean needLb = params.getBoolean("needLb");
        // boolean needFw = params.getBoolean("needFw");
        Map<String, Object> result = new HashMap<String, Object>();

        // cn2,eni检查是否存在可用子网
        if (StringUtils.equals("cn2", type) || StringUtils.equals("eni", type))
        {
            result = getAvailableSubNet(cloudEnvInfo, vdcName, type, ipCount, needLb);
            if (null != result && result.containsKey("subnetId"))
            {
                return result;
            }
        }
        // 不存在可用子网则创建
        if (StringUtils.isBlank(subnetPool) || StringUtils.isBlank(cidr))
        {
            Map<String, Object> ips = null;
            try
            {
                ips = getSubnetPool(cloudEnvInfo, Integer.parseInt(ipCount), needLb);
            }
            catch (Exception e)
            {
                if (null != ips && ips.containsKey("id") && ips.containsKey("cidr"))
                {
                    subnetPool = ips.get("id").toString();
                    cidr = ips.get("cidr").toString();
                }
            }
        }

        if (StringUtils.isBlank(subnetPool) || StringUtils.isBlank(cidr))
        {
            result.put("success", false);
            result.put("message", type + " network has not enough ip address for " + ipCount
                    + " ip and the config of need loadbalance is " + needLb);
            return result;
        }

        // 建网络
        if (StringUtils.equals("cn2", type))
        {
            result = createNetworkCN2AndEni("cn2", subnetPool, vdcName, vdcId, cidr, cloudEnvInfo);
        }
        else if (StringUtils.equals("eni", type))
        {
            result = createNetworkCN2AndEni("eni", subnetPool, vdcName, vdcId, cidr, cloudEnvInfo);
        }
        else if (StringUtils.equals("b", type))
        {
            result = createNetworkB(cidr, vdcName, vdcId, cloudEnvInfo);
        }

        // if (null != result)
        // {
        // //绑定防火墙
        // if (needFw)
        // {
        // JSONObject firewall = createFirewall(type, result, vdcName, cloudEnvInfo);
        // if (null != firewall && firewall.containsKey("id"))
        // {
        // result.put("firewallId", firewall.getString("id"));
        // }
        // }
        //
        // //绑定负载均衡
        // if (needLb)
        // {
        // JSONObject lb = createLb(type, result, vdcName, cloudEnvInfo);
        // if (null != lb && lb.containsKey("id"))
        // {
        // result.put("lbId", lb.getString("id"));
        // }
        // }
        // }

        return result;
    }

    public Map<String, Object> getAvailableSubNet(CloudEnvInfo cloudEnvInfo, String type, String vdcName,
            String ipCount, boolean needLb)
    {
        Map<String, Object> result = new HashMap<String, Object>();
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            result.put("message", "fail to get auth info");
            return result;
        }

        String networkName = "net" + "-" + vdcName + "-" + type.toLowerCase();
        JSONObject network = getNetwork(cloudEnvInfo, networkName);
        if (null != network)
        {
            String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.AVAILABILITIES_IP;
            url = url.replaceAll(CommonConstants.Common.NETWORK_ID, network.getString("id"));
            try
            {
                RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), "");
                if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
                {
                    JSONObject resp = JSON.parseObject(rsp.getResponseBody());
                    JSONObject networkIpAvailability = resp.getJSONObject("network_ip_availability");
                    if (null != networkIpAvailability && networkIpAvailability.containsKey("subnet_ip_availability"))
                    {
                        JSONArray subnetIpAvailabilities = networkIpAvailability.getJSONArray("subnet_ip_availability");
                        if (null != subnetIpAvailabilities)
                        {
                            for (Object temp : subnetIpAvailabilities)
                            {
                                if (null != temp)
                                {
                                    JSONObject subnetIpAvailability = (JSONObject) temp;
                                    if (subnetIpAvailability.containsKey("subnet_name")
                                            && subnetIpAvailability.getString("subnet_name").startsWith(
                                                    "subnet-" + "-" + vdcName + "-")
                                            && subnetIpAvailability.getString("").endsWith("-" + type.toLowerCase())
                                            && subnetIpAvailability.containsKey("used_ips")
                                            && subnetIpAvailability.containsKey("total_ips"))
                                    {
                                        int total = subnetIpAvailability.getIntValue("total_ips");
                                        int used = subnetIpAvailability.getIntValue("used_ips");
                                        if (total - used >= Integer.parseInt(ipCount))
                                        {
                                            JSONObject subnet = getSubNetworkDetail(cloudEnvInfo, subnetIpAvailability
                                                    .getString("subnet_id"));
                                            if (null != subnet && subnet.containsKey("id")
                                                    && subnet.containsKey("subnetpool_id")
                                                    && StringUtils.isNotBlank(subnet.getString("subnetpool_id")))
                                            {
                                                String subnetPool = subnet.getString("subnetpool_id");
                                                String routerName = "router" + "-" + vdcName + "-" + subnetPool + "-"
                                                        + type.toLowerCase();
                                                JSONObject router = createRouter(cloudEnvInfo, routerName);
                                                if (null != router && router.containsKey("id"))
                                                {
                                                    result.put("routerName", routerName);
                                                    result.put("routerId", router.getString("id"));
                                                    JSONObject binding = bindSubNetworkToRouter(cloudEnvInfo,
                                                            subnetIpAvailability.getString("subnet_id"), router
                                                                    .getString("id"));

                                                    if (null != binding && binding.containsKey("id"))
                                                    {
                                                        result.put("routerbindId", router.getString("id"));
                                                        return result;
                                                    }
                                                }
                                            }
                                            result.put("networkId", network.getString("id"));
                                            result.put("networkName", network.getString("name"));
                                            result.put("subnetId", subnetIpAvailability.getString("subnet_id"));
                                            result.put("subnetName", subnetIpAvailability.getString("subnet_name"));
                                            // result.put("", subnetIpAvailability);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    logger.error("createCloudEnvNet failed, response body = ", rsp.getResponseBody());
                }
            }
            catch (Exception e)
            {
                logger.error("createCloudEnvNet error, ", e);
            }
        }

        return result;
    }

    public JSONObject getSubNetworkDetail(CloudEnvInfo cloudEnvInfo, String subnetId)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new JSONObject();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.SUBNET;
        url = url.replaceAll(CommonConstants.Common.SUBNET_ID, subnetId);

        try
        {
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONObject("subnet");
            }
            else
            {
                logger.error("getSubnet failed, response body = ", rsp.getResponseBody());
                return new JSONObject();
            }
        }
        catch (Exception e)
        {
            logger.error("getSubnet error, ", e);
            return new JSONObject();
        }
    }

    public JSONArray getVdcNet(CloudEnvInfo cloudEnvInfo, String vdcId, String vdcName)
    {
        String url = CommonConstants.Neutron.VDC_NETWORKS_BATCH;
        RestfulRsp response;
        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            Map<String, Object> vdc = new HashMap<String, Object>();
            vdc.put("name", vdcName);
            vdc.put("id", vdcId);
            List<Map<String, Object>> vdcs = new ArrayList<Map<String, Object>>();
            vdcs.add(vdc);
            params.put("vdcList", vdcs);
            response = serviceBase.post(params, url);
            if (response.getStatusCode() == CommonConstants.SUCCESS_CODE_200
                    && StringUtils.isNotBlank(response.getResponseBody()))
            {
                JSONObject networkResult = JSON.parseObject(response.getResponseBody().toString());
                if (null != networkResult && networkResult.containsKey("vdc_networks"))
                {
                    return networkResult.getJSONArray("vdc_networks");
                }
            }
            else
            {
                logger.error("getVdcNet failed, response body = ", response.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("getVdcNet failed", e);
        }

        return null;
    }

    public Map<String, Object> createVdcNet(CloudEnvInfo cloudEnvInfo, String vdcId, String vdcName)
    {
        String vdcNetworkName = "net-" + vdcName + "-private";
        JSONArray vdcNetworks = getVdcNet(cloudEnvInfo, vdcId, vdcName);
        if (null != vdcNetworks && vdcNetworks.size() > 0)
        {
            for (Object temp : vdcNetworks)
            {
                if (null != temp)
                {
                    JSONObject vdcNetwork = (JSONObject) temp;
                    if (vdcNetwork.containsKey("name")
                            && StringUtils.equals(vdcNetworkName, vdcNetwork.getString("name")))
                    {
                        return vdcNetwork;
                    }
                }
            }
        }

        try
        {
            JSONObject network = createCloudEnvNet(cloudEnvInfo, vdcId, vdcName);

            if (null != network && network.containsKey("id"))
            {
                JSONObject subNetwork = createCloudEnvSubNet(cloudEnvInfo, network, vdcId, vdcName);

                if (null != subNetwork && subNetwork.containsKey("id"))
                {
                    return bindVdcNet(vdcId, network.getString("name"), network.getString("id"));
                }
                else
                {
                    logger.error("createSubNet in createVdcNet failed");
                }
            }
            else
            {
                logger.error("createNet in createVdcNet failed");
            }
        }
        catch (Exception e)
        {
            logger.error("createVdcNet error, ", e);
        }
        return new HashMap<String, Object>();
    }

    public JSONObject getVdcNet(String vdcId, String vdcNetworkId)
    {
        try
        {
            String url = CommonConstants.Neutron.GET_VDC_NETWORK;
            url = url.replaceAll(CommonConstants.Common.VDC_ID, vdcId);
            url = url.replaceAll(CommonConstants.Common.NETWORK_ID, vdcNetworkId);
            RestfulRsp response = serviceBase.get(url);
            if (response.getStatusCode() == CommonConstants.SUCCESS_CODE_200
                    && StringUtils.isNotBlank(response.getResponseBody()))
            {
                JSONObject networkResult = JSON.parseObject(response.getResponseBody().toString());
                if (null != networkResult)
                {
                    return networkResult.getJSONObject("vdc_network");
                }
            }
            else
            {
                logger.error("getVdcNet failed, response body = ", response.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("getVdcNet error, ", e);
        }
        return new JSONObject();
    }

    public JSONObject bindVdcNet(String vdcId, String vdcNetworkName, String vdcNetworkId)
    {
        JSONObject vdcNet = getVdcNet(vdcId, vdcNetworkId);
        if (null != vdcNet && vdcNet.containsKey("id"))
        {
            return vdcNet;
        }

        try
        {
            Map<String, Object> networkMap = new HashMap<String, Object>();
            networkMap.put("name", vdcNetworkName);
            networkMap.put("description", "ceate network " + vdcNetworkName);
            networkMap.put("net_mode", "inner");
            Map<String, Object> networkId = new HashMap<String, Object>();
            networkId.put("network_id", vdcNetworkId);
            List<Map<String, Object>> networkIds = new ArrayList<Map<String, Object>>();
            networkIds.add(networkId);
            networkMap.put("cloudenv_networks", networkIds);
            String url = CommonConstants.Neutron.CREATE_VDC_NETWORK;
            url = url.replaceAll(CommonConstants.Common.ID, vdcId);
            RestfulRsp response = serviceBase.post(networkMap, url);
            if (response.getStatusCode() == CommonConstants.ACCEPTED_CODE_202
                    && StringUtils.isNotBlank(response.getResponseBody()))
            {
                JSONObject networkResult = JSON.parseObject(response.getResponseBody().toString());
                if (null != networkResult)
                {
                    return networkResult.getJSONObject("vdc_network");
                }
            }
            else
            {
                logger.error("createVdcNet failed, response body = ", response.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createVdcNet error, ", e);
        }
        return new JSONObject();
    }
}
