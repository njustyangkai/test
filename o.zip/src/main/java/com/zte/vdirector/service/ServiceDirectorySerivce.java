package com.zte.vdirector.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.domain.servicedirectory.ServiceDirectoryBean;
import com.zte.vdirector.domain.servicedirectory.ServiceDirectoryDao;
import com.zte.vdirector.frame.utils.I18nUtil;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：ServiceDirectorySerivce   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 上午10:46:15 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 上午10:46:15  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Service
public class ServiceDirectorySerivce
{
    //private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private ServiceBase serviceBase;

    @Resource
    private Environment env;

    @Resource
    private ServiceDirectoryDao serviceDirectoryDao;

    @Resource
    protected I18nUtil i18nUtil;

    public List<ServiceDirectoryBean> listServiceDirectorys()
    {
        return serviceDirectoryDao.listServiceDirectorys();
    }

    public ServiceDirectoryBean getServiceDirectoryDetail(String id)
    {
        return serviceDirectoryDao.getServiceDirectoryDetail(id);
    }
}
