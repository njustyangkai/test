package com.zte.vdirector.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.domain.serviceprice.ChargeItemBean;
import com.zte.vdirector.domain.serviceprice.ServicePriceDao;
import com.zte.vdirector.frame.utils.I18nUtil;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：ServicePriceSerivce   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 上午10:46:15 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 上午10:46:15  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Service
public class ServicePriceSerivce
{
    //private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private ServiceBase serviceBase;

    @Resource
    private Environment env;

    @Resource
    private ServicePriceDao servicePriceDao;

    @Resource
    protected I18nUtil i18nUtil;

    public List<ChargeItemBean> getChargeItemList(String serviceDirectoryId)
    {
        return servicePriceDao.getChargeItemList(serviceDirectoryId);
    }

    /**
     * 递归获取计费项的子计费项
     * (过滤不能定价的项，例如：操作系统，只返回其子项。子项名称前加上父项使用"-"连接符连接)
     * @param itemList 计费项
     * @return 子计费项
     */
    public List<ChargeItemBean> recursionChargeItems(List<ChargeItemBean> itemList)
    {
        List<ChargeItemBean> resultList = new ArrayList<ChargeItemBean>();
        if (null != itemList && !itemList.isEmpty())
        {
            for (ChargeItemBean item : itemList)
            {
                // 非叶子节点才查询子项
                if (item.getIsleaf() == 0)
                {
                    List<ChargeItemBean> subItemList = servicePriceDao.getChargeItemListByParentId(item.getId());
                    if (null != subItemList && !subItemList.isEmpty())
                    {
                        List<ChargeItemBean> newSubItemList = new ArrayList<ChargeItemBean>();
                        for (ChargeItemBean subItem : subItemList)
                        {
                            ChargeItemBean newSubItem = subItem.clone();
                            newSubItem.setName(item.getName() + "-" + subItem.getName());
                            newSubItemList.add(newSubItem);
                        }
                        resultList.addAll(recursionChargeItems(newSubItemList));
                    }
                }
                else
                {
                    resultList.add(item);
                }
            }
        }
        return resultList;
    }

    /**
     * 递归获取计费项的全部子计费项
     * @param item 计费项
     * @return 计费项包含全部子计费项
     */
    public void recursionChargeItems(ChargeItemBean item)
    {
        // 非叶子节点才查询子项
        if (null != item && item.getIsleaf() == 0)
        {
            List<ChargeItemBean> subItemList = servicePriceDao.getChargeItemListByParentId(item.getId());
            if (null != subItemList && !subItemList.isEmpty())
            {
                item.setChildren(subItemList);
                for (ChargeItemBean subItem : subItemList)
                {
                    recursionChargeItems(subItem);
                }
            }
        }
    }

    public List<ChargeItemBean> getChargeItemListByParentId(String parentId)
    {
        return servicePriceDao.getChargeItemListByParentId(parentId);
    }

    public boolean updateChargeItemPrice(ChargeItemBean chargeItem)
    {
        return servicePriceDao.updateChargeItemPrice(chargeItem);
    }
}
