/**
 * 
 */
package com.zte.vdirector.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zte.vdirector.api.ResourceApi;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.volume.Volume;
import com.zte.vdirector.domain.volume.Volumes;
import com.zte.vdirector.frame.constants.CommonConstants;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Operate  
 * </p>  
 * <p>   
 * 类名称：ResourceService   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10138528   
 * </p>  
 * <p>  
 * 创建时间：2016-11-4 下午6:47:05 
 * </p>  
 * <p>    
 * 修改人：10138528  
 * </p>  
 * <p>  
 * 修改时间：2016-11-4 下午6:47:05  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Service
public class ResourceService
{
    public Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private AuthService authService;

    @Resource
    private ResourceApi resourceApi;

    public JSONArray getVms(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        try
        {
            Map<String, String> authMap = authService.getAuthInfoMap(cloudEnvInfo);
            String url = authMap.get(CommonConstants.Nova.COMPUTE) + CommonConstants.Nova.SERVERS_DETAIL;
            if (allTenants)
            {
                url += "?all_tenants=True";
            }

            RestfulRsp rsp = resourceApi.get(url, AuthService.getHeader(authMap), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("servers");
            }
            else
            {
                logger.error("getVms faild, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getVms error, ", e);
            return new JSONArray();
        }
    }

    public List<Volume> getVolumes(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        try
        {
            Map<String, String> authMap = authService.getAuthInfoMap(cloudEnvInfo);
            String url = authMap.get(CommonConstants.Cinder.VOLUMEV2) + CommonConstants.Cinder.VOLUMES_DETAIL;
            if (allTenants)
            {
                url += "?all_tenants=True";
            }

            RestfulRsp rsp = resourceApi.get(url, AuthService.getHeader(authMap), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                Volumes volumes = JSON.parseObject(rsp.getResponseBody(), Volumes.class);
                return volumes.getVolumes();
            }
            else
            {
                logger.error("getVolumes faild, response body = ", rsp.getResponseBody());
                return new ArrayList<Volume>();
            }
        }
        catch (Exception e)
        {
            logger.error("getVolumes error, ", e);
            return new ArrayList<Volume>();
        }
    }

    public JSONArray getImages(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        try
        {
            Map<String, String> authMap = authService.getAuthInfoMap(cloudEnvInfo);
            String url = authMap.get(CommonConstants.Glance.IMAGE) + CommonConstants.Glance.IMAGES;
            if (allTenants)
            {
                url += "?all_tenants=True";
            }

            RestfulRsp rsp = resourceApi.get(url, AuthService.getHeader(authMap), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("images");
            }
            else
            {
                logger.error("getImages faild, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getImages error, ", e);
            return new JSONArray();
        }
    }

    public JSONArray getFlavors(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        try
        {
            Map<String, String> authMap = authService.getAuthInfoMap(cloudEnvInfo);
            String url = authMap.get(CommonConstants.Nova.COMPUTE) + CommonConstants.Nova.FLAVORS_DETAIL;
            if (allTenants)
            {
                url += "?all_tenants=True";
            }

            RestfulRsp rsp = resourceApi.get(url, AuthService.getHeader(authMap), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("flavors");
            }
            else
            {
                logger.error("getFlavors faild, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getFlavors error, ", e);
            return new JSONArray();
        }
    }

    public JSONArray getFloatingIps(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        try
        {
            Map<String, String> authMap = authService.getAuthInfoMap(cloudEnvInfo);
            String url = authMap.get(CommonConstants.Neutron.NETWORK) + CommonConstants.Neutron.FLOATING_IPS;
            if (allTenants)
            {
                url += "?all_tenants=True";
            }

            RestfulRsp rsp = resourceApi.get(url, AuthService.getHeader(authMap), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("floatingips");
            }
            else
            {
                logger.error("getFloatingIps faild, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getFloatingIps error, ", e);
            return new JSONArray();
        }
    }

    public JSONArray getPrivateIps(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        try
        {
            Map<String, String> authMap = authService.getAuthInfoMap(cloudEnvInfo);
            String url = authMap.get(CommonConstants.Neutron.NETWORK) + CommonConstants.Neutron.PORTS;
            if (allTenants)
            {
                url += "?all_tenants=True";
            }

            RestfulRsp rsp = resourceApi.get(url, AuthService.getHeader(authMap), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("ports");
            }
            else
            {
                logger.error("getPrivateIps faild, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getPrivateIps error, ", e);
            return new JSONArray();
        }
    }

    public JSONArray getVrs(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        try
        {
            Map<String, String> authMap = authService.getAuthInfoMap(cloudEnvInfo);
            String url = authMap.get(CommonConstants.Neutron.NETWORK) + CommonConstants.Neutron.ROUTERS;
            if (allTenants)
            {
                url += "?all_tenants=True";
            }
            else
            {
                url += "?tenant_id=" + cloudEnvInfo.getTenantId();
            }

            RestfulRsp rsp = resourceApi.get(url, AuthService.getHeader(authMap), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("routers");
            }
            else
            {
                logger.error("getVrs faild, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getVrs error, ", e);
            return new JSONArray();
        }
    }

    public JSONArray getVfws(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        try
        {
            Map<String, String> authMap = authService.getAuthInfoMap(cloudEnvInfo);
            String url = authMap.get(CommonConstants.Neutron.NETWORK) + CommonConstants.Neutron.FIREWALLS;
            if (allTenants)
            {
                url += "?all_tenants=True";
            }
            else
            {
                url += "?tenant_id=" + cloudEnvInfo.getTenantId();
            }

            RestfulRsp rsp = resourceApi.get(url, AuthService.getHeader(authMap), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("firewalls");
            }
            else
            {
                logger.error("getVfws faild, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getVfws error, ", e);
            return new JSONArray();
        }
    }

    public JSONArray getVlbs(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        try
        {
            Map<String, String> authMap = authService.getAuthInfoMap(cloudEnvInfo);
            String url = authMap.get(CommonConstants.Neutron.NETWORK) + CommonConstants.Neutron.LOADBALANCES;
            if (allTenants)
            {
                url += "?all_tenants=True";
            }
            else
            {
                url += "?tenant_id=" + cloudEnvInfo.getTenantId();
            }

            RestfulRsp rsp = resourceApi.get(url, AuthService.getHeader(authMap), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject resources = JSON.parseObject(rsp.getResponseBody());
                return resources.getJSONArray("loadbalancers");
            }
            else
            {
                logger.error("getVlbs faild, response body = ", rsp.getResponseBody());
                return new JSONArray();
            }
        }
        catch (Exception e)
        {
            logger.error("getVlbs error, ", e);
            return new JSONArray();
        }
    }
}
