/**
 * 
 */
package com.zte.vdirector.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.CloudEnvs;
import com.zte.vdirector.frame.constants.CommonConstants;

/**
 * <p>
 * 版权所有：中兴通讯股份有限公司
 * </p>
 * <p>
 * 项目名称：Operate
 * </p>
 * <p>
 * 类名称：OrgService
 * </p>
 * <p>
 * 类描述：
 * </p>
 * <p>
 * 创建人：10138528
 * </p>
 * <p>
 * 创建时间：2016-11-2 下午6:27:01
 * </p>
 * <p>
 * 修改人：10138528
 * </p>
 * <p>
 * 修改时间：2016-11-2 下午6:27:01
 * </p>
 * <p>
 * 修改备注：
 * </p>
 * 
 * @version 1.0
 * 
 */
@Service
public class OrgService
{
    private Logger logger = Logger.getLogger(OrgService.class);

    @Resource
    private ServiceBase serviceBase;

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getOrgs()
    {
        try
        {
            RestfulRsp response = serviceBase.get(CommonConstants.Url.GET_ORGS);
            if (StringUtils.isNotBlank(response.getResponseBody()))
            {
                List<Map<String, Object>> orgs = JSON.parseObject(response.getResponseBody().toString(),
                        new ArrayList<Map<String, Object>>().getClass());
                if (null != orgs)
                {
                    return orgs;
                }
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get orgs", e);
        }
        return new ArrayList<Map<String, Object>>();
    }

    public JSONArray getVdcsInOrg(String orgId)
    {
        try
        {
            RestfulRsp response = serviceBase.get(CommonConstants.Url.GET_VDCS.replaceAll(
                    CommonConstants.Common.ORG_ID, orgId));
            if (StringUtils.isNotBlank(response.getResponseBody()))
            {
                JSONArray vdcs = JSON.parseObject(response.getResponseBody().toString()).getJSONArray("vdcIds");
                if (null != vdcs)
                {
                    return vdcs;
                }
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get vdcs", e);
        }
        return new JSONArray();
    }

    public Map<String, JSONObject> getProjectVdcRelInOrg(String orgId)
    {
        Map<String, JSONObject> projectVdcRel = new HashMap<String, JSONObject>();
        try
        {
            RestfulRsp response = serviceBase.get(CommonConstants.Url.ORG_PROJECT_LIST.replaceAll(
                    CommonConstants.Common.ORG_ID, orgId));
            if (response.getStatusCode() == CommonConstants.SUCCESS_CODE_200
                    && StringUtils.isNotBlank(response.getResponseBody()))
            {
                JSONArray projects = JSON.parseArray(response.getResponseBody().toString());
                {
                    if (null != projects)
                    {
                        for (Object temp : projects)
                        {
                            if (null != temp)
                            {
                                JSONObject project = (JSONObject) temp;
                                if (project.containsKey("id"))
                                {
                                    JSONArray vdcs = getVdcsInProject(project.getString("id"));
                                    if (null != vdcs)
                                    {
                                        for (Object tempVdc : vdcs)
                                        {
                                            JSONObject vdc = (JSONObject) tempVdc;
                                            projectVdcRel.put(vdc.getString("id"), project);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get vdcs", e);
        }
        return projectVdcRel;
    }

    public JSONArray getVdcsInProject(String projectId)
    {
        try
        {
            RestfulRsp response = serviceBase.get(CommonConstants.Url.GET_VDCS_IN_PROJECT.replaceAll(
                    CommonConstants.Common.PROJECT_ID, projectId)
                    .replaceAll(CommonConstants.Common.BIND_STATUS, "bind"));
            if (StringUtils.isNotBlank(response.getResponseBody()))
            {
                JSONArray vdcs = JSON.parseArray(response.getResponseBody().toString());
                if (null != vdcs)
                {
                    return vdcs;
                }
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get vdcs", e);
        }
        return new JSONArray();
    }

    public String getProcjectId(String orgId, String projectName)
    {
        try
        {
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("type", orgId);
            params.put("projectName", projectName);
            RestfulRsp response = serviceBase.post(params, CommonConstants.Url.GET_PROJECT_ID);
            if (StringUtils.isNotBlank(response.getResponseBody()))
            {
                String projectId = JSON.parseObject(response.getResponseBody().toString()).getString("projectId");
                if (StringUtils.isNotBlank(projectId))
                {
                    return projectId;
                }
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get vdcs", e);
        }
        return "";
    }

    public JSONObject getVdcInfo(String vdcId)
    {
        try
        {
            String uri = CommonConstants.Url.VDC_DETAIL;
            uri = uri.replaceAll("\\{id\\}", vdcId);
            RestfulRsp rsp = serviceBase.get(uri);
            String rspBody = rsp.getResponseBody();
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject vdc = JSON.parseObject(rspBody);
                if (vdc == null)
                {
                    logger.error("getVdcInfo failed, response body is null");
                }
                return vdc.getJSONObject("vdcs");
            }
            else
            {
                logger.error("getVdcInfo failed, response body = " + rspBody);
            }
        }
        catch (Exception e)
        {
            logger.error("getVdcInfo error:", e);
        }
        return null;
    }

    public List<CloudEnvInfo> getCloudEnvList(String vdcId, String tenantId)
    {
        try
        {
            String uri = CommonConstants.Url.VDC_ENVS_URI;
            uri = uri.replaceAll("\\{id\\}", vdcId);
            if (StringUtils.isNotBlank(tenantId))
            {
                uri = uri + "?tenantId=" + tenantId;
            }
            RestfulRsp rsp = serviceBase.get(uri);
            String rspBody = rsp.getResponseBody();
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                CloudEnvs cloudEnvs = JSON.parseObject(rspBody, CloudEnvs.class);
                List<CloudEnvInfo> list = cloudEnvs.getTenantEnvs();
                if (list == null)
                {
                    logger.error("getDcs failed, response body is null");
                }
                return list;
            }
            else
            {
                logger.error("getCloudEnvList failed, response body = " + rspBody);
                return new ArrayList<CloudEnvInfo>();
            }
        }
        catch (Exception e)
        {
            logger.error("getCloudEnvList error:", e);
            return new ArrayList<CloudEnvInfo>();
        }
    }
}
