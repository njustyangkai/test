/**
 * 
 */
package com.zte.vdirector.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.openstack.OperateApI;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.auth.AccessBean;
import com.zte.vdirector.domain.firewall.Firewall;
import com.zte.vdirector.domain.firewall.FirewallPolicy;
import com.zte.vdirector.domain.firewall.FirewallPolicyWrapper;
import com.zte.vdirector.domain.firewall.FirewallPolicys;
import com.zte.vdirector.domain.firewall.FirewallRule;
import com.zte.vdirector.domain.firewall.FirewallRuleWrapper;
import com.zte.vdirector.domain.firewall.FirewallRules;
import com.zte.vdirector.domain.firewall.FirewallWrapper;
import com.zte.vdirector.domain.firewall.Firewalls;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.utils.Utils;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：FirewallService   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年11月7日 下午8:19:55 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年11月7日 下午8:19:55  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Service
public class FirewallService
{
    public Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private OperateApI operateApI;

    @Resource
    private AuthService authService;

    @Resource
    private ServiceBase serviceBase;

    @Resource
    private CommonService commonService;

    public List<Firewall> getFirewalls(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<Firewall>();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALLS;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                Firewalls firewalls = JSON.parseObject(rsp.getResponseBody(), Firewalls.class);
                return firewalls.getFirewalls();
            }
            else
            {
                logger.error("getFirewalls failed, response body = ", rsp.getResponseBody());
                return new ArrayList<Firewall>();
            }
        }
        catch (Exception e)
        {
            logger.error("getFirewalls error, ", e);
            return new ArrayList<Firewall>();
        }
    }

    public RestfulRsp deleteFirewall(CloudEnvInfo cloudEnvInfo, String firewallId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALLS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLID, firewallId);

        RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            FirewallWrapper firewallWrapper = JSON.parseObject(rsp.getResponseBody(), FirewallWrapper.class);
            Firewall firewall = firewallWrapper.getFirewall();
            if (null != firewall)
            {
                List<String> routerIds = firewall.getRouterIds();
                if (null != routerIds && !routerIds.isEmpty())
                {
                    firewall.setRouterIds(new ArrayList<String>());
                    firewall.setStatus(null);
                    firewall.setId(null);
                    firewall.setTenantId(null);
                    FirewallWrapper updateFwBody = new FirewallWrapper();
                    updateFwBody.setFirewall(firewall);
                    try
                    {
                        this.updateFirewall(cloudEnvInfo, firewallId, JSON.toJSONString(updateFwBody));
                    }
                    catch (Exception e)
                    {
                        logger.error("Fail to disassociate firewall and router relation. "
                                + "Maybe system does not support currently.", e);
                    }
                }
            }
        }

        return operateApI.delete(url, Utils.getHeader(accessBean), null);
    }

    public RestfulRsp updateFirewall(CloudEnvInfo cloudEnvInfo, String firewallId, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALLS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLID, firewallId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public Firewall getFirewall(CloudEnvInfo cloudEnvInfo, String firewallId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALLS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLID, firewallId);
        RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            FirewallWrapper firewallWrapper = JSON.parseObject(rsp.getResponseBody(), FirewallWrapper.class);
            Firewall v = firewallWrapper.getFirewall();
            v.setCloudenv(cloudEnvInfo);
            return v;
        }
        else
        {
            logger.error("getFirewall failed, response body = " + rsp.getResponseBody());
            return null;
        }
    }

    public RestfulRsp createFirewall(CloudEnvInfo cloudEnvInfo, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALLS;
        return operateApI.post(url, Utils.getHeader(accessBean), body);
    }

    public List<FirewallPolicy> getPolicys(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<FirewallPolicy>();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_POLICIES;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                FirewallPolicys firewallPolicies = JSON.parseObject(rsp.getResponseBody(), FirewallPolicys.class);
                return firewallPolicies.getFirewallPolicies();
            }
            else
            {
                logger.error("getPolicys failed, response body = ", rsp.getResponseBody());
                return new ArrayList<FirewallPolicy>();
            }
        }
        catch (Exception e)
        {
            logger.error("getPolicys error, ", e);
            return new ArrayList<FirewallPolicy>();
        }
    }

    public RestfulRsp deletePolicy(CloudEnvInfo cloudEnvInfo, String policyId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_POLICIES_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLPOLICYID, policyId);
        return operateApI.delete(url, Utils.getHeader(accessBean), null);
    }

    public RestfulRsp updatePolicy(CloudEnvInfo cloudEnvInfo, String policyId, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_POLICIES_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLPOLICYID, policyId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public RestfulRsp policyInsertRule(CloudEnvInfo cloudEnvInfo, String policyId, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_POLICIES_INSERTRULE;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLPOLICYID, policyId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public RestfulRsp policyRemoveRule(CloudEnvInfo cloudEnvInfo, String policyId, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_POLICIES_REMOVERULE;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLPOLICYID, policyId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public FirewallPolicy getPolicy(CloudEnvInfo cloudEnvInfo, String policyId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_POLICIES_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLPOLICYID, policyId);
        RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            FirewallPolicyWrapper policyWrapper = JSON.parseObject(rsp.getResponseBody(), FirewallPolicyWrapper.class);
            FirewallPolicy v = policyWrapper.getFirewallPolicy();
            v.setCloudenv(cloudEnvInfo);
            return v;
        }
        else
        {
            logger.error("getPolicy failed, response body = " + rsp.getResponseBody());
            return null;
        }
    }

    public RestfulRsp createPolicy(CloudEnvInfo cloudEnvInfo, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_POLICIES;
        return operateApI.post(url, Utils.getHeader(accessBean), body);
    }

    public List<FirewallRule> getRules(CloudEnvInfo cloudEnvInfo, boolean allTenants, String policyId)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<FirewallRule>();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_RULES;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            if (StringUtils.isNotBlank(policyId))
            {
                url = url + "&firewall_policy_id=" + policyId;
            }
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                FirewallRules firewallRules = JSON.parseObject(rsp.getResponseBody(), FirewallRules.class);
                return firewallRules.getFirewallRules();
            }
            else
            {
                logger.error("getRules failed, response body = ", rsp.getResponseBody());
                return new ArrayList<FirewallRule>();
            }
        }
        catch (Exception e)
        {
            logger.error("getRules error, ", e);
            return new ArrayList<FirewallRule>();
        }
    }

    public RestfulRsp deleteRule(CloudEnvInfo cloudEnvInfo, String ruleId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_RULES_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLRULEID, ruleId);
        return operateApI.delete(url, Utils.getHeader(accessBean), null);
    }

    public RestfulRsp updateRule(CloudEnvInfo cloudEnvInfo, String ruleId, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_RULES_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLRULEID, ruleId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public FirewallRule getRule(CloudEnvInfo cloudEnvInfo, String ruleId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_RULES_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_FIREWALLRULEID, ruleId);
        RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            FirewallRuleWrapper ruleWrapper = JSON.parseObject(rsp.getResponseBody(), FirewallRuleWrapper.class);
            FirewallRule v = ruleWrapper.getRule();
            v.setCloudenv(cloudEnvInfo);
            return v;
        }
        else
        {
            logger.error("getRule failed, response body = " + rsp.getResponseBody());
            return null;
        }
    }

    public RestfulRsp createRule(CloudEnvInfo cloudEnvInfo, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.FIREWALL_RULES;
        return operateApI.post(url, Utils.getHeader(accessBean), body);
    }
}
