package com.zte.vdirector.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.servicedirectory.Vdc;
import com.zte.vdirector.domain.servicedirectory.VdcServiceDirectoryBean;
import com.zte.vdirector.domain.servicedirectory.VdcServiceDirectoryDao;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.utils.I18nUtil;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：VdcServiceDirectorySerivce   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 上午10:46:15 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 上午10:46:15  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Service
public class VdcServiceDirectorySerivce
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private ServiceBase serviceBase;

    @Resource
    private Environment env;

    @Resource
    private VdcServiceDirectoryDao vdcServiceDirectoryDao;

    @Resource
    protected I18nUtil i18nUtil;

    public List<Vdc> getVdcs()
    {
        try
        {
            RestfulRsp response = serviceBase.get(CommonConstants.Url.VDC_GET_LIST);

            String body = response.getResponseBody();
            Map<String, List<Vdc>> vdcInfo = JSON.parseObject(body, new TypeReference<Map<String, List<Vdc>>>()
            {
            });
            List<Vdc> vdcs = vdcInfo.get("vdcs");
            return vdcs;
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            return null;
        }
    }

    /**
     * vdclist转换为map
     * @return
     */
    public Map<String, Vdc> getVdcsMap()
    {
        List<Vdc> allVds = getVdcs();
        Map<String, Vdc> allVdcMap = new HashMap<String, Vdc>();

        if (allVds != null && allVds.size() > 0)
        {
            for (Vdc vdc : allVds)
            {
                allVdcMap.put(vdc.getId(), vdc);
            }
        }
        return allVdcMap;
    }

    public List<VdcServiceDirectoryBean> listVdcServiceDirectorys()
    {
        return vdcServiceDirectoryDao.listVdcServiceDirectorys();
    }

    public VdcServiceDirectoryBean getVdcServiceDirectory(String vdcId)
    {
        return vdcServiceDirectoryDao.getVdcServiceDirectory(vdcId);
    }

    public boolean addVdcServiceDirectory(VdcServiceDirectoryBean vdcSerDir)
    {
        return vdcServiceDirectoryDao.addVdcServiceDirectory(vdcSerDir);
    }

    public boolean updateVdcServiceDirectory(VdcServiceDirectoryBean vdcSerDir)
    {
        return vdcServiceDirectoryDao.updateVdcServiceDirectory(vdcSerDir);
    }

    public boolean deleteVdcServiceDirectory(String vdcId)
    {
        return vdcServiceDirectoryDao.deleteVdcServiceDirectory(vdcId);
    }
}
