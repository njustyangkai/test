/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月20日      下午2:42:20
*/
package com.zte.vdirector.service;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.ticket.TicketBean;
import com.zte.vdirector.domain.ticket.TicketDao;
import com.zte.vdirector.domain.ticket.TicketDeviceRestBean;
import com.zte.vdirector.domain.ticket.TicketNetworkBean;
import com.zte.vdirector.domain.ticket.TicketNetworkRestBean;
import com.zte.vdirector.domain.ticket.TicketProgressBean;
import com.zte.vdirector.domain.ticket.TicketResourceBean;
import com.zte.vdirector.domain.ticket.TicketRestBean;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.utils.I18nUtil;
import com.zte.vdirector.frame.utils.excel.Common;
import com.zte.vdirector.frame.utils.excel.Util;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */
@Service
public class TicketSerivce
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private ServiceBase serviceBase;

    @Resource
    private Environment env;

    @Resource
    private TicketDao ticketDao;

    @Resource
    protected I18nUtil i18nUtil;

    /**
     * 
     * @param file
     * @param projectName
     * @param projectId
     * @return
     * @throws Exception e
     */
    public TicketRestBean readExcel(MultipartFile file, String projectName, String projectId) throws Exception

    {

        if (file == null || Common.EMPTY.equals(file.getOriginalFilename()))
        {
            throw new Exception("FileError");
        }
        else
        {
            String postfix = Util.getPostfix(file.getOriginalFilename());
            if (!Common.EMPTY.equals(postfix))
            {
                if (Common.OFFICE_EXCEL_2003_POSTFIX.equals(postfix))
                {
                    return readXls(file, projectName, projectId);
                }
                else if (Common.OFFICE_EXCEL_2010_POSTFIX.equals(postfix))
                {
                    return readXlsx(file, projectName, projectId);
                }
            }
            else
            {
                throw new Exception("FileError");
            }
        }
        throw new Exception("FileError");

    }

    /**
     * 
     * @param file
     * @param projectName
     * @param projectId
     * @return
     * @throws Exception e
     */
    @SuppressWarnings("resource")
    public TicketRestBean readXlsx(MultipartFile file, String projectName, String projectId) throws Exception
    {

        InputStream is = file.getInputStream();
        XSSFWorkbook xssfWorkbook = new XSSFWorkbook(is);
        TicketRestBean ticketRestBean = new TicketRestBean();
        //sheet1
        XSSFSheet xssfSheet = xssfWorkbook.getSheetAt(0);
        if (xssfSheet == null)
        {
            throw new Exception("excelEmpty");
        }
        XSSFRow xssfRow1 = xssfSheet.getRow(1);
        if (xssfRow1 != null)
        {
            //申请人
            XSSFCell username = xssfRow1.getCell(1);
            ticketRestBean.setApplicant(username.getStringCellValue());
            //申请单位
            XSSFCell appCompanyTmp = xssfRow1.getCell(3);
            String appCompany = changeRestString(getValue(appCompanyTmp));
            ticketRestBean.setAppCompany(appCompany);
        }

        XSSFRow xssfRow2 = xssfSheet.getRow(2);
        if (xssfRow2 != null)
        {
            //申请人电话
            XSSFCell appPhoneNumTmp = xssfRow2.getCell(1);
            String appPhoneNum = changeRestString(getValue(appPhoneNumTmp));
            ticketRestBean.setAppPhoneNum(appPhoneNum);
            //申请人邮件
            XSSFCell appEmailTmp = xssfRow2.getCell(3);
            String appEmail = changeRestString(getValue(appEmailTmp));
            ticketRestBean.setAppEmail(appEmail);
        }

        XSSFRow xssfRow3 = xssfSheet.getRow(3);
        if (xssfRow3 != null)
        {
            //申请日期
            XSSFCell appDateTmp = xssfRow3.getCell(1);
            String appDate = changeRestString(getValue(appDateTmp));
            ticketRestBean.setAppDate(appDate);
            //申请类型
            XSSFCell appTypeTmp = xssfRow3.getCell(3);
            String appType = changeRestString(getValue(appTypeTmp));
            ticketRestBean.setAppType(appType);
        }

        XSSFRow xssfRow4 = xssfSheet.getRow(4);
        if (xssfRow4 != null)
        {
            //申请日期
            XSSFCell appNumberTmp = xssfRow4.getCell(1);
            String appNumber = changeRestString(getValue(appNumberTmp));
            ticketRestBean.setAppNumber(appNumber);

        }

        XSSFRow xssfRow5 = xssfSheet.getRow(5);
        if (xssfRow5 != null)
        {
            //是否工程
            XSSFCell isProjectTmp = xssfRow5.getCell(1);
            String isProject = changeRestString(getValue(isProjectTmp));
            ticketRestBean.setIsProject(isProject);
            //工程编号
            XSSFCell proNumberTmp = xssfRow5.getCell(3);
            String proNumber = changeRestString(getValue(proNumberTmp));
            ticketRestBean.setProNumber(proNumber);
        }

        XSSFRow xssfRow6 = xssfSheet.getRow(6);
        if (xssfRow6 != null)
        {
            //金银铜域
            XSSFCell gscFieldTmp = xssfRow6.getCell(1);
            String gscField = changeRestString(getValue(gscFieldTmp));
            ticketRestBean.setGscField(gscField);
        }

        XSSFRow xssfRow7 = xssfSheet.getRow(7);
        if (xssfRow7 != null)
        {
            //平台名称
            XSSFCell platformNameTmp = xssfRow7.getCell(1);
            String platformName = changeRestString(getValue(platformNameTmp));
            ticketRestBean.setPlatformName(platformName);
        }

        String uuidTmp = UUID.randomUUID().toString();

        ticketRestBean.setAppId(uuidTmp);
        //平台代号
        XSSFRow xssfRow8 = xssfSheet.getRow(8);
        if (xssfRow8 != null)
        {
            XSSFCell platformCode = xssfRow8.getCell(1);
            String vdcNameExcel = changeRestString(getValue(platformCode));
            ticketRestBean.setPlatformCode(vdcNameExcel);
        }
        XSSFRow xssfRow9 = xssfSheet.getRow(9);
        if (xssfRow9 != null)
        {
            //维护单位
            XSSFCell maintainCompanyTmp = xssfRow9.getCell(1);
            String maintainCompany = changeRestString(getValue(maintainCompanyTmp));
            ticketRestBean.setMaintainCompany(maintainCompany);
            //联系人员
            XSSFCell contactsTmp = xssfRow9.getCell(3);
            String contacts = changeRestString(getValue(contactsTmp));
            ticketRestBean.setContacts(contacts);
        }

        XSSFRow xssfRow10 = xssfSheet.getRow(10);
        if (xssfRow10 != null)
        {
            //联系人电话
            XSSFCell contPhoneNumTmp = xssfRow10.getCell(1);
            String contPhoneNum = changeRestString(getValue(contPhoneNumTmp));
            ticketRestBean.setContPhoneNum(contPhoneNum);
            //联系人邮件
            XSSFCell contEmailTmp = xssfRow10.getCell(3);
            String contEmail = changeRestString(getValue(contEmailTmp));
            ticketRestBean.setContEmail(contEmail);

        }

        XSSFRow xssfRow11 = xssfSheet.getRow(11);
        if (xssfRow11 != null)
        {
            //平台主要服务项目
            XSSFCell serviceProjectTmp = xssfRow11.getCell(1);
            String serviceProject = changeRestString(getValue(serviceProjectTmp));
            ticketRestBean.setServiceProject(serviceProject);

        }

        //sheet2
        XSSFSheet xssfSheet2 = xssfWorkbook.getSheetAt(1);
        if (xssfSheet2 == null)
        {
            throw new Exception("sheet2Empty");
        }

        // Read the Row
        List<TicketDeviceRestBean> deviceList = new ArrayList<TicketDeviceRestBean>();
        for (int rowNum = 10; rowNum <= xssfSheet2.getLastRowNum(); rowNum++)
        {
            XSSFRow xssfRow = xssfSheet2.getRow(rowNum);
            if (xssfRow != null)
            {
                TicketDeviceRestBean ticketDeviceRestBean = new TicketDeviceRestBean();
                XSSFCell appType = xssfRow.getCell(2);
                XSSFCell deviceCode = xssfRow.getCell(1);
                XSSFCell deviceCpuNew = xssfRow.getCell(6);
                XSSFCell deviceHardDiskNew = xssfRow.getCell(8);
                XSSFCell deviceMemoryNew = xssfRow.getCell(7);
                XSSFCell deviceType = xssfRow.getCell(3);
                XSSFCell netCn2New = xssfRow.getCell(12);
                XSSFCell netEniNew = xssfRow.getCell(10);
                XSSFCell netInternetNew = xssfRow.getCell(11);
                XSSFCell netbPlaneNew = xssfRow.getCell(9);
                XSSFCell osVersion = xssfRow.getCell(24);
                XSSFCell remark = xssfRow.getCell(26);
                XSSFCell serverFunction = xssfRow.getCell(4);
                XSSFCell vmName = xssfRow.getCell(5);

                ticketDeviceRestBean.setAppType(changeRestString(getValue(appType)));
                ticketDeviceRestBean.setDeviceCode(changeRestString(getValue(deviceCode)));
                ticketDeviceRestBean.setDeviceCpuNew(changeRestString(getValue(deviceCpuNew), "CPU"));
                ticketDeviceRestBean.setDeviceHardDiskNew(changeRestString(getValue(deviceHardDiskNew), "HardDisk"));
                ticketDeviceRestBean.setDeviceMemoryNew(changeRestString(getValue(deviceMemoryNew), "Memory"));
                ticketDeviceRestBean.setDeviceType(changeRestString(getValue(deviceType)));
                ticketDeviceRestBean.setNetCn2New(changeRestString(getValue(netCn2New), "BOOLEAN"));
                ticketDeviceRestBean.setNetEniNew(changeRestString(getValue(netEniNew), "BOOLEAN"));
                ticketDeviceRestBean.setNetInternetNew(changeRestString(getValue(netInternetNew), "BOOLEAN"));
                ticketDeviceRestBean.setNetbPlaneNew(changeRestString(getValue(netbPlaneNew), "BOOLEAN"));
                ticketDeviceRestBean.setOsVersion(changeRestString(getValue(osVersion)));
                ticketDeviceRestBean.setRemark(changeRestString(getValue(remark)));
                ticketDeviceRestBean.setServerFunction(changeRestString(getValue(serverFunction)));
                ticketDeviceRestBean.setVmName(changeRestString(getValue(vmName)));

                deviceList.add(ticketDeviceRestBean);

            }

        }
        ticketRestBean.setDevices(deviceList);

        //sheet2
        XSSFSheet xssfSheet3 = xssfWorkbook.getSheetAt(2);
        if (xssfSheet3 == null)
        {
            throw new Exception("sheet3Empty");
        }

        String networkType = "";
        List<TicketNetworkRestBean> networkList = new ArrayList<TicketNetworkRestBean>();

        // Read the Row
        for (int rowNum = 1; rowNum <= xssfSheet3.getLastRowNum(); rowNum++)
        {
            XSSFRow xssfRow = xssfSheet3.getRow(rowNum);
            if (xssfRow != null)
            {
                XSSFCell cellDesc = xssfRow.getCell(0);

                String cellString = getValue(cellDesc);

                if (StringUtils.isBlank(cellString) || "序号".equals(cellString.trim()))
                {
                    continue;
                }
                else if (i18nUtil.getMessage("ticker.type.eni").equals(cellString.trim()))
                {
                    networkType = "ENI";
                }
                else if (i18nUtil.getMessage("ticker.type.b").equals(cellString.trim()))
                {
                    networkType = "B";
                }
                else if (i18nUtil.getMessage("ticker.type.cn2").equals(cellString.trim()))
                {
                    networkType = "CN2";
                }
                else if (i18nUtil.getMessage("ticker.type.internet").equals(cellString.trim()))
                {
                    networkType = "Internet";
                }
                else
                {
                    //读取数据
                    TicketNetworkRestBean ticketNetworkRestBean = new TicketNetworkRestBean();
                    ticketNetworkRestBean.setType(networkType);
                    XSSFCell description = null;
                    XSSFCell id = null;
                    XSSFCell networkfn = null;
                    XSSFCell vmWork = null;
                    XSSFCell vmName = null;
                    XSSFCell subnet = null;
                    if ("ENI".equals(networkType) || "CN2".equals(networkType) || "Internet".equals(networkType))
                    {
                        description = xssfRow.getCell(4);
                        id = xssfRow.getCell(0);
                        networkfn = xssfRow.getCell(3);
                        vmWork = xssfRow.getCell(1);
                        vmName = xssfRow.getCell(2);
                    }
                    else if ("B".equals(networkType))
                    {
                        description = xssfRow.getCell(5);
                        id = xssfRow.getCell(0);
                        networkfn = xssfRow.getCell(4);
                        vmWork = xssfRow.getCell(1);
                        vmName = xssfRow.getCell(2);
                        subnet = xssfRow.getCell(3);
                    }

                    if (description != null)
                    {
                        ticketNetworkRestBean.setDescription(changeRestString(getValue(description)));
                    }

                    if (subnet != null)
                    {
                        ticketNetworkRestBean.setSubnet(changeRestString(getValue(subnet)));
                    }

                    if (id != null)
                    {
                        ticketNetworkRestBean.setId(changeRestString(getValue(id)));
                    }

                    if (networkfn != null)
                    {
                        ticketNetworkRestBean.setNetworkfn(changeRestString(getValue(networkfn)));
                    }

                    if (vmName != null)
                    {
                        ticketNetworkRestBean.setVmName(changeRestString(getValue(vmName)));
                    }

                    if (vmWork != null)
                    {
                        ticketNetworkRestBean.setVmWork(changeRestString(getValue(vmWork)));
                    }

                    networkList.add(ticketNetworkRestBean);

                }

            }
        }
        ticketRestBean.setNetworks(networkList);

        return ticketRestBean;

    }

    @SuppressWarnings("resource")
    public TicketRestBean readXls(MultipartFile file, String projectName, String projectId) throws Exception
    {

        InputStream is = file.getInputStream();
        HSSFWorkbook hssfWorkbook = new HSSFWorkbook(is);
        TicketRestBean ticketRestBean = new TicketRestBean();
        //sheet1
        HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(0);
        if (hssfSheet == null)
        {
            throw new Exception("excelEmpty");
        }
        // Read the Row

        HSSFRow hssfRow1 = hssfSheet.getRow(1);
        if (hssfRow1 != null)
        {
            //申请人
            HSSFCell username = hssfRow1.getCell(1);
            ticketRestBean.setApplicant(username.getStringCellValue());
            //申请单位
            HSSFCell appCompanyTmp = hssfRow1.getCell(3);
            String appCompany = changeRestString(getValue(appCompanyTmp));
            ticketRestBean.setAppCompany(appCompany);
        }

        HSSFRow hssfRow2 = hssfSheet.getRow(2);
        if (hssfRow2 != null)
        {
            //申请人电话
            HSSFCell appPhoneNumTmp = hssfRow2.getCell(1);
            String appPhoneNum = changeRestString(getValue(appPhoneNumTmp));
            ticketRestBean.setAppPhoneNum(appPhoneNum);
            //申请人邮件
            HSSFCell appEmailTmp = hssfRow2.getCell(3);
            String appEmail = changeRestString(getValue(appEmailTmp));
            ticketRestBean.setAppEmail(appEmail);
        }

        HSSFRow hssfRow3 = hssfSheet.getRow(3);
        if (hssfRow3 != null)
        {
            //申请日期
            HSSFCell appDateTmp = hssfRow3.getCell(1);
            String appDate = changeRestString(getValue(appDateTmp));
            ticketRestBean.setAppDate(appDate);
            //申请类型
            HSSFCell appTypeTmp = hssfRow3.getCell(3);
            String appType = changeRestString(getValue(appTypeTmp));
            ticketRestBean.setAppType(appType);
        }

        HSSFRow hssfRow4 = hssfSheet.getRow(4);
        if (hssfRow4 != null)
        {
            //申请单号
            HSSFCell appNumberTmp = hssfRow4.getCell(1);
            String appNumber = changeRestString(getValue(appNumberTmp));

            TicketBean ticketBean = ticketDao.getTicketFlag(appNumber);

            if (ticketBean != null)
            {
                throw new Exception("ExistTicketNum");
            }

            ticketRestBean.setAppNumber(appNumber);

        }

        HSSFRow hssfRow5 = hssfSheet.getRow(5);
        if (hssfRow5 != null)
        {
            //是否工程
            HSSFCell isProjectTmp = hssfRow5.getCell(1);
            String isProject = changeRestString(getValue(isProjectTmp));
            ticketRestBean.setIsProject(isProject);
            //工程编号
            HSSFCell proNumberTmp = hssfRow5.getCell(3);
            String proNumber = changeRestString(getValue(proNumberTmp));
            ticketRestBean.setProNumber(proNumber);
        }

        HSSFRow hssfRow6 = hssfSheet.getRow(6);
        if (hssfRow6 != null)
        {
            //金银铜域
            HSSFCell gscFieldTmp = hssfRow6.getCell(1);
            String gscField = changeRestString(getValue(gscFieldTmp));
            ticketRestBean.setGscField(gscField);
        }

        HSSFRow hssfRow7 = hssfSheet.getRow(7);
        if (hssfRow7 != null)
        {
            //平台名称
            HSSFCell platformNameTmp = hssfRow7.getCell(1);
            String platformName = changeRestString(getValue(platformNameTmp));
            ticketRestBean.setPlatformName(platformName);
        }

        String uuidTmp = UUID.randomUUID().toString();

        ticketRestBean.setAppId(uuidTmp);
        //平台代号
        HSSFRow hssfRow8 = hssfSheet.getRow(8);
        if (hssfRow8 != null)
        {
            HSSFCell platformCode = hssfRow8.getCell(1);
            String vdcNameExcel = changeRestString(getValue(platformCode));
            ticketRestBean.setPlatformCode(vdcNameExcel);
        }

        HSSFRow hssfRow9 = hssfSheet.getRow(9);
        if (hssfRow9 != null)
        {
            //维护部门
            HSSFCell maintainDeptTmp = hssfRow9.getCell(1);
            String maintainDept = changeRestString(getValue(maintainDeptTmp));

            ticketRestBean.setMaintainDept(maintainDept);

        }

        HSSFRow hssfRow10 = hssfSheet.getRow(10);
        if (hssfRow10 != null)
        {
            //维护单位
            HSSFCell maintainCompanyTmp = hssfRow10.getCell(1);
            String maintainCompany = changeRestString(getValue(maintainCompanyTmp));

            ticketRestBean.setMaintainCompany(maintainCompany);
            //联系人电话
            HSSFCell contPhoneNumTmp = hssfRow10.getCell(3);
            String contPhoneNum = changeRestString(getValue(contPhoneNumTmp));
            ticketRestBean.setContPhoneNum(contPhoneNum);

        }

        HSSFRow hssfRow11 = hssfSheet.getRow(11);
        if (hssfRow11 != null)
        {
            //联系人员
            HSSFCell contactsTmp = hssfRow11.getCell(1);
            String contacts = changeRestString(getValue(contactsTmp));
            ticketRestBean.setContacts(contacts);
            //联系人邮件
            HSSFCell contEmailTmp = hssfRow11.getCell(3);
            String contEmail = changeRestString(getValue(contEmailTmp));
            ticketRestBean.setContEmail(contEmail);

        }

        HSSFRow hssfRow12 = hssfSheet.getRow(12);
        if (hssfRow12 != null)
        {
            //备用联系人员
            HSSFCell contactsTmp = hssfRow12.getCell(1);
            String contacts = changeRestString(getValue(contactsTmp));
            ticketRestBean.setContactsBak(contacts);

        }

        HSSFRow hssfRow13 = hssfSheet.getRow(13);
        if (hssfRow13 != null)
        {
            // 备用联系人员电话
            HSSFCell contPhoneNumTmp = hssfRow13.getCell(1);
            String contPhoneNum = changeRestString(getValue(contPhoneNumTmp));
            ticketRestBean.setContPhoneNumBak(contPhoneNum);
            //备用联系人邮件
            HSSFCell contEmailTmp = hssfRow13.getCell(3);
            String contEmail = changeRestString(getValue(contEmailTmp));
            ticketRestBean.setContEmailBak(contEmail);

        }

        HSSFRow hssfRow14 = hssfSheet.getRow(14);
        if (hssfRow14 != null)
        {
            //平台主要服务项目
            HSSFCell serviceProjectTmp = hssfRow14.getCell(1);
            String serviceProject = changeRestString(getValue(serviceProjectTmp));
            ticketRestBean.setServiceProject(serviceProject);

        }

        HSSFRow hssfRow15 = hssfSheet.getRow(15);
        if (hssfRow15 != null)
        {
            //平台主要服务项目
            HSSFCell serviceProjectTmp = hssfRow15.getCell(1);
            String serviceProject = changeRestString(getValue(serviceProjectTmp));
            ticketRestBean.setServiceProject(serviceProject);

        }
        //sheet2
        HSSFSheet hssfSheet2 = hssfWorkbook.getSheetAt(1);
        if (hssfSheet2 == null)
        {
            throw new Exception("sheet2Empty");
        }

        // Read the Row
        List<TicketDeviceRestBean> deviceList = new ArrayList<TicketDeviceRestBean>();
        for (int rowNum = 9; rowNum <= hssfSheet2.getLastRowNum(); rowNum++)
        {
            HSSFRow hssfRow = hssfSheet2.getRow(rowNum);
            if (hssfRow != null)
            {
                if (StringUtils.isBlank(getValue(hssfRow.getCell(2))))
                {
                    continue;
                }

                TicketDeviceRestBean ticketDeviceRestBean = new TicketDeviceRestBean();
                HSSFCell appType = hssfRow.getCell(2);
                HSSFCell deviceCode = hssfRow.getCell(1);
                HSSFCell deviceCpuNew = hssfRow.getCell(6);
                HSSFCell deviceHardDiskNew = hssfRow.getCell(8);
                HSSFCell deviceMemoryNew = hssfRow.getCell(7);
                HSSFCell deviceType = hssfRow.getCell(3);
                HSSFCell netCn2New = hssfRow.getCell(12);
                HSSFCell netEniNew = hssfRow.getCell(10);
                HSSFCell netInternetNew = hssfRow.getCell(11);
                HSSFCell netbPlaneNew = hssfRow.getCell(9);
                HSSFCell osVersion = hssfRow.getCell(24);
                HSSFCell remark = hssfRow.getCell(26);
                HSSFCell serverFunction = hssfRow.getCell(4);
                HSSFCell vmName = hssfRow.getCell(5);

                ticketDeviceRestBean.setAppType(changeRestString(getValue(appType)));
                ticketDeviceRestBean.setDeviceCode(changeRestString(getValue(deviceCode)));
                ticketDeviceRestBean.setDeviceCpuNew(changeRestString(getValue(deviceCpuNew), "CPU"));
                ticketDeviceRestBean.setDeviceHardDiskNew(changeRestString(getValue(deviceHardDiskNew), "HardDisk"));
                ticketDeviceRestBean.setDeviceMemoryNew(changeRestString(getValue(deviceMemoryNew), "Memory"));
                ticketDeviceRestBean.setDeviceType(changeRestString(getValue(deviceType)));
                ticketDeviceRestBean.setNetCn2New(changeRestString(getValue(netCn2New), "BOOLEAN"));
                ticketDeviceRestBean.setNetEniNew(changeRestString(getValue(netEniNew), "BOOLEAN"));
                ticketDeviceRestBean.setNetInternetNew(changeRestString(getValue(netInternetNew), "BOOLEAN"));
                ticketDeviceRestBean.setNetbPlaneNew(changeRestString(getValue(netbPlaneNew), "BOOLEAN"));
                ticketDeviceRestBean.setOsVersion(changeRestString(getValue(osVersion)));
                ticketDeviceRestBean.setRemark(changeRestString(getValue(remark)));
                ticketDeviceRestBean.setServerFunction(changeRestString(getValue(serverFunction)));
                ticketDeviceRestBean.setVmName(changeRestString(getValue(vmName)));
                ticketDeviceRestBean.setOrderId(uuidTmp);
                deviceList.add(ticketDeviceRestBean);

            }

        }
        ticketRestBean.setDevices(deviceList);

        //sheet2
        HSSFSheet hssfSheet3 = hssfWorkbook.getSheetAt(2);
        if (hssfSheet3 == null)
        {
            throw new Exception("sheet3Empty");
        }

        String networkType = "";
        List<TicketNetworkRestBean> networkList = new ArrayList<TicketNetworkRestBean>();

        // Read the Row
        for (int rowNum = 0; rowNum <= hssfSheet3.getLastRowNum(); rowNum++)
        {
            HSSFRow hssfRow = hssfSheet3.getRow(rowNum);
            if (hssfRow != null)
            {
                HSSFCell cellDesc = hssfRow.getCell(0);

                String cellString = getValue(cellDesc);

                if (StringUtils.isBlank(cellString) || "序号".equals(cellString.trim()))
                {
                    continue;
                }

                else if (i18nUtil.getMessage("ticker.type.eni").equals(cellString.trim()))
                {
                    networkType = "ENI";
                }
                else if (i18nUtil.getMessage("ticker.type.b").equals(cellString.trim()))
                {
                    networkType = "B";
                }
                else if (i18nUtil.getMessage("ticker.type.cn2").equals(cellString.trim()))
                {
                    networkType = "CN2";
                }
                else if (i18nUtil.getMessage("ticker.type.internet").equals(cellString.trim()))
                {
                    networkType = "Internet";
                }
                else
                {
                    //读取数据
                    TicketNetworkRestBean ticketNetworkRestBean = new TicketNetworkRestBean();
                    ticketNetworkRestBean.setType(networkType);
                    HSSFCell description = null;
                    HSSFCell networkfn = null;
                    HSSFCell vmWork = null;
                    HSSFCell vmName = null;
                    HSSFCell subnet = null;
                    if ("ENI".equals(networkType) || "CN2".equals(networkType) || "Internet".equals(networkType))
                    {
                        description = hssfRow.getCell(4);
                        networkfn = hssfRow.getCell(3);
                        vmWork = hssfRow.getCell(1);
                        vmName = hssfRow.getCell(2);
                    }
                    else if ("B".equals(networkType))
                    {
                        description = hssfRow.getCell(5);
                        networkfn = hssfRow.getCell(4);
                        vmWork = hssfRow.getCell(1);
                        vmName = hssfRow.getCell(2);
                        subnet = hssfRow.getCell(3);
                    }

                    if (description != null)
                    {
                        ticketNetworkRestBean.setDescription(changeRestString(getValue(description)));
                    }

                    if (subnet != null)
                    {
                        ticketNetworkRestBean.setSubnet(changeRestString(getValue(subnet)));
                    }

                    if (networkfn != null)
                    {
                        ticketNetworkRestBean.setNetworkfn(changeRestString(getValue(networkfn)));
                    }

                    if (vmName != null)
                    {
                        ticketNetworkRestBean.setVmName(changeRestString(getValue(vmName)));
                    }

                    if (vmWork != null)
                    {
                        ticketNetworkRestBean.setVmWork(changeRestString(getValue(vmWork)));
                    }
                    ticketNetworkRestBean.setOrderId(uuidTmp);

                    networkList.add(ticketNetworkRestBean);

                }

            }
        }
        ticketRestBean.setNetworks(networkList);

        return ticketRestBean;

    }

    @SuppressWarnings({ "deprecation" })
    private String getValue(XSSFCell cell)
    {
        String str = "";
        if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
        {

            DateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

            if (HSSFDateUtil.isCellDateFormatted(cell))
            {
                // 是否为日期型
                str = format.format(cell.getDateCellValue()).substring(0, 10);
            }
            else
            {
                // 是否为数值型
                double d = cell.getNumericCellValue();
                if (d - (int) d < Double.MIN_VALUE)
                {
                    // 是否为int型
                    str = Integer.toString((int) d);
                }
                else
                {
                    DecimalFormat df = new DecimalFormat("#");
                    str = df.format(cell.getNumericCellValue());
                    // 是否为double型
                    //str = Double.toString(cell.getNumericCellValue());
                }
            }

        }
        else if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING)
        {
            str = cell.getRichStringCellValue().getString();
        }
        else if (cell.getCellType() == XSSFCell.CELL_TYPE_FORMULA)
        {
            str = cell.getCellFormula();
        }
        else if (cell.getCellType() == XSSFCell.CELL_TYPE_BLANK)
        {
            str = " ";
        }
        else if (cell.getCellType() == XSSFCell.CELL_TYPE_ERROR)
        {
            str = " ";
        }
        return str;
    }

    /**
     * 
     * @param id
     * @return e
     */
    public TicketBean getTicketDetail(String id)
    {
        return ticketDao.getTicketDetail(id);
    }

    /**
     * 
     * @param appNumber
     * @return e
     */
    /*private TicketBean getTicketFlag(String appNumber)
    {
        return ticketDao.getTicketFlag(appNumber);
    }*/

    /**
     * 
     * @param appId
     * @return e
     */
    public List<TicketResourceBean> getTicketResourceList(String appId)
    {
        return ticketDao.getTicketResourceList(appId);
    }

    /**
     * 
     * @param appId
     * @return e
     */
    public List<TicketNetworkBean> getTicketNetworkList(String appId)
    {
        return ticketDao.getTicketNetworkList(appId);
    }

    @SuppressWarnings({ "deprecation" })
    private String getValue(HSSFCell cell)
    {
        String str = "";
        if (cell == null)
        {
            return str;
        }

        if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
        {

            DateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

            if (HSSFDateUtil.isCellDateFormatted(cell))
            {
                // 是否为日期型
                str = format.format(cell.getDateCellValue()).substring(0, 10);
            }
            else
            {
                // 是否为数值型
                double d = cell.getNumericCellValue();
                if (d - (int) d < Double.MIN_VALUE)
                {
                    // 是否为int型
                    str = Integer.toString((int) d);
                }
                else
                {
                    DecimalFormat df = new DecimalFormat("#");
                    str = df.format(cell.getNumericCellValue());
                    // 是否为double型
                    //str = Double.toString(cell.getNumericCellValue());
                }
            }

        }
        else if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING)
        {
            str = cell.getRichStringCellValue().getString();
        }
        else if (cell.getCellType() == HSSFCell.CELL_TYPE_FORMULA)
        {
            str = cell.getCellFormula();
        }
        else if (cell.getCellType() == HSSFCell.CELL_TYPE_BLANK)
        {
            str = " ";
        }
        else if (cell.getCellType() == HSSFCell.CELL_TYPE_ERROR)
        {
            str = " ";
        }
        return str;
    }

    private String changeRestString(String value, String... key)
    {
        if (StringUtils.isNotBlank(value))
        {
            if (key != null && key.length > 0)
            {
                if ("CPU".equals(key[0]) || "Memory".equals(key[0]) || "HardDisk".equals(key[0]))
                {
                    value = value.replaceAll(" ", "");
                    if ("CPU".equals(key[0]))
                    {
                        if (value.indexOf("CPU") > -1)
                        {
                            return value.substring(0, value.length() - 3);
                        }

                    }
                    else
                    {
                        if (value.indexOf("GB") > -1)
                        {
                            return value.substring(0, value.length() - 2);
                        }
                    }
                    return value;
                }
                else if ("BOOLEAN".equals(key[0]))
                {
                    if (i18nUtil.getMessage("common.yes").equals(value))
                    {
                        return "1";
                    }
                    else
                    {
                        return "0";
                    }
                }

            }
        }
        return value;

    }

    /**
     * 
     * @param params
     * @return e
     */
    public String uploadExcel(TicketRestBean ticketRestBean) throws Exception
    {

        RestfulRsp rep = serviceBase.post(ticketRestBean, CommonConstants.Url.LIXIANG_UPLOAD_TICKET);

        if (rep.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            return "SUCCESS";
        }
        else
        {
            logger.error(rep.getResponseBody());
            throw new Exception("uploadError");
        }

    }

    public String deleteTicket(String appId) throws Exception
    {

        String url = CommonConstants.Url.LIXIANG_DELETE_TICKET.replace("{id}", appId);
        //删除接口
        RestfulRsp rep = serviceBase.delete(url);

        if (rep.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            return "SUCCESS";
        }
        else
        {
            logger.error(rep.getResponseBody());
            throw new Exception("deleteError");
        }
    }

    /**
     * 
     * @param resourceId
     * @return
     * @throws Exception e
     */
    public String reExecute(String resourceId) throws Exception
    {

        String url = CommonConstants.Url.LIXIANG_REEXECUTE_TICKET;

        Map<String, Object> map = new HashMap<String, Object>();

        map.put("id", resourceId);
        //重新执行接口
        RestfulRsp rep = serviceBase.post(map, url);

        if (rep.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            return "SUCCESS";
        }
        else
        {
            logger.error(rep.getResponseBody());
            throw new Exception("reExecuteError");
        }
    }

    public List<TicketProgressBean> getTicketProgressList(String appId)
    {
        return ticketDao.getTicketProgressList(appId);
    }

    /**
     * 
     * @param id
     * @param status e
     */
    public void updateTicketProcess(String id, String status)
    {
        ticketDao.updateTicketProcess(id, status);
    }

    /**
     * 
     * @param projectId
     * @return e
     */
    public List<TicketBean> listTickets(String projectId, String type)
    {
        List<TicketBean> list = new ArrayList<TicketBean>();

        try
        {
            String[] projectIds = null;
            if ("ORG".equals(type))
            {
                list = ticketDao.listTicketsByOrgId(projectId);
            }
            else
            {
                projectIds = new String[1];
                projectIds[0] = projectId;
                list = ticketDao.listTickets(projectIds);
            }

        }
        catch (Exception e)
        {
            logger.error("list ticket error", e);
        }

        return list;
    }

}
