package com.zte.vdirector.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.zte.vdirector.api.AuthApi;
import com.zte.vdirector.cache.AuthCache;
import com.zte.vdirector.client.openstack.OperateApI;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.auth.Access;
import com.zte.vdirector.domain.auth.AccessBean;
import com.zte.vdirector.domain.auth.AccessWrapper;
import com.zte.vdirector.domain.auth.Auth;
import com.zte.vdirector.domain.auth.AuthWrapper;
import com.zte.vdirector.domain.auth.PasswordCredentials;
import com.zte.vdirector.domain.auth.ServiceCatalog;
import com.zte.vdirector.domain.auth.Token;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.utils.Utils;

@Service
public class AuthService
{
    @Resource
    private OperateApI operateApI;

    @Resource
    private AuthApi authApi;

    public AccessBean getAuthInfo(CloudEnvInfo cloudEnvInfo) throws Exception
    {
        String key = Utils.getCloudKey(cloudEnvInfo);
        AccessBean accessBean = AuthCache.getAccessFromCache(key);
        if (accessBean != null)
        {
            return accessBean;
        }
        else
        {
            accessBean = getAuthInfoByApi(cloudEnvInfo);
            return accessBean;
        }
    }

    private AccessBean getAuthInfoByApi(CloudEnvInfo cloudEnvInfo) throws Exception
    {
        String key = Utils.getCloudKey(cloudEnvInfo);
        String authUrl = cloudEnvInfo.getUrl() + CommonConstants.KeyStone.VERSION_TOKENS;
        AuthWrapper authWrapper = this.getAuthWrapper(cloudEnvInfo);
        RestfulRsp rep = operateApI.getAccess(authUrl, authWrapper);
        if (rep.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            AccessBean accessBean = new AccessBean();
            AccessWrapper accessWrapper = JSON.parseObject(rep.getResponseBody(), AccessWrapper.class);
            Access access = accessWrapper.getAccess();
            Token token = access.getToken();
            long diffTime = token.getExpires().getTime() - token.getIssued_at().getTime();
            long issueTime = System.currentTimeMillis();
            //微服务中token提前60秒过期,避免在过期时间点无法访问
            long expireTime = issueTime + diffTime - 60000;
            accessBean.setIssueTime(issueTime);
            accessBean.setExpireTime(expireTime);
            accessBean.setToken(token.getId());
            accessBean.setCloudEnvInfo(cloudEnvInfo);
            List<ServiceCatalog> serviceCatalogList = access.getServiceCatalog();
            for (ServiceCatalog serviceCatalog : serviceCatalogList)
            {
                String type = serviceCatalog.getType();
                if (CommonConstants.Cinder.VOLUMEV2.equals(type))
                {
                    accessBean.setCinderUrl(serviceCatalog.getEndpoints().get(0).getAdminURL());
                }
                else if (CommonConstants.Glance.IMAGE.equals(type))
                {
                    accessBean.setGlanceUrl(serviceCatalog.getEndpoints().get(0).getAdminURL());
                }
                else if (CommonConstants.Nova.COMPUTE.equals(type))
                {
                    accessBean.setNovaUrl(serviceCatalog.getEndpoints().get(0).getAdminURL());
                }
                else if (CommonConstants.Neutron.NETWORK.equals(type))
                {
                    accessBean.setNeutronUrl(serviceCatalog.getEndpoints().get(0).getAdminURL());
                }
            }
            AuthCache.putAccess2Cache(key, accessBean);
            return accessBean;
        }
        else
        {
            AuthCache.removeAccessFromCache(key);
            throw new Exception(rep.getResponseBody());
        }
    }

    public Map<String, String> getAuthInfoMap(CloudEnvInfo cloudEnvInfo) throws Exception
    {
        Map<String, String> authMap = getAuthInfoMapByApi(cloudEnvInfo);
        return authMap;
    }

    public Map<String, String> getAuthInfoMapByApi(CloudEnvInfo cloudEnvInfo) throws Exception
    {
        Map<String, String> authMap = new HashMap<String, String>();
        String authUrl = cloudEnvInfo.getUrl() + CommonConstants.KeyStone.VERSION_TOKENS;
        AuthWrapper authWrapper = this.getAuthWrapper(cloudEnvInfo);
        RestfulRsp rep = authApi.getAccess(authUrl, authWrapper);
        if (rep.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            AccessWrapper accessWrapper = JSON.parseObject(rep.getResponseBody(), AccessWrapper.class);
            authMap.put(CommonConstants.KeyStone.X_AUTH_TOKEN, accessWrapper.getAccess().getToken().getId());
            List<ServiceCatalog> serviceCatalogList = accessWrapper.getAccess().getServiceCatalog();
            for (ServiceCatalog serviceCatalog : serviceCatalogList)
            {
                authMap.put(serviceCatalog.getType(), serviceCatalog.getEndpoints().get(0).getAdminURL());
            }
            return authMap;
        }
        else
        {
            throw new Exception(rep.getResponseBody());
        }
    }

    private AuthWrapper getAuthWrapper(CloudEnvInfo cloudEnvInfo)
    {
        PasswordCredentials passwordCredentials = new PasswordCredentials();
        passwordCredentials.setUsername(cloudEnvInfo.getUserName());
        passwordCredentials.setPassword(cloudEnvInfo.getPassword());
        Auth auth = new Auth();
        auth.setTenantName(cloudEnvInfo.getTenantName());
        auth.setPasswordCredentials(passwordCredentials);
        AuthWrapper authWrapper = new AuthWrapper();
        authWrapper.setAuth(auth);
        return authWrapper;
    }

    public static Map<String, String> getHeader(Map<String, String> authMap)
    {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(CommonConstants.KeyStone.X_AUTH_TOKEN, authMap.get(CommonConstants.KeyStone.X_AUTH_TOKEN));
        return headers;
    }

    public static String getServiceAdminUrl(AccessWrapper accessWrapper, String serviceType)
    {
        List<ServiceCatalog> serviceCatalogList = accessWrapper.getAccess().getServiceCatalog();

        for (ServiceCatalog serviceCatalog : serviceCatalogList)
        {
            if (serviceType.equals(serviceCatalog.getType()))
            {
                return serviceCatalog.getEndpoints().get(0).getAdminURL();
            }
        }
        return null;
    }
}
