package com.zte.vdirector.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.CloudEnvs;
import com.zte.vdirector.frame.constants.CommonConstants;

@Service
public class CommonService
{
    public Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private ServiceBase serviceBase;

    /**
     * 根据组织ID查询VDCID列表
     * 
     * @param orgId
     *            组织ID
     * @return VDCID列表
     */
    public List<String> getVdcIdsByOrgId(String orgId)
    {
        try
        {
            String url = "/api/v2.0/orgService/orgs/{org_id}/vdcIds";
            url = url.replaceAll("\\{org_id\\}", orgId);
            RestfulRsp rsp = serviceBase.get(url);
            if (rsp.getStatusCode() == 200)
            {
                Map<String, List<String>> map = JSON.parseObject(rsp.getResponseBody(),
                        new TypeReference<Map<String, List<String>>>()
                        {
                        });
                return map.get("vdcIds");
            }
        }
        catch (Exception e)
        {
            logger.error("getVdcIdsByOrgId error", e);
        }
        return new ArrayList<String>();
    }

    /**
     * 根据部门ID查询VDCID列表
     * 
     * @param projectId
     *            部门ID
     * @return VDCID列表
     */
    public List<String> getVdcIdsByProjectId(String projectId)
    {
        try
        {
            String url = "/api/v2.0/orgService/projects/{project_id}/vdcIds";
            url = url.replaceAll("\\{project_id\\}", projectId);
            RestfulRsp rsp = serviceBase.get(url);
            if (rsp.getStatusCode() == 200)
            {
                Map<String, List<String>> map = JSON.parseObject(rsp.getResponseBody(),
                        new TypeReference<Map<String, List<String>>>()
                        {
                        });
                return map.get("vdcIds");
            }
        }
        catch (Exception e)
        {
            logger.error("getVdcIdsByProjectId error", e);
        }
        return new ArrayList<String>();
    }

    /**
     * 根据VDCID查询云环境列表
     * 
     * @param vdcId
     *            VDCID
     * @param tenantId
     *            租户ID (可选项，若指定了租户，则只返回的对应的云环境。)
     * @return 云环境列表
     */
    public List<CloudEnvInfo> getCloudEnvList(String vdcId, String tenantId)
    {
        try
        {
            // 注：VDC提供的这个接口，其tenantId参数是一级租户，非云环境中的tenant_id。
            // 因此如果指定了租户ID查询参数，需要在得到列表后进行过滤筛选。
            String uri = CommonConstants.MicroServiceUri.VDC_ENVS_URI;
            uri = uri.replaceAll("\\{id\\}", vdcId);
            RestfulRsp rsp = serviceBase.get(uri);
            String rspBody = rsp.getResponseBody();
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                CloudEnvs cloudEnvs = JSON.parseObject(rspBody, CloudEnvs.class);
                List<CloudEnvInfo> list = cloudEnvs.getTenantEnvs();
                if (list == null)
                {
                    logger.error("getDcs failed, response body is null");
                    return new ArrayList<CloudEnvInfo>();
                }
                else
                {
                    if (StringUtils.isNotBlank(tenantId))
                    {
                        List<CloudEnvInfo> resultList = new ArrayList<CloudEnvInfo>();
                        for (CloudEnvInfo env : list)
                        {
                            if (StringUtils.equals(env.getTenantId(), tenantId))
                            {
                                resultList.add(env);
                            }
                        }
                        return resultList;
                    }
                    else
                    {
                        return list;
                    }
                }
            }
            else
            {
                logger.error("getCloudEnvList failed, response body = " + rspBody);
                return new ArrayList<CloudEnvInfo>();
            }
        }
        catch (Exception e)
        {
            logger.error("getCloudEnvList error:", e);
            return new ArrayList<CloudEnvInfo>();
        }
    }

    public JSONArray getDcList()
    {
        try
        {
            String uri = CommonConstants.Url.DCS;
            RestfulRsp rsp = serviceBase.get(uri);
            String rspBody = rsp.getResponseBody();
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                JSONObject dcs = JSON.parseObject(rspBody);
                if (dcs != null)
                {
                    return dcs.getJSONArray("dcs");
                }
            }
            else
            {
                logger.error("getDcList failed, response body = " + rspBody);
            }
        }
        catch (Exception e)
        {
            logger.error("getDcList error:", e);
        }
        return new JSONArray();
    }

    public String getDcId(String cloudEnvId)
    {
        JSONArray dcs = getDcList();
        if (null != dcs)
        {
            for (Object temp : dcs)
            {
                if (null != temp)
                {
                    JSONObject dc = (JSONObject) temp;
                    if (dc.containsKey("cloudEnvs"))
                    {
                        JSONArray cloudEnvs = dc.getJSONArray("cloudEnvs");
                        for (Object tempCloud : cloudEnvs)
                        {
                            JSONObject cloudEnv = (JSONObject) tempCloud;
                            if (null != cloudEnv && cloudEnv.containsKey("id")
                                    && StringUtils.equals(cloudEnv.getString("id"), cloudEnvId))
                            {
                                return dc.getString("id");
                            }
                        }
                    }

                }
            }
        }
        return "";
    }
}
