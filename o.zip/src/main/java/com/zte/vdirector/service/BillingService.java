/**
 * 
 */
package com.zte.vdirector.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.billing.BillingDao;
import com.zte.vdirector.domain.gridqueryparams.PagingResult;
import com.zte.vdirector.domain.volume.Volume;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.utils.Utils;

/**
 * <p>
 * 版权所有：中兴通讯股份有限公司
 * </p>
 * <p>
 * 项目名称：Operate
 * </p>
 * <p>
 * 类名称：BillingService
 * </p>
 * <p>
 * 类描述：
 * </p>
 * <p>
 * 创建人：10138528
 * </p>
 * <p>
 * 创建时间：2016-11-2 下午5:42:03
 * </p>
 * <p>
 * 修改人：10138528
 * </p>
 * <p>
 * 修改时间：2016-11-2 下午5:42:03
 * </p>
 * <p>
 * 修改备注：
 * </p>
 * 
 * @version 1.0
 * 
 */
@Service
public class BillingService
{
    private Logger logger = Logger.getLogger(OrgService.class);

    // private static int BILLING_CIRCLE = 1;
    private static Map<String, Double> prices = new HashMap<String, Double>();
    private static List<Object[]> vmMap = Collections.synchronizedList(new ArrayList<Object[]>());
    private static List<Object[]> volumeMap = Collections.synchronizedList(new ArrayList<Object[]>());
    private static List<Object[]> vrMap = Collections.synchronizedList(new ArrayList<Object[]>());
    private static List<Object[]> vfwMap = Collections.synchronizedList(new ArrayList<Object[]>());
    private static List<Object[]> vlbMap = Collections.synchronizedList(new ArrayList<Object[]>());
    // private static List<Object[]> vdeskMap = Collections.synchronizedList(new ArrayList<Object[]>());
    // private static List<Object[]> vnetMap = Collections.synchronizedList(new ArrayList<Object[]>());
    private static Map<String, JSONObject> imageMap = new HashMap<String, JSONObject>();
    private static Map<String, JSONObject> flavorMap = new HashMap<String, JSONObject>();
    private static Map<String, Map<String, Object>> portMap = new HashMap<String, Map<String, Object>>();
    private static Map<String, Map<String, Object>> floatingIpMap = new HashMap<String, Map<String, Object>>();
    private static String[] types = { "vm", "volume", "vr", "vfw", "vlb", "vdesk", "vnet" };

    @Resource
    private Environment env;

    @Resource
    private OrgService orgService;

    @Resource
    private ResourceService resourceService;

    @Resource
    private ServicePriceSerivce servicePriceSerivce;

    @Resource
    private BillingDao billingDao;

    private void init()
    {
        prices = new HashMap<String, Double>();
        List<Map<String, Object>> priceItems = billingDao.queryPrice();
        if (null != priceItems)
        {
            for (Map<String, Object> item : priceItems)
            {
                if (CommonConstants.Billing.CPU.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("cpu", Double.parseDouble(item.get("price").toString()));
                }
                else if (CommonConstants.Billing.MEMORY.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("memory", Double.parseDouble(item.get("price").toString()));
                }
                else if (CommonConstants.Billing.OS_DISK.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("osDisk", Double.parseDouble(item.get("price").toString()));
                }
                else if (CommonConstants.Billing.FLOATING_IP.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("floatingIp", Double.parseDouble(item.get("price").toString()));
                }
                else if (CommonConstants.Billing.PRIVATE_IP.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("privateIp", Double.parseDouble(item.get("price").toString()));
                }
                else if (CommonConstants.Billing.OS_WINDOWS.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("windows", Double.parseDouble(item.get("price").toString()));
                }
                else if (CommonConstants.Billing.OS_LINUX.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("linux", Double.parseDouble(item.get("price").toString()));
                }
                else if (CommonConstants.Billing.OS.equalsIgnoreCase(item.get("parent_id").toString()))
                {
                    prices.put("os_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item.get(
                            "price").toString()));
                }
                else if (CommonConstants.Billing.VOLUME_STANDARD.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("volume", Double.parseDouble(item.get("price").toString()));

                    prices.put("volume_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item
                            .get("price").toString()));
                }
                else if (CommonConstants.Billing.VOLUME.equalsIgnoreCase(item.get("service_directory_id").toString()))
                {
                    prices.put("volume_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item
                            .get("price").toString()));
                }
                else if (CommonConstants.Billing.ROUTER_DEFAULT.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("vr", Double.parseDouble(item.get("price").toString()));

                    prices.put("vr_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item.get(
                            "price").toString()));
                }
                else if (CommonConstants.Billing.ROUTER.equalsIgnoreCase(item.get("service_directory_id").toString()))
                {
                    prices.put("vr_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item.get(
                            "price").toString()));
                }
                else if (CommonConstants.Billing.FIREWALL_DEFAULT.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("vfw", Double.parseDouble(item.get("price").toString()));

                    prices.put("vfw_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item.get(
                            "price").toString()));
                }
                else if (CommonConstants.Billing.FIREWALL.equalsIgnoreCase(item.get("service_directory_id").toString()))
                {
                    prices.put("vfw_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item.get(
                            "price").toString()));
                }
                else if (CommonConstants.Billing.LOADBALANCE_DEFAULT.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("vlb", Double.parseDouble(item.get("price").toString()));

                    prices.put("vlb_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item.get(
                            "price").toString()));
                }
                else if (CommonConstants.Billing.LOADBALANCE.equalsIgnoreCase(item.get("service_directory_id")
                        .toString()))
                {
                    prices.put("vlb_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item.get(
                            "price").toString()));
                }
                else if (CommonConstants.Billing.DESKTOP_DEFAULT.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("vdesk", Double.parseDouble(item.get("price").toString()));

                    prices.put("vdesk_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item.get(
                            "price").toString()));
                }
                else if (CommonConstants.Billing.DESKTOP.equalsIgnoreCase(item.get("service_directory_id").toString()))
                {
                    prices.put("vdesk_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item.get(
                            "price").toString()));
                }
                else if (CommonConstants.Billing.BANDWIDTH_DEFAULT.equalsIgnoreCase(item.get("id").toString()))
                {
                    prices.put("bandwidth", Double.parseDouble(item.get("price").toString()));

                    prices.put("bandwidth_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item
                            .get("price").toString()));
                }
                else if (CommonConstants.Billing.BANDWIDTH
                        .equalsIgnoreCase(item.get("service_directory_id").toString()))
                {
                    prices.put("bandwidth_price_" + item.get("name").toString().toLowerCase(), Double.parseDouble(item
                            .get("price").toString()));
                }
            }
        }
    }

    private void initImages(CloudEnvInfo cloudEnvInfo)
    {
        JSONArray images = resourceService.getImages(cloudEnvInfo, false);
        if (null != images)
        {
            for (Object temp : images)
            {
                if (null != temp)
                {
                    JSONObject image = (JSONObject) temp;
                    imageMap.put(cloudEnvInfo.getEnvId() + "_" + image.getString("id"), image);
                }
            }
        }
    }

    private void initFlavors(CloudEnvInfo cloudEnvInfo)
    {
        JSONArray flavors = resourceService.getFlavors(cloudEnvInfo, false);
        if (null != flavors)
        {
            for (Object temp : flavors)
            {
                if (null != temp)
                {
                    JSONObject flavor = (JSONObject) temp;
                    flavorMap.put(cloudEnvInfo.getEnvId() + "_" + flavor.getString("id"), flavor);
                }
            }
        }
    }

    private void initPrivateIps(CloudEnvInfo cloudEnvInfo)
    {
        portMap = new HashMap<String, Map<String, Object>>();
        JSONArray privateIps = resourceService.getPrivateIps(cloudEnvInfo, false);
        if (null != privateIps)
        {
            Map<String, Object> ports = new HashMap<String, Object>();
            for (Object temp : privateIps)
            {
                if (null != temp)
                {
                    JSONObject privateIp = (JSONObject) temp;

                    if (portMap.containsKey(cloudEnvInfo.getEnvId() + "_" + privateIp.getString("device_id")))
                    {
                        ports = portMap.get(cloudEnvInfo.getEnvId() + "_" + privateIp.getString("device_id"));
                    }
                    else
                    {
                        ports = new HashMap<String, Object>();
                    }
                    ports.put(privateIp.getString("id"), privateIp);
                    portMap.put(cloudEnvInfo.getEnvId() + "_" + privateIp.getString("device_id"), ports);
                }
            }
        }
    }

    private void initFloatingIps(CloudEnvInfo cloudEnvInfo)
    {
        floatingIpMap = new HashMap<String, Map<String, Object>>();
        JSONArray floatingIps = resourceService.getFloatingIps(cloudEnvInfo, false);
        if (null != floatingIps)
        {
            Map<String, Object> floatingIpTempMap = new HashMap<String, Object>();
            for (Object temp : floatingIps)
            {
                if (null != temp)
                {
                    JSONObject floatingIp = (JSONObject) temp;
                    if (null != floatingIp.getString("port_id"))
                    {
                        if (floatingIpMap.containsKey(cloudEnvInfo.getEnvId() + "_" + floatingIp.getString("port_id")))
                        {
                            floatingIpTempMap = floatingIpMap.get(cloudEnvInfo.getEnvId() + "_"
                                    + floatingIp.getString("port_id"));
                        }
                        else
                        {
                            floatingIpTempMap = new HashMap<String, Object>();
                        }
                        floatingIpTempMap.put(floatingIp.getString("id"), floatingIp);
                        floatingIpMap.put(cloudEnvInfo.getEnvId() + "_" + floatingIp.getString("port_id"),
                                floatingIpTempMap);
                    }
                }
            }
        }
    }

    public void clear()
    {
        try
        {
            // 每月20号后，开始清理两年前的数据，即下个月表的数据
            Calendar now = Calendar.getInstance();
            if (now.get(Calendar.DAY_OF_MONTH) < 20)
            {
                return;
            }

            now.add(Calendar.MONTH, 1);
            String date = Utils.toString(now.getTime(), "yyyy-MM");
            for (String type : types)
            {
                String tableName = BillingDao.getTableName(type, date);
                billingDao.clear(tableName);
            }
        }
        catch (Exception e)
        {
            logger.error("fail to clear billing data.", e);
        }
    }

    public void handle()
    {
        // 清理数据
        clear();

        // BILLING_CIRCLE = env.getProperty("billing.circle", Integer.class);

        // 初始化价格
        init();

        // 遍历资源计费
        List<Map<String, Object>> orgs = orgService.getOrgs();
        if (null != orgs)
        {
            for (Map<String, Object> org : orgs)
            {
                if (null != org)
                {
                    JSONArray vdcs = orgService.getVdcsInOrg(org.get("id").toString());
                    if (null != vdcs)
                    {
                        Map<String, JSONObject> projectVdcRel = orgService.getProjectVdcRelInOrg(org.get("id")
                                .toString());

                        for (Object vdcId : vdcs)
                        {
                            if (null != vdcId)
                            {
                                handleVdc(org, vdcId.toString(), projectVdcRel);
                            }
                        }
                    }
                }
            }
        }
    }

    public void handleVdc(Map<String, Object> org, String vdcId, Map<String, JSONObject> projectVdcRels)
    {
        List<CloudEnvInfo> cloudEnvInfos = orgService.getCloudEnvList(vdcId, "");
        if (null != cloudEnvInfos)
        {
            JSONObject vdc = orgService.getVdcInfo(vdcId);
            String projectId = "";
            String projectName = "";
            for (CloudEnvInfo cloudEnvInfo : cloudEnvInfos)
            {
                try
                {
                    if (projectVdcRels.containsKey(vdc.getString("id")))
                    {
                        JSONObject projectVdcRel = projectVdcRels.get(vdc.getString("id"));
                        if (null != projectVdcRel)
                        {
                            projectId = projectVdcRel.getString("id");
                            projectName = projectVdcRel.getString("name");
                        }
                        else
                        {
                            projectId = "";
                            projectName = "";
                        }
                    }
                    else
                    {
                        projectId = "";
                        projectName = "";
                    }
                    insertOrgVdcRel(org.get("id").toString(), org.get("name").toString(), projectId, projectName, vdc
                            .get("id").toString(), vdc.get("name").toString(), cloudEnvInfo.getEnvId(), cloudEnvInfo
                            .getEnvName());
                }
                catch (Exception e)
                {
                    logger.error("fail to add vdc org rel", e);
                }

                initImages(cloudEnvInfo);
                initFlavors(cloudEnvInfo);
                initFloatingIps(cloudEnvInfo);
                initPrivateIps(cloudEnvInfo);

                handleVms(org, vdc, projectId, projectName, cloudEnvInfo);
                handleVolumes(org, vdc, projectId, projectName, cloudEnvInfo);
                handleVrs(org, vdc, projectId, projectName, cloudEnvInfo);
                handleVfws(org, vdc, projectId, projectName, cloudEnvInfo);
                handleVlbs(org, vdc, projectId, projectName, cloudEnvInfo);
            }
        }
    }

    private void insertOrgVdcRel(String orgId, String orgName, String projectId, String projectName, String vdcId,
            String vdcName, String envId, String envName)
    {
        billingDao.insertOrgVdcRel(orgId, orgName, projectId, projectName, vdcId, vdcName, envId, envName);
    }

    private List<Object[]> billingToDb(List<Object[]> records, String table)
    {
        List<Object[]> temp = records;
        if (null != temp && temp.size() > 0)
        {
            billingDao.batchInsert(temp, table);
        }
        return Collections.synchronizedList(new ArrayList<Object[]>());
    }

    private Map<String, Object> getVmPrice(CloudEnvInfo cloudEnvInfo, JSONObject vm)
    {
        Map<String, Object> cost = new HashMap<String, Object>();
        StringBuilder desc = new StringBuilder();
        double total = 0;

        // 描述
        try
        {
            desc.append("name:").append(vm.get("name"));
        }
        catch (Exception e)
        {
            logger.error("fail to get name of vm", e);
        }

        // 根据镜像查os
        double osDisk = 0;
        String os = "";
        String osType = "";
        try
        {
            if (vm.containsKey("image"))
            {
                JSONObject image = (JSONObject) vm.get("image");
                if (null != image)
                {
                    String imageId = image.getString("id");
                    vm.put("imageId", imageId);

                    if (!imageMap.containsKey(cloudEnvInfo.getEnvId() + "_" + imageId))
                    {
                        initImages(cloudEnvInfo);
                    }

                    if (imageMap.containsKey(cloudEnvInfo.getEnvId() + "_" + imageId))
                    {
                        JSONObject imageDetail = imageMap.get(cloudEnvInfo.getEnvId() + "_" + imageId);
                        if (null != imageDetail)
                        {
                            desc.append(", image:").append(imageDetail.get("name"));
                            osDisk = imageDetail.getInteger("virtual_size") / 1024d / 1024 / 1024;
                            if (imageDetail.containsKey("os_name"))
                            {
                                os = imageDetail.getString("os_name").toLowerCase();
                            }
                            if (imageDetail.containsKey("os_type"))
                            {
                                osType = imageDetail.getString("os_type").toLowerCase();
                            }
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get os info of vm", e);
        }

        // 根据flavor查cpu， memory，os disk
        try
        {
            double cpuPrice = 0;
            double memoryPrice = 0;
            double osDiskPrice = 0;
            if (vm.containsKey("flavor"))
            {
                JSONObject flavor = (JSONObject) vm.get("flavor");
                if (null != flavor)
                {
                    int vcpus = 0;
                    int ram = 0;
                    int disk = 0;
                    try
                    {
                        cpuPrice = prices.get("cpu");
                        memoryPrice = prices.get("memory");
                        osDiskPrice = prices.get("osDisk");
                    }
                    catch (Exception e)
                    {
                    }

                    String flavorId = flavor.getString("id");
                    vm.put("flavorId", flavorId);

                    if (!flavorMap.containsKey(cloudEnvInfo.getEnvId() + "_" + flavorId))
                    {
                        initFlavors(cloudEnvInfo);
                    }

                    if (flavorMap.containsKey(cloudEnvInfo.getEnvId() + "_" + flavorId))
                    {
                        JSONObject falvorDetail = flavorMap.get(cloudEnvInfo.getEnvId() + "_" + flavorId);
                        if (null != falvorDetail)
                        {
                            desc.append(", flavor:").append(falvorDetail.get("name")).append(" ");
                            vcpus = falvorDetail.getInteger("vcpus");
                            ram = falvorDetail.getInteger("ram");// m
                            disk = falvorDetail.getInteger("disk");// g

                            total += vcpus * cpuPrice;
                            desc.append(", vcpu: " + vcpus + " * " + cpuPrice);

                            total += ram / 1024d * memoryPrice;
                            desc.append(", memory: " + ram + "/1024 * " + memoryPrice);

                            if (disk > 0)
                            {
                                total += disk * osDiskPrice;
                            }
                            else if (osDisk > 0)
                            {
                                total += osDisk * osDiskPrice;
                            }
                            desc.append(", os disk: " + osDisk + " * " + osDiskPrice);
                        }
                    }
                }
            }

        }
        catch (Exception e)
        {
            logger.error("fail to get cpu, memory, os disk info of vm", e);
        }

        // 操作系统费用
        try
        {
            double osPrice = 0;
            if (StringUtils.isNotBlank(os) && prices.containsKey("os_price_" + os))
            {
                osPrice = prices.get("os_price_" + os);
                total += osPrice;
                desc.append(", os : " + os + " = " + osPrice);
            }
            else if (StringUtils.isNotBlank(osType))
            {
                osPrice = prices.get(osType);
                total += osPrice;
                desc.append(", os : " + osType + " = " + osPrice);
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get os info of vm", e);
        }

        // 内部网络
        try
        {
            double privateAddressPrice = 0;
            double floatingIpPrice = 0;
            if (portMap.containsKey(cloudEnvInfo.getEnvId() + "_" + vm.getString("id")))
            {
                Map<String, Object> ports = portMap.get(cloudEnvInfo.getEnvId() + "_" + vm.getString("id"));
                if (null != ports && ports.size() > 0)
                {
                    privateAddressPrice = prices.get("privateIp");
                    total += ports.size() * privateAddressPrice;
                    desc.append(", private address: " + ports.size() + " * " + privateAddressPrice);

                    for (String key : ports.keySet())
                    {
                        if (null != ports.get(key))
                        {
                            JSONObject temp = (JSONObject) ports.get(key);
                            if (floatingIpMap.containsKey(cloudEnvInfo.getEnvId() + "_" + temp.getString("id")))
                            {
                                Map<String, Object> floatingIpTempMap = floatingIpMap.get(cloudEnvInfo.getEnvId() + "_"
                                        + temp.getString("id"));
                                if (null != floatingIpTempMap)
                                {

                                    floatingIpPrice = prices.get("floatingIp");
                                    total += floatingIpTempMap.size() * floatingIpPrice;
                                    desc.append(", floating ip: " + floatingIpTempMap.size() + " * " + floatingIpPrice);
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get private address of vm", e);
        }

        cost.put("desc", desc.toString());
        cost.put("price", total);
        return cost;
    }

    private Map<String, Object> getVolumePrice(Volume volume)
    {
        Map<String, Object> volumePrice = new HashMap<String, Object>();

        double price = 0;
        String desc = "";
        try
        {

            if (StringUtils.equalsIgnoreCase(volume.getStatus(), "error"))
            {
                desc = "volume " + volume.getId() + " status is " + volume.getStatus();
            }
            else
            {
                price = prices.get("volume");
                if (StringUtils.isNotBlank(volume.getVolumeType())
                        && prices.containsKey("volume_price_" + volume.getVolumeType().toLowerCase()))
                {
                    price = prices.get("volume_price_" + volume.getVolumeType().toLowerCase());
                }

                price = volume.getSize() * price;
                desc = volume.getSize() + " * " + price;
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get volume info", e);
        }
        volumePrice.put("price", price);
        volumePrice.put("desc", desc);
        return volumePrice;
    }

    private Map<String, Object> getVrPrice(CloudEnvInfo cloudEnvInfo, JSONObject router)
    {
        Map<String, Object> cost = new HashMap<String, Object>();
        StringBuilder desc = new StringBuilder();
        double routerPrice = 0;

        // 操作系统费用
        try
        {
            if (prices.containsKey("vr_price_" + router.getString("name")))
            {
                routerPrice = prices.get("vr_price_" + router.getString("name"));
                desc.append("router : " + router.getString("type") + " = " + routerPrice);
            }
            else
            {
                routerPrice = prices.get("vr");
                desc.append("router = " + routerPrice);
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get router price", e);
        }

        cost.put("desc", desc.toString());
        cost.put("price", routerPrice);
        return cost;
    }

    private Map<String, Object> getFirewallPrice(CloudEnvInfo cloudEnvInfo, JSONObject vfw)
    {
        Map<String, Object> cost = new HashMap<String, Object>();
        StringBuilder desc = new StringBuilder();
        double vfwPrice = 0;

        // 操作系统费用
        try
        {
            if (prices.containsKey("vfw_price_" + vfw.getString("name")))
            {
                vfwPrice = prices.get("vfw_price_" + vfw.getString("name"));
                desc.append("vfw : " + vfw.getString("type") + " = " + vfwPrice);
            }
            else
            {
                vfwPrice = prices.get("vfw");
                desc.append("vfw = " + vfwPrice);
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get router price", e);
        }

        cost.put("desc", desc.toString());
        cost.put("price", vfwPrice);
        return cost;
    }

    private Map<String, Object> getVlbPrice(CloudEnvInfo cloudEnvInfo, JSONObject vlb)
    {
        Map<String, Object> cost = new HashMap<String, Object>();
        StringBuilder desc = new StringBuilder();
        double vlbPrice = 0;

        // 操作系统费用
        try
        {
            if (prices.containsKey("vlb_price_" + vlb.getString("name")))
            {
                vlbPrice = prices.get("vlb_price_" + vlb.getString("name"));
                desc.append("vlb : " + vlb.getString("type") + " = " + vlbPrice);
            }
            else
            {
                vlbPrice = prices.get("vlb");
                desc.append("vlb = " + vlbPrice);
            }
        }
        catch (Exception e)
        {
            logger.error("fail to get vlb price", e);
        }

        cost.put("desc", desc.toString());
        cost.put("price", vlbPrice);
        return cost;
    }

    private void handleVms(Map<String, Object> org, JSONObject vdc, String projectId, String projectName,
            CloudEnvInfo cloudEnvInfo)
    {
        JSONArray vms = resourceService.getVms(cloudEnvInfo, false);
        if (null != vms)
        {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            String table = BillingDao.getTableName("vm", "");

            for (Object temp : vms)
            {
                if (null != temp)
                {
                    try
                    {
                        JSONObject vm = (JSONObject) temp;
                        Map<String, Object> priceMap = getVmPrice(cloudEnvInfo, vm);
                        double price = (Double) priceMap.get("price");
                        double cost = price;
                        List<Object> record = new ArrayList<Object>();
                        record.add(org.get("id"));
                        record.add(org.get("name"));
                        record.add(vdc.get("id"));
                        record.add(vdc.get("name"));
                        record.add(projectId);
                        record.add(projectName);
                        record.add(cloudEnvInfo.getEnvId());
                        record.add(cloudEnvInfo.getEnvName());
                        record.add(vm.get("tenant_id"));
                        record.add(vm.get("user_id"));
                        record.add(vm.get("id"));
                        record.add(vm.get("name"));
                        record.add(vm.get("status"));
                        record.add(vm.get("imageId"));
                        record.add(vm.get("flavorId"));
                        record.add(price);
                        record.add(cost);
                        record.add(priceMap.get("desc"));
                        record.add(calendar.getTime());
                        // calendar.add(Calendar.HOUR, -BILLING_CIRCLE);
                        record.add(calendar.getTime());
                        record.add(new Date());
                        record.add("");// extra
                        record.add(price);
                        record.add(cost);
                        record.add(vm.get("status"));
                        record.add(priceMap.get("desc"));
                        vmMap.add(record.toArray());

                        if (vmMap.size() > 1000)
                        {
                            List<Object[]> tempMap = vmMap;
                            vmMap = Collections.synchronizedList(new ArrayList<Object[]>());
                            billingToDb(tempMap, table);
                        }
                    }
                    catch (Exception e)
                    {
                        logger.error("fail to get vm price", e);
                    }
                }
            }
            List<Object[]> tempMap = vmMap;
            vmMap = Collections.synchronizedList(new ArrayList<Object[]>());
            billingToDb(tempMap, table);
        }
    }

    private void handleVolumes(Map<String, Object> org, JSONObject vdc, String projectId, String projectName,
            CloudEnvInfo cloudEnvInfo)
    {
        List<Volume> volumes = resourceService.getVolumes(cloudEnvInfo, false);
        if (null != volumes)
        {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            String table = BillingDao.getTableName("volume", "");

            for (Volume volume : volumes)
            {
                if (null != volume)
                {
                    Map<String, Object> priceMap = getVolumePrice(volume);
                    List<Object> record = new ArrayList<Object>();
                    record.add(org.get("id"));
                    record.add(org.get("name"));
                    record.add(vdc.get("id"));
                    record.add(vdc.get("name"));
                    record.add(projectId);
                    record.add(projectName);
                    record.add(cloudEnvInfo.getEnvId());
                    record.add(cloudEnvInfo.getEnvName());
                    record.add(volume.getTenantId());
                    record.add(volume.getUserId());
                    record.add(volume.getId());
                    record.add(volume.getName());
                    record.add(volume.getStatus());
                    record.add(volume.getVolumeType());
                    record.add(volume.getSize());
                    record.add(priceMap.get("price"));
                    record.add(priceMap.get("price"));
                    record.add(priceMap.get("desc"));
                    record.add(Utils.toString(calendar.getTime(), Utils.TIME_FORMAT));
                    // calendar.add(Calendar.HOUR, -BILLING_CIRCLE);
                    record.add(Utils.toString(calendar.getTime(), Utils.TIME_FORMAT));
                    record.add(Utils.toString(new Date(), Utils.TIME_FORMAT));
                    record.add("");// extra
                    record.add(priceMap.get("price"));
                    record.add(priceMap.get("price"));
                    record.add(volume.getStatus());
                    record.add(priceMap.get("desc"));
                    volumeMap.add(record.toArray());

                    if (volumeMap.size() > 1000)
                    {
                        List<Object[]> tempMap = volumeMap;
                        volumeMap = Collections.synchronizedList(new ArrayList<Object[]>());
                        billingToDb(tempMap, table);
                    }
                }
            }
            List<Object[]> tempMap = volumeMap;
            volumeMap = Collections.synchronizedList(new ArrayList<Object[]>());
            billingToDb(tempMap, table);
        }
    }

    private void handleVrs(Map<String, Object> org, JSONObject vdc, String projectId, String projectName,
            CloudEnvInfo cloudEnvInfo)
    {
        JSONArray vrs = resourceService.getVrs(cloudEnvInfo, false);
        if (null != vrs)
        {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            String table = BillingDao.getTableName("vr", "");

            for (Object temp : vrs)
            {
                if (null != temp)
                {
                    try
                    {
                        JSONObject vr = (JSONObject) temp;
                        Map<String, Object> priceMap = getVrPrice(cloudEnvInfo, vr);
                        double price = (Double) priceMap.get("price");
                        double cost = price;
                        List<Object> record = new ArrayList<Object>();
                        record.add(org.get("id"));
                        record.add(org.get("name"));
                        record.add(vdc.get("id"));
                        record.add(vdc.get("name"));
                        record.add(projectId);
                        record.add(projectName);
                        record.add(cloudEnvInfo.getEnvId());
                        record.add(cloudEnvInfo.getEnvName());
                        record.add(vr.get("tenant_id"));
                        record.add(vr.get("user_id"));
                        record.add(vr.get("id"));
                        record.add(vr.get("name"));
                        record.add(vr.get("status"));
                        record.add("");
                        record.add("");
                        record.add(price);
                        record.add(cost);
                        record.add(priceMap.get("desc"));
                        record.add(Utils.toString(calendar.getTime(), Utils.TIME_FORMAT));
                        // calendar.add(Calendar.HOUR, -BILLING_CIRCLE);
                        record.add(Utils.toString(calendar.getTime(), Utils.TIME_FORMAT));
                        record.add(Utils.toString(new Date(), Utils.TIME_FORMAT));
                        record.add("");// extra
                        record.add(price);
                        record.add(cost);
                        record.add(vr.get("status"));
                        record.add(priceMap.get("desc"));
                        vrMap.add(record.toArray());

                        if (vrMap.size() > 1000)
                        {
                            List<Object[]> tempMap = vrMap;
                            vrMap = Collections.synchronizedList(new ArrayList<Object[]>());
                            billingToDb(tempMap, table);
                        }
                    }
                    catch (Exception e)
                    {
                        logger.error("fail to get vr price", e);
                    }
                }
            }
            List<Object[]> tempMap = vrMap;
            vrMap = Collections.synchronizedList(new ArrayList<Object[]>());
            billingToDb(tempMap, table);
        }
    }

    private void handleVfws(Map<String, Object> org, JSONObject vdc, String projectId, String projectName,
            CloudEnvInfo cloudEnvInfo)
    {
        JSONArray vfws = resourceService.getVfws(cloudEnvInfo, false);
        if (null != vfws)
        {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            String table = BillingDao.getTableName("vfw", "");

            for (Object temp : vfws)
            {
                if (null != temp)
                {
                    try
                    {
                        JSONObject vfw = (JSONObject) temp;
                        Map<String, Object> priceMap = getFirewallPrice(cloudEnvInfo, vfw);
                        double price = (Double) priceMap.get("price");
                        double cost = price;
                        List<Object> record = new ArrayList<Object>();
                        record.add(org.get("id"));
                        record.add(org.get("name"));
                        record.add(vdc.get("id"));
                        record.add(vdc.get("name"));
                        record.add(projectId);
                        record.add(projectName);
                        record.add(cloudEnvInfo.getEnvId());
                        record.add(cloudEnvInfo.getEnvName());
                        record.add(vfw.get("tenant_id"));
                        record.add(vfw.get("user_id"));
                        record.add(vfw.get("id"));
                        record.add(vfw.get("name"));
                        record.add(vfw.get("status"));
                        record.add("");
                        record.add("");
                        record.add(price);
                        record.add(cost);
                        record.add(priceMap.get("desc"));
                        record.add(Utils.toString(calendar.getTime(), Utils.TIME_FORMAT));
                        // calendar.add(Calendar.HOUR, -BILLING_CIRCLE);
                        record.add(Utils.toString(calendar.getTime(), Utils.TIME_FORMAT));
                        record.add(Utils.toString(new Date(), Utils.TIME_FORMAT));
                        record.add("");// extra
                        record.add(price);
                        record.add(cost);
                        record.add(vfw.get("status"));
                        record.add(priceMap.get("desc"));
                        vfwMap.add(record.toArray());

                        if (vfwMap.size() > 1000)
                        {
                            List<Object[]> tempMap = vfwMap;
                            vfwMap = Collections.synchronizedList(new ArrayList<Object[]>());
                            billingToDb(tempMap, table);
                        }
                    }
                    catch (Exception e)
                    {
                        logger.error("fail to get vfw price", e);
                    }
                }
            }
            List<Object[]> tempMap = vfwMap;
            vfwMap = Collections.synchronizedList(new ArrayList<Object[]>());
            billingToDb(tempMap, table);
        }
    }

    private void handleVlbs(Map<String, Object> org, JSONObject vdc, String projectId, String projectName,
            CloudEnvInfo cloudEnvInfo)
    {
        JSONArray vlbs = resourceService.getVlbs(cloudEnvInfo, false);
        if (null != vlbs)
        {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            String table = BillingDao.getTableName("vlb", "");

            for (Object temp : vlbs)
            {
                if (null != temp)
                {
                    try
                    {
                        JSONObject vlb = (JSONObject) temp;
                        Map<String, Object> priceMap = getVlbPrice(cloudEnvInfo, vlb);
                        double price = (Double) priceMap.get("price");
                        double cost = price;
                        List<Object> record = new ArrayList<Object>();
                        record.add(org.get("id"));
                        record.add(org.get("name"));
                        record.add(vdc.get("id"));
                        record.add(vdc.get("name"));
                        record.add(projectId);
                        record.add(projectName);
                        record.add(cloudEnvInfo.getEnvId());
                        record.add(cloudEnvInfo.getEnvName());
                        record.add(vlb.get("tenant_id"));
                        record.add(vlb.get("user_id"));
                        record.add(vlb.get("id"));
                        record.add(vlb.get("name"));
                        record.add(vlb.get("status"));
                        record.add("");
                        record.add("");
                        record.add(price);
                        record.add(cost);
                        record.add(priceMap.get("desc"));
                        record.add(Utils.toString(calendar.getTime(), Utils.TIME_FORMAT));
                        // calendar.add(Calendar.HOUR, -BILLING_CIRCLE);
                        record.add(Utils.toString(calendar.getTime(), Utils.TIME_FORMAT));
                        record.add(Utils.toString(new Date(), Utils.TIME_FORMAT));
                        record.add("");// extra
                        record.add(price);
                        record.add(cost);
                        record.add(vlb.get("status"));
                        record.add(priceMap.get("desc"));
                        vlbMap.add(record.toArray());

                        if (vlbMap.size() > 1000)
                        {
                            List<Object[]> tempMap = vlbMap;
                            vlbMap = Collections.synchronizedList(new ArrayList<Object[]>());
                            billingToDb(tempMap, table);
                        }
                    }
                    catch (Exception e)
                    {
                        logger.error("fail to get vlb price", e);
                    }
                }
            }
            List<Object[]> tempMap = vlbMap;
            vlbMap = Collections.synchronizedList(new ArrayList<Object[]>());
            billingToDb(tempMap, table);
        }
    }

    public PagingResult getBillingList(String orgId, String vdcId, String type, String name, String beginTime,
            String endTime, int start, int limit)
    {
        List<Map<String, Object>> orgs = orgService.getOrgs();
        String projectId = "";
        boolean isOrg = false;
        if (null != orgs)
        {
            for (Map<String, Object> org : orgs)
            {
                if (null != org && StringUtils.equals(orgId, org.get("id").toString()))
                {
                    isOrg = true;
                    break;
                }
            }
            if (!isOrg)
            {
                projectId = orgId;
                orgId = "";
            }
        }
        return billingDao.queryBilling(orgId, projectId, vdcId, type, name, beginTime, endTime, start, limit);
    }

    public PagingResult getStatistics(String orgId, String vdcId, String beginTime, String endTime, int start, int limit)
    {
        List<Map<String, Object>> orgs = orgService.getOrgs();
        String projectId = "";
        boolean isOrg = false;
        if (null != orgs)
        {
            for (Map<String, Object> org : orgs)
            {
                if (null != org && StringUtils.equals(orgId, org.get("id").toString()))
                {
                    isOrg = true;
                    break;
                }
            }
            if (!isOrg)
            {
                projectId = orgId;
                orgId = "";
            }
        }
        return billingDao.getStatistics(orgId, projectId, vdcId, beginTime, endTime, start, limit);
    }
    
    @Cacheable(value = "operate_cache", key = "'key_' + #id")
    public String cacheGet(String id)
    {
        return "value" + id;
    }

    //@CachePut(value = "volume_cache", key = "'account_key_' + #account.getSequenceId()")
    @CachePut(value = "operate_cache", key = "'key_' + #id")
    public String cachePut(String id)
    {
        return "value-" + id;
    }

    @CacheEvict(value = "operate_cache", key = "'key_' + #id")
    public boolean cacheDelete(String id)
    {
        return true;
    }
}
