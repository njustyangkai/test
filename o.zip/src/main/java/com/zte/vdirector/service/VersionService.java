package com.zte.vdirector.service;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zte.vdirector.domain.version.VersionDao;

/** 
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：VersionService   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年12月6日 下午2:46:08 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年12月6日 下午2:46:08  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Service
public class VersionService
{
    @Resource
    private VersionDao versionDao;

    public Map<String, Object> getVersionInfo()
    {
        return versionDao.getVersionInfo();
    }

    public void updateVersion(String sqlVersion)
    {
        versionDao.updateVersion(sqlVersion);
    }
}
