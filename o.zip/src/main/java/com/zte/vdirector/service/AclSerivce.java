package com.zte.vdirector.service;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.acls.AclAuthReq;
import com.zte.vdirector.domain.acls.AclAuthRsp;
import com.zte.vdirector.domain.acls.AclQueryCondition;
import com.zte.vdirector.domain.acls.AclResponse;
import com.zte.vdirector.frame.constants.CommonConstants;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate
 * </p>  
 * <p>   
 * 类名称：AclSerivce   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年11月30日 下午2:56:06 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年11月30日 下午2:56:06  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Service
public class AclSerivce
{
    public Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private ServiceBase serviceBase;

    public AclResponse getAcls(AclQueryCondition aclCondition)
    {
        AclResponse aclRsp = null;
        try
        {
            StringBuilder url = new StringBuilder();
            url.append("/api/v1.0/iks/acls");

            StringBuilder params = new StringBuilder();
            if (StringUtils.isNotBlank(aclCondition.getTokenId()))
            {
                params.append("&token=").append(aclCondition.getTokenId());
            }

            if (StringUtils.isNotBlank(aclCondition.getResourceId()))
            {
                params.append("&resourceId=").append(aclCondition.getResourceId());
            }

            if (StringUtils.isNotBlank(aclCondition.getResourceType()))
            {
                params.append("&resourceType=").append(aclCondition.getResourceType());
            }

            if (StringUtils.isNotBlank(aclCondition.getUserId()))
            {
                params.append("&userId=").append(aclCondition.getUserId());
            }

            if (StringUtils.isNotBlank(params))
            {
                url.append('?').append(StringUtils.substring(params.toString(), 1));
            }

            RestfulRsp rsp = serviceBase.get(url.toString());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                aclRsp = JSON.parseObject(rsp.getResponseBody(), AclResponse.class);
            }
        }
        catch (Exception e)
        {
            logger.error("getAcls error", e);
        }
        return aclRsp;
    }

    public AclAuthRsp authorizeResourcesForAdmin(AclAuthReq aclAuthReq)
    {
        try
        {
            String url = "/api/v1.0/iks/acls";
            RestfulRsp rsp = serviceBase.post(aclAuthReq, url);
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                return JSON.parseObject(rsp.getResponseBody(), AclAuthRsp.class);
            }
        }
        catch (Exception e)
        {
            logger.error("authorizeResourcesForAdmin error", e);
        }
        return null;
    }
}
