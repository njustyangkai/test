/**
 * 
 */
package com.zte.vdirector.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.openstack.OperateApI;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.auth.AccessBean;
import com.zte.vdirector.domain.instance.Server;
import com.zte.vdirector.domain.instance.Servers;
import com.zte.vdirector.domain.loadbalancer.HealthMonitor;
import com.zte.vdirector.domain.loadbalancer.HealthMonitorsv2;
import com.zte.vdirector.domain.loadbalancer.HealthMonitorv2Wrapper;
import com.zte.vdirector.domain.loadbalancer.Listener;
import com.zte.vdirector.domain.loadbalancer.ListenerWrapper;
import com.zte.vdirector.domain.loadbalancer.Listeners;
import com.zte.vdirector.domain.loadbalancer.LoadBalancer;
import com.zte.vdirector.domain.loadbalancer.LoadBalancerWrapper;
import com.zte.vdirector.domain.loadbalancer.LoadBalancers;
import com.zte.vdirector.domain.loadbalancer.Member;
import com.zte.vdirector.domain.loadbalancer.MemberWrapper;
import com.zte.vdirector.domain.loadbalancer.Members;
import com.zte.vdirector.domain.loadbalancer.Pool;
import com.zte.vdirector.domain.loadbalancer.PoolWrapper;
import com.zte.vdirector.domain.loadbalancer.Pools;
import com.zte.vdirector.domain.subnet.Port;
import com.zte.vdirector.domain.subnet.Port.Ip;
import com.zte.vdirector.domain.subnet.Ports;
import com.zte.vdirector.domain.subnet.Subnet;
import com.zte.vdirector.domain.subnet.Subnets;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.utils.Utils;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：LoadBalancerService   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年11月7日 下午8:19:55 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年11月7日 下午8:19:55  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Service
public class LoadBalancerService
{
    public Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private OperateApI operateApI;

    @Resource
    private AuthService authService;

    @Resource
    private ServiceBase serviceBase;

    @Resource
    private CommonService commonService;

    public List<LoadBalancer> getLoadBalancers(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<LoadBalancer>();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LOADBALANCERS;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                LoadBalancers vlbs = JSON.parseObject(rsp.getResponseBody(), LoadBalancers.class);
                return vlbs.getLoadbalancers();
            }
            else
            {
                logger.error("getLoadBalancers failed, response body = ", rsp.getResponseBody());
                return new ArrayList<LoadBalancer>();
            }
        }
        catch (Exception e)
        {
            logger.error("getLoadBalancers error, ", e);
            return new ArrayList<LoadBalancer>();
        }
    }

    public RestfulRsp deleteLoadBalancer(CloudEnvInfo cloudEnvInfo, String vlbId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LOADBALANCERS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_LOADBALANCERID, vlbId);
        return operateApI.delete(url, Utils.getHeader(accessBean), null);
    }

    public RestfulRsp updateLoadBalancer(CloudEnvInfo cloudEnvInfo, String vlbId, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LOADBALANCERS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_LOADBALANCERID, vlbId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public LoadBalancer getLoadBalancer(CloudEnvInfo cloudEnvInfo, String vlbId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LOADBALANCERS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_LOADBALANCERID, vlbId);
        RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            LoadBalancerWrapper vlbWrapper = JSON.parseObject(rsp.getResponseBody(), LoadBalancerWrapper.class);
            LoadBalancer v = vlbWrapper.getLoadbalancer();
            v.setCloudenv(cloudEnvInfo);
            return v;
        }
        else
        {
            logger.error("getLoadBalancer failed, response body = " + rsp.getResponseBody());
            return null;
        }
    }

    public RestfulRsp createLoadBalancer(CloudEnvInfo cloudEnvInfo, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LOADBALANCERS;
        return operateApI.post(url, Utils.getHeader(accessBean), body);
    }

    public List<Listener> getListeners(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<Listener>();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LISTENERS;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                Listeners listeners = JSON.parseObject(rsp.getResponseBody(), Listeners.class);
                return listeners.getListeners();
            }
            else
            {
                logger.error("getListeners failed, response body = ", rsp.getResponseBody());
                return new ArrayList<Listener>();
            }
        }
        catch (Exception e)
        {
            logger.error("getPoliListenerror, ", e);
            return new ArrayList<Listener>();
        }
    }

    public RestfulRsp deleteListener(CloudEnvInfo cloudEnvInfo, String listenerId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LISTENERS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_LISTENERID, listenerId);
        return operateApI.delete(url, Utils.getHeader(accessBean), null);
    }

    public RestfulRsp updateListener(CloudEnvInfo cloudEnvInfo, String listenerId, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LISTENERS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_LISTENERID, listenerId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public Listener getListener(CloudEnvInfo cloudEnvInfo, String listenerId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LISTENERS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_LISTENERID, listenerId);
        RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            ListenerWrapper policyWrapper = JSON.parseObject(rsp.getResponseBody(), ListenerWrapper.class);
            Listener v = policyWrapper.getListener();
            v.setCloudenv(cloudEnvInfo);
            return v;
        }
        else
        {
            logger.error("getListener failed, response body = " + rsp.getResponseBody());
            return null;
        }
    }

    public RestfulRsp createListener(CloudEnvInfo cloudEnvInfo, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_LISTENERS;
        return operateApI.post(url, Utils.getHeader(accessBean), body);
    }

    public List<Pool> getPools(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<Pool>();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_POOLS;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                Pools firewallPools = JSON.parseObject(rsp.getResponseBody(), Pools.class);
                return firewallPools.getPools();
            }
            else
            {
                logger.error("getPools failed, response body = ", rsp.getResponseBody());
                return new ArrayList<Pool>();
            }
        }
        catch (Exception e)
        {
            logger.error("getPools error, ", e);
            return new ArrayList<Pool>();
        }
    }

    public RestfulRsp deletePool(CloudEnvInfo cloudEnvInfo, String poolId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_POOLS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_POOLID, poolId);
        return operateApI.delete(url, Utils.getHeader(accessBean), null);
    }

    public RestfulRsp updatePool(CloudEnvInfo cloudEnvInfo, String poolId, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_POOLS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_POOLID, poolId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public Pool getPool(CloudEnvInfo cloudEnvInfo, String poolId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_POOLS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_POOLID, poolId);
        RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            PoolWrapper ruleWrapper = JSON.parseObject(rsp.getResponseBody(), PoolWrapper.class);
            Pool v = ruleWrapper.getPool();
            v.setCloudenv(cloudEnvInfo);
            return v;
        }
        else
        {
            logger.error("getPool failed, response body = " + rsp.getResponseBody());
            return null;
        }
    }

    public RestfulRsp createPool(CloudEnvInfo cloudEnvInfo, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_POOLS;
        return operateApI.post(url, Utils.getHeader(accessBean), body);
    }

    public List<Member> getMembers(CloudEnvInfo cloudEnvInfo, boolean allTenants, String poolId)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<Member>();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_MEMBERS;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_POOLID, poolId);
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                Members firewallMembers = JSON.parseObject(rsp.getResponseBody(), Members.class);
                return firewallMembers.getMembers();
            }
            else
            {
                logger.error("getMembers failed, response body = ", rsp.getResponseBody());
                return new ArrayList<Member>();
            }
        }
        catch (Exception e)
        {
            logger.error("getMembers error, ", e);
            return new ArrayList<Member>();
        }
    }

    public RestfulRsp deleteMember(CloudEnvInfo cloudEnvInfo, String memberId, String poolId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_MEMBERS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_POOLID, poolId);
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_MEMBERID, memberId);
        return operateApI.delete(url, Utils.getHeader(accessBean), null);
    }

    public RestfulRsp updateMember(CloudEnvInfo cloudEnvInfo, String memberId, String body, String poolId)
            throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_MEMBERS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_POOLID, poolId);
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_MEMBERID, memberId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public Member getMember(CloudEnvInfo cloudEnvInfo, String memberId, String poolId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_MEMBERS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_POOLID, poolId);
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_MEMBERID, memberId);
        RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            MemberWrapper ruleWrapper = JSON.parseObject(rsp.getResponseBody(), MemberWrapper.class);
            Member v = ruleWrapper.getMember();
            v.setCloudenv(cloudEnvInfo);
            return v;
        }
        else
        {
            logger.error("getMember failed, response body = " + rsp.getResponseBody());
            return null;
        }
    }

    public RestfulRsp createMember(CloudEnvInfo cloudEnvInfo, String body, String poolId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_MEMBERS;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_POOLID, poolId);
        return operateApI.post(url, Utils.getHeader(accessBean), body);
    }

    public List<HealthMonitor> getHealthMonitors(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<HealthMonitor>();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_HEALTH_MONITORS;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                HealthMonitorsv2 healthMonitors = JSON.parseObject(rsp.getResponseBody(), HealthMonitorsv2.class);
                return healthMonitors.getHealthmonitors();
            }
            else
            {
                logger.error("getHealthMonitors failed, response body = ", rsp.getResponseBody());
                return new ArrayList<HealthMonitor>();
            }
        }
        catch (Exception e)
        {
            logger.error("getHealthMonitors error, ", e);
            return new ArrayList<HealthMonitor>();
        }
    }

    public RestfulRsp deleteHealthMonitor(CloudEnvInfo cloudEnvInfo, String monitorId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_HEALTH_MONITORS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_MONITORID, monitorId);
        return operateApI.delete(url, Utils.getHeader(accessBean), null);
    }

    public RestfulRsp updateHealthMonitor(CloudEnvInfo cloudEnvInfo, String monitorId, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_HEALTH_MONITORS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_MONITORID, monitorId);
        return operateApI.put(url, Utils.getHeader(accessBean), body);
    }

    public HealthMonitor getHealthMonitor(CloudEnvInfo cloudEnvInfo, String monitorId) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_HEALTH_MONITORS_ID;
        url = url.replaceAll(CommonConstants.Neutron.REPLACE_PART_MONITORID, monitorId);
        RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
        if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
        {
            HealthMonitorv2Wrapper ruleWrapper = JSON.parseObject(rsp.getResponseBody(), HealthMonitorv2Wrapper.class);
            HealthMonitor v = ruleWrapper.getHealthmonitor();
            v.setCloudenv(cloudEnvInfo);
            return v;
        }
        else
        {
            logger.error("getHealthMonitor failed, response body = " + rsp.getResponseBody());
            return null;
        }
    }

    public RestfulRsp createHealthMonitor(CloudEnvInfo cloudEnvInfo, String body) throws Exception
    {
        AccessBean accessBean = authService.getAuthInfo(cloudEnvInfo);
        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.V2_HEALTH_MONITORS;
        return operateApI.post(url, Utils.getHeader(accessBean), body);
    }

    public List<Subnet> getSubnetList(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<Subnet>();
        }

        String url = accessBean.getNeutronUrl() + CommonConstants.Neutron.SUBNETS;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                Subnets subnets = JSON.parseObject(rsp.getResponseBody(), Subnets.class);
                return subnets.getSubnets();
            }
            else
            {
                logger.error("getSubnetList failed, response body = ", rsp.getResponseBody());
                return new ArrayList<Subnet>();
            }
        }
        catch (Exception e)
        {
            logger.error("getSubnetList error, ", e);
            return new ArrayList<Subnet>();
        }
    }

    public List<Member> getCandidateMemberList(CloudEnvInfo cloudEnvInfo, boolean allTenants)
    {
        AccessBean accessBean = null;
        try
        {
            accessBean = authService.getAuthInfo(cloudEnvInfo);
        }
        catch (Exception e)
        {
            logger.error("Fail to getAuthInfo.", e);
            return new ArrayList<Member>();
        }

        List<Member> memberList = new ArrayList<Member>();

        Map<String, Server> serverMap = new HashMap<String, Server>();
        List<Server> serverList = new ArrayList<Server>();
        String url = accessBean.getNovaUrl() + CommonConstants.Nova.SERVERS_DETAIL;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                Servers servers = JSON.parseObject(rsp.getResponseBody(), Servers.class);
                if (null != servers.getServers())
                {
                    serverList.addAll(servers.getServers());
                }
            }
        }
        catch (Exception e)
        {
            logger.error("getServerList error, ", e);
        }

        for (Server server : serverList)
        {
            serverMap.put(server.getId(), server);
        }

        List<Port> portList = new ArrayList<Port>();
        url = accessBean.getNeutronUrl() + CommonConstants.Neutron.PORTS;
        if (allTenants)
        {
            url = url + "?all_tenants=True";
        }
        try
        {
            url = url + "?tenant_id=" + cloudEnvInfo.getTenantId();
            RestfulRsp rsp = operateApI.get(url, Utils.getHeader(accessBean), null);
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                Ports ports = JSON.parseObject(rsp.getResponseBody(), Ports.class);
                if (null != ports.getPorts())
                {
                    portList.addAll(ports.getPorts());
                }
            }
        }
        catch (Exception e)
        {
            logger.error("getPortList error, ", e);
        }

        for (Port port : portList)
        {
            if (port.getDeviceOwner().startsWith("compute:"))
            {
                List<Ip> ipList = port.getFixedIps();
                if (null != ipList && !ipList.isEmpty())
                {
                    for (Ip ip : ipList)
                    {
                        Member member = new Member();
                        member.setSubnetId(ip.getSubnetId());
                        member.setAddress(ip.getIpAddress());
                        member.setStatus(serverMap.get(port.getDeviceId()).getName());
                        memberList.add(member);
                    }
                }
            }
        }

        return memberList;
    }
}
