/**
 * 
 */
package com.zte.vdirector.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zte.vdirector.api.ResourceApi;
import com.zte.vdirector.client.microservice.ServiceBase;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.frame.constants.CommonConstants;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Operate  
 * </p>  
 * <p>   
 * 类名称：ResourceUsageService   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10138528   
 * </p>  
 * <p>  
 * 创建时间：2016-11-15 下午2:24:45 
 * </p>  
 * <p>    
 * 修改人：10138528  
 * </p>  
 * <p>  
 * 修改时间：2016-11-15 下午2:24:45  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Service
public class ResourceUsageService
{
    public Logger logger = LoggerFactory.getLogger(this.getClass());

    //    private static List<String> subnetCm2 = Collections.synchronizedList(new ArrayList<String>());
    //    private static List<String> subnetENI = Collections.synchronizedList(new ArrayList<String>());
    //    private static List<String> subnetB = Collections.synchronizedList(new ArrayList<String>());
    //    private static List<String> subnetInternet = Collections.synchronizedList(new ArrayList<String>());

    @Resource
    private AuthService authService;

    @Resource
    private ResourceApi resourceApi;

    @Resource
    private OrgService orgService;

    @Resource
    private ServiceBase serviceBase;

    @Resource
    private CommonService commonService;

    @Resource
    private ResourceService resourceServie;

    @Resource
    private NetworkService networkService;

    public Map<String, Object> getOrgUsages(String orgId)
    {
        Map<String, Object> orgUsages = new HashMap<String, Object>();
        String orgName = "";
        List<Map<String, Object>> orgs = orgService.getOrgs();
        if (null != orgs)
        {
            for (Map<String, Object> tempOrg : orgs)
            {
                if (null != tempOrg && tempOrg.containsKey("id")
                        && StringUtils.equals(orgId, tempOrg.get("id").toString()))
                {
                    orgName = tempOrg.get("name").toString();
                    break;
                }
            }
        }

        JSONArray vdcs = orgService.getVdcsInOrg(orgId);
        if (null != vdcs)
        {
            getVdcsUsages(orgId, orgName, vdcs, orgUsages);
        }

        return orgUsages;
    }

    public Map<String, Object> getProjectUsages(String projectId, String projectName)
    {
        Map<String, Object> orgUsages = new HashMap<String, Object>();
        JSONArray vdcs = orgService.getVdcsInProject(projectId);
        if (null != vdcs)
        {
            getVdcsUsages(projectId, projectName, vdcs, orgUsages);
        }

        return orgUsages;
    }

    private void getVdcsUsages(String orgId, String orgName, JSONArray vdcs, Map<String, Object> orgUsages)
    {
        List<Map<String, Object>> vdcList = new ArrayList<Map<String, Object>>();
        Map<String, Object> vdcMap = new HashMap<String, Object>();
        double orgCpuNumTotal = 0;
        double orgCpuUtilTotal = 0;
        double orgMemAllTotal = 0;
        double orgMemUtilTotal = 0;
        double orgDiskAllTotal = 0;
        double orgDiskUtilTotal = 0;
        double orgNetInTotal = 0;
        double orgNetOutTotal = 0;
        Map<String, Object> vdc;
        for (Object vdcId : vdcs)
        {
            if (null != vdcId)
            {
                vdcMap = new HashMap<String, Object>();
                vdc = getVdcUsages(vdcId.toString());
                if (null != vdc)
                {
                    if (vdc.containsKey("cpuNumTotal"))
                    {
                        double cpuNumTotal = (double) vdc.get("cpuNumTotal");
                        orgCpuNumTotal += cpuNumTotal;
                    }
                    if (vdc.containsKey("cpuUtilTotal"))
                    {
                        double cpuUtilTotal = (double) vdc.get("cpuUtilTotal");
                        orgCpuUtilTotal += cpuUtilTotal;
                    }
                    if (vdc.containsKey("memAllTotal"))
                    {
                        double memAllTotal = (double) vdc.get("memAllTotal");
                        orgMemAllTotal += memAllTotal;
                    }
                    if (vdc.containsKey("memUtilTotal"))
                    {
                        double memUtilTotal = (double) vdc.get("memUtilTotal");
                        orgMemUtilTotal += memUtilTotal;
                    }
                    if (vdc.containsKey("diskAllTotal"))
                    {
                        double diskAllTotal = (double) vdc.get("diskAllTotal");
                        orgDiskAllTotal += diskAllTotal;
                    }
                    if (vdc.containsKey("diskUtilTotal"))
                    {
                        double diskUtilTotal = (double) vdc.get("diskUtilTotal");
                        orgDiskUtilTotal += diskUtilTotal;
                    }
                    if (vdc.containsKey("netInTotal"))
                    {
                        double netInTotal = (double) vdc.get("netInTotal");
                        orgNetInTotal += netInTotal;
                    }
                    if (vdc.containsKey("netOutTotal"))
                    {
                        double netOutTotal = (double) vdc.get("netOutTotal");
                        orgNetOutTotal += netOutTotal;
                    }

                    vdcMap.put("vdcId", vdc.get("id"));
                    vdcMap.put("vdcName", vdc.get("name"));
                    vdcMap.put("cpu", vdc.get("cpu"));
                    vdcMap.put("memory", vdc.get("memory"));
                    vdcMap.put("disk", vdc.get("disk"));
                    vdcMap.put("netIn", vdc.get("netIn"));
                    vdcMap.put("netOut", vdc.get("netOut"));

                    vdcList.add(vdcMap);
                }
            }
        }

        orgUsages.put("orgId", orgId);
        orgUsages.put("orgName", orgName);
        orgUsages.put("cpu", orgCpuNumTotal != 0 ? orgCpuUtilTotal * 1d / orgCpuNumTotal : 0);
        orgUsages.put("memory", orgMemAllTotal != 0 ? orgMemUtilTotal * 1d / orgMemAllTotal : 0);
        orgUsages.put("disk", orgDiskAllTotal != 0 ? orgDiskUtilTotal * 1d / orgDiskAllTotal : 0);
        orgUsages.put("netIn", orgNetInTotal);
        orgUsages.put("netOut", orgNetOutTotal);
        orgUsages.put("vdcs", vdcList);
    }

    public Map<String, Object> getVdcUsages(String vdcId)
    {
        JSONObject vdc = orgService.getVdcInfo(vdcId);
        Map<String, Object> vdcUsages = new HashMap<String, Object>();

        vdcUsages.put("id", vdc.getString("id"));
        vdcUsages.put("name", vdc.getString("name"));

        double cpuNumTotal = 0;
        double cpuUtilTotal = 0;
        double memAllTotal = 0;
        double memUtilTotal = 0;
        double diskAllTotal = 0;
        double diskUtilTotal = 0;
        double netInTotal = 0;
        double netOutTotal = 0;
        List<Map<String, Object>> vmUsages = new ArrayList<Map<String, Object>>();
        List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdc.getString("id"), "");
        if (null != cloudEnvList && !cloudEnvList.isEmpty())
        {
            Map<String, Object> vmUsage;
            for (CloudEnvInfo cloudEnvInfo : cloudEnvList)
            {
                JSONArray resourceUsages = getResourceUsage(cloudEnvInfo);
                Map<String, List<Map<String, Object>>> portsUsages = getPortsUsage(cloudEnvInfo);
                if (null != resourceUsages)
                {
                    vmUsage = new HashMap<String, Object>();
                    for (Object temp : resourceUsages)
                    {
                        if (null != temp)
                        {
                            JSONObject resourceUsage = (JSONObject) temp;
                            vmUsage.put("vmId", resourceUsage.getString("objectId"));
                            vmUsage.put("vmName", resourceUsage.getString("objectName"));
                            JSONArray counters = resourceUsage.getJSONArray("counters");
                            if (null != counters)
                            {
                                double cpuNum = 0;
                                double cpuUtil = 0;
                                double memAll = 0;
                                double memUtil = 0;
                                double diskAll = 0;
                                double diskUtil = 0;
                                for (Object tempCounter : counters)
                                {
                                    if (null != tempCounter)
                                    {
                                        JSONObject counter = (JSONObject) tempCounter;
                                        if (StringUtils.equals(counter.getString("meterItem"), "VCPU_NUM"))
                                        {
                                            cpuNum = counter.getDoubleValue("meterValue");
                                            cpuNumTotal += cpuNum;
                                        }
                                        else if (StringUtils.equals(counter.getString("meterItem"), "CPU_UTIL"))
                                        {
                                            cpuUtil = counter.getDoubleValue("meterValue");
                                            vmUsage.put("cpu", cpuUtil);
                                        }
                                        else if (StringUtils.equals(counter.getString("meterItem"), "MEM_ALL"))
                                        {
                                            memAll = counter.getDoubleValue("meterValue");
                                            memAllTotal += memAll;
                                        }
                                        else if (StringUtils.equals(counter.getString("meterItem"), "MEM_UTIL"))
                                        {
                                            memUtil = counter.getDoubleValue("meterValue");
                                            vmUsage.put("memory", memUtil);
                                        }
                                        else if (StringUtils.equals(counter.getString("meterItem"), "DISK_ALL"))
                                        {
                                            diskAll = counter.getDoubleValue("meterValue");
                                            diskAllTotal += diskAll;
                                        }
                                        else if (StringUtils.equals(counter.getString("meterItem"), "DISK_UTIL"))
                                        {
                                            diskUtil = counter.getDoubleValue("meterValue");
                                            vmUsage.put("disk", memUtil);
                                        }
                                    }
                                }

                                if (null != portsUsages && portsUsages.containsKey(resourceUsage.getString("objectId")))
                                {
                                    List<Map<String, Object>> vmNetUsages = portsUsages.get(resourceUsage
                                            .getString("objectId"));
                                    if (null != vmNetUsages)
                                    {
                                        vmUsage.put("net", vmNetUsages);

                                        for (Map<String, Object> vmNetUsage : vmNetUsages)
                                        {
                                            if (vmNetUsage.containsKey("in") && null != vmNetUsage.get("in"))
                                            {
                                                netInTotal += (double) vmNetUsage.get("in");
                                            }
                                            else if (vmNetUsage.containsKey("out") && null != vmNetUsage.get("out"))
                                            {
                                                netOutTotal += (double) vmNetUsage.get("out");
                                            }
                                        }
                                    }
                                }
                                cpuUtilTotal += cpuNum * cpuUtil;
                                memUtilTotal += memAll * memUtil;
                                diskUtilTotal += diskAll * diskUtil;
                            }
                        }
                    }
                }
            }
        }

        vdcUsages.put("cpu", cpuNumTotal != 0 ? cpuUtilTotal * 1d / cpuNumTotal : 0);
        vdcUsages.put("memory", memAllTotal != 0 ? memUtilTotal * 1d / memAllTotal : 0);
        vdcUsages.put("disk", diskAllTotal != 0 ? diskUtilTotal * 1d / diskAllTotal : 0);
        vdcUsages.put("netIn", netInTotal);
        vdcUsages.put("netOut", netOutTotal);

        vdcUsages.put("cpuNumTotal", cpuNumTotal);
        vdcUsages.put("cpuUtilTotal", cpuUtilTotal);
        vdcUsages.put("memAllTotal", memAllTotal);
        vdcUsages.put("memUtilTotal", memUtilTotal);
        vdcUsages.put("diskAllTotal", diskAllTotal);
        vdcUsages.put("diskUtilTotal", diskUtilTotal);
        vdcUsages.put("netInTotal", netInTotal);
        vdcUsages.put("netOutTotal", netOutTotal);

        vdcUsages.put("vms", vmUsages);

        return vdcUsages;
    }

    public JSONArray getResourceUsage(CloudEnvInfo cloudEnvInfo)
    {
        List<Map<String, Object>> vmObjects = new ArrayList<Map<String, Object>>();
        JSONArray vms = resourceServie.getVms(cloudEnvInfo, false);
        if (null != vms && vms.size() > 0)
        {
            Map<String, Object> vmObject = new HashMap<String, Object>();
            for (Object temp : vms)
            {
                JSONObject vm = (JSONObject) temp;
                vmObject.put("id", vm.getString("id"));
                vmObject.put("name", vm.getString("name"));
                vmObject.put("envId", cloudEnvInfo.getEnvId());
                vmObjects.add(vmObject);
            }

            try
            {
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("objects", vmObjects);
                params.put("objectType", "VM");
                params.put("timeInterval", null);
                params.put("period", "60");
                params.put("type", "vim");

                List<String> meterItems = new ArrayList<String>();
                meterItems.add("VCPU_NUM");
                meterItems.add("CPU_UTIL");
                meterItems.add("MEM_ALL");
                meterItems.add("MEM_UTIL");
                meterItems.add("DISK_ALL");
                meterItems.add("DISK_UTIL");

                params.put("meterItems", meterItems);

                Map<String, String> headers = new HashMap<String, String>();
                headers.put("operateuser", "DomainAdmin");

                RestfulRsp response = serviceBase.post(params, headers, CommonConstants.Usage.QUERY_USAGE);
                if (StringUtils.isNotBlank(response.getResponseBody()))
                {
                    JSONObject resp = JSON.parseObject(response.getResponseBody().toString());
                    if (null != resp)
                    {
                        return resp.getJSONArray("contents");
                    }
                }
            }
            catch (Exception e)
            {
                logger.error("fail to get orgs", e);
            }
        }
        return new JSONArray();
    }

    public Map<String, List<Map<String, Object>>> getPortsUsage(CloudEnvInfo cloudEnvInfo)
    {
        //        JSONArray subNetworks = networkService.getSubNetworks(cloudEnvInfo, true);
        //        if (null != subNetworks)
        //        {
        //            JSONObject subNetwork = null;
        //            for (Object temp : subNetworks)
        //            {
        //                if (null != temp)
        //                {
        //                    subNetwork = (JSONObject) temp;
        //                    String name = subNetwork.getString("name");
        //                    if (StringUtils.isNotBlank(name) && name.startsWith("-cm2"))
        //                    {
        //                        subnetCm2.add(subNetwork.getString("id"));
        //                    }
        //                    else if (StringUtils.isNotBlank(name) && name.endsWith("-eni"))
        //                    {
        //                        subnetENI.add(subNetwork.getString("id"));
        //                    }
        //                    else if (StringUtils.isNotBlank(name) && name.startsWith("subnet-b-"))
        //                    {
        //                        subnetB.add(subNetwork.getString("id"));
        //                    }
        //                    else if (StringUtils.isNotBlank(name) && name.startsWith("subnet-internet-pool"))
        //                    {
        //                        subnetInternet.add(subNetwork.getString("id"));
        //                    }
        //                }
        //            }
        //        }

        Map<String, List<Map<String, Object>>> portsUsages = new HashMap<String, List<Map<String, Object>>>();
        List<Map<String, Object>> portObjects = new ArrayList<Map<String, Object>>();
        JSONArray ports = resourceServie.getPrivateIps(cloudEnvInfo, false);
        Map<String, JSONObject> portVms = new HashMap<String, JSONObject>();
        if (null != ports && ports.size() > 0)
        {
            Map<String, Object> portObject = new HashMap<String, Object>();
            for (Object temp : ports)
            {
                JSONObject port = (JSONObject) temp;
                portObject.put("id", port.getString("id"));
                portObject.put("name", port.getString("id"));
                portObject.put("envId", cloudEnvInfo.getEnvId());
                portObjects.add(portObject);

                portVms.put(port.getString("id"), port);
            }

            try
            {
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("objects", portObject);
                params.put("objectType", "VMNETWORK");
                params.put("timeInterval", null);
                params.put("period", "60");
                params.put("type", "vim");

                List<String> meterItems = new ArrayList<String>();
                meterItems.add("VM_PORT_IN_RATE");
                meterItems.add("VM_PORT_OUT_RATE");

                params.put("meterItems", meterItems);

                Map<String, String> headers = new HashMap<String, String>();
                headers.put("operateuser", "DomainAdmin");

                RestfulRsp response = serviceBase.post(params, headers, CommonConstants.Usage.QUERY_USAGE);
                if (StringUtils.isNotBlank(response.getResponseBody()))
                {
                    JSONObject resp = JSON.parseObject(response.getResponseBody().toString());
                    if (null != resp)
                    {
                        JSONArray portUsages = resp.getJSONArray("contents");

                        if (null != portUsages && portUsages.size() > 0)
                        {
                            List<Map<String, Object>> vmPortUsage = new ArrayList<Map<String, Object>>();
                            Map<String, Object> portUsageMap;
                            for (Object temp : portUsages)
                            {
                                if (null != temp)
                                {
                                    JSONObject portUsage = (JSONObject) temp;
                                    JSONObject protInfo = null;
                                    if (null != portVms && portVms.containsKey(portUsage.getString("objectId")))
                                    {
                                        protInfo = portVms.get(portUsage.getString("objectId"));
                                    }

                                    if (null == protInfo)
                                    {
                                        continue;
                                    }

                                    if (portsUsages.containsKey(protInfo.getString("device_id")))
                                    {
                                        vmPortUsage = portsUsages.get(protInfo.getString("device_id"));
                                    }
                                    else
                                    {
                                        vmPortUsage = new ArrayList<Map<String, Object>>();
                                        portsUsages.put(protInfo.getString("device_id"), vmPortUsage);
                                    }

                                    portUsageMap = new HashMap<String, Object>();
                                    portUsageMap.put("mac", portUsage.getString("mac_address"));
                                    portUsageMap.put("portId", portUsage.getString("objectId"));

                                    vmPortUsage.add(portUsageMap);

                                    if (portUsage.containsKey("counters"))
                                    {
                                        JSONArray counters = portUsage.getJSONArray("counters");
                                        if (null != counters)
                                        {
                                            for (Object tempCounter : counters)
                                            {
                                                JSONObject counter = (JSONObject) tempCounter;
                                                if (counter.containsKey("meterItem"))
                                                {
                                                    if (StringUtils.equals(counter.getString("meterItem"),
                                                            "VM_PORT_IN_RATE"))
                                                    {
                                                        portUsageMap.put("in", counter.getDouble("meterValue"));
                                                    }
                                                    else if (StringUtils.equals(counter.getString("meterItem"),
                                                            "VM_PORT_OUT_RATE"))
                                                    {
                                                        portUsageMap.put("out", counter.getDouble("meterValue"));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                logger.error("fail to get orgs", e);
            }
        }

        return portsUsages;
    }
}
