package com.zte.vdirector.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.zte.vdirector.domain.gridqueryparams.GridQueryParams;
import com.zte.vdirector.domain.gridqueryparams.PagingResult;
import com.zte.vdirector.domain.serviceprice.ChargeItemBean;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.response.CommonResponse;
import com.zte.vdirector.service.ServicePriceSerivce;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：ServicePriceController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 上午10:41:15 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 上午10:41:15  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/serviceprices")
public class ServicePriceController extends CommonController
{
    @Resource
    private ServicePriceSerivce servicePriceService;

    @RequestMapping(value = "/{serviceDirectoryId}", method = RequestMethod.GET)
    public Object getChargeItemList(GridQueryParams params, @PathVariable String serviceDirectoryId,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.trace("getChargeItemList: client = " + request.getRemoteHost());

        long beginTime = System.currentTimeMillis();
        logger.info("getChargeItemList: beginTime = " + beginTime);
        try
        {
            List<ChargeItemBean> resp = servicePriceService.getChargeItemList(serviceDirectoryId);
            resp = servicePriceService.recursionChargeItems(resp);
            List<ChargeItemBean> pagingChargeItemList = new ArrayList<ChargeItemBean>();
            if (params != null && params.getLimit() != null)
            {
                if (resp != null && resp.size() > 0)
                {
                    for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resp.size(); i++)
                    {
                        pagingChargeItemList.add(resp.get(i));
                    }
                    long endTime = System.currentTimeMillis();
                    logger.info("getChargeItemList: endTime = " + endTime);
                    logger.info("getChargeItemList: cost = " + (endTime - beginTime));
                    return PagingResult.getResult(pagingChargeItemList, resp.size());
                }
                else
                {
                    long endTime = System.currentTimeMillis();
                    logger.info("getChargeItemList: endTime = " + endTime);
                    logger.info("getChargeItemList: cost = " + (endTime - beginTime));
                    return PagingResult.getResult(pagingChargeItemList, 0);
                }
            }
            else
            {
                long endTime = System.currentTimeMillis();
                logger.info("getChargeItemList: endTime = " + endTime);
                logger.info("getChargeItemList: cost = " + (endTime - beginTime));
                return resp;
            }
        }
        catch (Exception e)
        {
            logger.error("getChargeItemList failed", e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/{chargeItemId}", method = RequestMethod.PUT)
    public Object updateChargeItemPrice(@PathVariable String chargeItemId, @RequestBody String body,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("updateChargeItemPrice: client = " + request.getRemoteHost() + ", chargeItemId = " + chargeItemId
                + ", body = " + body);
        CommonResponse rsp = new CommonResponse();
        try
        {
            ChargeItemBean chargeItem = JSON.parseObject(body, ChargeItemBean.class);
            servicePriceService.updateChargeItemPrice(chargeItem);
            rsp.setSuccess(true);
            super.rptOptLog("serviceprice.operation.modify", null, null, request, response,
                    CommonConstants.SUCCESS_CODE_200);
        }
        catch (Exception e)
        {
            logger.error("updateChargeItemPrice error, chargeItemId = " + chargeItemId + ", body = " + body, e);
            rsp.setSuccess(false);
            rsp.setMessage(e.getMessage());
            super.rptOptLog("serviceprice.operation.modify", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
        }
        return rsp;
    }
}
