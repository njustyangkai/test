package com.zte.vdirector.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zte.vdirector.domain.gridqueryparams.GridQueryParams;
import com.zte.vdirector.domain.gridqueryparams.PagingResult;
import com.zte.vdirector.domain.servicedirectory.ServiceDirectoryBean;
import com.zte.vdirector.frame.response.CommonResponse;
import com.zte.vdirector.service.ServiceDirectorySerivce;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：ServiceDirectoryController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 上午10:41:15 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 上午10:41:15  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/servicedirectorys")
public class ServiceDirectoryController extends CommonController
{
    @Resource
    private ServiceDirectorySerivce serviceDirectoryService;

    @RequestMapping(value = "", method = RequestMethod.GET)
    public Object getServiceDirectoryList(GridQueryParams params, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.trace("get service directory list: client = " + request.getRemoteHost());
        try
        {
            List<ServiceDirectoryBean> resp = serviceDirectoryService.listServiceDirectorys();
            List<ServiceDirectoryBean> pagingTicketList = new ArrayList<ServiceDirectoryBean>();
            if (params != null && params.getLimit() != null)
            {
                if (resp != null && resp.size() > 0)
                {
                    for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resp.size(); i++)
                    {
                        pagingTicketList.add(resp.get(i));
                    }
                    return PagingResult.getResult(pagingTicketList, resp.size());
                }
                else
                {
                    return PagingResult.getResult(pagingTicketList, 0);
                }
            }
            else
            {
                return resp;
            }
        }
        catch (Exception e)
        {
            logger.error("get service directory list failed", e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public Object getServiceDirectoryDetail(@PathVariable String id, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.trace("get service directory detail: client = " + request.getRemoteHost());
        try
        {
            ServiceDirectoryBean serDir = serviceDirectoryService.getServiceDirectoryDetail(id);
            CommonResponse rsp = new CommonResponse();
            rsp.setSuccess(true);
            rsp.setData(serDir);
            return rsp;
        }
        catch (Exception e)
        {
            logger.error("get service directory detail failed", e);
            return new CommonResponse(false, e.getMessage());
        }
    }
}
