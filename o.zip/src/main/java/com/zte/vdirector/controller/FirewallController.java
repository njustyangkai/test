package com.zte.vdirector.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.firewall.Firewall;
import com.zte.vdirector.domain.firewall.FirewallPolicy;
import com.zte.vdirector.domain.firewall.FirewallRule;
import com.zte.vdirector.domain.gridqueryparams.GridQueryParams;
import com.zte.vdirector.domain.gridqueryparams.PagingResult;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.response.CommonResponse;
import com.zte.vdirector.service.CommonService;
import com.zte.vdirector.service.FirewallService;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：FirewallController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年11月8日 上午10:54:35 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年11月8日 上午10:54:35  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/fw")
public class FirewallController extends CommonController
{
    @Resource
    private FirewallService firewallService;

    @Resource
    private CommonService commonService;

    @RequestMapping(value = "/firewalls", method = RequestMethod.GET)
    public Object getFirewalls(GridQueryParams params, HttpServletRequest request, HttpServletResponse response)
    {
        List<Firewall> resultList = new ArrayList<Firewall>();
        String orgId = request.getParameter("orgId");
        String orgType = request.getParameter("orgType");
        List<String> vdcIdList;

        // 组织管理员
        if ("ORG".equals(orgType))
        {
            vdcIdList = commonService.getVdcIdsByOrgId(orgId);
        }
        else
        {
            // 部门管理员
            vdcIdList = commonService.getVdcIdsByProjectId(orgId);
        }

        if (null != vdcIdList)
        {
            for (String vdcId : vdcIdList)
            {
                List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, null);
                if (null != cloudEnvList)
                {
                    for (CloudEnvInfo cloudEnv : cloudEnvList)
                    {
                        List<Firewall> fwList = firewallService.getFirewalls(cloudEnv, false);
                        if (null != fwList)
                        {
                            for (Firewall fw : fwList)
                            {
                                if (params != null && StringUtils.isNotBlank(params.getSearch()))
                                {
                                    // 支持名称模糊查询
                                    if (StringUtils.containsIgnoreCase(fw.getName(), params.getSearch().trim()))
                                    {
                                        fw.setCloudenv(cloudEnv);
                                        fw.setVdcId(vdcId);
                                        resultList.add(fw);
                                    }
                                }
                                else
                                {
                                    fw.setCloudenv(cloudEnv);
                                    fw.setVdcId(vdcId);
                                    resultList.add(fw);
                                }
                            }
                        }
                    }
                }
            }
        }

        List<Firewall> pagingFwList = new ArrayList<Firewall>();
        if (params != null && params.getLimit() != null)
        {
            if (resultList != null && resultList.size() > 0)
            {
                for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resultList.size(); i++)
                {
                    pagingFwList.add(resultList.get(i));
                }
                return PagingResult.getResult(pagingFwList, resultList.size());
            }
            else
            {
                return PagingResult.getResult(pagingFwList, 0);
            }
        }
        else
        {
            return resultList;
        }
    }

    @RequestMapping(value = "/cloudEnv/firewalls", method = RequestMethod.GET)
    public Object getCloudEnvFirewalls(@RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getCloudEnvFirewalls: client = " + request.getRemoteHost() + ", vdcId = " + vdcId
                + ", tenantId = " + tenantId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            List<Firewall> fws = firewallService.getFirewalls(cloudEnvInfo, false);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(fws);
            rsp.setSuccess(true);
            return rsp;
        }
        catch (Exception e)
        {
            logger.error("getCloudEnvFirewalls error, client = " + request.getRemoteHost() + ", vdcId = " + vdcId
                    + ", tenantId = " + tenantId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/firewalls/{firewallId}", method = RequestMethod.GET)
    public Object getFirewallDetail(@PathVariable String firewallId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getFirewallDetail: client = " + request.getRemoteHost() + ", firewallId = " + firewallId
                + ", vdcId = " + vdcId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, firewallId = " + firewallId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            Firewall firewall = firewallService.getFirewall(cloudEnvInfo, firewallId);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(firewall);
            return rsp;
        }
        catch (Exception e)
        {
            logger.error("getFirewallDetail error, firewallId = " + firewallId + ", tenantId = " + tenantId
                    + ", vdcId = " + vdcId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/firewalls/{firewallId}", method = RequestMethod.PUT)
    public Object updateFirewall(@PathVariable String firewallId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @RequestBody String body, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("updateFirewall: client = " + request.getRemoteHost() + ", firewallId = " + firewallId
                + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, firewallId = " + firewallId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.updateFirewall(cloudEnvInfo, firewallId, body);
            super.rptOptLog("fw.operation.modify", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("updateFirewall error, firewallId = " + firewallId + ", tenantId = " + tenantId + ", body = "
                    + body, e);
            super.rptOptLog("fw.operation.modify", null, null, request, response, CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/firewalls/{firewallId}", method = RequestMethod.DELETE)
    public Object deleteFirewall(@PathVariable String firewallId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("deleteFirewall: client = " + request.getRemoteHost() + ", firewallId = " + firewallId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, firewallId = " + firewallId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.deleteFirewall(cloudEnvInfo, firewallId);
            super.rptOptLog("fw.operation.delete", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.DELETE_CODE_204)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("deleteFirewall error, firewallId  = " + firewallId + ", tenantId = " + tenantId, e);
            super.rptOptLog("fw.operation.delete", null, null, request, response, CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/firewalls", method = RequestMethod.POST)
    public Object createFirewall(@RequestBody String body, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("createFirewall: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.createFirewall(cloudEnvInfo, body);
            super.rptOptLog("fw.operation.create", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createFirewall error, body  = " + body, e);
            super.rptOptLog("fw.operation.create", null, null, request, response, CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/policies", method = RequestMethod.GET)
    public Object getPolicies(GridQueryParams params, HttpServletRequest request, HttpServletResponse response)
    {
        List<FirewallPolicy> resultList = new ArrayList<FirewallPolicy>();
        String orgId = request.getParameter("orgId");
        String orgType = request.getParameter("orgType");
        List<String> vdcIdList;

        // 组织管理员
        if ("ORG".equals(orgType))
        {
            vdcIdList = commonService.getVdcIdsByOrgId(orgId);
        }
        else
        {
            // 部门管理员
            vdcIdList = commonService.getVdcIdsByProjectId(orgId);
        }
        if (null != vdcIdList)
        {
            for (String vdcId : vdcIdList)
            {
                List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, null);
                if (null != cloudEnvList)
                {
                    for (CloudEnvInfo cloudEnv : cloudEnvList)
                    {
                        List<FirewallPolicy> pList = firewallService.getPolicys(cloudEnv, false);
                        if (null != pList)
                        {
                            for (FirewallPolicy p : pList)
                            {
                                if (params != null && StringUtils.isNotBlank(params.getSearch()))
                                {
                                    // 支持名称模糊查询
                                    if (StringUtils.containsIgnoreCase(p.getName(), params.getSearch().trim()))
                                    {
                                        p.setCloudenv(cloudEnv);
                                        p.setVdcId(vdcId);
                                        resultList.add(p);
                                    }
                                }
                                else
                                {
                                    p.setCloudenv(cloudEnv);
                                    p.setVdcId(vdcId);
                                    resultList.add(p);
                                }
                            }
                        }
                    }
                }
            }
        }

        List<FirewallPolicy> pagingPolicyList = new ArrayList<FirewallPolicy>();
        if (params != null && params.getLimit() != null)
        {
            if (resultList != null && resultList.size() > 0)
            {
                for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resultList.size(); i++)
                {
                    pagingPolicyList.add(resultList.get(i));
                }
                return PagingResult.getResult(pagingPolicyList, resultList.size());
            }
            else
            {
                return PagingResult.getResult(pagingPolicyList, 0);
            }
        }
        else
        {
            return resultList;
        }
    }

    @RequestMapping(value = "/cloudEnv/policies", method = RequestMethod.GET)
    public Object getCloudEnvPolicies(@RequestHeader("vdcId") String vdcId, @RequestHeader("tenantId") String tenantId,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getCloudEnvPolicies: client = " + request.getRemoteHost() + ", vdcId = " + vdcId + ", tenantId = "
                + tenantId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            List<FirewallPolicy> rules = firewallService.getPolicys(cloudEnvInfo, false);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(rules);
            rsp.setSuccess(true);
            return rsp;
        }
        catch (Exception e)
        {
            logger.error("getCloudEnvPolicies error, client = " + request.getRemoteHost() + ", vdcId = " + vdcId
                    + ", tenantId = " + tenantId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/policies/{policyId}", method = RequestMethod.GET)
    public Object getPolicyDetail(@PathVariable String policyId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getPolicyDetail: client = " + request.getRemoteHost() + ", policyId = " + policyId + ", vdcId = "
                + vdcId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, policyId = " + policyId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            FirewallPolicy policy = firewallService.getPolicy(cloudEnvInfo, policyId);
            policy.setVdcId(vdcId);
            policy.setCloudenv(cloudEnvInfo);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(policy);
            return rsp;
        }
        catch (Exception e)
        {
            logger.error("getPolicyDetail error, policyId = " + policyId + ", tenantId = " + tenantId + ", vdcId = "
                    + vdcId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/policies/{policyId}", method = RequestMethod.PUT)
    public Object updatePolicy(@PathVariable String policyId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @RequestBody String body, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("updatePolicy: client = " + request.getRemoteHost() + ", policyId = " + policyId + ", body = "
                + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, policyId = " + policyId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.updatePolicy(cloudEnvInfo, policyId, body);
            super.rptOptLog("fw.policy.operation.modify", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error(
                    "updatePolicy error, policyId = " + policyId + ", tenantId = " + tenantId + ", body = " + body, e);
            super.rptOptLog("fw.policy.operation.modify", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/policies/{policyId}", method = RequestMethod.DELETE)
    public Object deletePolicy(@PathVariable String policyId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("deletePolicy: client = " + request.getRemoteHost() + ", policyId = " + policyId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, policyId = " + policyId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.deletePolicy(cloudEnvInfo, policyId);
            super.rptOptLog("fw.policy.operation.delete", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.DELETE_CODE_204)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("deletePolicy error, policyId  = " + policyId + ", tenantId = " + tenantId, e);
            super.rptOptLog("fw.policy.operation.delete", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/policies", method = RequestMethod.POST)
    public Object createPolicy(@RequestBody String body, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("createPolicy: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.createPolicy(cloudEnvInfo, body);
            super.rptOptLog("fw.policy.operation.create", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createPolicy error, body  = " + body, e);
            super.rptOptLog("fw.policy.operation.create", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/policies/{policyId}/insertrule", method = RequestMethod.PUT)
    public Object policyInsertRule(@PathVariable String policyId, @RequestBody String body,
            @RequestHeader("vdcId") String vdcId, @RequestHeader("tenantId") String tenantId,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("policyInsertRule: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.policyInsertRule(cloudEnvInfo, policyId, body);
            super.rptOptLog("fw.policy.operation.insert.rule", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("policyInsertRule error, body  = " + body, e);
            super.rptOptLog("fw.policy.operation.insert.rule", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/policies/{policyId}/removerule", method = RequestMethod.PUT)
    public Object policyRemoveRule(@PathVariable String policyId, @RequestBody String body,
            @RequestHeader("vdcId") String vdcId, @RequestHeader("tenantId") String tenantId,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("policyRemoveRule: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.policyRemoveRule(cloudEnvInfo, policyId, body);
            super.rptOptLog("fw.policy.operation.remove.rule", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("policyRemoveRule error, body  = " + body, e);
            super.rptOptLog("fw.policy.operation.remove.rule", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/rules", method = RequestMethod.GET)
    public Object getRules(GridQueryParams params, HttpServletRequest request, HttpServletResponse response)
    {
        List<FirewallRule> resultList = new ArrayList<FirewallRule>();
        String orgId = request.getParameter("orgId");
        String orgType = request.getParameter("orgType");
        List<String> vdcIdList;

        // 组织管理员
        if ("ORG".equals(orgType))
        {
            vdcIdList = commonService.getVdcIdsByOrgId(orgId);
        }
        else
        {
            // 部门管理员
            vdcIdList = commonService.getVdcIdsByProjectId(orgId);
        }
        if (null != vdcIdList)
        {
            for (String vdcId : vdcIdList)
            {
                List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, null);
                if (null != cloudEnvList)
                {
                    for (CloudEnvInfo cloudEnv : cloudEnvList)
                    {
                        List<FirewallRule> rList = firewallService.getRules(cloudEnv, false, null);
                        if (null != rList)
                        {
                            for (FirewallRule r : rList)
                            {
                                if (params != null && StringUtils.isNotBlank(params.getSearch()))
                                {
                                    // 支持名称和协议模糊查询
                                    if (StringUtils.containsIgnoreCase(r.getName(), params.getSearch().trim())
                                            || StringUtils.containsIgnoreCase(r.getProtocol(), params.getSearch()
                                                    .trim()))
                                    {
                                        r.setCloudenv(cloudEnv);
                                        r.setVdcId(vdcId);
                                        resultList.add(r);
                                    }
                                }
                                else
                                {
                                    r.setCloudenv(cloudEnv);
                                    r.setVdcId(vdcId);
                                    resultList.add(r);
                                }
                            }
                        }
                    }
                }
            }
        }

        List<FirewallRule> pagingPolicyList = new ArrayList<FirewallRule>();
        if (params != null && params.getLimit() != null)
        {
            if (resultList != null && resultList.size() > 0)
            {
                for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resultList.size(); i++)
                {
                    pagingPolicyList.add(resultList.get(i));
                }
                return PagingResult.getResult(pagingPolicyList, resultList.size());
            }
            else
            {
                return PagingResult.getResult(pagingPolicyList, 0);
            }
        }
        else
        {
            return resultList;
        }
    }

    @RequestMapping(value = "/cloudEnv/rules", method = RequestMethod.GET)
    public Object getCloudEnvRules(@RequestHeader("vdcId") String vdcId, @RequestHeader("tenantId") String tenantId,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getCloudEnvRules: client = " + request.getRemoteHost() + ", vdcId = " + vdcId + ", tenantId = "
                + tenantId);
        try
        {
            String policyId = request.getParameter("policyId");
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            List<FirewallRule> rules = firewallService.getRules(cloudEnvInfo, false, policyId);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(rules);
            rsp.setSuccess(true);
            return rsp;
        }
        catch (Exception e)
        {
            logger.error("getCloudEnvRules error, client = " + request.getRemoteHost() + ", vdcId = " + vdcId
                    + ", tenantId = " + tenantId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/rules/{ruleId}", method = RequestMethod.GET)
    public Object getRuleDetail(@PathVariable String ruleId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getRuleDetail: client = " + request.getRemoteHost() + ", ruleId = " + ruleId + ", vdcId = "
                + vdcId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, ruleId = " + ruleId + ", tenantId = " + tenantId + ", vdcId = "
                        + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            FirewallRule rule = firewallService.getRule(cloudEnvInfo, ruleId);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(rule);
            return rsp;
        }
        catch (Exception e)
        {
            logger.error("getRuleDetail error, ruleId = " + ruleId + ", tenantId = " + tenantId + ", vdcId = " + vdcId,
                    e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/rules/{ruleId}", method = RequestMethod.PUT)
    public Object updateRule(@PathVariable String ruleId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @RequestBody String body, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("updateRule: client = " + request.getRemoteHost() + ", ruleId = " + ruleId + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, ruleId = " + ruleId + ", tenantId = " + tenantId + ", vdcId = "
                        + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.updateRule(cloudEnvInfo, ruleId, body);
            super.rptOptLog("fw.rule.operation.modify", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("updateRule error, ruleId = " + ruleId + ", tenantId = " + tenantId + ", body = " + body, e);
            super.rptOptLog("fw.rule.operation.modify", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/rules/{ruleId}", method = RequestMethod.DELETE)
    public Object deleteRule(@PathVariable String ruleId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("deleteRule: client = " + request.getRemoteHost() + ", ruleId = " + ruleId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, ruleId = " + ruleId + ", tenantId = " + tenantId + ", vdcId = "
                        + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.deleteRule(cloudEnvInfo, ruleId);
            super.rptOptLog("fw.rule.operation.delete", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.DELETE_CODE_204)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("deleteRule error, ruleId  = " + ruleId + ", tenantId = " + tenantId, e);
            super.rptOptLog("fw.rule.operation.delete", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/rules", method = RequestMethod.POST)
    public Object createRule(@RequestBody String body, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("createRule: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = firewallService.createRule(cloudEnvInfo, body);
            super.rptOptLog("fw.rule.operation.create", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createRule error, body  = " + body, e);
            super.rptOptLog("fw.rule.operation.create", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }
}
