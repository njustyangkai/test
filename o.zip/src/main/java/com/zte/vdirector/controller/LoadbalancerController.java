package com.zte.vdirector.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.gridqueryparams.GridQueryParams;
import com.zte.vdirector.domain.gridqueryparams.PagingResult;
import com.zte.vdirector.domain.loadbalancer.HealthMonitor;
import com.zte.vdirector.domain.loadbalancer.Listener;
import com.zte.vdirector.domain.loadbalancer.LoadBalancer;
import com.zte.vdirector.domain.loadbalancer.Member;
import com.zte.vdirector.domain.loadbalancer.Pool;
import com.zte.vdirector.domain.subnet.Subnet;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.response.CommonResponse;
import com.zte.vdirector.service.CommonService;
import com.zte.vdirector.service.LoadBalancerService;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：LoadbalancerController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年11月9日 下午3:19:51 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年11月9日 下午3:19:51  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/lbaas")
public class LoadbalancerController extends CommonController
{
    @Resource
    private LoadBalancerService loadBalancerService;

    @Resource
    private CommonService commonService;

    @RequestMapping(value = "/loadbalancers", method = RequestMethod.GET)
    public Object getLoadBalancers(GridQueryParams params, HttpServletRequest request, HttpServletResponse response)
    {
        Object objResult;
        List<LoadBalancer> resultList = new ArrayList<LoadBalancer>();
        String orgId = request.getParameter("orgId");
        String orgType = request.getParameter("orgType");
        List<String> vdcIdList;

        // 组织管理员
        if ("ORG".equals(orgType))
        {
            vdcIdList = commonService.getVdcIdsByOrgId(orgId);
        }
        else
        {
            // 部门管理员
            vdcIdList = commonService.getVdcIdsByProjectId(orgId);
        }

        if (null != vdcIdList)
        {
            for (String vdcId : vdcIdList)
            {
                List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, null);
                if (null != cloudEnvList)
                {
                    for (CloudEnvInfo cloudEnv : cloudEnvList)
                    {
                        List<Subnet> subnetList = loadBalancerService.getSubnetList(cloudEnv, false);
                        Map<String, String> subnetMap = new HashMap<String, String>();
                        if (null != subnetList)
                        {
                            for (Subnet subnet : subnetList)
                            {
                                subnetMap.put(subnet.getId(), subnet.getName());
                            }
                        }
                        List<LoadBalancer> lbList = loadBalancerService.getLoadBalancers(cloudEnv, false);
                        if (null != lbList)
                        {
                            for (LoadBalancer lb : lbList)
                            {
                                lb.setVipSubnetName(subnetMap.get(lb.getVipSubnetId()));
                                if (params != null && StringUtils.isNotBlank(params.getSearch()))
                                {
                                    // 支持名称模糊查询
                                    if (StringUtils.containsIgnoreCase(lb.getName(), params.getSearch().trim()))
                                    {
                                        lb.setCloudenv(cloudEnv);
                                        lb.setVdcId(vdcId);
                                        resultList.add(lb);
                                    }
                                }
                                else
                                {
                                    lb.setCloudenv(cloudEnv);
                                    lb.setVdcId(vdcId);
                                    resultList.add(lb);
                                }
                            }
                        }
                    }
                }
            }
        }

        List<LoadBalancer> pagingLbList = new ArrayList<LoadBalancer>();
        if (params != null && params.getLimit() != null)
        {
            if (resultList != null && resultList.size() > 0)
            {
                for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resultList.size(); i++)
                {
                    pagingLbList.add(resultList.get(i));
                }
                objResult = PagingResult.getResult(pagingLbList, resultList.size());
            }
            else
            {
                objResult = PagingResult.getResult(pagingLbList, 0);
            }
        }
        else
        {
            objResult = resultList;
        }
        return JSON.toJSONString(objResult, SerializerFeature.DisableCircularReferenceDetect);
    }

    @RequestMapping(value = "/cloudEnv/loadbalancers", method = RequestMethod.GET)
    public Object getCloudEnvLoadBalancers(@RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getCloudEnvLoadBalancers: client = " + request.getRemoteHost() + ", vdcId = " + vdcId
                + ", tenantId = " + tenantId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            List<LoadBalancer> vlbs = loadBalancerService.getLoadBalancers(cloudEnvInfo, false);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(vlbs);
            rsp.setSuccess(true);
            return rsp;
        }
        catch (Exception e)
        {
            logger.error("getCloudEnvLoadBalancers error, client = " + request.getRemoteHost() + ", vdcId = " + vdcId
                    + ", tenantId = " + tenantId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/loadbalancers/{loadbalancerId}", method = RequestMethod.GET)
    public Object getLoadBalancerDetail(@PathVariable String loadbalancerId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getLoadBalancerDetail: client = " + request.getRemoteHost() + ", loadbalancerId = "
                + loadbalancerId + ", vdcId = " + vdcId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, loadbalancerId = " + loadbalancerId + ", tenantId = "
                        + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            LoadBalancer loadBalancer = loadBalancerService.getLoadBalancer(cloudEnvInfo, loadbalancerId);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(loadBalancer);
            return JSON.toJSONString(rsp);
        }
        catch (Exception e)
        {
            logger.error("getLoadBalancerDetail error, loadbalancerId = " + loadbalancerId + ", tenantId = " + tenantId
                    + ", vdcId = " + vdcId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/loadbalancers/{loadbalancerId}", method = RequestMethod.PUT)
    public Object updateLoadBalancer(@PathVariable String loadbalancerId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @RequestBody String body, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("updateLoadBalancer: client = " + request.getRemoteHost() + ", loadbalancerId = " + loadbalancerId
                + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, loadbalancerId = " + loadbalancerId + ", tenantId = "
                        + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.updateLoadBalancer(cloudEnvInfo, loadbalancerId, body);
            super.rptOptLog("vlb.operation.modify", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("updateLoadBalancer error, loadbalancerId = " + loadbalancerId + ", tenantId = " + tenantId
                    + ", body = " + body, e);
            super.rptOptLog("vlb.operation.modify", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/loadbalancers/{loadbalancerId}", method = RequestMethod.DELETE)
    public Object deleteLoadBalancer(@PathVariable String loadbalancerId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("deleteLoadBalancer: client = " + request.getRemoteHost() + ", loadbalancerId = " + loadbalancerId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, loadbalancerId = " + loadbalancerId + ", tenantId = "
                        + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.deleteLoadBalancer(cloudEnvInfo, loadbalancerId);
            super.rptOptLog("vlb.operation.delete", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.DELETE_CODE_204)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("deleteLoadBalancer error, loadbalancerId  = " + loadbalancerId + ", tenantId = " + tenantId,
                    e);
            super.rptOptLog("vlb.operation.delete", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/loadbalancers", method = RequestMethod.POST)
    public Object createLoadBalancer(@RequestBody String body, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("createLoadBalancer: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.createLoadBalancer(cloudEnvInfo, body);
            super.rptOptLog("vlb.operation.create", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createLoadBalancer error, body  = " + body, e);
            super.rptOptLog("vlb.operation.create", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/listeners", method = RequestMethod.GET)
    public Object getListeners(GridQueryParams params, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        Object objResult;
        List<Listener> resultList = new ArrayList<Listener>();
        String loadbalancerId = request.getParameter("loadbalancerId");
        CloudEnvInfo cloudEnvInfo = null;
        List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
        if (null != cloudEnvList && !cloudEnvList.isEmpty())
        {
            cloudEnvInfo = cloudEnvList.get(0);
        }
        else
        {
            logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
            objResult = new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
        }
        List<Listener> listenerList = loadBalancerService.getListeners(cloudEnvInfo, false);
        if (null != listenerList)
        {
            for (Listener listener : listenerList)
            {
                if (StringUtils.isNotBlank(loadbalancerId))
                {
                    boolean found = false;
                    List<LoadBalancer> vlbs = listener.getLoadbalancers();
                    if (null != vlbs && !vlbs.isEmpty())
                    {
                        for (LoadBalancer vlb : vlbs)
                        {
                            if (StringUtils.equals(vlb.getId(), loadbalancerId))
                            {
                                found = true;
                            }
                        }
                    }
                    if (!found)
                    {
                        continue;
                    }
                }
                if (params != null && StringUtils.isNotBlank(params.getSearch()))
                {
                    // 支持名称模糊查询
                    if (StringUtils.containsIgnoreCase(listener.getName(), params.getSearch().trim()))
                    {
                        listener.setCloudenv(cloudEnvInfo);
                        listener.setVdcId(vdcId);
                        resultList.add(listener);
                    }
                }
                else
                {
                    listener.setCloudenv(cloudEnvInfo);
                    listener.setVdcId(vdcId);
                    resultList.add(listener);
                }
            }
        }

        List<Listener> pagingListenerList = new ArrayList<Listener>();
        if (params != null && params.getLimit() != null)
        {
            if (resultList != null && resultList.size() > 0)
            {
                for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resultList.size(); i++)
                {
                    pagingListenerList.add(resultList.get(i));
                }
                objResult = PagingResult.getResult(pagingListenerList, resultList.size());
            }
            else
            {
                objResult = PagingResult.getResult(pagingListenerList, 0);
            }
        }
        else
        {
            objResult = resultList;
        }
        return JSON.toJSONString(objResult, SerializerFeature.DisableCircularReferenceDetect);
    }

    @RequestMapping(value = "/listeners/{listenerId}", method = RequestMethod.GET)
    public Object getListenerDetail(@PathVariable String listenerId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getListenerDetail: client = " + request.getRemoteHost() + ", listenerId = " + listenerId
                + ", vdcId = " + vdcId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, listenerId = " + listenerId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            Listener listener = loadBalancerService.getListener(cloudEnvInfo, listenerId);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(listener);
            return JSON.toJSONString(rsp);
        }
        catch (Exception e)
        {
            logger.error("getListenerDetail error, listenerId = " + listenerId + ", tenantId = " + tenantId
                    + ", vdcId = " + vdcId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/listeners/{listenerId}", method = RequestMethod.PUT)
    public Object updateListener(@PathVariable String listenerId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @RequestBody String body, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("updateListener: client = " + request.getRemoteHost() + ", listenerId = " + listenerId
                + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, listenerId = " + listenerId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.updateListener(cloudEnvInfo, listenerId, body);
            super.rptOptLog("vlb.listener.operation.modify", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("updateListener error, listenerId = " + listenerId + ", tenantId = " + tenantId + ", body = "
                    + body, e);
            super.rptOptLog("vlb.listener.operation.modify", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/listeners/{listenerId}", method = RequestMethod.DELETE)
    public Object deleteListener(@PathVariable String listenerId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("deleteListener: client = " + request.getRemoteHost() + ", listenerId = " + listenerId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, listenerId = " + listenerId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.deleteListener(cloudEnvInfo, listenerId);
            super.rptOptLog("vlb.listener.operation.delete", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.DELETE_CODE_204)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("deleteListener error, listenerId  = " + listenerId + ", tenantId = " + tenantId, e);
            super.rptOptLog("vlb.listener.operation.delete", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/listeners", method = RequestMethod.POST)
    public Object createListener(@RequestBody String body, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("createListener: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.createListener(cloudEnvInfo, body);
            super.rptOptLog("vlb.listener.operation.create", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createListener error, body  = " + body, e);
            super.rptOptLog("vlb.listener.operation.create", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    /*@RequestMapping(value = "/pools", method = RequestMethod.GET)
    public Object getPools(GridQueryParams params, HttpServletRequest request, HttpServletResponse response)
    {
        List<Pool> resultList = new ArrayList<Pool>();
        String orgId = request.getParameter("orgId");
        String orgType = request.getParameter("orgType");
        List<String> vdcIdList;

        // 组织管理员
        if ("ORG".equals(orgType))
        {
            vdcIdList = commonService.getVdcIdsByOrgId(orgId);
        }
        else
        {
            // 部门管理员
            vdcIdList = commonService.getVdcIdsByProjectId(orgId);
        }
        if (null != vdcIdList)
        {
            for (String vdcId : vdcIdList)
            {
                List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, null);
                if (null != cloudEnvList)
                {
                    for (CloudEnvInfo cloudEnv : cloudEnvList)
                    {
                        List<Pool> poolList = loadBalancerService.getPools(cloudEnv, false);
                        if (null != poolList)
                        {
                            for (Pool pool : poolList)
                            {
                                if (params != null && StringUtils.isNotBlank(params.getSearch()))
                                {
                                    // 支持名称模糊查询
                                    if (StringUtils.containsIgnoreCase(pool.getName(), params.getSearch().trim()))
                                    {
                                        pool.setCloudenv(cloudEnv);
                                        pool.setVdcId(vdcId);
                                        resultList.add(pool);
                                    }
                                }
                                else
                                {
                                    pool.setCloudenv(cloudEnv);
                                    pool.setVdcId(vdcId);
                                    resultList.add(pool);
                                }
                            }
                        }
                    }
                }
            }
        }

        List<Pool> pagingPoolList = new ArrayList<Pool>();
        if (params != null && params.getLimit() != null)
        {
            if (resultList != null && resultList.size() > 0)
            {
                for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resultList.size(); i++)
                {
                    pagingPoolList.add(resultList.get(i));
                }
                return PagingResult.getResult(pagingPoolList, resultList.size());
            }
            else
            {
                return PagingResult.getResult(pagingPoolList, 0);
            }
        }
        else
        {
            return resultList;
        }
    }*/

    @RequestMapping(value = "/pools/{poolId}", method = RequestMethod.GET)
    public Object getPoolDetail(@PathVariable String poolId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getPoolDetail: client = " + request.getRemoteHost() + ", poolId = " + poolId + ", vdcId = "
                + vdcId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, poolId = " + poolId + ", tenantId = " + tenantId + ", vdcId = "
                        + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            Pool pool = loadBalancerService.getPool(cloudEnvInfo, poolId);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(pool);
            return JSON.toJSONString(rsp);
        }
        catch (Exception e)
        {
            logger.error("getPoolDetail error, poolId = " + poolId + ", tenantId = " + tenantId + ", vdcId = " + vdcId,
                    e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/pools/{poolId}", method = RequestMethod.PUT)
    public Object updatePool(@PathVariable String poolId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @RequestBody String body, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("updatePool: client = " + request.getRemoteHost() + ", poolId = " + poolId + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, poolId = " + poolId + ", tenantId = " + tenantId + ", vdcId = "
                        + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.updatePool(cloudEnvInfo, poolId, body);
            super.rptOptLog("vlb.pool.operation.modify", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("updatePool error, poolId = " + poolId + ", tenantId = " + tenantId + ", body = " + body, e);
            super.rptOptLog("vlb.pool.operation.modify", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/pools/{poolId}", method = RequestMethod.DELETE)
    public Object deletePool(@PathVariable String poolId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("deletePool: client = " + request.getRemoteHost() + ", poolId = " + poolId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, poolId = " + poolId + ", tenantId = " + tenantId + ", vdcId = "
                        + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.deletePool(cloudEnvInfo, poolId);
            super.rptOptLog("vlb.pool.operation.delete", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.DELETE_CODE_204)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("deletePool error, poolId  = " + poolId + ", tenantId = " + tenantId, e);
            super.rptOptLog("vlb.pool.operation.delete", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/pools", method = RequestMethod.POST)
    public Object createPool(@RequestBody String body, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("createPool: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.createPool(cloudEnvInfo, body);
            super.rptOptLog("vlb.pool.operation.create", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createPool error, body  = " + body, e);
            super.rptOptLog("vlb.pool.operation.create", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/pools/{poolId}/members", method = RequestMethod.GET)
    public Object getMembers(GridQueryParams params, @PathVariable String poolId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        Object objResult;
        List<Member> resultList = new ArrayList<Member>();
        CloudEnvInfo cloudEnvInfo = null;
        List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
        if (null != cloudEnvList && !cloudEnvList.isEmpty())
        {
            cloudEnvInfo = cloudEnvList.get(0);
        }
        else
        {
            logger.error("Cannot find the cloudenv, poolId = " + poolId + ", tenantId = " + tenantId + ", vdcId = "
                    + vdcId);
            objResult = new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
        }

        List<Member> memberList = loadBalancerService.getMembers(cloudEnvInfo, false, poolId);
        if (null != memberList)
        {
            for (Member lb : memberList)
            {
                if (params != null && StringUtils.isNotBlank(params.getSearch()))
                {
                    // 支持端口、IP地址模糊查询
                    if (StringUtils.containsIgnoreCase(lb.getAddress(), params.getSearch().trim())
                            || StringUtils.containsIgnoreCase(String.valueOf(lb.getProtocolPort()), params.getSearch()
                                    .trim()))
                    {
                        lb.setCloudenv(cloudEnvInfo);
                        lb.setVdcId(vdcId);
                        resultList.add(lb);
                    }
                }
                else
                {
                    lb.setCloudenv(cloudEnvInfo);
                    lb.setVdcId(vdcId);
                    resultList.add(lb);
                }
            }
        }

        List<Member> pagingMemberList = new ArrayList<Member>();
        if (params != null && params.getLimit() != null)
        {
            if (resultList != null && resultList.size() > 0)
            {
                for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resultList.size(); i++)
                {
                    pagingMemberList.add(resultList.get(i));
                }
                objResult = PagingResult.getResult(pagingMemberList, resultList.size());
            }
            else
            {
                objResult = PagingResult.getResult(pagingMemberList, 0);
            }
        }
        else
        {
            objResult = resultList;
        }
        return JSON.toJSONString(objResult, SerializerFeature.DisableCircularReferenceDetect);
    }

    @RequestMapping(value = "/pools/{poolId}/members/{memberId}", method = RequestMethod.GET)
    public Object getMemberDetail(@PathVariable String memberId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @PathVariable String poolId, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("getMemberDetail: client = " + request.getRemoteHost() + ", memberId = " + memberId + ", vdcId = "
                + vdcId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, memberId = " + memberId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            Member member = loadBalancerService.getMember(cloudEnvInfo, memberId, poolId);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(member);
            return JSON.toJSONString(rsp);
        }
        catch (Exception e)
        {
            logger.error("getMemberDetail error, memberId = " + memberId + ", tenantId = " + tenantId + ", vdcId = "
                    + vdcId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/pools/{poolId}/members/{memberId}", method = RequestMethod.PUT)
    public Object updateMember(@PathVariable String memberId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @PathVariable String poolId, @RequestBody String body,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("updateMember: client = " + request.getRemoteHost() + ", memberId = " + memberId + ", body = "
                + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, memberId = " + memberId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.updateMember(cloudEnvInfo, memberId, body, poolId);
            super.rptOptLog("vlb.member.operation.modify", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error(
                    "updateMember error, memberId = " + memberId + ", tenantId = " + tenantId + ", body = " + body, e);
            super.rptOptLog("vlb.member.operation.modify", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/pools/{poolId}/members/{memberId}", method = RequestMethod.DELETE)
    public Object deleteMember(@PathVariable String memberId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @PathVariable String poolId, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("deleteMember: client = " + request.getRemoteHost() + ", memberId = " + memberId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, memberId = " + memberId + ", tenantId = " + tenantId
                        + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.deleteMember(cloudEnvInfo, memberId, poolId);
            super.rptOptLog("vlb.member.operation.delete", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.DELETE_CODE_204)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("deleteMember error, memberId  = " + memberId + ", tenantId = " + tenantId, e);
            super.rptOptLog("vlb.member.operation.delete", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/pools/{poolId}/members", method = RequestMethod.POST)
    public Object createMember(@RequestBody String body, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @PathVariable String poolId, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("createMember: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.createMember(cloudEnvInfo, body, poolId);
            super.rptOptLog("vlb.member.operation.create", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createMember error, body  = " + body, e);
            super.rptOptLog("vlb.member.operation.create", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/pools/{poolId}/healthmonitors", method = RequestMethod.GET)
    public Object getHealthMonitors(GridQueryParams params, @PathVariable String poolId,
            @RequestHeader("vdcId") String vdcId, @RequestHeader("tenantId") String tenantId,
            HttpServletRequest request, HttpServletResponse response)
    {
        Object objResult;
        List<HealthMonitor> resultList = new ArrayList<HealthMonitor>();
        CloudEnvInfo cloudEnvInfo = null;
        List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
        if (null != cloudEnvList && !cloudEnvList.isEmpty())
        {
            cloudEnvInfo = cloudEnvList.get(0);
        }
        else
        {
            logger.error("Cannot find the cloudenv, poolId = " + poolId + ", tenantId = " + tenantId + ", vdcId = "
                    + vdcId);
            objResult = new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
        }

        List<HealthMonitor> monitorList = loadBalancerService.getHealthMonitors(cloudEnvInfo, false);
        if (null != monitorList)
        {
            for (HealthMonitor monitor : monitorList)
            {
                JSONArray pools = monitor.getPools();
                if (null != pools && !pools.isEmpty())
                {
                    for (int i = 0; i < pools.size(); i++)
                    {
                        JSONObject jsonObject = (JSONObject) pools.get(i);
                        if (StringUtils.equals(poolId, jsonObject.getString("id")))
                        {
                            if (params != null && StringUtils.isNotBlank(params.getSearch()))
                            {
                                // 支持监控类型模糊查询
                                if (StringUtils.containsIgnoreCase(monitor.getType(), params.getSearch().trim()))
                                {
                                    monitor.setCloudenv(cloudEnvInfo);
                                    monitor.setVdcId(vdcId);
                                    resultList.add(monitor);
                                }
                            }
                            else
                            {
                                monitor.setCloudenv(cloudEnvInfo);
                                monitor.setVdcId(vdcId);
                                resultList.add(monitor);
                            }
                        }
                    }
                }
            }
        }

        List<HealthMonitor> pagingHealthMonitorList = new ArrayList<HealthMonitor>();
        if (params != null && params.getLimit() != null)
        {
            if (resultList != null && resultList.size() > 0)
            {
                for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resultList.size(); i++)
                {
                    pagingHealthMonitorList.add(resultList.get(i));
                }
                objResult = PagingResult.getResult(pagingHealthMonitorList, resultList.size());
            }
            else
            {
                objResult = PagingResult.getResult(pagingHealthMonitorList, 0);
            }
        }
        else
        {
            objResult = resultList;
        }

        return JSON.toJSONString(objResult, SerializerFeature.DisableCircularReferenceDetect);
    }

    @RequestMapping(value = "/healthmonitors/{healthMonitorId}", method = RequestMethod.GET)
    public Object getHealthMonitorDetail(@PathVariable String healthMonitorId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("getHealthMonitorDetail: client = " + request.getRemoteHost() + ", healthMonitorId = "
                + healthMonitorId + ", vdcId = " + vdcId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, healthMonitorId = " + healthMonitorId + ", tenantId = "
                        + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            HealthMonitor monitor = loadBalancerService.getHealthMonitor(cloudEnvInfo, healthMonitorId);
            CommonResponse rsp = new CommonResponse();
            rsp.setData(monitor);
            return JSON.toJSONString(rsp);
        }
        catch (Exception e)
        {
            logger.error("getHealthMonitorDetail error, healthMonitorId = " + healthMonitorId + ", tenantId = "
                    + tenantId + ", vdcId = " + vdcId, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/healthmonitors/{healthMonitorId}", method = RequestMethod.PUT)
    public Object updateHealthMonitor(@PathVariable String healthMonitorId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, @RequestBody String body, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("updateHealthMonitor: client = " + request.getRemoteHost() + ", healthMonitorId = "
                + healthMonitorId + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, healthMonitorId = " + healthMonitorId + ", tenantId = "
                        + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.updateHealthMonitor(cloudEnvInfo, healthMonitorId, body);
            super.rptOptLog("vlb.monitor.operation.modify", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.SUCCESS_CODE_200)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("updateHealthMonitor error, healthMonitorId = " + healthMonitorId + ", tenantId = " + tenantId
                    + ", body = " + body, e);
            super.rptOptLog("vlb.monitor.operation.modify", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/healthmonitors/{healthMonitorId}", method = RequestMethod.DELETE)
    public Object deleteHealthMonitor(@PathVariable String healthMonitorId, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("deleteHealthMonitor: client = " + request.getRemoteHost() + ", healthMonitorId = "
                + healthMonitorId);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, healthMonitorId = " + healthMonitorId + ", tenantId = "
                        + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.deleteHealthMonitor(cloudEnvInfo, healthMonitorId);
            super.rptOptLog("vlb.monitor.operation.delete", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.DELETE_CODE_204)
            {
                return new CommonResponse();
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("deleteHealthMonitor error, healthMonitorId  = " + healthMonitorId + ", tenantId = "
                    + tenantId, e);
            super.rptOptLog("vlb.monitor.operation.delete", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/healthmonitors", method = RequestMethod.POST)
    public Object createHealthMonitor(@RequestBody String body, @RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("createHealthMonitor: client = " + request.getRemoteHost() + ", body = " + body);
        try
        {
            CloudEnvInfo cloudEnvInfo = null;
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
            if (null != cloudEnvList && !cloudEnvList.isEmpty())
            {
                cloudEnvInfo = cloudEnvList.get(0);
            }
            else
            {
                logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
                return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
            }
            RestfulRsp rsp = loadBalancerService.createHealthMonitor(cloudEnvInfo, body);
            super.rptOptLog("vlb.monitor.operation.create", null, null, request, response, rsp.getStatusCode());
            if (rsp.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                CommonResponse commonResponse = new CommonResponse();
                commonResponse.setData(JSON.parseObject(rsp.getResponseBody()));
                return commonResponse;
            }
            else
            {
                return new CommonResponse(false, rsp.getResponseBody());
            }
        }
        catch (Exception e)
        {
            logger.error("createHealthMonitor error, body  = " + body, e);
            super.rptOptLog("vlb.monitor.operation.create", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/subnets", method = RequestMethod.GET)
    public Object getSubnetList(@RequestHeader("vdcId") String vdcId, @RequestHeader("tenantId") String tenantId,
            HttpServletRequest request, HttpServletResponse response)
    {
        CloudEnvInfo cloudEnvInfo = null;
        List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
        if (null != cloudEnvList && !cloudEnvList.isEmpty())
        {
            cloudEnvInfo = cloudEnvList.get(0);
        }
        else
        {
            logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
            return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
        }

        List<Subnet> subnetList = loadBalancerService.getSubnetList(cloudEnvInfo, false);
        CommonResponse rsp = new CommonResponse();
        rsp.setData(subnetList);
        return JSON.toJSONString(rsp);
    }

    @RequestMapping(value = "/candidatemembers", method = RequestMethod.GET)
    public Object getCandidateMemberList(@RequestHeader("vdcId") String vdcId,
            @RequestHeader("tenantId") String tenantId, HttpServletRequest request, HttpServletResponse response)
    {
        CloudEnvInfo cloudEnvInfo = null;
        List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, tenantId);
        if (null != cloudEnvList && !cloudEnvList.isEmpty())
        {
            cloudEnvInfo = cloudEnvList.get(0);
        }
        else
        {
            logger.error("Cannot find the cloudenv, tenantId = " + tenantId + ", vdcId = " + vdcId);
            return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
        }

        List<Member> memberList = loadBalancerService.getCandidateMemberList(cloudEnvInfo, false);
        CommonResponse rsp = new CommonResponse();
        rsp.setData(memberList);
        return JSON.toJSONString(rsp);
    }
}
