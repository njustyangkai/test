/**
 * 
 */
package com.zte.vdirector.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.response.CommonResponse;
import com.zte.vdirector.service.CommonService;
import com.zte.vdirector.service.NetworkService;

/**
 * <p>
 * 版权所有：中兴通讯股份有限公司
 * </p>
 * <p>
 * 项目名称：Operate
 * </p>
 * <p>
 * 类名称：NetworkController
 * </p>
 * <p>
 * 类描述：
 * </p>
 * <p>
 * 创建人：10138528
 * </p>
 * <p>
 * 创建时间：2016-11-14 下午3:22:42
 * </p>
 * <p>
 * 修改人：10138528
 * </p>
 * <p>
 * 修改时间：2016-11-14 下午3:22:42
 * </p>
 * <p>
 * 修改备注：
 * </p>
 * 
 * @version 1.0
 * 
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/network")
public class NetworkController extends CommonController
{
    @Resource
    private NetworkService networkService;

    @Resource
    private CommonService commonService;

    @RequestMapping(value = "/subnetpool", method = RequestMethod.GET)
    public Object getSubnetPool(HttpServletRequest request, HttpServletResponse response)
    {
        String ipCount = request.getParameter("ipCount");
        String needLb = request.getParameter("needLb");
        String vdcId = request.getParameter("vdcId");
        logger.info("getSubnetPool: client = " + request.getRemoteHost() + ", vdcId = " + vdcId + ", ipCount = "
                + ipCount + ", needLb = " + needLb);

        try
        {
            Object subnetPool = null;
            if (null != vdcId)
            {
                CloudEnvInfo cloudEnvInfo = null;
                List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, "");
                if (null != cloudEnvList && !cloudEnvList.isEmpty())
                {
                    cloudEnvInfo = cloudEnvList.get(0);
                }
                else
                {
                    logger.error("Cannot find the cloudenv, vdcId = " + vdcId);
                    return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
                }
                if (StringUtils.isBlank(needLb) && StringUtils.isBlank(ipCount))
                {
                    subnetPool = networkService.getSubnetPool(cloudEnvInfo);
                }
                else
                {
                    subnetPool = networkService.getSubnetPool(cloudEnvInfo, Integer.parseInt(ipCount), Boolean
                            .parseBoolean(needLb));
                }
            }

            CommonResponse rsp = new CommonResponse();
            rsp.setData(subnetPool);
            return rsp;
        }
        catch (Exception e)
        {
            logger.error("getSubnetPool error, client = " + request.getRemoteHost() + ", vdcId = " + vdcId
                    + ", ipCount = " + ipCount + ", needLb = " + needLb, e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "/{type}", method = RequestMethod.POST)
    public Object createNetwork(@PathVariable String type, @RequestBody String body, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("createNetwork: client = " + request.getRemoteHost() + ", type = " + type + ", body = " + body);

        try
        {
            String vdcId = "";
            String vdcName = "";
            JSONObject params = JSON.parseObject(body);
            if (null != params)
            {
                vdcId = params.getString("vdcId");
                vdcName = params.getString("vdcName");

                if (null != vdcId && null != vdcName)
                {
                    CloudEnvInfo cloudEnvInfo = null;
                    List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, "");
                    if (null != cloudEnvList && !cloudEnvList.isEmpty())
                    {
                        cloudEnvInfo = cloudEnvList.get(0);
                    }
                    else
                    {
                        logger.error("Cannot find the cloudenv, vdcId = " + vdcId);
                        return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
                    }

                    Map<String, Object> network = networkService.createNetwork(cloudEnvInfo, type, params);
                    if (null == network || network.size() == 0)
                    {
                        super.rptOptLog("network.operation.create", null, null, request, response,
                                CommonConstants.SERVER_ERROR_CODE_500);
                        return new CommonResponse(false, "Network creation failed.");
                    }

                    CommonResponse rsp = new CommonResponse();
                    rsp.setData(network);
                    super.rptOptLog("network.operation.create", null, null, request, response,
                            CommonConstants.CREATED_CODE_201);
                    return rsp;
                }
                else
                {
                    return new CommonResponse(false, "vdcId or vdcName is null.");
                }
            }
            return new CommonResponse(false, "body is null.");
        }
        catch (Exception e)
        {
            logger.error("createNetwork error, type = " + type + ", body = " + body, e);
            super.rptOptLog("network.operation.create", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
            return new CommonResponse(false, e.getMessage());
        }
    }

    @RequestMapping(value = "", method = RequestMethod.POST)
    public Object createVdcNet(@RequestBody String body, HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("createVdcNet: client = " + request.getRemoteHost() + ", body = " + body);
        String vdcId = "";
        String vdcName = "";

        try
        {
            JSONObject params = JSON.parseObject(body);
            if (null != params)
            {
                vdcId = params.getString("vdcId");
                vdcName = params.getString("vdcName");
            }

            if (null != vdcId && null != vdcName)
            {
                CloudEnvInfo cloudEnvInfo = null;
                List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, "");
                if (null != cloudEnvList && !cloudEnvList.isEmpty())
                {
                    cloudEnvInfo = cloudEnvList.get(0);
                }
                else
                {
                    logger.error("Cannot find the cloudenv, vdcId = " + vdcId);
                    return new CommonResponse(false, i18nUtil.getMessage("common.cloudenv.notfound"));
                }
                Map<String, Object> vdcNet = networkService.createVdcNet(cloudEnvInfo, vdcId, vdcName);
                if (null != vdcNet && vdcNet.containsKey("id"))
                {
                    CommonResponse rsp = new CommonResponse();
                    rsp.setData(vdcNet);
                    return rsp;
                }
            }
            else
            {
                return new CommonResponse(false, "vdcId or vdcName is null.");
            }
        }
        catch (Exception e)
        {
            logger.error("createVdcNet error, vdcId = " + vdcId, e);
            return new CommonResponse(false, e.getMessage());
        }

        return new CommonResponse(false, "create vdc network error.");
    }
}
