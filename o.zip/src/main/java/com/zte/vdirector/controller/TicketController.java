/**
 * 
 */
package com.zte.vdirector.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.zte.vdirector.domain.gridqueryparams.GridQueryParams;
import com.zte.vdirector.domain.gridqueryparams.PagingResult;
import com.zte.vdirector.domain.ticket.TicketBean;
import com.zte.vdirector.domain.ticket.TicketNetworkBean;
import com.zte.vdirector.domain.ticket.TicketProgressBean;
import com.zte.vdirector.domain.ticket.TicketResourceBean;
import com.zte.vdirector.domain.ticket.TicketRestBean;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.response.CommonResponse;
import com.zte.vdirector.frame.response.Response;
import com.zte.vdirector.service.TicketSerivce;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：TicketController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326   
 * </p>  
 * <p>  
 * 创建时间：2016年7月28日 下午3:30:01 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年7月28日 下午3:30:01  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/tickets")
public class TicketController extends CommonController
{
    @Resource
    private TicketSerivce ticketService;

    @RequestMapping(value = "/{project_id}", method = RequestMethod.GET)
    public Object getTicketList(GridQueryParams params, @PathVariable String project_id, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.trace("get project List: client = " + request.getRemoteHost());
        try
        {
            String type = request.getParameter("orgType");
            List<TicketBean> resp = ticketService.listTickets(project_id, type);
            List<TicketBean> pagingTicketList = new ArrayList<TicketBean>();
            if (params != null && params.getLimit() != null)
            {
                if (resp != null && resp.size() > 0)
                {
                    for (int i = params.getOffset(); i < params.getOffset() + params.getLimit() && i < resp.size(); i++)
                    {
                        pagingTicketList.add(resp.get(i));
                    }
                    return PagingResult.getResult(pagingTicketList, resp.size());
                }
                else
                {
                    return PagingResult.getResult(pagingTicketList, 0);
                }
            }
            else
            {
                return resp;
            }
        }
        catch (Exception e)
        {
            logger.error("get ticket List failed", e);
            response.setStatus(CommonConstants.SERVER_ERROR_CODE_500);
            return new Response(CommonConstants.SERVER_ERROR_CODE_500, e.getMessage());
        }
    }

    /**
     * 
     * @param id
     * @param request
     * @param response
     * @return e
     */
    @RequestMapping(value = "/progress/{id}", method = RequestMethod.GET)
    public Object getTicketProgressList(@PathVariable String id, HttpServletRequest request,
            HttpServletResponse response)
    {
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            List<TicketProgressBean> list = ticketService.getTicketProgressList(id);
            commonResponse.setData(list);
        }
        catch (Exception e)
        {
            logger.error("getTicketProgressList", e);
            commonResponse.setSuccess(false);

            commonResponse.setMessage(e.getMessage());
        }
        return commonResponse;
    }

    /**
     * 
     * @param id
     * @param request
     * @param response
     * @return e
     */
    @RequestMapping(value = "/ips/{id}", method = RequestMethod.GET)
    public Object getTicketNetworkList(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            List<TicketNetworkBean> list = ticketService.getTicketNetworkList(id);
            commonResponse.setData(list);
        }
        catch (Exception e)
        {
            logger.error("getTicketNetworkList", e);
            commonResponse.setSuccess(false);
            commonResponse.setMessage(e.getMessage());
        }
        return commonResponse;
    }

    /**
     * 
     * @param id
     * @param request
     * @param response
     * @return e
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public Object updateTicket(HttpServletRequest request, HttpServletResponse response)
    {
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            String id = request.getParameter("id");
            ticketService.updateTicketProcess(id, "2");
            super.rptOptLog("ticket.operation.update", null, null, request, response, CommonConstants.SUCCESS_CODE_200);
            return commonResponse;
        }
        catch (Exception e)
        {
            logger.error("updateTicket", e);
            commonResponse.setSuccess(false);
            commonResponse.setMessage("update ticket failed,beacuse " + e.getMessage());
            super.rptOptLog("ticket.operation.update", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
        }
        return commonResponse;
    }

    /**
     * 
     * @param id
     * @param request
     * @param response
     * @return e
     */
    @RequestMapping(value = "/reExecute", method = RequestMethod.PUT)
    public Object reEcecuteTicket(HttpServletRequest request, HttpServletResponse response)
    {
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            String id = request.getParameter("id");

            String result = ticketService.reExecute(id);

            if ("reExecuteError".equals(result))
            {
                commonResponse.setMessage("reExecute ticket failed");
                commonResponse.setSuccess(false);
            }

            super.rptOptLog("ticket.operation.reexecute", null, null, request, response,
                    CommonConstants.SUCCESS_CODE_200);
            return commonResponse;
        }
        catch (Exception e)
        {
            logger.error("reExecuteTicket", e);
            commonResponse.setSuccess(false);
            commonResponse.setMessage("reExecute ticket failed,beacuse " + e.getMessage());
            super.rptOptLog("ticket.operation.reexecute", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
        }
        return commonResponse;
    }

    /**
     * 
     * @param id
     * @param request
     * @param response
     * @return e
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public Object deleteTicket(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            String result = ticketService.deleteTicket(id);

            if ("deleteError".equals(result))
            {
                commonResponse.setMessage("delete ticket failed");
                commonResponse.setSuccess(false);
            }

            super.rptOptLog("ticket.operation.delete", null, null, request, response, CommonConstants.SUCCESS_CODE_200);
            return commonResponse;
        }
        catch (Exception e)
        {
            logger.error("deleteTicket", e);
            commonResponse.setSuccess(false);
            commonResponse.setMessage(e.getMessage());
            super.rptOptLog("ticket.operation.delete", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
        }
        return commonResponse;
    }

    /**
     * 
     * @param id
     * @param request
     * @param response
     * @return e
     */
    @RequestMapping(value = "/resourceApply/{id}", method = RequestMethod.GET)
    public Object getTicketResourceList(@PathVariable String id, HttpServletRequest request,
            HttpServletResponse response)
    {
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            List<TicketResourceBean> list = ticketService.getTicketResourceList(id);
            commonResponse.setData(list);
        }
        catch (Exception e)
        {
            logger.error("getTicketResourceList", e);
            commonResponse.setSuccess(false);
            commonResponse.setMessage(e.getMessage());
        }
        return commonResponse;
    }

    /**
     * 
     * @param id
     * @param request
     * @param response
     * @return e
     */
    @RequestMapping(value = "/basicInfo/{id}", method = RequestMethod.GET)
    public Object getTicketDetail(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            TicketBean ticketBean = ticketService.getTicketDetail(id);
            commonResponse.setData(ticketBean);
        }
        catch (Exception e)
        {
            logger.error("getTicketDetail", e);
            commonResponse.setSuccess(false);
            commonResponse.setMessage(e.getMessage());
        }
        return commonResponse;
    }

    @RequestMapping(value = "/import", method = RequestMethod.POST)
    public Object upload(@RequestParam("file") MultipartFile multipartFile, HttpServletRequest request,
            HttpServletResponse response)
    {
        String projectId = request.getParameter("projectId");
        String projectName = request.getParameter("projectName");
        CommonResponse commonResponse = new CommonResponse();
        try
        {
            TicketRestBean ticketRestBean = ticketService.readExcel(multipartFile, projectName, projectId);

            ticketService.uploadExcel(ticketRestBean);

            super.rptOptLog("ticket.operation.upload", null, null, request, response, CommonConstants.SUCCESS_CODE_200);
        }
        catch (Exception e)
        {
            super.rptOptLog("ticket.operation.upload", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);

            logger.error("upload file error", e);
            if ("excelEmpty".equals(e.getMessage()) || "sheet2Empty".equals(e.getMessage())
                    || "sheet3Empty".equals(e.getMessage()))
            {
                commonResponse.setMessage(i18nUtil.getMessage("ticket.upload.failed"));
                commonResponse.setSuccess(false);
                return commonResponse;
            }
            else if ("vdcNameError".equals(e.getMessage()))
            {
                commonResponse.setMessage(i18nUtil.getMessage("ticket.upload.failed2"));
                commonResponse.setSuccess(false);
                return commonResponse;
            }
            else if ("FileError".equals(e.getMessage()))
            {
                commonResponse.setMessage(i18nUtil.getMessage("ticket.upload.failed5"));
                commonResponse.setSuccess(false);
                return commonResponse;
            }
            else if ("projectNameError".equals(e.getMessage()))
            {
                commonResponse.setMessage(i18nUtil.getMessage("ticket.upload.failed1"));
                commonResponse.setSuccess(false);
                return commonResponse;
            }
            else if ("ExistTicketNum".equals(e.getMessage()))
            {
                commonResponse.setMessage(i18nUtil.getMessage("ticket.upload.failed6"));
                commonResponse.setSuccess(false);
                return commonResponse;
            }
            else if ("uploadError".equals(e.getMessage()))
            {
                commonResponse.setMessage(i18nUtil.getMessage("ticket.upload.failed4"));
                commonResponse.setSuccess(false);
                return commonResponse;
            }
            else
            {
                commonResponse.setMessage(i18nUtil.getMessage("ticket.upload.failed3") + e.getMessage());
                commonResponse.setSuccess(false);
                return commonResponse;
            }
        }
        return commonResponse;
    }
}
