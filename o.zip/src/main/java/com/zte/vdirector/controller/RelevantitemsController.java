package com.zte.vdirector.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.firewall.Firewall;
import com.zte.vdirector.domain.firewall.FirewallPolicy;
import com.zte.vdirector.domain.firewall.FirewallRule;
import com.zte.vdirector.domain.loadbalancer.Listener;
import com.zte.vdirector.domain.loadbalancer.LoadBalancer;
import com.zte.vdirector.domain.loadbalancer.Pool;
import com.zte.vdirector.domain.servicedirectory.VdcServiceDirectoryBean;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.service.CommonService;
import com.zte.vdirector.service.FirewallService;
import com.zte.vdirector.service.LoadBalancerService;
import com.zte.vdirector.service.VdcServiceDirectorySerivce;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：RelevantitemsController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年11月15日 上午10:32:06 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年11月15日 上午10:32:06  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/relevantitems")
public class RelevantitemsController extends CommonController
{
    private static final String STEP_FW = "firewall";
    private static final String STEP_FW_POLICY = "firewallpolicy";
    private static final String STEP_FW_RULE = "firewallrule";
    private static final String STEP_VLB = "loadbalance";
    private static final String STEP_SERVICEDIRECTORY = "servicedirectory";

    @Resource
    private LoadBalancerService loadBalancerService;

    @Resource
    private FirewallService firewallService;

    @Resource
    private VdcServiceDirectorySerivce vdcServiceDirectoryService;

    @Resource
    private CommonService commonService;

    @RequestMapping(value = "", method = RequestMethod.GET)
    public Object getRelevantitems(HttpServletRequest request, HttpServletResponse response)
    {
        JSONObject result = new JSONObject();
        String vdcId = request.getParameter("vdcId");
        String step = request.getParameter("step");
        JSONArray resultList = new JSONArray();
        if (STEP_SERVICEDIRECTORY.equals(step))
        {
            VdcServiceDirectoryBean vdcSerDir = vdcServiceDirectoryService.getVdcServiceDirectory(vdcId);
            if (null != vdcSerDir)
            {
                resultList.add(vdcSerDir);
            }
        }
        else
        {
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, null);
            if (null != cloudEnvList)
            {
                for (CloudEnvInfo cloudEnv : cloudEnvList)
                {
                    if (STEP_FW.equals(step))
                    {
                        List<Firewall> fwList = firewallService.getFirewalls(cloudEnv, false);
                        if (null != fwList)
                        {
                            resultList.addAll(fwList);
                        }
                    }
                    else if (STEP_FW_POLICY.equals(step))
                    {
                        List<FirewallPolicy> policyList = firewallService.getPolicys(cloudEnv, false);
                        if (null != policyList)
                        {
                            resultList.addAll(policyList);
                        }
                    }
                    else if (STEP_FW_RULE.equals(step))
                    {
                        List<FirewallRule> ruleList = firewallService.getRules(cloudEnv, false, null);
                        if (null != ruleList)
                        {
                            resultList.addAll(ruleList);
                        }
                    }
                    else if (STEP_VLB.equals(step))
                    {
                        List<LoadBalancer> lbList = loadBalancerService.getLoadBalancers(cloudEnv, false);
                        if (null != lbList)
                        {
                            resultList.addAll(lbList);
                        }
                    }
                }
            }
        }
        result.put("itemList", resultList);
        return result;
    }

    @RequestMapping(value = "", method = RequestMethod.DELETE)
    public Object deleteRelevantitems(HttpServletRequest request, HttpServletResponse response)
    {
        JSONObject result = new JSONObject();
        String vdcId = request.getParameter("vdcId");
        String step = request.getParameter("step");
        JSONArray failedList = new JSONArray();
        if (STEP_SERVICEDIRECTORY.equals(step))
        {
            try
            {
                vdcServiceDirectoryService.deleteVdcServiceDirectory(vdcId);
            }
            catch (Exception e)
            {
                logger.error("Fail to delete vdc service diretory, id : " + vdcId, e);
                failedList.add(vdcId);
                super.rptOptLog("servicedirectory.operation.delete", null, null, request, response,
                        CommonConstants.SERVER_ERROR_CODE_500);
            }
        }
        else
        {
            List<CloudEnvInfo> cloudEnvList = commonService.getCloudEnvList(vdcId, null);
            if (null != cloudEnvList)
            {
                for (CloudEnvInfo cloudEnv : cloudEnvList)
                {
                    if (STEP_FW.equals(step))
                    {
                        List<Firewall> fwList = firewallService.getFirewalls(cloudEnv, false);
                        if (null != fwList)
                        {
                            for (Firewall fw : fwList)
                            {
                                try
                                {
                                    firewallService.deleteFirewall(cloudEnv, fw.getId());
                                    super.rptOptLog("vdc.resource.delete.fw", null, null, request, response,
                                            CommonConstants.SUCCESS_CODE_200);
                                }
                                catch (Exception e)
                                {
                                    logger.error(
                                            "Fail to delete firewall, id : " + fw.getId() + ", name : " + fw.getName(),
                                            e);
                                    failedList.add(fw);
                                    super.rptOptLog("vdc.resource.delete.fw", null, null, request, response,
                                            CommonConstants.SERVER_ERROR_CODE_500);
                                }
                            }
                        }
                    }
                    else if (STEP_FW_POLICY.equals(step))
                    {
                        List<FirewallPolicy> policyList = firewallService.getPolicys(cloudEnv, false);
                        if (null != policyList)
                        {
                            for (FirewallPolicy policy : policyList)
                            {
                                try
                                {
                                    firewallService.deletePolicy(cloudEnv, policy.getId());
                                    super.rptOptLog("vdc.resource.delete.fw.policy", null, null, request, response,
                                            CommonConstants.SUCCESS_CODE_200);
                                }
                                catch (Exception e)
                                {
                                    logger.error("Fail to delete firewallpolicy, id : " + policy.getId() + ", name : "
                                            + policy.getName(), e);
                                    failedList.add(policy);
                                    super.rptOptLog("vdc.resource.delete.fw.policy", null, null, request, response,
                                            CommonConstants.SERVER_ERROR_CODE_500);
                                }
                            }
                        }
                    }
                    else if (STEP_FW_RULE.equals(step))
                    {
                        List<FirewallRule> ruleList = firewallService.getRules(cloudEnv, false, null);
                        if (null != ruleList)
                        {
                            for (FirewallRule rule : ruleList)
                            {
                                try
                                {
                                    firewallService.deleteRule(cloudEnv, rule.getId());
                                    super.rptOptLog("vdc.resource.delete.fw.rule", null, null, request, response,
                                            CommonConstants.SUCCESS_CODE_200);
                                }
                                catch (Exception e)
                                {
                                    logger.error("Fail to delete firewallrule, id : " + rule.getId() + ", name : "
                                            + rule.getName(), e);
                                    failedList.add(rule);
                                    super.rptOptLog("vdc.resource.delete.fw.rule", null, null, request, response,
                                            CommonConstants.SERVER_ERROR_CODE_500);
                                }
                            }
                        }
                    }
                    else if (STEP_VLB.equals(step))
                    {
                        //loadBalancerService.getHealthMonitors(cloudEnv, false);

                        Map<String, Listener> listenerMap = new HashMap<String, Listener>();
                        List<Listener> listenerList = loadBalancerService.getListeners(cloudEnv, false);
                        if (null != listenerList && !listenerList.isEmpty())
                        {
                            for (Listener l : listenerList)
                            {
                                listenerMap.put(l.getId(), l);
                            }
                        }

                        Map<String, Pool> poolMap = new HashMap<String, Pool>();
                        List<Pool> poolList = loadBalancerService.getPools(cloudEnv, false);
                        if (null != poolList && !poolList.isEmpty())
                        {
                            for (Pool p : poolList)
                            {
                                poolMap.put(p.getId(), p);
                            }
                        }

                        //loadBalancerService.getMembers(cloudEnv, false, poolId);

                        List<LoadBalancer> lbList = loadBalancerService.getLoadBalancers(cloudEnv, false);
                        if (null != lbList)
                        {
                            for (LoadBalancer vlb : lbList)
                            {
                                try
                                {
                                    List<String> listenerIds = vlb.getListeners();
                                    if (null != listenerIds)
                                    {
                                        for (String id : listenerIds)
                                        {
                                            Listener listener = listenerMap.get(id);
                                            if (null != listener)
                                            {
                                                Pool pool = poolMap.get(listener.getDefaultPoolId());

                                                if (null != pool)
                                                {
                                                    // 删除监控
                                                    if (null != pool.getHealthMonitors())
                                                    {
                                                        for (String monitorId : pool.getHealthMonitors())
                                                        {
                                                            loadBalancerService
                                                                    .deleteHealthMonitor(cloudEnv, monitorId);
                                                        }
                                                    }

                                                    // 删除成员
                                                    if (null != pool.getMembers())
                                                    {
                                                        for (Object memberId : pool.getMembers())
                                                        {
                                                            loadBalancerService.deleteMember(cloudEnv,
                                                                    (String) memberId, pool.getId());
                                                        }
                                                    }

                                                    // 删除资源池
                                                    loadBalancerService.deletePool(cloudEnv, pool.getId());
                                                }

                                                // 删除监听
                                                loadBalancerService.deleteListener(cloudEnv, id);
                                            }
                                        }
                                    }

                                    // 删除负载均衡
                                    loadBalancerService.deleteLoadBalancer(cloudEnv, vlb.getId());
                                    super.rptOptLog("vdc.resource.delete.vlb", null, null, request, response,
                                            CommonConstants.SUCCESS_CODE_200);
                                }
                                catch (Exception e)
                                {
                                    logger.error(
                                            "Fail to delete loadbalancer, id : " + vlb.getId() + ", name : "
                                                    + vlb.getName(), e);
                                    failedList.add(vlb);
                                    super.rptOptLog("vdc.resource.delete.vlb", null, null, request, response,
                                            CommonConstants.SERVER_ERROR_CODE_500);
                                }
                            }
                        }
                    }
                }
            }
        }
        result.put("itemList", failedList);
        response.setStatus(CommonConstants.DELETE_CODE_204);
        return result;
    }
}
