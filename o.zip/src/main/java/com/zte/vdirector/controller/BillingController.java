/**
 * 
 */
package com.zte.vdirector.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zte.vdirector.domain.gridqueryparams.GridQueryParams;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.response.CommonResponse;
import com.zte.vdirector.frame.response.Response;
import com.zte.vdirector.service.BillingService;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：TicketController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326   
 * </p>  
 * <p>  
 * 创建时间：2016年7月28日 下午3:30:01 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年7月28日 下午3:30:01  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/billings")
public class BillingController extends CommonController
{
    @Resource
    private BillingService billingService;

    @RequestMapping(value = "/{orgId}/{vdcId}", method = RequestMethod.GET)
    public Object getStatistics(GridQueryParams params, @PathVariable String orgId, @PathVariable String vdcId,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.trace("getStatistics client = " + request.getRemoteHost());
        try
        {
            String beginTime = request.getParameter("date");
            String endTime = request.getParameter("endTime");
            return billingService
                    .getStatistics(orgId, vdcId, beginTime, endTime, params.getOffset(), params.getLimit());
        }
        catch (Exception e)
        {
            logger.error("getStatistics failed", e);
            response.setStatus(CommonConstants.SERVER_ERROR_CODE_500);
            return new Response(CommonConstants.SERVER_ERROR_CODE_500, e.getMessage());
        }
    }

    /**
     * 
     * @param id
     * @param request
     * @param response
     * @return e
     */
    @RequestMapping(value = "/{orgId}/{vdcId}/{type}", method = RequestMethod.GET)
    public Object getBillingList(GridQueryParams params, @PathVariable String orgId, @PathVariable String vdcId,
            @PathVariable String type, HttpServletRequest request, HttpServletResponse response)
    {
        logger.trace("getBillingList: client = " + request.getRemoteHost());
        try
        {
            String resourceName = request.getParameter("resourceName");
            String beginTime = request.getParameter("date");
            String endTime = request.getParameter("endTime");

            return billingService.getBillingList(orgId, vdcId, type, resourceName, beginTime, endTime,
                    params.getOffset(), params.getLimit());
        }
        catch (Exception e)
        {
            logger.error("getBillingList failed", e);
            response.setStatus(CommonConstants.SERVER_ERROR_CODE_500);
            return new Response(CommonConstants.SERVER_ERROR_CODE_500, e.getMessage());
        }
    }

    @RequestMapping(value = "/run", method = RequestMethod.GET)
    public Object run(HttpServletRequest request, HttpServletResponse response)
    {
        logger.trace("run: client = " + request.getRemoteHost());
        CommonResponse rsp = new CommonResponse();
        try
        {
            billingService.handle();
            rsp.setSuccess(true);
        }
        catch (Exception e)
        {
            logger.error("run failed", e);
            rsp.setSuccess(false);
            rsp.setMessage(e.getMessage());
        }
        return rsp;
    }
    
    @RequestMapping(value = "/cache/get/{id}", method = RequestMethod.GET)
    public Object cacheGet(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        return billingService.cacheGet(id);
    }
    
    @RequestMapping(value = "/cache/put/{id}", method = RequestMethod.GET)
    public Object cachePut(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        return billingService.cachePut(id);
    }
    
    @RequestMapping(value = "/cache/delete/{id}", method = RequestMethod.GET)
    public Object cacheDelete(@PathVariable String id, HttpServletRequest request, HttpServletResponse response)
    {
        return billingService.cacheDelete(id);
    }
}
