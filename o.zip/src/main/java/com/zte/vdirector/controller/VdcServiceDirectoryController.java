package com.zte.vdirector.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.zte.vdirector.domain.acls.AclEntity;
import com.zte.vdirector.domain.acls.AclEntity.ResourceEntity;
import com.zte.vdirector.domain.acls.AclQueryCondition;
import com.zte.vdirector.domain.acls.AclResponse;
import com.zte.vdirector.domain.gridqueryparams.GridQueryParams;
import com.zte.vdirector.domain.gridqueryparams.PagingResult;
import com.zte.vdirector.domain.servicedirectory.ServiceDirectoryBean;
import com.zte.vdirector.domain.servicedirectory.Vdc;
import com.zte.vdirector.domain.servicedirectory.VdcServiceDirectoryBean;
import com.zte.vdirector.domain.serviceprice.ChargeItemBean;
import com.zte.vdirector.frame.constants.CommonConstants;
import com.zte.vdirector.frame.response.CommonResponse;
import com.zte.vdirector.service.AclSerivce;
import com.zte.vdirector.service.ServiceDirectorySerivce;
import com.zte.vdirector.service.ServicePriceSerivce;
import com.zte.vdirector.service.VdcServiceDirectorySerivce;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：VdcServiceDirectoryController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 上午10:41:15 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 上午10:41:15  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/vdc/servicedirectorys")
public class VdcServiceDirectoryController extends CommonController
{
    private static ThreadPoolExecutor executor = null;
    static
    {
        executor = new ThreadPoolExecutor(100, 200, 3, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(200),
                new ThreadPoolExecutor.DiscardOldestPolicy());
    }

    class VdcServiceDirectoryDeleteThread extends Thread
    {
        private String vdcId;

        public VdcServiceDirectoryDeleteThread(String vdcId)
        {
            this.vdcId = vdcId;
        }

        @Override
        public void run()
        {
            vdcServiceDirectoryService.deleteVdcServiceDirectory(vdcId);
        }
    }

    @Resource
    private ServiceDirectorySerivce serviceDirectoryService;

    @Resource
    private VdcServiceDirectorySerivce vdcServiceDirectoryService;

    @Resource
    private ServicePriceSerivce servicePriceSerivce;

    @Resource
    private AclSerivce aclSerivce;

    /**
     * 查询服务目录基本信息列表
     * @param params GridQueryParams
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @return 服务目录基本信息列表
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public Object getVdcServiceDirectoryList(GridQueryParams params, @RequestHeader("Access-Token") String tokenId,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("get vdc service directory list: client = " + request.getRemoteHost());
        long beginTime = System.currentTimeMillis();
        logger.info("getVdcServiceDirectoryList: beginTime = " + beginTime);
        try
        {
            List<VdcServiceDirectoryBean> resultList = new ArrayList<VdcServiceDirectoryBean>();

            List<String> vdcIdList = this.getAclIdList(tokenId);

            Map<String, Vdc> vdcMap = vdcServiceDirectoryService.getVdcsMap();
            List<VdcServiceDirectoryBean> vdcSerDirList = vdcServiceDirectoryService.listVdcServiceDirectorys();
            Map<String, VdcServiceDirectoryBean> vdcSerDirMap = new HashMap<String, VdcServiceDirectoryBean>();
            if (null != vdcSerDirList)
            {
                for (VdcServiceDirectoryBean vdcSerDir : vdcSerDirList)
                {
                    // 若VDC存在，则当前VDC的服务目录数据是有效的。
                    if (vdcMap.containsKey(vdcSerDir.getVdcId()))
                    {
                        vdcSerDir.setVdcName(vdcMap.get(vdcSerDir.getVdcId()).getName());
                        vdcSerDirMap.put(vdcSerDir.getVdcId(), vdcSerDir);
                        if (StringUtils.isNotBlank(params.getSearch()))
                        {
                            // 支持按照VDC名称模糊查询
                            // 非当前管理员管辖的VDC不展示
                            if (StringUtils.containsIgnoreCase(vdcSerDir.getVdcName(), params.getSearch())
                                    && vdcIdList.contains(vdcSerDir.getVdcId()))
                            {
                                resultList.add(vdcSerDir);
                            }
                        }
                        else
                        {
                            // 非当前管理员管辖的VDC不展示
                            if (vdcIdList.contains(vdcSerDir.getVdcId()))
                            {
                                resultList.add(vdcSerDir);
                            }
                        }
                    }
                    else
                    {
                        // 若VDC已被删除，则清理其服务目录。
                        VdcServiceDirectoryController.executor.execute(new VdcServiceDirectoryDeleteThread(vdcSerDir
                                .getVdcId()));
                    }
                }
            }

            // 进入菜单时初始化， 模糊查询时不进行初始化
            if (null != vdcMap && StringUtils.isBlank(params.getSearch()))
            {
                for (Vdc vdc : vdcMap.values())
                {
                    // 非当前管理员管辖的VDC不展示
                    if (!vdcIdList.contains(vdc.getId()))
                    {
                        continue;
                    }

                    // 有效的服务目录数据中找不到该VDC，则需要初始化该VDC的服务目录。
                    if (!vdcSerDirMap.containsKey(vdc.getId()))
                    {
                        VdcServiceDirectoryBean vSerDir = initVdcServiceDirectory(vdc, 2);
                        if (null != vSerDir)
                        {
                            resultList.add(vSerDir);
                        }
                    }
                }
            }

            List<VdcServiceDirectoryBean> pagingVdcSerDirList = new ArrayList<VdcServiceDirectoryBean>();
            if (params != null && params.getLimit() != null)
            {
                if (resultList != null && resultList.size() > 0)
                {
                    for (int i = params.getOffset(); i < params.getOffset() + params.getLimit()
                            && i < resultList.size(); i++)
                    {
                        pagingVdcSerDirList.add(resultList.get(i));
                    }

                    long endTime = System.currentTimeMillis();
                    logger.info("getVdcServiceDirectoryList: endTime = " + endTime);
                    logger.info("getVdcServiceDirectoryList: cost = " + (endTime - beginTime));
                    return PagingResult.getResult(pagingVdcSerDirList, resultList.size());
                }
                else
                {
                    long endTime = System.currentTimeMillis();
                    logger.info("getVdcServiceDirectoryList: endTime = " + endTime);
                    logger.info("getVdcServiceDirectoryList: cost = " + (endTime - beginTime));
                    return PagingResult.getResult(pagingVdcSerDirList, 0);
                }
            }
            else
            {
                long endTime = System.currentTimeMillis();
                logger.info("getVdcServiceDirectoryList: endTime = " + endTime);
                logger.info("getVdcServiceDirectoryList: cost = " + (endTime - beginTime));
                return resultList;
            }
        }
        catch (Exception e)
        {
            logger.error("get vdc service directory list failed", e);
            return new CommonResponse(false, e.getMessage());
        }
    }

    private VdcServiceDirectoryBean initVdcServiceDirectory(Vdc vdc, int status)
    {
        List<ServiceDirectoryBean> serDirList = serviceDirectoryService.listServiceDirectorys();
        if (serDirList != null && vdc != null)
        {
            for (ServiceDirectoryBean serDir : serDirList)
            {
                serDir.setStatus(status);
            }
            VdcServiceDirectoryBean vdcServiceDirectory = new VdcServiceDirectoryBean();
            vdcServiceDirectory.setVdcId(vdc.getId());
            vdcServiceDirectory.setVdcName(vdc.getName());
            vdcServiceDirectory.setExtra(JSON.toJSONString(serDirList));
            return vdcServiceDirectory;
        }
        return null;
    }

    /**
     * 调用分权分域接口，根据tokenId和资源类型获取管理的
     * @param tokenId 令牌ID
     * @return 资源ID列表
     */
    private List<String> getAclIdList(String tokenId)
    {
        List<String> idList = new ArrayList<String>();

        AclQueryCondition aclCondition = new AclQueryCondition();
        aclCondition.setTokenId(tokenId);
        aclCondition.setResourceType("vdc");
        AclResponse aclRsp = aclSerivce.getAcls(aclCondition);
        if (null != aclRsp && null != aclRsp.getAcls())
        {
            List<AclEntity> entityList = aclRsp.getAcls();
            for (AclEntity entity : entityList)
            {
                List<ResourceEntity> resList = entity.getResources();
                if (null != resList)
                {
                    for (ResourceEntity res : resList)
                    {
                        idList.add(res.getResourceId());
                    }
                }
            }
        }

        return idList;
    }

    /**
     * 为理想提供查询服务目录的接口：
     * 查询服务目录详情列表
     * 带服务目录的计费项以及价格信息
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @return 服务目录详情列表
     */
    @RequestMapping(value = "/detail", method = RequestMethod.GET)
    public Object getVdcServiceDirectoryDetailForIdeal(HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("get vdc service directory detail for Ideal: client = " + request.getRemoteHost());
        long beginTime = System.currentTimeMillis();
        logger.info("getVdcServiceDirectoryDetailForIdeal: beginTime = " + beginTime);
        String vdcId = request.getParameter("vdc_id");
        CommonResponse rsp = new CommonResponse();
        try
        {
            // 调用VDC服务接口，判断VDC是否存在；
            Map<String, Vdc> vdcMap = vdcServiceDirectoryService.getVdcsMap();
            if (!vdcMap.containsKey(vdcId))
            {
                response.setStatus(CommonConstants.BAD_REQUEST_400);
                rsp.setSuccess(false);
                rsp.setMessage("The vdc does not exist.");
                return rsp;
            }

            VdcServiceDirectoryBean vdcServiceDirectory = vdcServiceDirectoryService.getVdcServiceDirectory(vdcId);
            if (null == vdcServiceDirectory)
            {
                vdcServiceDirectory = initVdcServiceDirectory(vdcMap.get(vdcId), 2);
                if (null == vdcServiceDirectory)
                {
                    response.setStatus(CommonConstants.SERVER_ERROR_CODE_500);
                    rsp.setSuccess(false);
                    rsp.setMessage("The global service directory is not initialized.");
                    return rsp;
                }
            }

            List<VdcServiceDirectoryBean> serDirList = JSON.parseObject(vdcServiceDirectory.getExtra(),
                    new TypeReference<List<VdcServiceDirectoryBean>>()
                    {
                    });

            if (serDirList != null)
            {
                for (VdcServiceDirectoryBean serDir : serDirList)
                {
                    List<ChargeItemBean> chargeItemList = servicePriceSerivce.getChargeItemList(serDir.getId());
                    if (null != chargeItemList)
                    {
                        for (ChargeItemBean chargeItem : chargeItemList)
                        {
                            servicePriceSerivce.recursionChargeItems(chargeItem);
                        }
                    }
                    serDir.setChargeItemList(chargeItemList);
                }
            }

            rsp.setData(serDirList);
            rsp.setSuccess(true);
        }
        catch (Exception e)
        {
            logger.error("get vdc service directory detail for Ideal failed", e);
            response.setStatus(CommonConstants.SERVER_ERROR_CODE_500);
            rsp.setSuccess(false);
            rsp.setMessage(e.getMessage());
        }

        long endTime = System.currentTimeMillis();
        logger.info("getVdcServiceDirectoryDetailForIdeal: endTime = " + endTime);
        logger.info("getVdcServiceDirectoryDetailForIdeal: cost = " + (endTime - beginTime));
        return rsp;
    }

    @RequestMapping(value = "/detail/{vdcId}", method = RequestMethod.GET)
    public Object getVdcServiceDirectoryDetail(@PathVariable String vdcId, @RequestBody String body,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("get vdc service directory detail : client = " + request.getRemoteHost());
        CommonResponse rsp = new CommonResponse();
        try
        {
            VdcServiceDirectoryBean vdcServiceDirectory = vdcServiceDirectoryService.getVdcServiceDirectory(vdcId);
            List<VdcServiceDirectoryBean> serDirList = JSON.parseObject(vdcServiceDirectory.getExtra(),
                    new TypeReference<List<VdcServiceDirectoryBean>>()
                    {
                    });
            rsp.setData(serDirList);
            rsp.setSuccess(true);
        }
        catch (Exception e)
        {
            logger.error("get vdc service directory detail failed", e);
            rsp.setSuccess(false);
            rsp.setMessage(e.getMessage());
        }
        return rsp;
    }

    @RequestMapping(value = "/{vdcId}", method = RequestMethod.PUT)
    public Object releaseVdcServiceDirectory(@PathVariable String vdcId, @RequestBody String body,
            HttpServletRequest request, HttpServletResponse response)
    {
        logger.info("releaseVdcServiceDirectory: client = " + request.getRemoteHost() + ", vdcId = " + vdcId
                + ", body = " + body);

        CommonResponse rsp = new CommonResponse();
        try
        {
            // 调用VDC服务接口，判断VDC是否存在；
            Map<String, Vdc> vdcMap = vdcServiceDirectoryService.getVdcsMap();
            if (!vdcMap.containsKey(vdcId))
            {
                response.setStatus(CommonConstants.BAD_REQUEST_400);
                rsp.setSuccess(false);
                rsp.setMessage("The vdc does not exist.");
                return rsp;
            }

            VdcServiceDirectoryBean vdcServiceDirectory = vdcServiceDirectoryService.getVdcServiceDirectory(vdcId);
            if (null == vdcServiceDirectory)
            {
                if (JSON.parseArray(body).isEmpty())
                {
                    vdcServiceDirectory = initVdcServiceDirectory(vdcMap.get(vdcId), 1);
                    if (null == vdcServiceDirectory)
                    {
                        response.setStatus(CommonConstants.SERVER_ERROR_CODE_500);
                        rsp.setSuccess(false);
                        rsp.setMessage("The global service directory is not initialized.");
                        return rsp;
                    }
                }
                else
                {
                    vdcServiceDirectory = initVdcServiceDirectory(vdcMap.get(vdcId), 2);
                    if (null == vdcServiceDirectory)
                    {
                        response.setStatus(CommonConstants.SERVER_ERROR_CODE_500);
                        rsp.setSuccess(false);
                        rsp.setMessage("The global service directory is not initialized.");
                        return rsp;
                    }
                    this.setLatestData(body, vdcServiceDirectory);
                }
                vdcServiceDirectoryService.addVdcServiceDirectory(vdcServiceDirectory);
            }
            else
            {
                this.setLatestData(body, vdcServiceDirectory);
                vdcServiceDirectoryService.updateVdcServiceDirectory(vdcServiceDirectory);
            }

            rsp.setSuccess(true);
            super.rptOptLog("servicedirectory.operation.modify", null, null, request, response,
                    CommonConstants.SUCCESS_CODE_200);
        }
        catch (Exception e)
        {
            logger.error("releaseVdcServiceDirectory error, vdcId = " + vdcId + ", body = " + body, e);
            rsp.setSuccess(false);
            rsp.setMessage(e.getMessage());
            super.rptOptLog("servicedirectory.operation.modify", null, null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
        }
        return rsp;
    }

    private void setLatestData(String body, VdcServiceDirectoryBean vdcServiceDirectory)
    {
        List<ServiceDirectoryBean> serDirList = JSON.parseObject(body, new TypeReference<List<ServiceDirectoryBean>>()
        {
        });
        List<ServiceDirectoryBean> vdcSerDirList = JSON.parseObject(vdcServiceDirectory.getExtra(),
                new TypeReference<List<ServiceDirectoryBean>>()
                {
                });
        if (vdcSerDirList != null && serDirList != null)
        {
            for (ServiceDirectoryBean vdcSer : vdcSerDirList)
            {
                for (ServiceDirectoryBean ser : serDirList)
                {
                    if (StringUtils.equals(vdcSer.getId(), ser.getId()))
                    {
                        vdcSer.setStatus(ser.getStatus());
                        break;
                    }
                }
            }
        }
        vdcServiceDirectory.setExtra(JSON.toJSONString(vdcSerDirList));
    }

    @RequestMapping(value = "/{vdcId}", method = RequestMethod.POST)
    public Object createVdcServiceDirectory(@PathVariable String vdcId, HttpServletRequest request,
            HttpServletResponse response)
    {
        logger.info("createVdcServiceDirectory: client = " + request.getRemoteHost() + ", vdcId = " + vdcId);

        CommonResponse rsp = new CommonResponse();
        try
        {
            VdcServiceDirectoryBean vdcSerDir = vdcServiceDirectoryService.getVdcServiceDirectory(vdcId);
            if (null != vdcSerDir)
            {
                rsp.setSuccess(false);
                rsp.setMessage("The vdc service directory already exists.");
                return rsp;
            }

            List<ServiceDirectoryBean> serDirList = serviceDirectoryService.listServiceDirectorys();
            if (serDirList != null)
            {
                for (ServiceDirectoryBean serDir : serDirList)
                {
                    serDir.setStatus(2);
                }
                VdcServiceDirectoryBean vdcServiceDirectory = new VdcServiceDirectoryBean();
                vdcServiceDirectory.setVdcId(vdcId);
                vdcServiceDirectory.setExtra(JSON.toJSONString(serDirList));
                vdcServiceDirectoryService.addVdcServiceDirectory(vdcServiceDirectory);
                rsp.setData(vdcServiceDirectory);
                rsp.setSuccess(true);
                super.rptOptLog("servicedirectory.operation.create", null, null, request, response,
                        CommonConstants.SUCCESS_CODE_200);
            }
            else
            {
                rsp.setSuccess(false);
                rsp.setMessage("The global service directory is not initialized.");
                super.rptOptLog("servicedirectory.operation.create", rsp.getMessage(), null, request, response,
                        CommonConstants.SERVER_ERROR_CODE_500);
            }
        }
        catch (Exception e)
        {
            logger.error("createVdcServiceDirectory error, vdcId = " + vdcId, e);
            rsp.setSuccess(false);
            rsp.setMessage(e.getMessage());
            super.rptOptLog("servicedirectory.operation.create", rsp.getMessage(), null, request, response,
                    CommonConstants.SERVER_ERROR_CODE_500);
        }
        return rsp;
    }
}
