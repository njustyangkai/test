/**
 * 
 */
package com.zte.vdirector.controller;

import java.util.ArrayList;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zte.vdirector.service.OrgService;
import com.zte.vdirector.service.ResourceUsageService;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Operate  
 * </p>  
 * <p>   
 * 类名称：ResourceUsageController   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10138528   
 * </p>  
 * <p>  
 * 创建时间：2016-11-15 上午9:02:59 
 * </p>  
 * <p>    
 * 修改人：10138528  
 * </p>  
 * <p>  
 * 修改时间：2016-11-15 上午9:02:59  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/usage")
public class ResourceUsageController extends CommonController
{
    @Resource
    private ResourceUsageService resourceUsageService;

    @Resource
    private OrgService orgService;

    @RequestMapping(value = "", method = RequestMethod.POST)
    public Object getUsages(@RequestBody String body, HttpServletRequest request, HttpServletResponse response)
    {
        JSONObject params = JSON.parseObject(body);
        String orgId = params.getString("orgId");

        String projectId = params.getString("projectId");
        String projectName = params.getString("projectName");
        String type = params.getString("type");

        String vdcId = params.getString("vdcId");

        if (StringUtils.isBlank(projectId) && StringUtils.isNotBlank(projectName) && StringUtils.isNotBlank(type))
        {
            projectId = orgService.getProcjectId(type, projectName);
        }

        if (StringUtils.isNotBlank(type))
        {
            orgId = type;
        }

        if (StringUtils.isNotBlank(projectId))
        {
            return resourceUsageService.getProjectUsages(projectName, projectId);
        }
        else if (StringUtils.isNotBlank(vdcId))
        {
            return resourceUsageService.getVdcUsages(vdcId);
        }
        else if (StringUtils.isNotBlank(orgId))
        {
            return resourceUsageService.getOrgUsages(orgId);
        }

        return new ArrayList<Map<String, Object>>();
    }
}
