/**
 * 
 */
package com.zte.vdirector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.zte.vdirector.frame.interceptor.AuthInterceptor;
import com.zte.vdirector.frame.listener.ApplicationStartedListener;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：111  
 * </p>  
 * <p>   
 * 类名称：Main   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326   
 * </p>  
 * <p>  
 * 创建时间：2016年7月26日 下午2:56:42 
 * </p>  
 * <p>    
 * 修改人：10125326 11 
 * </p>  
 * <p>  
 * 修改时间：2016年7月26日 下午2:56:42  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0 11   
 *    
 */
@SpringBootApplication
@ServletComponentScan
public class Main extends WebMvcConfigurerAdapter
{
    public static void main(String[] args)
    {
        System.setProperty("spring.config.name", "operate");
        SpringApplication application = new SpringApplication(Main.class);
        application.addListeners(new ApplicationStartedListener());
        application.run(args);
    }

    public void addInterceptors(InterceptorRegistry registry)
    {
        registry.addInterceptor(new AuthInterceptor()).addPathPatterns("/**");
    }
}
