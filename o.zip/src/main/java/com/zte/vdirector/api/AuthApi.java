package com.zte.vdirector.api;

import org.springframework.stereotype.Service;

import com.zte.vdirector.client.util.BaseRequest;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.auth.AuthWrapper;

@Service
public class AuthApi extends BaseRequest
{
	
	 public RestfulRsp getAccess(String authUrl, AuthWrapper authWrapper) throws Exception
    {
        return super.post(authWrapper, null, null, authUrl);
    }
}
