package com.zte.vdirector.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：ScheduleTest   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年8月1日 下午2:19:18 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年8月1日 下午2:19:18  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Configuration
@EnableScheduling
public class ScheduleTest
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    /**
     * 定时器测试，20秒执行一次
     */
    @Scheduled(cron = "0/20 * * * * ?")
    public void scheduler()
    {
        logger.info("==================ScheduleTest 20 seconds==================");
    }
}
