package com.zte.vdirector.cache;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.zte.vdirector.domain.auth.AccessBean;

public class AuthCache
{
    private static final int CLEAR_SIZE = 1000;

    private static Map<String, AccessBean> accessCacheMap = new HashMap<String, AccessBean>();

    public synchronized static void putAccess2Cache(String key, AccessBean accessBean)
    {
        if (accessCacheMap.size() > CLEAR_SIZE)
        {
            long nowTime = System.currentTimeMillis();
            Iterator<AccessBean> values = accessCacheMap.values().iterator();
            while (values.hasNext())
            {
                AccessBean a = values.next();
                long expireTime = a.getExpireTime();
                if (expireTime < nowTime)
                {
                    values.remove();
                }
            }
        }
        accessCacheMap.put(key, accessBean);
    }

    public synchronized static void removeAccessFromCache(String key)
    {
        accessCacheMap.remove(key);
    }

    public synchronized static AccessBean getAccessFromCache(String key)
    {
        AccessBean accessBean = accessCacheMap.get(key);
        if (accessBean != null)
        {
            long expireTime = accessBean.getExpireTime();
            long nowTime = System.currentTimeMillis();
            if (nowTime < expireTime)
            {
                return accessBean;
            }
            else
            {
                accessCacheMap.remove(key);
                return null;
            }
        }
        else
        {
            return null;
        }
    }
}
