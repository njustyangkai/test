/**
 * 
 */
package com.zte.vdirector.frame.utils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.zte.vdirector.domain.gridqueryparams.PagingResult;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Operate  
 * </p>  
 * <p>   
 * 类名称：DbUtils   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10138528   
 * </p>  
 * <p>  
 * 创建时间：2016-11-8 下午4:29:43 
 * </p>  
 * <p>    
 * 修改人：10138528  
 * </p>  
 * <p>  
 * 修改时间：2016-11-8 下午4:29:43  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class DbUtils
{
    public static PagingResult pageQuery(JdbcTemplate jdbcTemplate, final String sql, final int start, final int limit)
    {
        final RowMapper<Map<String, Object>> rowMapper = new ColumnMapRowMapper();
        return jdbcTemplate.query(new ScrollPreparedStatementCreator(sql), new ResultSetExtractor<PagingResult>()
        {
            public PagingResult extractData(ResultSet rs) throws SQLException, DataAccessException
            {
                PagingResult queryResult = new PagingResult();
                List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();

                // 根据分页参数移动游标获取结果
                if (start == 0 || rs.absolute(start))
                {
                    for (int i = 0; i < limit && rs.next(); i++)
                    {
                        rows.add(rowMapper.mapRow(rs, i));
                    }
                }

                queryResult.setList(rows);

                // 将游标移至最后一行获取总记录数
                if (rs.last())
                {
                    queryResult.setTotal(rs.getRow());
                }

                return queryResult;
            }
        });
    }
}
