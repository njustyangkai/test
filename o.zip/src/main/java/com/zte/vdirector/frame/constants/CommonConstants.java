/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年7月28日      下午6:53:54
 */
package com.zte.vdirector.frame.constants;

/**
 * <p>
 * 描述:
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0:
 * </p>
 * <p>
 * 版本2.0:
 * </p>
 * 
 * @author 10171003
 * @version 2.0
 */

public interface CommonConstants
{

    int SUCCESS_CODE_200 = 200;
    int CREATED_CODE_201 = 201;
    int ACCEPTED_CODE_202 = 202;
    int DELETE_CODE_204 = 204;
    int SERVER_ERROR_CODE_500 = 500;
    int CONFLICT_CODE_409 = 409;
    int NOT_ACCEPTABLE_406 = 406;
    int NOT_FOUND_404 = 404;
    int BAD_REQUEST_400 = 400;

    /**
     * 
     * <p>
     * 描述:
     * </p>
     * <p>
     * 版权所有: 版权所有(C)2001-2016
     * </p>
     * <p>
     * 公 司: 深圳市中兴通讯股份有限公司
     * </p>
     * <p>
     * 版本1.0: 2011-4-2 新建
     * </p>
     * <p>
     * 版本1.1:
     * </p>
     * 
     * @author 10171003
     * @since ROS1.0
     * @version 1.0
     */
    interface ParamKey
    {
        String COMMON_URI = "uri";

        String COMMON_REQUESTBODY = "requestBody";

        String KEY_ID = "id";

        String KEY_NAME = "name";
    }

    interface Common
    {
        String SERVICE_NAME = "\\{serviceName\\}";
        String VERSION = "\\{version\\}";
        String ORG_ID = "\\{org_id\\}";
        String ID = "\\{id\\}";
        String PROJECT_ID = "\\{project_id\\}";
        String BIND_STATUS = "\\{bind_status\\}";
        String VDC_ID = "\\{vdc_id\\}";
        String NETWORK_ID = "\\{network_id\\}";
        String SUBNET_ID = "\\{subnet_id\\}";
    }

    interface KeyStone
    {
        String VERSION_TOKENS = "/v2.0/tokens";
        String X_AUTH_TOKEN = "X-Auth-Token";
    }

    /**
     * 
     * @author 10184649 url
     */
    interface Url
    {
        String VDC_GET_LIST = "/api/v1.0/vdclcm/vdcs";
        String VDC_ORG_LIST = "/api/v2.0/orgService/projects/{project_id}/vdcs/{bind_status}";
        String LIXIANG_UPLOAD_TICKET = "/icms/rest/getorder";
        String LIXIANG_DELETE_TICKET = "/icms/rest/delWorkOrder/{id}";
        String LIXIANG_REEXECUTE_TICKET = "/icms/rest/reExecute";
        String ORG_PROJECT_LIST = "/api/v2.0/orgService/orgs/{org_id}/projects";
        String GET_ORGS = "/api/v2.0/orgService/orgs";
        String GET_VDCS = "/api/v2.0/orgService/orgs/{org_id}/vdcIds";
        String VDC_ENVS_URI = "/api/v1.0/vdclcm/vdcs/{id}/tenantsenvs";
        String VDC_DETAIL = "/api/v1.0/vdclcm/vdcs/{id}";
        String GET_VDCS_IN_PROJECT = "/api/v2.0/orgService/projects/{project_id}/vdcs/{bind_status}";
        String GET_PROJECT_ID = "/projectName/projectType/projectId";
        String DCS = "/api/v1.0/vrm/dcs";
        String DC = "/api/v1.0/vrm/dcs/{id}";
        String CLOUD_ENV = "/api/v1.0/vrm/cloudenvs/{id}";
    }

    interface Cinder
    {
        String VOLUMES = "/volumes";
        String VOLUMES_DETAIL = "/volumes/detail";
        String VOLUMEV2 = "volumev2";
        String VOLUMES_VOLUME_ID = "/volumes/{volume_id}";
        String VOLUMES_VOLUME_ID_ACTION = "/volumes/{volume_id}/action";
        String VOLUMES_DELETE = "/volumes/{volume_id}";
        String REPLACE_PART_VOLUMEID = "\\{volume_id\\}";
        String VOLUME_TYPE = "/types";
    }

    interface Nova
    {
        String SERVERS = "/servers";
        String SERVERS_DETAIL = "/servers/detail";
        String COMPUTE = "compute";
        String SERVER_ID = "\\{server_id\\}";
        String ATTACHMENT_ID = "\\{attachment_id\\}";
        String SERVERS_SERVER_ID_OS_VOLUME_ATTACHMENTS = "/servers/{server_id}/os-volume_attachments";
        String SERVERS_SERVER_ID_OS_VOLUME_ATTACHMENTS_VOLUME_ID = "/servers/{server_id}/os-volume_attachments/{volume_id}";
        String FLAVORS = "/flavors";
        String FLAVORS_DETAIL = "/flavors/detail";
    }

    interface Glance
    {
        String IMAGES = "/v2/images";
        String IMAGE = "image";
    }

    interface Neutron
    {
        String NETWORKS = "/networks";
        String NETWORK = "network";
        String REPLACE_PART_FIREWALLID = "\\{firewall_id\\}";
        String REPLACE_PART_FIREWALLPOLICYID = "\\{firewall_policy_id\\}";
        String REPLACE_PART_FIREWALLRULEID = "\\{firewall_rule_id\\}";

        String FIREWALLS = "/v2.0/fw/firewalls";
        String FIREWALLS_ID = "/v2.0/fw/firewalls/{firewall_id}";
        String FIREWALL_POLICIES = "/v2.0/fw/firewall_policies";
        String FIREWALL_POLICIES_ID = "/v2.0/fw/firewall_policies/{firewall_policy_id}";
        String FIREWALL_POLICIES_INSERTRULE = "/v2.0/fw/firewall_policies/{firewall_policy_id}/insert_rule";
        String FIREWALL_POLICIES_REMOVERULE = "/v2.0/fw/firewall_policies/{firewall_policy_id}/remove_rule";
        String FIREWALL_RULES = "/v2.0/fw/firewall_rules";
        String FIREWALL_RULES_ID = "/v2.0/fw/firewall_rules/{firewall_rule_id}";

        String REPLACE_PART_LOADBALANCERID = "\\{loadbalancer_id\\}";
        String REPLACE_PART_LISTENERID = "\\{listener_id\\}";
        String REPLACE_PART_POOLID = "\\{pool_id\\}";
        String REPLACE_PART_MEMBERID = "\\{member_id\\}";
        String REPLACE_PART_MONITORID = "\\{health_monitor_id\\}";

        String V2_LOADBALANCERS = "/v2.0/lbaas/loadbalancers";
        String V2_LOADBALANCERS_ID = "/v2.0/lbaas/loadbalancers/{loadbalancer_id}";
        String V2_LISTENERS = "/v2.0/lbaas/listeners";
        String V2_LISTENERS_ID = "/v2.0/lbaas/listeners/{listener_id}";
        String V2_POOLS = "/v2.0/lbaas/pools";
        String V2_POOLS_ID = "/v2.0/lbaas/pools/{pool_id}";
        String V2_MEMBERS = "/v2.0/lbaas/pools/{pool_id}/members";
        String V2_MEMBERS_ID = "/v2.0/lbaas/pools/{pool_id}/members/{member_id}";
        String V2_HEALTH_MONITORS = "/v2.0/lbaas/healthmonitors";
        String V2_HEALTH_MONITORS_ID = "/v2.0/lbaas/healthmonitors/{health_monitor_id}";

        String SUBNETS = "/v2.0/subnets";

        String FLOATING_IPS = "/v2.0/floatingips";
        String PORTS = "/v2.0/ports";

        String ROUTERS = "/v2.0/routers";
        String LOADBALANCES = "/v2.0/lbaas/loadbalancers";

        String SUBNET_POOL = "/v2.0/subnetpools";
        String SUBNET_POOL_IP_AVAILABILITY = "v2.0/subnetpool-ip-availabilities";

        String SUBNET_POOL_ID = "\\{subnet_pool_id\\}";
        String PREFIX = "\\{prefix\\}";

        String CREATE_NETWORK = "/api/v1.0/dcisvc/cloudenv_networks";
        String CREATE_SUB_NETWORK = "/api/v1.0/dcisvc/cloudenv_subnets";
        String CREATE_VDC_NETWORK = "/api/v1.0/dcisvc/vdcs/{id}/vdc_networks";
        String GET_PHYSICAL_NETWORKS = "/v2.0/physnets";
        String VDC_NETWORKS_BATCH = "/api/v1.0/dcisvc/vdc_networks/batch";
        String GET_VDC_NETWORK = "/api/v1.0/dcisvc/vdcs/{vdc_id}/vdc_networks/{network_id}";

        String NEUTRON_NETWORKS = "/v2.0/networks";
        String NEUTRON_SUBNETS = "/v2.0/subnets";
        String NEUTRON_ROUTERS = "/v2.0/routers";
        String ROUTER_ID = "\\{router_id\\}";
        String NEUTRON_ROUTERS_BIND = "/v2.0/routers/{router_id}/add_router_interface";
        String AVAILABILITIES_IP = "/v2.0/network-ip-availabilities/{network_id}";
        String SUBNET = "/v2.0/subnets/{subnet_id}";
    }

    interface MicroServiceUri
    {
        String VRM_URI = "/api/v1.0/vrm/resourceGrant?type=volume";
        String VDC_ENVS_URI = "/api/v1.0/vdclcm/vdcs/{id}/tenantsenvs";
        String SM_URI = "/api/v1.0/vks/tokens/{id}";
        String ENVS_URI = "/api/v1.0/vdclcm/vdcs/{id}/tenantsenvs";
    }

    interface Billing
    {
        String CPU = "1001";
        String MEMORY = "1002";
        String OS_DISK = "1003";
        String FLOATING_IP = "1004";
        String PRIVATE_IP = "1005";
        String OS = "1006";
        String OS_WINDOWS = "1007";
        String OS_LINUX = "1008";
        String VOLUME = "2000";
        String VOLUME_STANDARD = "2001";
        String ROUTER = "3000";
        String ROUTER_DEFAULT = "3001";
        String FIREWALL = "4000";
        String FIREWALL_DEFAULT = "4001";
        String LOADBALANCE = "5000";
        String LOADBALANCE_DEFAULT = "5001";
        String DESKTOP = "6000";
        String DESKTOP_DEFAULT = "6001";
        String BANDWIDTH = "7000";
        String BANDWIDTH_DEFAULT = "7001";
    }

    interface Usage
    {
        String QUERY_USAGE = "/api/v1.0/pm/query";
    }
}
