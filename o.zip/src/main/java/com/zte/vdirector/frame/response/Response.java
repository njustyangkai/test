package com.zte.vdirector.frame.response;

public class Response
{
    /**
     * 返回码
     */
    private int code;
    /**
     * 描述
     */
    private String message;
    
    public Response(int code, String message)
    {
    	this.code = code;
    	this.message = message;
    }
	public int getCode() 
	{
		return code;
	}
	public void setCode(int code)
	{
		this.code = code;
	}
	public String getMessage() 
	{
		return message;
	}
	public void setMessage(String message)
	{
		this.message = message;
	}
}