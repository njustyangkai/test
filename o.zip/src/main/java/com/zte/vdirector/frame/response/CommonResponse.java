package com.zte.vdirector.frame.response;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Backup  
 * </p>  
 * <p>   
 * 类名称：CommonResponse   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年9月10日 下午3:09:52 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年9月10日 下午3:09:52  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class CommonResponse
{
    
    public CommonResponse()
    {
        this.success = true;
    }

    public CommonResponse(boolean success, String message)
    {
        this.success = success;
        this.message = message;
    }
    
    /**
     * true 成功
     * false 失败
     */
    private boolean success;

    /**
     * 失败时的描述
     */
    private String message;

    /**
     * 查询成功后得到的消息内容
     */
    private Object data;

    /**
     * @return the success
     */
    public boolean isSuccess()
    {
        return success;
    }

    /**
     * @param success the success to set
     */
    public void setSuccess(boolean success)
    {
        this.success = success;
    }

    /**
     * @return the message
     */
    public String getMessage()
    {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message)
    {
        this.message = message;
    }

    /**
     * @return the data
     */
    public Object getData()
    {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(Object data)
    {
        this.data = data;
    }
}
