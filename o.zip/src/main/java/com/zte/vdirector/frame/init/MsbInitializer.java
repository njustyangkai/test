package com.zte.vdirector.frame.init;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.zte.vdirector.client.microservice.msb.MsbAPI;
import com.zte.vdirector.client.util.MsbUtil;
import com.zte.vdirector.client.util.RestfulClient;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.frame.constants.CommonConstants;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：MsbInitializer   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10125326王明涛 
 * </p>  
 * <p>  
 * 创建时间：2016年8月2日 上午8:22:00 
 * </p>  
 * <p>    
 * 修改人：10125326  
 * </p>  
 * <p>  
 * 修改时间：2016年8月2日 上午8:22:00  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Component
public class MsbInitializer implements CommandLineRunner
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private Environment env;
    @Resource
    private MsbAPI msbAPI;

    @Override
    public void run(String... arg0) throws Exception
    {
        // 初始化RestfulClient
        int connectTimeout = env.getProperty("http.connecttimeout", Integer.class);
        int readTimeout = env.getProperty("http.readtimeout", Integer.class);
        int maxPerRoute = env.getProperty("http.clent.maxperroute", Integer.class);
        int maxTotal = env.getProperty("http.clent.maxtotal", Integer.class);
        RestfulClient.init(maxPerRoute, maxTotal, connectTimeout, readTimeout);

        String msbFlag = env.getProperty("msb.flag");

        if ("1".equals(msbFlag))
        {
            new Thread()
            {
                @Override
                public void run()
                {
                    String msbIp = env.getProperty("msb.address");
                    String msbPort = env.getProperty("msb.port");
                    String msbInnerPort = env.getProperty("msb.inner.port");
                    //配置微服务内部调用ip地址，统一为msb内部调用地址
                    MsbUtil.setMsbUrlPath("http://" + msbIp + ":" + msbInnerPort);

                    String serviceName = env.getProperty("server.serviceName");
                    String port = env.getProperty("server.port");
                    String path = env.getProperty("server.context-path");
                    String version = env.getProperty("server.version");

                    String msbUrl = "http://" + msbIp + ":" + msbPort
                            + "/api/microservices/v1/services?createOrUpdate=false";

                    boolean result = false;
                    while (!result)
                    {
                        logger.info("================MSB注册================");
                        result = registerMsb(msbAPI, path, version, serviceName, port, msbUrl);
                        try
                        {
                            Thread.sleep(10000);
                        }
                        catch (Exception e)
                        {
                            logger.info("================MSB注册 fail to sleep================");
                        }
                    }
                    logger.info("================MSB注册成功================");
                }
            }.start();
        }
    }

    /**
     * 注册msb
     * @param msbAPI 
     * @param url
     * @param serviceName
     * @param port
     * @param ip
     * @return e
     */
    private boolean registerMsb(MsbAPI msbAPI, String url, String version, String serviceName, String port,
            String msbUrl)
    {
        Map<String, Object> node = new HashMap<String, Object>();
        //ip传空字符串即可，msb会识别到过来请求的ip
        node.put("ip", "");
        node.put("port", port);
        node.put("ttl", 0);

        List<Map<String, Object>> nodes = new ArrayList<Map<String, Object>>();
        nodes.add(node);

        Map<String, Object> registerMap = new HashMap<String, Object>();
        registerMap.put("serviceName", serviceName);
        registerMap.put("version", version);
        registerMap.put("url", url);
        registerMap.put("protocol", "REST");
        registerMap.put("type", "UI");
        registerMap.put("nodes", nodes);

        try
        {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(CommonConstants.ParamKey.COMMON_REQUESTBODY, registerMap);
            map.put(CommonConstants.ParamKey.COMMON_URI, msbUrl);
            RestfulRsp response = msbAPI.registerMsb(map);
            if (response.getStatusCode() == CommonConstants.CREATED_CODE_201)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception e)
        {
            logger.error("register Msb error", e);
            return false;
        }
    }
}
