package com.zte.vdirector.frame.utils.excel;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCell;

/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ������������������������������������������������������������������������������������������
 * 10171003     2016��10��19��      ����2:54:14
*/

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class Util
{
    /**
     * get postfix of the path
     * @param path
     * @return
     */
    public static String getPostfix(String path)
    {
        if (path == null || Common.EMPTY.equals(path.trim()))
        {
            return Common.EMPTY;
        }
        if (path.contains(Common.POINT))
        {
            return path.substring(path.lastIndexOf(Common.POINT) + 1, path.length());
        }
        return Common.EMPTY;
    }

    @SuppressWarnings({ "static-access", "deprecation" })
    public static String getValue(XSSFCell xssfRow)
    {
        if (xssfRow.getCellType() == xssfRow.CELL_TYPE_BOOLEAN)
        {
            return String.valueOf(xssfRow.getBooleanCellValue());
        }
        else if (xssfRow.getCellType() == xssfRow.CELL_TYPE_NUMERIC)
        {
            return String.valueOf(xssfRow.getNumericCellValue());
        }
        else
        {
            return String.valueOf(xssfRow.getStringCellValue());
        }
    }

    @SuppressWarnings({ "static-access", "deprecation" })
    public static String getValue(HSSFCell hssfCell)
    {
        if (hssfCell.getCellType() == hssfCell.CELL_TYPE_BOOLEAN)
        {
            return String.valueOf(hssfCell.getBooleanCellValue());
        }
        else if (hssfCell.getCellType() == hssfCell.CELL_TYPE_NUMERIC)
        {
            return String.valueOf(hssfCell.getNumericCellValue());
        }
        else
        {
            return String.valueOf(hssfCell.getStringCellValue());
        }
    }
}
