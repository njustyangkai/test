/*
 * ZTE Corporation, Copyright 2001-2011, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * Administrator     2011-6-14      下午02:55:07
*/
package com.zte.vdirector.frame.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementCreator;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2011
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本1.0: 2011-4-2 新建
 * </p> 
 * <p>
 * 版本1.1: 
 * </p>
 * @author Administrator
 * @since ROS1.0
 * @version 1.0
 */
public class ScrollPreparedStatementCreator implements PreparedStatementCreator
{
    private String sql;
    
    /**
     * Instantiates a new scroll prepared statement creator.
     * 
     * @param sql 
     */
    public ScrollPreparedStatementCreator(String sql)
    {
        this.sql = sql;
    }

    /**
     * 创建结果集可以上下移动的PreparedStatment.
     * 
     * @param con 
     * @return the prepared statement
     * @throws SQLException 
     * @version
     */
    public PreparedStatement createPreparedStatement(Connection con) throws SQLException
    {
        return con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    }
}
