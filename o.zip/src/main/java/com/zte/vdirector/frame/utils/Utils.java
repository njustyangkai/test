package com.zte.vdirector.frame.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zte.vdirector.domain.CloudEnvInfo;
import com.zte.vdirector.domain.auth.AccessBean;
import com.zte.vdirector.frame.constants.CommonConstants;

public class Utils
{
    public static Logger logger = LoggerFactory.getLogger(Utils.class);
    public static String TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

    /**
     * 时间格式转换
     * eg:"created_at": "2016-09-01T12:20:47.000000","created_at": "2016-09-01 20:20:47",
     * @param createdAt
     * @return
     */
    public static String convertTimeFormat(String createdAt)
    {
        try
        {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            df.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date date = df.parse(createdAt);
            SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return d.format(date);
        }
        catch (ParseException e)
        {
            logger.error("convertTimeFormat is error:", e);
            return null;
        }
    }

    public static String toString(Date date, String format)
    {
        if (date == null)
        {
            return "";
        }

        if ((format == null) || (format.length() == 0))
        {
            return "";
        }

        SimpleDateFormat formatter = new SimpleDateFormat(format);
        return formatter.format(date);
    }

    public static String getCloudKey(CloudEnvInfo c)
    {
        return c.getEnvId() + c.getTenantName() + c.getUserName() + c.getPassword();
    }

    public static String decodeStr(String str)
    {
        if (StringUtils.isNotBlank(str))
        {
            try
            {
                str = URLDecoder.decode(str, "utf-8");
            }
            catch (UnsupportedEncodingException e)
            {
                logger.error("decode str error", e);
            }
        }
        return str;
    }

    public static Map<String, String> getHeader(AccessBean accessBean)
    {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put(CommonConstants.KeyStone.X_AUTH_TOKEN, accessBean.getToken());
        return headers;
    }
}
