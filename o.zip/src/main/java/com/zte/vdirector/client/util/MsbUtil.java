/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年8月12日      上午10:28:26
 */
package com.zte.vdirector.client.util;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class MsbUtil
{

    private static String msbUrlPath;

    public static String getMsbUrlPath()
    {
        return msbUrlPath;
    }

    public static void setMsbUrlPath(String msbUrlPath)
    {
        MsbUtil.msbUrlPath = msbUrlPath;
    }

}
