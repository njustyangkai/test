package com.zte.vdirector.client.util;

import org.springframework.http.HttpHeaders;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：RosRestOut   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年7月30日 下午2:56:09 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年7月30日 下午2:56:09  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class RestfulRsp
{
    private int statusCode;

    private String statusName;

    private String responseBody;

    private HttpHeaders headers;

    /**
     * @return int
     */
    public int getStatusCode()
    {
        return statusCode;
    }

    /**
     * @param statusCode statusCode
     */
    public void setStatusCode(int statusCode)
    {
        this.statusCode = statusCode;
    }

    /**
     * @return String
     */
    public String getStatusName()
    {
        return statusName;
    }

    /**
     * @param statusName statusName
     */
    public void setStatusName(String statusName)
    {
        this.statusName = statusName;
    }

    /**
     * @return String
     */
    public String getResponseBody()
    {
        return responseBody;
    }

    /**
     * @param responseBody responseBody
     */
    public void setResponseBody(String responseBody)
    {
        this.responseBody = responseBody;
    }

    /**
     * @return HttpHeaders
     */
    public HttpHeaders getHeaders()
    {
        return headers;
    }

    /**
     * @param headers headers
     */
    public void setHeaders(HttpHeaders headers)
    {
        this.headers = headers;
    }
}
