/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年7月28日      下午6:52:34
 */
package com.zte.vdirector.client.microservice.msb;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.zte.vdirector.client.util.BaseRequest;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.frame.constants.CommonConstants;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */
@Service
public class MsbAPI extends BaseRequest
{
    /**
     * 注册msb接口.
     * 
     * @param map 
     * @return RestfulRsp
     * @throws Exception 
     */
    public RestfulRsp registerMsb(Map<String, Object> map) throws Exception
    {
        String url = map.get(CommonConstants.ParamKey.COMMON_URI).toString();
        return super.post(map.get(CommonConstants.ParamKey.COMMON_REQUESTBODY), null, null, url);
    }
}
