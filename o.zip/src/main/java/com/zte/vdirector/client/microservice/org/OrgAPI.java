/**
 * 
 */
package com.zte.vdirector.client.microservice.org;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.zte.vdirector.client.util.BaseRequest;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.frame.constants.CommonConstants;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：OrgAPI   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10138528   
 * </p>  
 * <p>  
 * 创建时间：2016-11-2 下午6:06:57 
 * </p>  
 * <p>    
 * 修改人：10138528  
 * </p>  
 * <p>  
 * 修改时间：2016-11-2 下午6:06:57  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
@Service
public class OrgAPI extends BaseRequest
{
    public RestfulRsp getOrgs(Map<String, Object> map) throws Exception
    {
        String url = map.get(CommonConstants.ParamKey.COMMON_URI).toString() + CommonConstants.Url.GET_ORGS;
        return super.get(null, null, null, url);
    }

    public RestfulRsp getVdcs(Map<String, Object> map) throws Exception
    {
        String url = map.get(CommonConstants.ParamKey.COMMON_URI).toString() + CommonConstants.Url.GET_ORGS;
        url = url.replace(CommonConstants.Common.ORG_ID, map.get("orgId").toString());
        return super.get(null, null, null, url);
    }
}
