package com.zte.vdirector.client.util;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.X509Certificate;

import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.log4j.Logger;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：iros-cos  
 * </p>  
 * <p>   
 * 类名称：DefaultHttpClient   
 * </p>  
 * <p>  
 * 类描述：重写DefaultHttpClient，禁用HTTPS的证书校验
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年5月26日 上午9:21:45 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年5月26日 上午9:21:45  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@SuppressWarnings("deprecation")
public class DefaultHttpClient extends org.apache.http.impl.client.DefaultHttpClient
{
    /**
     * 日志对象
     */
    private static Logger logger = Logger.getLogger(DefaultHttpClient.class);

    private static PoolingClientConnectionManager getPoolClientConnMgr(int maxPerRoute, int maxTotal)
    {
        PoolingClientConnectionManager pccm = null;
        logger.info("Begin to init client connection manager supported https.");
        TrustStrategy acceptingTrustStrategy = new TrustStrategy()
        {
            @Override
            public boolean isTrusted(X509Certificate[] certificate, String authType)
            {
                return true;
            }
        };
        SSLSocketFactory sf;
        try
        {
            sf = new SSLSocketFactory(acceptingTrustStrategy, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            SchemeRegistry registry = new SchemeRegistry();
            registry.register(new Scheme("http", 80, PlainSocketFactory.getSocketFactory()));
            registry.register(new Scheme("https", 443, sf));
            pccm = new PoolingClientConnectionManager(registry);
            //每个主机的最大并行链接数
            pccm.setDefaultMaxPerRoute(maxPerRoute > 0 ? maxPerRoute : 2);
            //客户端总并行链接最大数
            pccm.setMaxTotal(maxTotal > 0 ? maxTotal : 20);
        }
        catch (KeyManagementException e)
        {
            logger.error("Fail to create http client.", e);
        }
        catch (UnrecoverableKeyException e)
        {
            logger.error("Fail to create http client.", e);
        }
        catch (NoSuchAlgorithmException e)
        {
            logger.error("Fail to create http client.", e);
        }
        catch (KeyStoreException e)
        {
            logger.error("Fail to create http client.", e);
        }
        logger.info("Begin to init client connection manager supported https.");
        return pccm;
    }

    public DefaultHttpClient()
    {
        super(getPoolClientConnMgr(2, 20));
    }

    /**
     * 构造方法
     * 
     * @param maxPerRoute 每个主机的最大并行链接数
     * @param maxTotal 客户端总并行链接最大数
     */
    public DefaultHttpClient(int maxPerRoute, int maxTotal)
    {
        super(getPoolClientConnMgr(maxPerRoute, maxTotal));
    }
}
