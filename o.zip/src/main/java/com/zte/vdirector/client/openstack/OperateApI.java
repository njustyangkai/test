package com.zte.vdirector.client.openstack;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.zte.vdirector.client.util.BaseRequest;
import com.zte.vdirector.client.util.RestfulRsp;
import com.zte.vdirector.domain.auth.AuthWrapper;

@Service
public class OperateApI extends BaseRequest
{
    public RestfulRsp getAccess(String authUrl, AuthWrapper authWrapper) throws Exception
    {
        return super.post(authWrapper, null, null, authUrl);
    }

    public RestfulRsp post(String url, Map<String, String> headers, Object body) throws Exception
    {
        return super.post(body, headers, null, url);
    }

    public RestfulRsp delete(String url, Map<String, String> headers, Object body) throws Exception
    {
        return super.delete(body, headers, null, url);
    }

    public RestfulRsp get(String url, Map<String, String> headers, Object body) throws Exception
    {
        return super.get(body, headers, null, url);
    }

    public RestfulRsp put(String url, Map<String, String> headers, Object body) throws Exception
    {
        return super.put(body, headers, null, url);
    }
}
