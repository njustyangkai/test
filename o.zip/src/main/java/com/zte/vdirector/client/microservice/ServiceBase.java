package com.zte.vdirector.client.microservice;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.zte.vdirector.client.util.BaseRequest;
import com.zte.vdirector.client.util.MsbUtil;
import com.zte.vdirector.client.util.RestfulRsp;

@Service
public class ServiceBase extends BaseRequest
{

    public RestfulRsp post(Object map, String urlpath) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.post(map, null, null, url);
    }

    public RestfulRsp post(Object map, Map<String, String> headers, String urlpath) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.post(map, headers, null, url);
    }

    public RestfulRsp put(Object map, String urlpath) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.put(map, null, null, url);
    }

    public RestfulRsp get(String urlpath) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.get(null, null, null, url);
    }

    public RestfulRsp get(String urlpath, Map<String, String> header) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.get(null, header, null, url);
    }

    public RestfulRsp delete(String urlpath) throws Exception
    {
        String url = MsbUtil.getMsbUrlPath() + urlpath;
        return super.delete(null, null, null, url);
    }

}
