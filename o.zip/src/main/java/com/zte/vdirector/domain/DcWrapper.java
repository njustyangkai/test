package com.zte.vdirector.domain;

import java.util.List;

public class DcWrapper
{
	private List<Dc> dcs;

	public List<Dc> getDcs() 
	{
		return dcs;
	}

	public void setDcs(List<Dc> dcs) 
	{
		this.dcs = dcs;
	}
}
