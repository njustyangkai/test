package com.zte.vdirector.domain;

public class CloudEnvInfo
{
	private String envId;
	
	private String envName;
	
	private String url;
	
	private String type;

    private String tenantId;
	
	private String tenantName;
	
	private String userName;
	
	private String password;

	public String getEnvId() 
	{
		return envId;
	}

	public void setEnvId(String envId)
	{
		this.envId = envId;
	}

	public String getEnvName()
	{
		return envName;
	}

	public void setEnvName(String envName) 
	{
		this.envName = envName;
	}

	public String getUrl() 
	{
		return url;
	}

	public void setUrl(String url) 
	{
		this.url = url;
	}

	public String getType() 
	{
		return type;
	}

	public void setType(String type) 
	{
		this.type = type;
	}

    public String getTenantId()
    {
        return tenantId;
    }

    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    public String getTenantName()
	{
		return tenantName;
	}

	public void setTenantName(String tenantName) 
	{
		this.tenantName = tenantName;
	}

	public String getUserName() 
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}	
}
