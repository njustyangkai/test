package com.zte.vdirector.domain.servicedirectory;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：ServiceDirectoryDao   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 上午10:45:06 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 上午10:45:06  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Repository
public class ServiceDirectoryDao
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private JdbcTemplate jdbcTemplate;

    public List<ServiceDirectoryBean> listServiceDirectorys()
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from service_directory");
        return jdbcTemplate.query(sql.toString(), new ServiceDirectoryRowMapper());
    }

    public ServiceDirectoryBean getServiceDirectoryDetail(String id)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from service_directory where id = ? ");
        try
        {
            return jdbcTemplate.queryForObject(sql.toString(), new ServiceDirectoryRowMapper(), id);
        }
        catch (Exception e)
        {
            logger.error("Fail to get service directory detail.", e);
            return null;
        }
    }
}
