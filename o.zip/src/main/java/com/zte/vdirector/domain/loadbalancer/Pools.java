package com.zte.vdirector.domain.loadbalancer;

import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Pools   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *    "pools":[
 *       {
 *          "status":"ACTIVE",
 *          "lb_method":"ROUND_ROBIN",
 *          "protocol":"HTTP",
 *          "description":"",
 *          "health_monitors":[
 *             "466c8345-28d8-4f84-a246-e04380b0461d",
 *             "5d4b5228-33b0-4e60-b225-9b727c1a20e7"
 *          ],
 *          "subnet_id":"8032909d-47a1-4715-90af-5153ffe39861",
 *          "tenant_id":"83657cfcdfe44cd5920adaf26c48ceea",
 *          "admin_state_up":true,
 *          "name":"app_pool",
 *          "members":[
 *             "701b531b-111a-4f21-ad85-4795b7b12af6",
 *             "beb53b4d-230b-4abd-8118-575b8fa006ef"
 *          ],
 *          "id":"72741b06-df4d-4715-b142-276b6bce75ab",
 *          "vip_id":"4ec89087-d057-4e2c-911f-60a3b47ee304"
 *       }
 *    ]
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 下午3:16:09 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 下午3:16:09  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Pools implements Iterable<Pool>
{
    /**
     * Pool列表 
     */
    private List<Pool> pools;

    public List<Pool> getPools()
    {
        return pools;
    }

    public void setPools(List<Pool> pools)
    {
        this.pools = pools;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }

    @Override
    public Iterator<Pool> iterator()
    {
        return pools.iterator();
    }
}
