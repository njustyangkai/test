/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月20日      下午2:45:41
*/
package com.zte.vdirector.domain.ticket;

import java.util.List;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */
/*
 *  {

    "appId": "ICMS16SH1476932830973",   //工单编号全局唯一 

    "applicant": "test",                             //申请人

    "devices": [                                        //主机配置表

        {

            "appType": "新增",                     //申请类型

            "deviceCode": "1",                     //设备编号

            "deviceConfigurationId": "1111", //工单编号全局唯一

            "deviceCpuNew": "2",                //CPU 设备需求(新项)

            "deviceHardDiskNew": "50",       //硬盘  设备需求(新项)

            "deviceMemoryNew": "4",   //内存  设备需求(新项)

           "deviceType": "虚拟机",      //设备类型

            "netCn2New": "0",                //CN2 网络需求(新项)

            "netEniNew": "1",                //ENI 网络需求(新项)

            "netInternetNew": "0",         //Internet 网络需求(新项)

            "netbPlaneNew": "0",         //B平面  网络需求(新项)

            "osVersion": "Microsoft Windows Server 2008 R2 (64 位)",   //拟装操作系统版本

            "remark": "备注",                       //备注

            "serverFunction": "数据库服务器",   //服务器功能

            "vmName": "DB01"                                   //服务器名称

        }

    ], 

    "networks": [                       //IP地址申请表

        {

            "description": "浮动IP",       //备注

            "id": "111",                         //IP地址申请表主键ID

            "networkfn": "测试",            //地址用途

            "serialNo": "111",          //工单编号全局唯一

            "subnet": "111",                  //子网

            "type": "B",                  //网络申请种类

            "vmName": "DB01",      //服务器名称

            "vmWork": "虚机"      //服务器功能

        }

    ], 

    "platformCode": "ljdxjk"     //平台代号

}

 */
public class TicketRestBean
{

    private String appId;//工单编号全局唯一 

    private String applicant;//申请人

    private String appCompany;//申请单位

    private String appPhoneNum;//申请人电话呢

    private String appEmail;//申请人邮件

    private String appDate;//申请日期

    private String appType;//申请类型

    private String appNumber;//申请编号

    private String isProject;//是否工程

    private String proNumber;//工程编号

    private String gscField;//金银铜域

    private String platformName;//平台名称

    private String maintainDept;//维护部门

    private String maintainCompany;//维护单位

    public String getMaintainDept()
    {
        return maintainDept;
    }

    public void setMaintainDept(String maintainDept)
    {
        this.maintainDept = maintainDept;
    }

    /**
     * 联系人员
     */
    private String contacts;

    /**
     * 联系人电话
     */
    private String contPhoneNum;

    /**
     * 联系人邮件
     */
    private String contEmail;

    /**
     * 联系人员
     */
    private String ContactsBak;

    /**
     * 联系人电话
     */
    private String ContPhoneNumBak;

    /**
     * 联系人邮件
     */
    private String ContEmailBak;

    /**
     * 平台主要服务项目
     */
    private String serviceProject;

    private List<TicketDeviceRestBean> devices; //主机配置表

    private List<TicketNetworkRestBean> networks;//IP地址申请表

    private String platformCode;//平台代号

    public String getAppId()
    {
        return appId;
    }

    public void setAppId(String appId)
    {
        this.appId = appId;
    }

    public String getApplicant()
    {
        return applicant;
    }

    public void setApplicant(String applicant)
    {
        this.applicant = applicant;
    }

    public List<TicketDeviceRestBean> getDevices()
    {
        return devices;
    }

    public void setDevices(List<TicketDeviceRestBean> devices)
    {
        this.devices = devices;
    }

    public List<TicketNetworkRestBean> getNetworks()
    {
        return networks;
    }

    public void setNetworks(List<TicketNetworkRestBean> networks)
    {
        this.networks = networks;
    }

    public String getPlatformCode()
    {
        return platformCode;
    }

    public void setPlatformCode(String platformCode)
    {
        this.platformCode = platformCode;
    }

    public String getAppCompany()
    {
        return appCompany;
    }

    public void setAppCompany(String appCompany)
    {
        this.appCompany = appCompany;
    }

    public String getAppPhoneNum()
    {
        return appPhoneNum;
    }

    public void setAppPhoneNum(String appPhoneNum)
    {
        this.appPhoneNum = appPhoneNum;
    }

    public String getContactsBak()
    {
        return ContactsBak;
    }

    public void setContactsBak(String contactsBak)
    {
        ContactsBak = contactsBak;
    }

    public String getContPhoneNumBak()
    {
        return ContPhoneNumBak;
    }

    public void setContPhoneNumBak(String contPhoneNumBak)
    {
        ContPhoneNumBak = contPhoneNumBak;
    }

    public String getContEmailBak()
    {
        return ContEmailBak;
    }

    public void setContEmailBak(String contEmailBak)
    {
        ContEmailBak = contEmailBak;
    }

    public String getAppEmail()
    {
        return appEmail;
    }

    public void setAppEmail(String appEmail)
    {
        this.appEmail = appEmail;
    }

    public String getAppDate()
    {
        return appDate;
    }

    public void setAppDate(String appDate)
    {
        this.appDate = appDate;
    }

    public String getAppType()
    {
        return appType;
    }

    public void setAppType(String appType)
    {
        this.appType = appType;
    }

    public String getAppNumber()
    {
        return appNumber;
    }

    public void setAppNumber(String appNumber)
    {
        this.appNumber = appNumber;
    }

    public String getIsProject()
    {
        return isProject;
    }

    public void setIsProject(String isProject)
    {
        this.isProject = isProject;
    }

    public String getProNumber()
    {
        return proNumber;
    }

    public void setProNumber(String proNumber)
    {
        this.proNumber = proNumber;
    }

    public String getGscField()
    {
        return gscField;
    }

    public void setGscField(String gscField)
    {
        this.gscField = gscField;
    }

    public String getPlatformName()
    {
        return platformName;
    }

    public void setPlatformName(String platformName)
    {
        this.platformName = platformName;
    }

    public String getMaintainCompany()
    {
        return maintainCompany;
    }

    public void setMaintainCompany(String maintainCompany)
    {
        this.maintainCompany = maintainCompany;
    }

    public String getContacts()
    {
        return contacts;
    }

    public void setContacts(String contacts)
    {
        this.contacts = contacts;
    }

    public String getContPhoneNum()
    {
        return contPhoneNum;
    }

    public void setContPhoneNum(String contPhoneNum)
    {
        this.contPhoneNum = contPhoneNum;
    }

    public String getContEmail()
    {
        return contEmail;
    }

    public void setContEmail(String contEmail)
    {
        this.contEmail = contEmail;
    }

    public String getServiceProject()
    {
        return serviceProject;
    }

    public void setServiceProject(String serviceProject)
    {
        this.serviceProject = serviceProject;
    }

}
