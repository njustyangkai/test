package com.zte.vdirector.domain.instance;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：RuleIpRange   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月23日 上午11:11:29 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月23日 上午11:11:29  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class RuleIpRange
{
    /**
     * CIDR-无类型域间选路
     */
    private String cidr;

    public String getCidr()
    {
        return cidr;
    }

    public void setCidr(String cidr)
    {
        this.cidr = cidr;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
