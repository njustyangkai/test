package com.zte.vdirector.domain.subnet;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.loadbalancer.Pool;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Subnet   
 * </p>  
 * <p>  
 * 类描述：子网信息  
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 下午3:11:33 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 下午3:11:33  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Subnet
{
    /**
     * 名称
     */
    private String name;

    /**
     * 是否开启DHCP
     */
    @JSONField(name = "enable_dhcp")
    private boolean enableDhcp;

    /**
     * 网络ID
     */
    @JSONField(name = "network_id")
    private String networkId;

    /**
     * 租户ID
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    /**
     * 
     */
    @JSONField(name = "dns_nameservers")
    private List<String> dnsNameServers;

    /**
     * 
     */
    @JSONField(name = "allocation_pools")
    private List<Pool> allocationPools;

    /**
     * 
     */
    @JSONField(name = "host_routes")
    private List<HostRoutes> hostRoutes;

    /**
     * IP版本
     */
    @JSONField(name = "ip_version")
    private Integer ipVersion;

    /**
     * 网关IP
     */
    @JSONField(name = "gateway_ip")
    private String gatewayIp;

    /**
     * 
     */
    private String cidr;

    /**
     * 子网ID
     */
    private String id;

    /**
     * 网络信息
     */
    private Network network;

    public Network getNetwork()
    {
        return network;
    }

    public void setNetwork(Network network)
    {
        this.network = network;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getCidr()
    {
        return cidr;
    }

    public void setCidr(String cidr)
    {
        this.cidr = cidr;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public boolean isEnableDhcp()
    {
        return enableDhcp;
    }

    public void setEnableDhcp(boolean enableDhcp)
    {
        this.enableDhcp = enableDhcp;
    }

    public String getNetworkId()
    {
        return networkId;
    }

    public void setNetworkId(String networkId)
    {
        this.networkId = networkId;
    }

    public String getTenantId()
    {
        return tenantId;
    }

    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    public List<String> getDnsNameServers()
    {
        return dnsNameServers;
    }

    public void setDnsNameServers(List<String> dnsNameServers)
    {
        this.dnsNameServers = dnsNameServers;
    }

    public List<Pool> getAllocationPools()
    {
        return allocationPools;
    }

    public void setAllocationPools(List<Pool> allocationPools)
    {
        this.allocationPools = allocationPools;
    }

    public List<HostRoutes> getHostRoutes()
    {
        return hostRoutes;
    }

    public void setHostRoutes(List<HostRoutes> hostRoutes)
    {
        this.hostRoutes = hostRoutes;
    }

    public Integer getIpVersion()
    {
        return ipVersion;
    }

    public void setIpVersion(Integer ipVersion)
    {
        this.ipVersion = ipVersion;
    }

    public String getGatewayIp()
    {
        return gatewayIp;
    }

    public void setGatewayIp(String gatewayIp)
    {
        this.gatewayIp = gatewayIp;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
