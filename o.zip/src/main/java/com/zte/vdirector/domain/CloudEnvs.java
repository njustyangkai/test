package com.zte.vdirector.domain;

import java.util.List;

public class CloudEnvs 
{
	 List<CloudEnvInfo> tenantEnvs;

	public List<CloudEnvInfo> getTenantEnvs()
	{
		return tenantEnvs;
	}

	public void setTenantEnvs(List<CloudEnvInfo> tenantEnvs) 
	{
		this.tenantEnvs = tenantEnvs;
	}
}
