package com.zte.vdirector.domain.instance;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api-V4.03.xx  
 * </p>  
 * <p>   
 * 类名称：ValueReason   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：00141233   
 * </p>  
 * <p>  
 * 创建时间：2015-3-17 下午3:24:51 
 * </p>  
 * <p>    
 * 修改人：00141233 
 * </p>  
 * <p>  
 * 修改时间：2015-3-17 下午3:24:51  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class ValueReason
{
    /**
     * 资源名称
     */
    @JSONField(name = "display_name")
    private String displayName;

    /**
     * 资源id
     */
    @JSONField(name = "resource_id")
    private String resourceId;

    @JSONField(name = "resource_local")
    private String resourceLocal;

    @JSONField(name = "resource_property_key")
    private String resourcePropertyKey;

    @JSONField(name = "resource_property_value")
    private String resourcePropertyValue;

    public String getDisplayName()
    {
        return displayName;
    }

    public void setDisplayName(String displayName)
    {
        this.displayName = displayName;
    }

    public String getResourceId()
    {
        return resourceId;
    }

    public void setResourceId(String resourceId)
    {
        this.resourceId = resourceId;
    }

    public String getResourceLocal()
    {
        return resourceLocal;
    }

    public void setResourceLocal(String resourceLocal)
    {
        this.resourceLocal = resourceLocal;
    }

    public String getResourcePropertyKey()
    {
        return resourcePropertyKey;
    }

    public void setResourcePropertyKey(String resourcePropertyKey)
    {
        this.resourcePropertyKey = resourcePropertyKey;
    }

    public String getResourcePropertyValue()
    {
        return resourcePropertyValue;
    }

    public void setResourcePropertyValue(String resourcePropertyValue)
    {
        this.resourcePropertyValue = resourcePropertyValue;
    }

    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
