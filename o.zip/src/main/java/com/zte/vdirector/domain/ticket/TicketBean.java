/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月21日      下午5:15:50
*/
package com.zte.vdirector.domain.ticket;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketBean
{

    private String appId;

    private String status;

    private String applicant;

    private String appCompany;

    private String appPhoneNum;

    private String appEmail;

    private String appDate;

    private String appType;

    private String appNumber;

    private String isProject;

    private String proNumber;

    private String gscField;

    private String platformCode;

    private String platformName;

    private String maintainPlatform;

    private String contacts;

    private String contPhoneNum;

    private String contEmail;

    private String serviceProject;

    private String type;

    private String step;

    public String getAppId()
    {
        return appId;
    }

    public void setAppId(String appId)
    {
        this.appId = appId;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getApplicant()
    {
        return applicant;
    }

    public void setApplicant(String applicant)
    {
        this.applicant = applicant;
    }

    public String getAppCompany()
    {
        return appCompany;
    }

    public void setAppCompany(String appCompany)
    {
        this.appCompany = appCompany;
    }

    public String getAppPhoneNum()
    {
        return appPhoneNum;
    }

    public void setAppPhoneNum(String appPhoneNum)
    {
        this.appPhoneNum = appPhoneNum;
    }

    public String getAppEmail()
    {
        return appEmail;
    }

    public void setAppEmail(String appEmail)
    {
        this.appEmail = appEmail;
    }

    public String getAppDate()
    {
        return appDate;
    }

    public void setAppDate(String appDate)
    {
        this.appDate = appDate;
    }

    public String getAppType()
    {
        return appType;
    }

    public void setAppType(String appType)
    {
        this.appType = appType;
    }

    public String getIsProject()
    {
        return isProject;
    }

    public void setIsProject(String isProject)
    {
        this.isProject = isProject;
    }

    public String getProNumber()
    {
        return proNumber;
    }

    public void setProNumber(String proNumber)
    {
        this.proNumber = proNumber;
    }

    public String getGscField()
    {
        return gscField;
    }

    public void setGscField(String gscField)
    {
        this.gscField = gscField;
    }

    public String getPlatformCode()
    {
        return platformCode;
    }

    public void setPlatformCode(String platformCode)
    {
        this.platformCode = platformCode;
    }

    public String getPlatformName()
    {
        return platformName;
    }

    public void setPlatformName(String platformName)
    {
        this.platformName = platformName;
    }

    public String getMaintainPlatform()
    {
        return maintainPlatform;
    }

    public void setMaintainPlatform(String maintainPlatform)
    {
        this.maintainPlatform = maintainPlatform;
    }

    public String getContacts()
    {
        return contacts;
    }

    public String getAppNumber()
    {
        return appNumber;
    }

    public void setAppNumber(String appNumber)
    {
        this.appNumber = appNumber;
    }

    public void setContacts(String contacts)
    {
        this.contacts = contacts;
    }

    public String getContPhoneNum()
    {
        return contPhoneNum;
    }

    public void setContPhoneNum(String contPhoneNum)
    {
        this.contPhoneNum = contPhoneNum;
    }

    public String getContEmail()
    {
        return contEmail;
    }

    public void setContEmail(String contEmail)
    {
        this.contEmail = contEmail;
    }

    public String getServiceProject()
    {
        return serviceProject;
    }

    public void setServiceProject(String serviceProject)
    {
        this.serviceProject = serviceProject;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getStep()
    {
        return step;
    }

    public void setStep(String step)
    {
        this.step = step;
    }

}
