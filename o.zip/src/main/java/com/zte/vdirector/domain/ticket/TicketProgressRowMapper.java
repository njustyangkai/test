/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月21日      下午5:25:04
*/
package com.zte.vdirector.domain.ticket;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketProgressRowMapper implements RowMapper<TicketProgressBean>
{
    public TicketProgressBean mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        TicketProgressBean ticketBean = new TicketProgressBean();

        ticketBean.setId(rs.getInt("ID") + "");
        ticketBean.setOrderId(rs.getString("ORDER_ID"));
        ticketBean.setResourceId(rs.getString("RESOURCE_ID"));
        ticketBean.setResourceName(rs.getString("RESOURCE_NAME"));
        ticketBean.setAutoTask(rs.getString("AUTO_TASK"));
        ticketBean.setBaseCode(rs.getString("BASE_CODE"));
        ticketBean.setCode(rs.getString("CODE"));
        ticketBean.setNeedResource(rs.getString("NEED_RESOURCE"));
        ticketBean.setParentCode(rs.getString("PARENT_CODE"));
        ticketBean.setStatus(rs.getString("STATUS"));
        ticketBean.setAction(rs.getString("ACTION"));

        return ticketBean;
    }

}
