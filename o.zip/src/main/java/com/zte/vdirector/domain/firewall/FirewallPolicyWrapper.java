/**
 * 
 */
package com.zte.vdirector.domain.firewall;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：FirewallPolicyWrapper   
 * </p>  
 * <p>  
 * 类描述：防火墙规则封装类      
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "firewall_policy": {
 *         "name": "test-fxm-2",
 *         "firewall_rules": [],
 *         "tenant_id": "40bb3ee25d604d219866d08a93150c40",
 *         "audited": false,
 *         "shared": false,
 *         "id": "856ee2c2-c105-4b8d-b591-fd6be206619d",
 *         "description": ""
 *     }
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月24日 下午4:28:11 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月24日 下午4:28:11  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class FirewallPolicyWrapper
{
    /**
     * 防火墙规则信息
     */
    @JSONField(name = "firewall_policy")
    private FirewallPolicy firewallPolicy;

    /**
     * @return the firewallPolicy
     */
    public FirewallPolicy getFirewallPolicy()
    {
        return firewallPolicy;
    }

    /**
     * @param firewallPolicy the firewallPolicy to set
     */
    public void setFirewallPolicy(FirewallPolicy firewallPolicy)
    {
        this.firewallPolicy = firewallPolicy;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
