/**
 * 
 */
package com.zte.vdirector.domain.billing;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.zte.vdirector.domain.gridqueryparams.PagingResult;
import com.zte.vdirector.frame.utils.DbUtils;
import com.zte.vdirector.service.OrgService;

/**
 * <p>
 * 版权所有：中兴通讯股份有限公司
 * </p>
 * <p>
 * 项目名称：Operate
 * </p>
 * <p>
 * 类名称：BillingDao
 * </p>
 * <p>
 * 类描述：
 * </p>
 * <p>
 * 创建人：10138528
 * </p>
 * <p>
 * 创建时间：2016-11-5 下午4:18:47
 * </p>
 * <p>
 * 修改人：10138528
 * </p>
 * <p>
 * 修改时间：2016-11-5 下午4:18:47
 * </p>
 * <p>
 * 修改备注：
 * </p>
 * 
 * @version 1.0
 * 
 */
@Repository
public class BillingDao
{
    private Logger logger = Logger.getLogger(OrgService.class);

    @Resource
    private JdbcTemplate jdbcTemplate;

    public static String getSuffix(Calendar time)
    {
        Calendar now;
        if (null != time)
        {
            now = time;
        }
        else
        {
            now = Calendar.getInstance();
        }

        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH) + 1;

        // 每种类型有24张表，最多可以保存2年数据 ，双年是 01~12 ，单年 是 13~24
        if (year % 2 == 0)
        {
            return month < 10 ? ("0" + month) : month + "";
        }
        return (month + 12) + "";
    }

    public static String getTableName(String type, String beginTime)
    {
        String suffix;
        if (StringUtils.isNotBlank(beginTime))
        {
            String[] time = beginTime.split("-");
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR, Integer.parseInt(time[0]));
            calendar.set(Calendar.MONTH, Integer.parseInt(time[1]) - 1);
            suffix = getSuffix(calendar);
        }
        else
        {
            suffix = getSuffix(null);
        }
        return "billing_" + type + "_" + suffix;
    }

    public PagingResult queryBilling(String orgId, String projectId, String vdcId, String type, String name,
            String beginTime, String endTime, int start, int limit)
    {
        String tableName = getTableName(type, beginTime);
        try
        {
            String orgColume = "";
            String projectColume = "";
            if (StringUtils.isNotBlank(orgId) && !"-1".equals(orgId))
            {
                orgColume = " org_id as orgId, org_name as orgName, ";
            }

            if (StringUtils.isNotBlank(projectId) && !"-1".equals(projectId))
            {
                projectColume = " project_id as orgId, project_name as orgName, ";
            }

            String sql = "select '"
                    + beginTime
                    + "' date, "
                    + orgColume
                    + projectColume
                    + " vdc_id as vdcId, "
                    + " vdc_name as vdcName, env_id as envId, env_name as envName, tenant_id as tenantId, user_id as userId, resource_id as resourceId, "
                    + " resource_name as resourceName, '" + type + "' as resourceType, resource_info as resourceInfo,"
                    + " begin_time as beginTime, end_time as endTime, record_time as recordTime, cost from "
                    + tableName + " where 1= 1 ";
            if (StringUtils.isNotBlank(orgId) && !"-1".equals(orgId))
            {
                sql += " and org_id = '" + orgId + "' ";
            }
            if (StringUtils.isNotBlank(projectId) && !"-1".equals(projectId))
            {
                sql += " and project_id = '" + projectId + "' ";
            }
            if (StringUtils.isNotBlank(vdcId) && !"-1".equals(vdcId))
            {
                sql += " and vdc_id = '" + vdcId + "'";
            }
            if (StringUtils.isNotBlank(name))
            {
                sql += " and resource_name like '%" + name + "%'";
            }
            // if (StringUtils.isNotBlank(beginTime) && StringUtils.isNotBlank(endTime))
            // {
            // sql += " and begin_time between '" + beginTime + "' and '" + endTime + "'";
            // }
            sql += " order by record_time desc ";
            return DbUtils.pageQuery(jdbcTemplate, sql, start, limit);
        }
        catch (Exception e)
        {
            logger.error("fail to run sql ", e);
        }
        return new PagingResult();
    }

    public PagingResult getStatistics(String orgId, String projectId, String vdcId, String beginTime, String endTime,
            int start, int limit)
    {
        beginTime = beginTime.substring(0, 7);
        String[] time = beginTime.split("-");
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, Integer.parseInt(time[0]));
        calendar.set(Calendar.MONTH, Integer.parseInt(time[1]) - 1);
        String suffix = getSuffix(calendar);

        String orgSql = "";
        String orgColume = "";
        String projectSql = "";
        String projectColume = "";
        String orgProjectColume = "";
        if (StringUtils.isNotBlank(orgId) && !"-1".equals(orgId))
        {
            orgSql += " and a.org_id = '" + orgId + "' ";
            orgColume = " a.org_id as orgId, a.org_name as orgName, ";
            orgProjectColume = " org_id, org_name, ";
        }

        if (StringUtils.isNotBlank(projectId) && !"-1".equals(projectId))
        {
            projectSql += " and a.project_id = '" + projectId + "' ";
            projectColume = " a.project_id as orgId, a.project_name as orgName, ";
            orgProjectColume = " project_id, project_name, ";
        }

        String vdcIdSql = "";

        if (StringUtils.isNotBlank(vdcId) && !"-1".equals(vdcId))
        {
            vdcIdSql = " and a.vdc_id = '" + vdcId + "' ";
        }

        try
        {
            String sql = "select distinct '" + beginTime + "' date, " + orgColume + projectColume
                    + " vm, volume, vr, vfw, vlb, vdesk, vnet, "
                    + " (case when vm is null then 0 else vm end + case when volume is null then 0 else volume end "
                    + " + case when vr is null then 0 else vr end + case when vfw is null then 0 else vfw end "
                    + " + case when vlb is null then 0 else vlb end + case when vdesk is null then 0 else vdesk end "
                    + " + case when vnet is null then 0 else vnet end) cost from " + " (select distinct "
                    + orgProjectColume + " vdc_id, vdc_name from org_vdc_rel) a left join"
                    + " (select vdc_name, vdc_id, sum(cost) vm from operate.billing_vm_" + suffix
                    + " group by vdc_id) b on a.vdc_id = b.vdc_id left join"
                    + " (select vdc_name, vdc_id, sum(cost) volume from " + " operate.billing_volume_" + suffix
                    + " group by vdc_id) c on a.vdc_id = c.vdc_id left join"
                    + " (select vdc_name, vdc_id, sum(cost) vr from " + "operate.billing_vr_" + suffix
                    + " group by vdc_id) d on a.vdc_id = d.vdc_id left join"
                    + " (select vdc_name, vdc_id, sum(cost) vfw from " + "operate.billing_vfw_" + suffix
                    + " group by vdc_id) e on a.vdc_id = e.vdc_id left join"
                    + " (select vdc_name, vdc_id, sum(cost) vlb from " + "operate.billing_vlb_" + suffix
                    + " group by vdc_id) f on a.vdc_id = f.vdc_id left join"
                    + " (select vdc_name, vdc_id, sum(cost) vdesk from " + "operate.billing_vdesk_" + suffix
                    + " group by vdc_id) g on a.vdc_id = g.vdc_id left join"
                    + " (select vdc_name, vdc_id, sum(cost) vnet from " + "operate.billing_vnet_" + suffix
                    + " group by vdc_id) h on a.vdc_id = h.vdc_id where 1 = 1 " + orgSql + projectSql + vdcIdSql
                    + " order by cost desc, a.vdc_name";
            return DbUtils.pageQuery(jdbcTemplate, sql, start, limit);
        }
        catch (Exception e)
        {
            logger.error("fail to run sql ", e);
        }
        return new PagingResult();
    }

    public List<Map<String, Object>> queryPrice()
    {
        try
        {
            String sql = "select b.service_key, a.* from charge_item a, service_directory b "
                    + " where a.service_directory_id = b.id order by a.id";
            return jdbcTemplate.queryForList(sql);
        }
        catch (Exception e)
        {
            logger.error("fail to run sql ", e);
        }
        return new ArrayList<Map<String, Object>>();
    }

    public void batchInsert(List<Object[]> params, String table)
    {
        try
        {
            String sql = "insert into "
                    + table
                    + "(org_id, org_name, vdc_id, vdc_name, project_id, project_name, env_id, env_name, tenant_id, user_id, "
                    + " resource_id, resource_name, status, resource_type, resource_info, price, cost, "
                    + " description, begin_time, end_time, record_time, extra) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    + " on duplicate key update price = ?, cost = ?, status = ?, description = ? ";
            jdbcTemplate.batchUpdate(sql, params);
        }
        catch (Exception e)
        {
            logger.error("fail to run sql ", e);
        }
    }

    public void insertOrgVdcRel(String orgId, String orgName, String projectId, String projectName, String vdcId,
            String vdcName, String envId, String envName)
    {
        try
        {
            Object[] params = { orgId, orgName, projectId, projectName, vdcId, vdcName, envId, envName, orgName,
                    projectName, vdcName, envName };
            String sql = "insert into org_vdc_rel (org_id, org_name, project_id, project_name, vdc_id, vdc_name, env_id, env_name) values (?,?,?,?,?,?,?,?)"
                    + " on duplicate key update org_name = ?, project_name = ?, vdc_name = ?, env_name = ?";
            jdbcTemplate.update(sql, params);
        }
        catch (Exception e)
        {
            logger.error("fail to run sql ", e);
        }
    }

    public void clear(String table)
    {
        try
        {
            String sql = "truncate table " + table;
            jdbcTemplate.update(sql);
        }
        catch (Exception e)
        {
            logger.error("fail to clear table " + table, e);
        }
    }
}
