package com.zte.vdirector.domain.firewall;

import com.alibaba.fastjson.JSON;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：FirewallWrapper   
 * </p>  
 * <p>  
 * 类描述：防火墙封装类   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "firewall": {
 *         "status": "PENDING_CREATE",
 *         "name": "default",
 *         "admin_state_up": true,
 *         "tenant_id": "40bb3ee25d604d219866d08a93150c40",
 *         "firewall_policy_id": "856ee2c2-c105-4b8d-b591-fd6be206619d",
 *         "id": "36c0a4bb-3fee-475a-a701-40123993bcd4",
 *         "description": ""
 *     }
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月24日 下午4:21:09 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月24日 下午4:21:09  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class FirewallWrapper
{
    /**
     * 防火墙
     */
    private Firewall firewall;

    /**
     * @return the firewall
     */
    public Firewall getFirewall()
    {
        return firewall;
    }

    /**
     * @param firewall the firewall to set
     */
    public void setFirewall(Firewall firewall)
    {
        this.firewall = firewall;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
