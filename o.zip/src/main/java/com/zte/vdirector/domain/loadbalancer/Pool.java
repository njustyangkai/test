package com.zte.vdirector.domain.loadbalancer;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.CloudEnvInfo;

public class Pool
{
    /**
     * Unique identifier for the pool.
     */
    private String id;

    /**
     * 起始IP
     */
    private String start;

    /**
     * 结束IP
     */
    private String end;

    private CloudEnvInfo cloudenv;

    private String vdcId;

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    public CloudEnvInfo getCloudenv()
    {
        return cloudenv;
    }

    public void setCloudenv(CloudEnvInfo cloudenv)
    {
        this.cloudenv = cloudenv;
    }

    /**
     * @return the start
     */
    public String getStart()
    {
        return start;
    }

    /**
     * @param start the start to set
     */
    public void setStart(String start)
    {
        this.start = start;
    }

    /**
     * @return the end
     */
    public String getEnd()
    {
        return end;
    }

    /**
     * @param end the end to set
     */
    public void setEnd(String end)
    {
        this.end = end;
    }

    /**
     * Owner of the pool. Only an admin user can specify a tenant identifier other than its own.
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    /**
     * Human readable name for the pool. Does not have to be unique.
     */
    private String name;

    /**
     * Human readable description for the pool.
     */
    private String description;

    /**
     * The network that pool members belong to.
     */
    @JSONField(name = "subnet_id")
    private String subnetId;

    /**
     * The vip that the pool associated with.
     */
    @JSONField(name = "vip_id")
    private String vipId;

    /** 
     * The protocol of the pool address. { "TCP" | "HTTP" | "HTTPS" }
     */
    private String protocol;

    /**
     * The algorithm used to distribute load between the members of the pool.
     */
    @JSONField(name = "lb_method")
    private String lbMethod;

    /**
     * For 2.0
     */
    @JSONField(name = "lb_algorithm")
    private String lbAlgorithm;

    /**
     * For 2.0
     */
    @JSONField(name = "healthmonitor_id")
    private String healthmonitorId;

    /**
     * For 2.0
     */
    @JSONField(name = "listener_id")
    private String listenerId;

    @JSONField(name = "session_persistence")
    private String sessionPersistence;

    private List<Listener> listeners;

    /**
     * List of health monitors to associate with the pool.
     */
    @JSONField(name = "health_monitors")
    private List<String> healthMonitors;

    /**
     * List of members that belong to the pool.
     * List<String> 1.0
     * List<Member> 2.0
     * 
     */
    private List<Object> members;

    /**
     * Administrative state of the pool
     */
    @JSONField(name = "admin_state_up")
    private Boolean adminStateUp;

    /**
     * Indicates whether a pool is currently operational or not.
     */
    private String status;

    /**
     * 提供者
     */
    private String provider;

    public String getProvider()
    {
        return provider;
    }

    public void setProvider(String provider)
    {
        this.provider = provider;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getTenantId()
    {
        return tenantId;
    }

    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getSubnetId()
    {
        return subnetId;
    }

    public void setSubnetId(String subnetId)
    {
        this.subnetId = subnetId;
    }

    public String getVipId()
    {
        return vipId;
    }

    public void setVipId(String vipId)
    {
        this.vipId = vipId;
    }

    public String getProtocol()
    {
        return protocol;
    }

    public void setProtocol(String protocol)
    {
        this.protocol = protocol;
    }

    public String getLbMethod()
    {
        return lbMethod;
    }

    public void setLbMethod(String lbMethod)
    {
        this.lbMethod = lbMethod;
    }

    public List<String> getHealthMonitors()
    {
        return healthMonitors;
    }

    public void setHealthMonitors(List<String> healthMonitors)
    {
        this.healthMonitors = healthMonitors;
    }

    public List<Object> getMembers()
    {
        return members;
    }

    public void setMembers(List<Object> members)
    {
        this.members = members;
    }

    public Boolean getAdminStateUp()
    {
        return adminStateUp;
    }

    public void setAdminStateUp(Boolean adminStateUp)
    {
        this.adminStateUp = adminStateUp;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    /**
     * @return the lbAlgorithm
     */
    public String getLbAlgorithm()
    {
        return lbAlgorithm;
    }

    /**
     * @param lbAlgorithm the lbAlgorithm to set
     */
    public void setLbAlgorithm(String lbAlgorithm)
    {
        this.lbAlgorithm = lbAlgorithm;
    }

    /**
     * @return the healthmonitorId
     */
    public String getHealthmonitorId()
    {
        return healthmonitorId;
    }

    /**
     * @param healthmonitorId the healthmonitorId to set
     */
    public void setHealthmonitorId(String healthmonitorId)
    {
        this.healthmonitorId = healthmonitorId;
    }

    /**
     * @return the listenerId
     */
    public String getListenerId()
    {
        return listenerId;
    }

    /**
     * @param listenerId the listenerId to set
     */
    public void setListenerId(String listenerId)
    {
        this.listenerId = listenerId;
    }

    /**
     * @return the sessionPersistence
     */
    public String getSessionPersistence()
    {
        return sessionPersistence;
    }

    /**
     * @param sessionPersistence the sessionPersistence to set
     */
    public void setSessionPersistence(String sessionPersistence)
    {
        this.sessionPersistence = sessionPersistence;
    }

    /**
     * @return the listeners
     */
    public List<Listener> getListeners()
    {
        return listeners;
    }

    /**
     * @param listeners the listeners to set
     */
    public void setListeners(List<Listener> listeners)
    {
        this.listeners = listeners;
    }
}
