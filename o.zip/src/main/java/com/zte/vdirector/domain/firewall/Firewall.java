/**
 * 
 */
package com.zte.vdirector.domain.firewall;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.CloudEnvInfo;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Firewall   
 * </p>  
 * <p>  
 * 类描述：防火墙信息   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月24日 下午4:09:54 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月24日 下午4:09:54  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class Firewall
{
    /**
     * 状态
     */
    private String status;

    /**
     * 名称
     */
    private String name;

    /**
     * 
     */
    @JSONField(name = "admin_state_up")
    private Boolean adminStateUp;

    /**
     * 租户ID
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    /**
     * 防火墙规则ID
     */
    @JSONField(name = "firewall_policy_id")
    private String firewallPolicyId;

    /**
     * 防火墙ID
     */
    private String id;

    /**
     * 防火墙描述
     */
    private String description;

    private String vdcId;

    private CloudEnvInfo cloudenv;

    /**
     * K版本新增字段，表示防火墙关联的路由ID
     */
    @JSONField(name = "router_ids")
    private List<String> routerIds;

    /**
     * @return the routerIds
     */
    public List<String> getRouterIds()
    {
        return routerIds;
    }

    /**
     * @param routerIds the routerIds to set
     */
    public void setRouterIds(List<String> routerIds)
    {
        this.routerIds = routerIds;
    }

    /**
     * @return the status
     */
    public String getStatus()
    {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status)
    {
        this.status = status;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the adminStateUp
     */
    public Boolean getAdminStateUp()
    {
        return adminStateUp;
    }

    /**
     * @param adminStateUp the adminStateUp to set
     */
    public void setAdminStateUp(Boolean adminStateUp)
    {
        this.adminStateUp = adminStateUp;
    }

    /**
     * @return the tenantId
     */
    public String getTenantId()
    {
        return tenantId;
    }

    /**
     * @param tenantId the tenantId to set
     */
    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    /**
     * @return the firewallPolicyId
     */
    public String getFirewallPolicyId()
    {
        return firewallPolicyId;
    }

    /**
     * @param firewallPolicyId the firewallPolicyId to set
     */
    public void setFirewallPolicyId(String firewallPolicyId)
    {
        this.firewallPolicyId = firewallPolicyId;
    }

    /**
     * @return the id
     */
    public String getId()
    {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    public CloudEnvInfo getCloudenv()
    {
        return cloudenv;
    }

    public void setCloudenv(CloudEnvInfo cloudenv)
    {
        this.cloudenv = cloudenv;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
