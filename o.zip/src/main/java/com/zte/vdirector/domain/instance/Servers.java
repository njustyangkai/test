package com.zte.vdirector.domain.instance;

import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Servers   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "servers": [
 *         {
 *             "status": "ACTIVE",
 *             "updated": "2013-10-12T02:12:26Z",
 *             "hostId": "9191a5eed9ee9fb9350fa211cf40528c5b01133db5d8c8b9646f0d02",
 *             "OS-EXT-SRV-ATTR:host": "cccompute2-Lenovo",
 *             "addresses": {
 *                 "lb-network": [
 *                     {
 *                         "version": 4,
 *                         "addr": "10.10.10.4",
 *                         "OS-EXT-IPS:type": "fixed"
 *                     }
 *                 ]
 *             },
 *             "links": [
 *                 {
 *                     "href": "http://127.0.0.1:8774/v2/f241a207f7d24dd0a7d45582aa7295e4/servers/cf268b68-7df5-48d0-9535-e61056020f37",
 *                     "rel": "self"
 *                 },
 *                 {
 *                     "href": "http://127.0.0.1:8774/f241a207f7d24dd0a7d45582aa7295e4/servers/cf268b68-7df5-48d0-9535-e61056020f37",
 *                     "rel": "bookmark"
 *                 }
 *             ],
 *             "key_name": "",
 *             "image": {
 *                 "id": "10a628ce-edfc-41e3-a3f9-5e358417b952",
 *                 "links": [
 *                     {
 *                         "href": "http://127.0.0.1:8774/f241a207f7d24dd0a7d45582aa7295e4/images/10a628ce-edfc-41e3-a3f9-5e358417b952",
 *                         "rel": "bookmark"
 *                     }
 *                 ]
 *             },
 *             "OS-EXT-STS:task_state": null,
 *             "OS-EXT-STS:vm_state": "active",
 *             "OS-EXT-SRV-ATTR:instance_name": "instance-0000001a",
 *             "OS-EXT-SRV-ATTR:hypervisor_hostname": "cccompute2-Lenovo",
 *             "flavor": {
 *                 "id": "ebe8cd44-f91e-422a-9d1e-3db80aa9634a",
 *                 "links": [
 *                     {
 *                         "href": "http://127.0.0.1:8774/f241a207f7d24dd0a7d45582aa7295e4/flavors/ebe8cd44-f91e-422a-9d1e-3db80aa9634a",
 *                         "rel": "bookmark"
 *                     }
 *                 ]
 *             },
 *             "id": "cf268b68-7df5-48d0-9535-e61056020f37",
 *             "security_groups": [
 *                 {
 *                     "name": "default"
 *                 }
 *             ],
 *             "OS-EXT-AZ:availability_zone": "nova",
 *             "user_id": "cb898fb150c54361ac06fdff4a450b77",
 *             "name": "lb-xp2",
 *             "created": "2013-10-12T02:07:14Z",
 *             "tenant_id": "f241a207f7d24dd0a7d45582aa7295e4",
 *             "OS-DCF:diskConfig": "MANUAL",
 *             "accessIPv4": "",
 *             "accessIPv6": "",
 *             "progress": 0,
 *             "OS-EXT-STS:power_state": 1,
 *             "config_drive": "",
 *             "metadata": {}
 *         }
 *     ]
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月23日 下午4:19:42 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月23日 下午4:19:42  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Servers implements Iterable<Server>
{
    /**
     * 云服务器列表
     */
    private List<Server> servers;

    public List<Server> getServers()
    {
        return servers;
    }

    public void setServers(List<Server> servers)
    {
        this.servers = servers;
    }
    
    @Override
    public Iterator<Server> iterator()
    {
        return servers.iterator();
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
