package com.zte.vdirector.domain.acls;

import java.util.List;

public class AclAuthReq
{
    private List<AclEntity> add;
    private List<AclEntity> delete;

    public List<AclEntity> getAdd()
    {
        return add;
    }

    public void setAdd(List<AclEntity> add)
    {
        this.add = add;
    }

    public List<AclEntity> getDelete()
    {
        return delete;
    }

    public void setDelete(List<AclEntity> delete)
    {
        this.delete = delete;
    }
}
