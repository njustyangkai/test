package com.zte.vdirector.domain.servicedirectory;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：ServiceDirectoryBean   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月29日 下午5:04:16 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月29日 下午5:04:16  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class ServiceDirectoryBean
{
    /**
     * ID
     */
    private String id;

    /**
     * 名称
     */
    private String name;

    /**
     * 业务键
     */
    private String serviceKey;

    /**
     * 状态 ：1-已发布 2-未发布
     */
    private int status;

    /**
     * 描述
     */
    private String description;

    /**
     * 其他信息
     */
    private String extra;

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getServiceKey()
    {
        return serviceKey;
    }

    public void setServiceKey(String serviceKey)
    {
        this.serviceKey = serviceKey;
    }

    public int getStatus()
    {
        return status;
    }

    public void setStatus(int status)
    {
        this.status = status;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getExtra()
    {
        return extra;
    }

    public void setExtra(String extra)
    {
        this.extra = extra;
    }
}
