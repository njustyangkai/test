package com.zte.vdirector.domain.loadbalancer;

import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Member   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "members": [
 *         {
 *             "status": "ACTIVE",
 *             "protocol_port": 80,
 *             "weight": 1,
 *             "admin_state_up": true,
 *             "tenant_id": "32de7a2ec0b4459caec6754539bf8cee",
 *             "pool_id": "e1666e3f-19a1-4b6d-99a8-68cf8dfc1da3",
 *             "address": "192.168.2.6",
 *             "status_description": null,
 *             "id": "4f3302ad-2f76-4c02-b421-72b57e1f65ff"
 *         },
 *         {
 *             "status": "ACTIVE",
 *             "protocol_port": 8443,
 *             "weight": 5,
 *             "admin_state_up": true,
 *             "tenant_id": "32de7a2ec0b4459caec6754539bf8cee",
 *             "pool_id": "e1666e3f-19a1-4b6d-99a8-68cf8dfc1da3",
 *             "address": "192.168.1.40",
 *             "status_description": null,
 *             "id": "64a81cb8-f118-455e-ba65-c29d7f171553"
 *         },
 *         {
 *             "status": "ACTIVE",
 *             "protocol_port": 80,
 *             "weight": 1,
 *             "admin_state_up": true,
 *             "tenant_id": "32de7a2ec0b4459caec6754539bf8cee",
 *             "pool_id": "e1666e3f-19a1-4b6d-99a8-68cf8dfc1da3",
 *             "address": "192.168.2.4",
 *             "status_description": null,
 *             "id": "70b77f03-0c53-4606-b7f3-1edf48af7522"
 *         }
 *     ]
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 下午3:16:09 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 下午3:16:09  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Members implements Iterable<Member>
{
    /**
     * Member列表 
     */
    private List<Member> members;

    public List<Member> getMembers()
    {
        return members;
    }

    public void setMembers(List<Member> members)
    {
        this.members = members;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }

    @Override
    public Iterator<Member> iterator()
    {
        return members.iterator();
    }
}
