package com.zte.vdirector.domain.auth;

import com.zte.vdirector.domain.CloudEnvInfo;

public class AccessBean
{
    private String token;

    private String cinderUrl;

    private String novaUrl;

    private String glanceUrl;

    private String neutronUrl;

    private long issueTime;

    private long expireTime;

    private long lastAccessTime;

    private CloudEnvInfo cloudEnvInfo;

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public String getCinderUrl()
    {
        return cinderUrl;
    }

    public void setCinderUrl(String cinderUrl)
    {
        this.cinderUrl = cinderUrl;
    }

    public String getNovaUrl()
    {
        return novaUrl;
    }

    public void setNovaUrl(String novaUrl)
    {
        this.novaUrl = novaUrl;
    }

    public String getGlanceUrl()
    {
        return glanceUrl;
    }

    public void setGlanceUrl(String glanceUrl)
    {
        this.glanceUrl = glanceUrl;
    }

    public String getNeutronUrl()
    {
        return neutronUrl;
    }

    public void setNeutronUrl(String neutronUrl)
    {
        this.neutronUrl = neutronUrl;
    }

    public long getIssueTime()
    {
        return issueTime;
    }

    public void setIssueTime(long issueTime)
    {
        this.issueTime = issueTime;
    }

    public long getExpireTime()
    {
        return expireTime;
    }

    public void setExpireTime(long expireTime)
    {
        this.expireTime = expireTime;
    }

    public long getLastAccessTime()
    {
        return lastAccessTime;
    }

    public void setLastAccessTime(long lastAccessTime)
    {
        this.lastAccessTime = lastAccessTime;
    }

    public CloudEnvInfo getCloudEnvInfo()
    {
        return cloudEnvInfo;
    }

    public void setCloudEnvInfo(CloudEnvInfo cloudEnvInfo)
    {
        this.cloudEnvInfo = cloudEnvInfo;
    }
}
