package com.zte.vdirector.domain.subnet;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Network   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 上午10:27:21 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 上午10:27:21  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Network
{
    /**
     * 状态
     */
    private String status;

    /**
     * 子网ID列表
     */
    private List<String> subnets;

    /**
     * 名称
     */
    private String name;

    /**
     * 物理网络
     */
    @JSONField(name = "provider:physical_network")
    private String providerPhyNet;

    /**
     * 
     */
    @JSONField(name = "admin_state_up")
    private boolean adminStateUp;

    /**
     * 租户ID
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    /**
     * 网络类型
     */
    @JSONField(name = "provider:network_type")
    private String netType;

    /**
     * 
     */
    @JSONField(name = "router:external")
    private String routerExternal;

    /**
     * 网络ID
     */
    private String id;

    /**
     * 是否公开
     */
    private boolean shared;

    /**
     * For OpenCOS 网络带宽,在端口的最大带宽没有指定时，使用该值作为端口的最大带宽，0表示不限速，默认值为0，单位为MB。范围只有是0和正整数
     */
    private String bandwidth;
    
    /**
     * 在端口的cbs没有指定时，使用该值作为端口的cbs，0表示不支持突发，默认值为0，单位为Byte。范围只有是0和正整数
     */
    private Integer cbs;
    
    /**
     * 在端口的DSCP值没有指定时，使用该值作为端口的DSCP值，默认值为0，有效范围为（0~63）
     */
    @JSONField(name = "dscp")
    private Integer dscp;

    /**
     * {'allow_post': True, 'allow_put': True, 'default': 1500, 'convert_to': convert_to_int, 'is_visible': True}
     */
    private String mtu;
    
    /**
     * For OpenCOS
     * 虚拟网络中最多可部署虚拟机的个数。如果不配置，则采用配置文件中的默认值；
     * 如果配置为-1，表示不限制；如果配置为0，表示不允许在这个网络内创建虚拟机；其它情况，表示允许创建的虚拟机的台数。
     */
    @JSONField(name = "max_server_num")
    private String maxServerNum;
    
    /**
     * For OpenCOS 本网络内已经被虚拟机使用的端口的个数。
     */
    @JSONField(name = "attached_port_num")
    private String attachedPortNum;

    /**
     * 
     */
    @JSONField(name = "provider:segmentation_id")
    private String providerSegID;

    public Integer getCbs()
    {
        return cbs;
    }

    public void setCbs(Integer cbs)
    {
        this.cbs = cbs;
    }

    public Integer getDscp()
    {
        return dscp;
    }

    public void setDscp(Integer dscp)
    {
        this.dscp = dscp;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public List<String> getSubnets()
    {
        return subnets;
    }

    public void setSubnets(List<String> subnets)
    {
        this.subnets = subnets;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getProviderPhyNet()
    {
        return providerPhyNet;
    }

    public void setProviderPhyNet(String providerPhyNet)
    {
        this.providerPhyNet = providerPhyNet;
    }

    public String getNetType()
    {
        return netType;
    }

    public void setNetType(String netType)
    {
        this.netType = netType;
    }

    public String getRouterExternal()
    {
        return routerExternal;
    }

    public void setRouterExternal(String routerExternal)
    {
        this.routerExternal = routerExternal;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getProviderSegID()
    {
        return providerSegID;
    }

    public void setProviderSegID(String providerSegID)
    {
        this.providerSegID = providerSegID;
    }

    public boolean isAdminStateUp()
    {
        return adminStateUp;
    }

    public void setAdminStateUp(boolean adminStateUp)
    {
        this.adminStateUp = adminStateUp;
    }

    public String getTenantId()
    {
        return tenantId;
    }

    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    public boolean isShared()
    {
        return shared;
    }

    public void setShared(boolean shared)
    {
        this.shared = shared;
    }

    public String getBandwidth()
    {
        return bandwidth;
    }

    public void setBandwidth(String bandwidth)
    {
        this.bandwidth = bandwidth;
    }

    public String getMtu()
    {
        return mtu;
    }

    public void setMtu(String mtu)
    {
        this.mtu = mtu;
    }

    public String getMaxServerNum()
    {
        return maxServerNum;
    }

    public void setMaxServerNum(String maxServerNum)
    {
        this.maxServerNum = maxServerNum;
    }

    public String getAttachedPortNum()
    {
        return attachedPortNum;
    }

    public void setAttachedPortNum(String attachedPortNum)
    {
        this.attachedPortNum = attachedPortNum;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
