package com.zte.vdirector.domain.acls;

import java.util.List;

public class AclEntity
{
    private String userId;
    private List<ResourceEntity> resources;

    public String getUserId()
    {
        return userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public List<ResourceEntity> getResources()
    {
        return resources;
    }

    public void setResources(List<ResourceEntity> resources)
    {
        this.resources = resources;
    }

    public class ResourceEntity
    {
        private String resourceId;

        /**
         * 资源类型：
         * dc
         * org
         * project
         * vdc
         */
        private String resourceType;

        public String getResourceId()
        {
            return resourceId;
        }

        public void setResourceId(String resourceId)
        {
            this.resourceId = resourceId;
        }

        public String getResourceType()
        {
            return resourceType;
        }

        public void setResourceType(String resourceType)
        {
            this.resourceType = resourceType;
        }
    }
}
