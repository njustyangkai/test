package com.zte.vdirector.domain.loadbalancer;

import java.util.Iterator;
import java.util.List;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：HealthMonitors   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *    "healthmonitors":[
 *       {
 *          "admin_state_up":true,
 *          "tenant_id":"83657cfcdfe44cd5920adaf26c48ceea",
 *          "delay":10,
 *          "max_retries":1,
 *          "timeout":1,
 *          "type":"PING",
 *          "id":"466c8345-28d8-4f84-a246-e04380b0461d"
 *       },
 *       {
 *          "admin_state_up":true,
 *          "tenant_id":"83657cfcdfe44cd5920adaf26c48ceea",
 *          "delay":5,
 *          "expected_codes":"200",
 *          "max_retries":2,
 *          "http_method":"GET",
 *          "timeout":2,
 *          "url_path":"/",
 *          "type":"HTTP",
 *          "id":"5d4b5228-33b0-4e60-b225-9b727c1a20e7"
 *       }
 *    ]
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年8月28日 下午7:29:47 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年8月28日 下午7:29:47  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class HealthMonitorsv2 implements Iterable<HealthMonitor>
{
    private List<HealthMonitor> healthmonitors;

    public List<HealthMonitor> getHealthmonitors()
    {
        return healthmonitors;
    }

    public void setHealthmonitors(List<HealthMonitor> healthmonitors)
    {
        this.healthmonitors = healthmonitors;
    }

    @Override
    public Iterator<HealthMonitor> iterator()
    {
        return healthmonitors.iterator();
    }
}
