package com.zte.vdirector.domain.serviceprice;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：ServiceDirectoryDao   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 上午10:45:06 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 上午10:45:06  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Repository
public class ServicePriceDao
{
    @Resource
    private JdbcTemplate jdbcTemplate;

    public List<ChargeItemBean> getChargeItemList(String serviceDirectoryId)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from charge_item where service_directory_id = ? ");
        return jdbcTemplate.query(sql.toString(), new ServicePriceRowMapper(), serviceDirectoryId);
    }

    public List<ChargeItemBean> getChargeItemListByParentId(String parentId)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from charge_item where parent_id = ? ");
        return jdbcTemplate.query(sql.toString(), new ServicePriceRowMapper(), parentId);
    }

    public boolean updateChargeItemPrice(ChargeItemBean chargeItem)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("update charge_item set price = ?, status = ? where id = ? ");
        return jdbcTemplate.update(sql.toString(), chargeItem.getPrice(), chargeItem.getStatus(), chargeItem.getId()) > 0;
    }
}
