/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月21日      下午5:25:04
*/
package com.zte.vdirector.domain.ticket;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketNetworkRowMapper implements RowMapper<TicketNetworkBean>
{
    public TicketNetworkBean mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        TicketNetworkBean ticketBean = new TicketNetworkBean();

        ticketBean.setDescription(rs.getString("DESCRIPTION"));
        ticketBean.setId(rs.getString("ID"));
        ticketBean.setNetworkfn(rs.getString("NETWORK_FN"));
        ticketBean.setOrderId(rs.getString("ORDER_ID"));
        ticketBean.setSerialNo(rs.getString("SERIAL_NUM"));
        ticketBean.setSubnet(rs.getString("SUBNET"));
        ticketBean.setType(rs.getString("TYPE"));
        ticketBean.setVmName(rs.getString("VM_NAME"));
        ticketBean.setVmWork(rs.getString("VM_WORK"));

        return ticketBean;
    }

}
