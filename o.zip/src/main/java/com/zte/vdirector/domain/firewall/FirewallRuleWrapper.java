package com.zte.vdirector.domain.firewall;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：FirewallRuleWrapper   
 * </p>  
 * <p>  
 * 类描述：防火墙规则信息封装类   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "firewall_rule": {
 *         "action": "allow",
 *         "description": "",
 *         "destination_ip_address": null,
 *         "destination_port": "80",
 *         "enabled": true,
 *         "firewall_policy_id": null,
 *         "id": "8722e0e0-9cc9-4490-9660-8c9a5732fbb0",
 *         "ip_version": 4,
 *         "name": "ALLOW_HTTP",
 *         "position": null,
 *         "protocol": "tcp",
 *         "shared": false,
 *         "source_ip_address": null,
 *         "source_port": null,
 *         "tenant_id": "45977fa2dbd7482098dd68d0d8970117"
 *     }
 * }
 * </pre></blockquote><p>
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年5月7日 下午8:31:02 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年5月7日 下午8:31:02  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class FirewallRuleWrapper
{
    /**
     * 防火墙规则信息
     */
    @JSONField(name = "firewall_rule")
    private FirewallRule rule;

    /**
     * @return the rule
     */
    public FirewallRule getRule()
    {
        return rule;
    }

    /**
     * @param rule the rule to set
     */
    public void setRule(FirewallRule rule)
    {
        this.rule = rule;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
