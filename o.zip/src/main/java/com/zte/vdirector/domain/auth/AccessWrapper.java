package com.zte.vdirector.domain.auth;

public class AccessWrapper 
{
	 private Access access;

	public Access getAccess()
	{
		return access;
	}

	public void setAccess(Access access)
	{
		this.access = access;
	}
	 
	 

}
