package com.zte.vdirector.domain.instance;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Fault   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月23日 下午4:30:55 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月23日 下午4:30:55  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *"fault": {
            "message": "NV-9937007 Unable to resize virtual machine 'AAA-1-ed28443e-00000066'. Resizing an active virtual machine requires RMC connectivity.",
            "code": 500,
            "details": "  File \"/usr/lib/python2.6/site-packages/nova/compute/manager.py\", line 318, in decorated_function\n    return function(self, context, *args, **kwargs)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/compute/__init__.py\", line 389, in wrapper\n    _notify(exception_msg)\n  File \"/usr/lib/python2.6/site-packages/nova/openstack/common/excutils.py\", line 82, in __exit__\n    six.reraise(self.type_, self.value, self.tb)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/compute/__init__.py\", line 379, in wrapper\n    r = f(*args, **kwds)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/compute/__init__.py\", line 176, in wrapper\n    return function(*args, **kwargs)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/compute/manager.py\", line 2035, in resize_instance\n    timeout, retry_interval)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/__init__.py\", line 98, in wrapper\n    r = f(*args, **kwds)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/virt/ibmpowervm/hmc/driver.py\", line 1981, in migrate_disk_and_power_off\n    LOG.exception(exc)\n  File \"/usr/lib/python2.6/site-packages/nova/openstack/common/excutils.py\", line 82, in __exit__\n    six.reraise(self.type_, self.value, self.tb)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/virt/ibmpowervm/hmc/driver.py\", line 1978, in migrate_disk_and_power_off\n    network_info, block_devices_info)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/__init__.py\", line 98, in wrapper\n    r = f(*args, **kwds)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/virt/ibmpowervm/hmc/lpar.py\", line 839, in resize\n    _resize_lpar(k2resp, retries == POST_RETRIES)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/virt/ibmpowervm/hmc/lpar.py\", line 754, in _resize_lpar\n    host, len(network_info), curr_flavor))\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/__init__.py\", line 98, in wrapper\n    r = f(*args, **kwds)\n  File \"/usr/lib/python2.6/site-packages/powervc_nova/virt/ibmpowervm/hmc/instance_type.py\", line 145, in validate\n    instance_name=self._inst_name)\n",
            "created": "2015-03-31T01:07:17Z"
        },
 */
public class Fault
{
    /**
     * 错误码
     */
    private Integer code;

    /**
     * 错误描述
     */
    private String message;

    /**
     * 错误详情
     */
    private String details;

    /**
     * 创建时间
     */
    private String created;

    public Integer getCode()
    {
        return code;
    }

    public void setCode(Integer code)
    {
        this.code = code;
    }

    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }

    public String getDetails()
    {
        return details;
    }

    public void setDetails(String details)
    {
        this.details = details;
    }

    public String getCreated()
    {
        return created;
    }

    public void setCreated(String created)
    {
        this.created = created;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}