package com.zte.vdirector.domain.loadbalancer;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：MemberWrapper   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *    "member":{
 *       "status":"PENDING_CREATE",
 *       "protocol_port":8080,
 *       "weight":1,
 *       "admin_state_up":true,
 *       "tenant_id":"4fd44f30292945e481c7b8a0c8908869",
 *       "pool_id":"7803631d-f181-4500-b3a2-1b68ba2a75fd",
 *       "address":"10.0.0.5",
 *       "status_description":null,
 *       "id":"48a471ea-64f1-4eb6-9be7-dae6bbe40a0f"
 *    }
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 下午3:10:03 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 下午3:10:03  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class MemberWrapper
{
    /**
     * Member信息
     */
    private Member member;

    public Member getMember()
    {
        return member;
    }

    public void setMember(Member member)
    {
        this.member = member;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
