/**
 * 
 */
package com.zte.vdirector.domain.billing;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：Operate  
 * </p>  
 * <p>   
 * 类名称：Billing   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10138528   
 * </p>  
 * <p>  
 * 创建时间：2016-11-2 下午5:41:05 
 * </p>  
 * <p>    
 * 修改人：10138528  
 * </p>  
 * <p>  
 * 修改时间：2016-11-2 下午5:41:05  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class Billing
{

}
