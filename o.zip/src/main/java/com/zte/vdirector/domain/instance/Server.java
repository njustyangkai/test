package com.zte.vdirector.domain.instance;

import java.awt.Image;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.auth.Link;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Server   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月23日 下午4:21:34 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月23日 下午4:21:34  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Server   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：00186819   
 * </p>  
 * <p>  
 * 创建时间：2016年1月21日 上午2:45:40 
 * </p>  
 * <p>    
 * 修改人：10079153  
 * </p>  
 * <p>  
 * 修改时间：2016年1月21日 上午2:45:40  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */ 
public class Server
{
    /**
     * 云服务器ID
     */
    private String id;

    /**
     * 云服务器名称
     */
    private String name;

    /**
     * 云服务器IPs
     */
    private Map<String, List<Address>> addresses;

    /**
     * 
     */
    private List<Link> links;

    /**
     * 镜像信息
     */
    private Object image;

    /**
     * 规格信息
     */
    private Flavor flavor;

    /**
     * 运行状况
     */
    private HealthStatus healthStatus;

    /**
     * IPv4
     */
    private String accessIPv4;

    /**
     * IPv6
     */
    private String accessIPv6;

    /**
     * 
     */
    @JSONField(name = "config_drive")
    private String configDrive;

    /**
     * 状态
     */
    private String status;

    /**
     * 
     */
    private Integer progress;

    /**
     * 故障信息
     */
    private Fault fault;

    /**
     * 租户ID
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    /**
     * 用户ID
     */
    @JSONField(name = "user_id")
    private String userId;

    /**
     * 
     */
    @JSONField(name = "key_name")
    private String keyName;

    /**
     * 
     */
    private String hostId;

    /**
     * 修改日期
     */
    private Date updated;

    /**
     * 创建日期
     */
    private Date created;

    /**
     * 元数据
     */
    private Map<String, String> metadata;

    /**
     * 所属安全组列表
     */
    @JSONField(name = "security_groups")
    private List<SecurityGroup> securityGroups;

    /**
     * 
     */
    @JSONField(name = "OS-EXT-STS:task_state")
    private String taskState;

    /**
     * 
     */
    @JSONField(name = "OS-EXT-STS:power_state")
    private String powerState;

    /**
     * 
     */
    @JSONField(name = "OS-EXT-STS:vm_state")
    private String vmState;

    /**
     * 
     */
    @JSONField(name = "OS-EXT-SRV-ATTR:host")
    private String host;

    /**
     * 
     */
    @JSONField(name = "OS-EXT-SRV-ATTR:instance_name")
    private String instanceName;

    /**
     * 
     */
    @JSONField(name = "OS-EXT-SRV-ATTR:hypervisor_hostname")
    private String hypervisorHostname;

    /**
     * 
     */
    @JSONField(name = "OS-DCF:diskConfig")
    private String diskConfig;

    /**
     * 
     */
    @JSONField(name = "OS-EXT-AZ:availability_zone")
    private String availabilityZone;

    /**
     * 卷挂载信息
     */
    @JSONField(name = "os-extended-volumes:volumes_attached")
    private List<Map<String, Object>> volumesAttached;

    /**
     * uuid
     */
    private String uuid;

    /**
     * adminPass
     */
    private String adminPass;
    
    
    private String priority;
    
    private String auto_start;
    private String move;
    private String vnc;
    private String boot_index_type;
    private String qos;
    


    /**
     * @return the qos
     */
    public String getQos()
    {
        return qos;
    }

    /**
     * @param qos the qos to set
     */
    public void setQos(String qos)
    {
        this.qos = qos;
    }

    /**
     * @return the priority
     */
    public String getPriority()
    {
        return priority;
    }

    /**
     * @param priority the priority to set
     */
    public void setPriority(String priority)
    {
        this.priority = priority;
    }

    /**
     * @return the auto_start
     */
    public String getAuto_start()
    {
        return auto_start;
    }

    /**
     * @param auto_start the auto_start to set
     */
    public void setAuto_start(String auto_start)
    {
        this.auto_start = auto_start;
    }

    /**
     * @return the move
     */
    public String getMove()
    {
        return move;
    }

    /**
     * @param move the move to set
     */
    public void setMove(String move)
    {
        this.move = move;
    }

    /**
     * @return the vnc
     */
    public String getVnc()
    {
        return vnc;
    }

    /**
     * @param vnc the vnc to set
     */
    public void setVnc(String vnc)
    {
        this.vnc = vnc;
    }

    /**
     * @return the boot_index_type
     */
    public String getBoot_index_type()
    {
        return boot_index_type;
    }

    /**
     * @param boot_index_type the boot_index_type to set
     */
    public void setBoot_index_type(String boot_index_type)
    {
        this.boot_index_type = boot_index_type;
    }


    /**
     * USB列表
     */
    private List<Map<String, Object>> usbs;

    /**
     * Gets the usbs.
     * 
     * @return the usbs
     */
    public List<Map<String, Object>> getUsbs()
    {
        return usbs;
    }

    /**
     * Sets the usbs.
     * 
     * @param usbs the usbs to set
     */
    public void setUsbs(List<Map<String, Object>> usbs)
    {
        this.usbs = usbs;
    }

    /**
     * Gets the 云服务器ID.
     * 
     * @return the 云服务器ID
     */
    public String getId()
    {
        return id;
    }

    /**
     * Sets the 云服务器ID.
     * 
     * @param id the new 云服务器ID
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * Gets the 云服务器名称.
     * 
     * @return the 云服务器名称
     */
    public String getName()
    {
        return name;
    }

    /**
     * Sets the 云服务器名称.
     * 
     * @param name the new 云服务器名称
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Gets the 云服务器IPs.
     * 
     * @return the 云服务器IPs
     */
    public Map<String, List<Address>> getAddresses()
    {
        return addresses;
    }

    /**
     * Sets the 云服务器IPs.
     * 
     * @param addresses the new 云服务器IPs
     * @version
     */
    public void setAddresses(Map<String, List<Address>> addresses)
    {
        this.addresses = addresses;
    }

    /**
     * Gets the links.
     * 
     * @return the links
     */
    public List<Link> getLinks()
    {
        return links;
    }

    /**
     * Sets the links.
     * 
     * @param links the links
     */
    public void setLinks(List<Link> links)
    {
        this.links = links;
    }

    /**
     * Gets the 镜像信息.
     * 
     * @return the 镜像信息
     */
    public Object getImage()
    {
        if ("".equals(image))
        {
            return null;
        }
        else
        {
            return JSON.parseObject(JSON.toJSONString(image), Image.class);
        }
    }

    /**
     * Sets the 镜像信息.
     * 
     * @param image the new 镜像信息
     */
    public void setImage(Object image)
    {
        if ("".equals(image))
        {
            this.image = null;
        }
        else
        {
            this.image = JSON.parseObject(JSON.toJSONString(image), Image.class);
        }
    }

    /**
     * Gets the 规格信息.
     * 
     * @return the 规格信息
     */
    public Flavor getFlavor()
    {
        return flavor;
    }

    /**
     * Sets the 规格信息.
     * 
     * @param flavor the new 规格信息
     */
    public void setFlavor(Flavor flavor)
    {
        this.flavor = flavor;
    }

    /**
     * Gets the 运行状况.
     * 
     * @return the health status
     */
    public HealthStatus getHealthStatus()
    {
        return healthStatus;
    }

    /**
     * Sets the 运行状况.
     * 
     * @param healthStatus the new health status
     */
    public void setHealthStatus(HealthStatus healthStatus)
    {
        this.healthStatus = healthStatus;
    }

    /**
     * Gets the iPv4.
     * 
     * @return the iPv4
     */
    public String getAccessIPv4()
    {
        return accessIPv4;
    }

    /**
     * Sets the iPv4.
     * 
     * @param accessIPv4 the new iPv4
     */
    public void setAccessIPv4(String accessIPv4)
    {
        this.accessIPv4 = accessIPv4;
    }

    /**
     * Gets the iPv6.
     * 
     * @return the iPv6
     */
    public String getAccessIPv6()
    {
        return accessIPv6;
    }

    /**
     * Sets the iPv6.
     * 
     * @param accessIPv6 the new iPv6
     */
    public void setAccessIPv6(String accessIPv6)
    {
        this.accessIPv6 = accessIPv6;
    }

    /**
     * Gets the 状态.
     * 
     * @return the 状态
     */
    public String getStatus()
    {
        return status;
    }

    /**
     * Sets the 状态.
     * 
     * @param status the new 状态
     */
    public void setStatus(String status)
    {
        this.status = status;
    }

    /**
     * Gets the progress.
     * 
     * @return the progress
     */
    public Integer getProgress()
    {
        return progress;
    }

    /**
     * Sets the progress.
     * 
     * @param progress the progress
     */
    public void setProgress(Integer progress)
    {
        this.progress = progress;
    }

    /**
     * Gets the fault.
     * 
     * @return the fault
     */
    public Fault getFault()
    {
        return fault;
    }

    /**
     * Sets the fault.
     * 
     * @param fault the fault
     */
    public void setFault(Fault fault)
    {
        this.fault = fault;
    }

    /**
     * Gets the host id.
     * 
     * @return the host id
     */
    public String getHostId()
    {
        return hostId;
    }

    /**
     * Sets the host id.
     * 
     * @param hostId the host id
     */
    public void setHostId(String hostId)
    {
        this.hostId = hostId;
    }

    /**
     * Gets the 修改日期.
     * 
     * @return the 修改日期
     */
    public Date getUpdated()
    {
        return updated;
    }

    /**
     * Sets the 修改日期.
     * 
     * @param updated the new 修改日期
     */
    public void setUpdated(Date updated)
    {
        this.updated = updated;
    }

    /**
     * Gets the 创建日期.
     * 
     * @return the 创建日期
     */
    public Date getCreated()
    {
        return created;
    }

    /**
     * Sets the 创建日期.
     * 
     * @param created the new 创建日期
     */
    public void setCreated(Date created)
    {
        this.created = created;
    }

    /**
     * Gets the 元数据.
     * 
     * @return the 元数据
     */
    public Map<String, String> getMetadata()
    {
        return metadata;
    }

    /**
     * Sets the 元数据.
     * 
     * @param metadata the new 元数据
     * @version
     */
    public void setMetadata(Map<String, String> metadata)
    {
        this.metadata = metadata;
    }

    /**
     * Gets the host.
     * 
     * @return the host
     */
    public String getHost()
    {
        return host;
    }

    /**
     * Sets the host.
     * 
     * @param host the host
     */
    public void setHost(String host)
    {
        this.host = host;
    }

    /**
     * Gets the disk config.
     * 
     * @return the disk config
     */
    public String getDiskConfig()
    {
        return diskConfig;
    }

    /**
     * Sets the disk config.
     * 
     * @param diskConfig the disk config
     */
    public void setDiskConfig(String diskConfig)
    {
        this.diskConfig = diskConfig;
    }

    /**
     * Gets the uuid.
     * 
     * @return the uuid
     */
    public String getUuid()
    {
        return uuid;
    }

    /**
     * Sets the uuid.
     * 
     * @param uuid the uuid
     */
    public void setUuid(String uuid)
    {
        this.uuid = uuid;
    }

    /**
     * Gets the admin pass.
     * 
     * @return the admin pass
     */
    public String getAdminPass()
    {
        return adminPass;
    }

    /**
     * Sets the admin pass.
     * 
     * @param adminPass the admin pass
     */
    public void setAdminPass(String adminPass)
    {
        this.adminPass = adminPass;
    }

    /**
     * Gets the config drive.
     * 
     * @return the config drive
     */
    public String getConfigDrive()
    {
        return configDrive;
    }

    /**
     * Sets the config drive.
     * 
     * @param configDrive the config drive
     */
    public void setConfigDrive(String configDrive)
    {
        this.configDrive = configDrive;
    }

    /**
     * Gets the 租户ID.
     * 
     * @return the 租户ID
     */
    public String getTenantId()
    {
        return tenantId;
    }

    /**
     * Sets the 租户ID.
     * 
     * @param tenantId the new 租户ID
     */
    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    /**
     * Gets the 用户ID.
     * 
     * @return the 用户ID
     */
    public String getUserId()
    {
        return userId;
    }

    /**
     * Sets the 用户ID.
     * 
     * @param userId the new 用户ID
     */
    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    /**
     * Gets the key name.
     * 
     * @return the key name
     */
    public String getKeyName()
    {
        return keyName;
    }

    /**
     * Sets the key name.
     * 
     * @param keyName the key name
     */
    public void setKeyName(String keyName)
    {
        this.keyName = keyName;
    }

    /**
     * Gets the 所属安全组列表.
     * 
     * @return the 所属安全组列表
     */
    public List<SecurityGroup> getSecurityGroups()
    {
        return securityGroups;
    }

    /**
     * Sets the 所属安全组列表.
     * 
     * @param securityGroups the new 所属安全组列表
     */
    public void setSecurityGroups(List<SecurityGroup> securityGroups)
    {
        this.securityGroups = securityGroups;
    }

    /**
     * Gets the task state.
     * 
     * @return the task state
     */
    public String getTaskState()
    {
        return taskState;
    }

    /**
     * Sets the task state.
     * 
     * @param taskState the task state
     */
    public void setTaskState(String taskState)
    {
        this.taskState = taskState;
    }

    /**
     * Gets the power state.
     * 
     * @return the power state
     */
    public String getPowerState()
    {
        return powerState;
    }

    /**
     * Sets the power state.
     * 
     * @param powerState the power state
     */
    public void setPowerState(String powerState)
    {
        this.powerState = powerState;
    }

    /**
     * Gets the vm state.
     * 
     * @return the vm state
     */
    public String getVmState()
    {
        return vmState;
    }

    /**
     * Sets the vm state.
     * 
     * @param vmState the vm state
     */
    public void setVmState(String vmState)
    {
        this.vmState = vmState;
    }

    /**
     * Gets the instance name.
     * 
     * @return the instance name
     */
    public String getInstanceName()
    {
        return instanceName;
    }

    /**
     * Sets the instance name.
     * 
     * @param instanceName the instance name
     */
    public void setInstanceName(String instanceName)
    {
        this.instanceName = instanceName;
    }

    /**
     * Gets the hypervisor hostname.
     * 
     * @return the hypervisor hostname
     */
    public String getHypervisorHostname()
    {
        return hypervisorHostname;
    }

    /**
     * Sets the hypervisor hostname.
     * 
     * @param hypervisorHostname the hypervisor hostname
     */
    public void setHypervisorHostname(String hypervisorHostname)
    {
        this.hypervisorHostname = hypervisorHostname;
    }

    /**
     * Gets the availability zone.
     * 
     * @return the availability zone
     */
    public String getAvailabilityZone()
    {
        return availabilityZone;
    }

    /**
     * Sets the availability zone.
     * 
     * @param availabilityZone the availability zone
     */
    public void setAvailabilityZone(String availabilityZone)
    {
        this.availabilityZone = availabilityZone;
    }

    /**
     * Gets the volumes attached.
     * 
     * @return the volumesAttached
     */
    public List<Map<String, Object>> getVolumesAttached()
    {
        return volumesAttached;
    }

    /**
     * Sets the volumes attached.
     * 
     * @param volumesAttached the volumesAttached to set
     * @version
     */
    public void setVolumesAttached(List<Map<String, Object>> volumesAttached)
    {
        this.volumesAttached = volumesAttached;
    }

    /**
     * To string.
     * 
     * @return the string
     * @version
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
