package com.zte.vdirector.domain.auth;

public class AuthWrapper
{
	private Auth auth;

	public Auth getAuth() 
	{
		return auth;
	}
	public void setAuth(Auth auth) 
	{
		this.auth = auth;
	}
}
