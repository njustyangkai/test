package com.zte.vdirector.domain.loadbalancer;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Agents   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 下午5:25:41 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 下午5:25:41  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Listeners implements Iterable<Listener>, Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 191394243691339395L;

    /**
     * 列表
     */
    private List<Listener> listeners;

    /**
     * @return the listeners
     */
    public List<Listener> getListeners()
    {
        return listeners;
    }

    /**
     * @param listeners the listeners to set
     */
    public void setListeners(List<Listener> listeners)
    {
        this.listeners = listeners;
    }

    @Override
    public Iterator<Listener> iterator()
    {
        return listeners.iterator();
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
