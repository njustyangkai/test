/**
 * 
 */
package com.zte.vdirector.domain.firewall;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.CloudEnvInfo;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：FirewallPolicy   
 * </p>  
 * <p>  
 * 类描述：防火墙策略信息   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月24日 下午4:10:25 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月24日 下午4:10:25  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class FirewallPolicy
{
    /**
     * 防火墙策略ID
     */
    private String id;

    /**
     * 防火墙策略名称
     */
    private String name;

    /**
     * 租户ID
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    /**
     * 
     */
    private Boolean audited;

    /**
     * 
     */
    @JSONField(name = "firewall_rules")
    private List<String> firewallRules;

    /**
     * 
     */
    private Boolean shared;

    /**
     * 防火墙策略描述
     */
    private String description;

    private String vdcId;

    private CloudEnvInfo cloudenv;

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    /**
     * @return the id
     */
    public String getId()
    {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the tenantId
     */
    public String getTenantId()
    {
        return tenantId;
    }

    /**
     * @param tenantId the tenantId to set
     */
    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    /**
     * @return the audited
     */
    public Boolean getAudited()
    {
        return audited;
    }

    /**
     * @param audited the audited to set
     */
    public void setAudited(Boolean audited)
    {
        this.audited = audited;
    }

    /**
     * @return the firewallRules
     */
    public List<String> getFirewallRules()
    {
        return firewallRules;
    }

    /**
     * @param firewallRules the firewallRules to set
     */
    public void setFirewallRules(List<String> firewallRules)
    {
        this.firewallRules = firewallRules;
    }

    /**
     * @return the shared
     */
    public Boolean getShared()
    {
        return shared;
    }

    /**
     * @param shared the shared to set
     */
    public void setShared(Boolean shared)
    {
        this.shared = shared;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    public CloudEnvInfo getCloudenv()
    {
        return cloudenv;
    }

    public void setCloudenv(CloudEnvInfo cloudenv)
    {
        this.cloudenv = cloudenv;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
