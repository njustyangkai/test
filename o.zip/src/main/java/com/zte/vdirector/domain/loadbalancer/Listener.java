package com.zte.vdirector.domain.loadbalancer;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.CloudEnvInfo;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：04.xx-openstack-api  
 * </p>  
 * <p>   
 * 类名称：LoadBalancer   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016-8-6 下午2:51:55 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016-8-6 下午2:51:55  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class Listener
{
    private String id;

    private String name;

    private String description;

    @JSONField(name = "admin_state_up")
    private Boolean adminStateUp;

    @JSONField(name = "tenant_id")
    private String tenantId;

    @JSONField(name = "loadbalancer_id")
    private String loadbalancerId;

    @JSONField(name = "connection_limit")
    private Integer connectionLimit;

    private List<LoadBalancer> loadbalancers;

    @JSONField(name = "default_pool_id")
    private String defaultPoolId;

    @JSONField(name = "protocol")
    private String protocol;

    @JSONField(name = "protocol_port")
    private Integer protocolPort;

    @JSONField(name = "default_tls_container_ref")
    private String defaultTlsContainerRef;

    @JSONField(name = "sni_container_refs")
    private List<String> sniContainerRefs;

    private CloudEnvInfo cloudenv;

    private String vdcId;

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    public CloudEnvInfo getCloudenv()
    {
        return cloudenv;
    }

    public void setCloudenv(CloudEnvInfo cloudenv)
    {
        this.cloudenv = cloudenv;
    }

    /**
     * @return the id
     */
    public String getId()
    {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return the adminStateUp
     */
    public Boolean getAdminStateUp()
    {
        return adminStateUp;
    }

    /**
     * @param adminStateUp the adminStateUp to set
     */
    public void setAdminStateUp(Boolean adminStateUp)
    {
        this.adminStateUp = adminStateUp;
    }

    /**
     * @return the tenantId
     */
    public String getTenantId()
    {
        return tenantId;
    }

    /**
     * @param tenantId the tenantId to set
     */
    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    /**
     * @return the connectionLimit
     */
    public Integer getConnectionLimit()
    {
        return connectionLimit;
    }

    /**
     * @param connectionLimit the connectionLimit to set
     */
    public void setConnectionLimit(Integer connectionLimit)
    {
        this.connectionLimit = connectionLimit;
    }

    /**
     * @return the loadbalancers
     */
    public List<LoadBalancer> getLoadbalancers()
    {
        return loadbalancers;
    }

    /**
     * @param loadbalancers the loadbalancers to set
     */
    public void setLoadbalancers(List<LoadBalancer> loadbalancers)
    {
        this.loadbalancers = loadbalancers;
    }

    /**
     * @return the defaultPoolId
     */
    public String getDefaultPoolId()
    {
        return defaultPoolId;
    }

    /**
     * @param defaultPoolId the defaultPoolId to set
     */
    public void setDefaultPoolId(String defaultPoolId)
    {
        this.defaultPoolId = defaultPoolId;
    }

    /**
     * @return the protocol
     */
    public String getProtocol()
    {
        return protocol;
    }

    /**
     * @param protocol the protocol to set
     */
    public void setProtocol(String protocol)
    {
        this.protocol = protocol;
    }

    /**
     * @return the protocolPort
     */
    public Integer getProtocolPort()
    {
        return protocolPort;
    }

    /**
     * @param protocolPort the protocolPort to set
     */
    public void setProtocolPort(Integer protocolPort)
    {
        this.protocolPort = protocolPort;
    }

    /**
     * @return the defaultTlsContainerRef
     */
    public String getDefaultTlsContainerRef()
    {
        return defaultTlsContainerRef;
    }

    /**
     * @param defaultTlsContainerRef the defaultTlsContainerRef to set
     */
    public void setDefaultTlsContainerRef(String defaultTlsContainerRef)
    {
        this.defaultTlsContainerRef = defaultTlsContainerRef;
    }

    /**
     * @return the sniContainerRefs
     */
    public List<String> getSniContainerRefs()
    {
        return sniContainerRefs;
    }

    /**
     * @param sniContainerRefs the sniContainerRefs to set
     */
    public void setSniContainerRefs(List<String> sniContainerRefs)
    {
        this.sniContainerRefs = sniContainerRefs;
    }

    /**
     * @return the loadbalancerId
     */
    public String getLoadbalancerId()
    {
        return loadbalancerId;
    }

    /**
     * @param loadbalancerId the loadbalancerId to set
     */
    public void setLoadbalancerId(String loadbalancerId)
    {
        this.loadbalancerId = loadbalancerId;
    }
}
