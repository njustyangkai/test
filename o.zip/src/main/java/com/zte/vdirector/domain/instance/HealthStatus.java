package com.zte.vdirector.domain.instance;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api-V4.03.xx  
 * </p>  
 * <p>   
 * 类名称：HealthStatus   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：00141233   
 * </p>  
 * <p>  
 * 创建时间：2015-3-17 下午3:08:23 
 * </p>  
 * <p>    
 * 修改人：00141233 
 * </p>  
 * <p>  
 * 修改时间：2015-3-17 下午3:08:23  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */

/*
 * health_status: {health_value: "WARNING", id:
 * "a91c62ef-8db3-491a-b358-2c5a3fc6315d",…} health_value: "WARNING"
 * id:"a91c62ef-8db3-491a-b358-2c5a3fc6315d"
 * updated_at:"2015-03-17T06:49:31.515053" value_reason: [ {resource_local:
 * "server", resource_id: "a91c62ef-8db3-491a-b358-2c5a3fc6315d",…}] 0:
 * {resource_local:"server", resource_id:
 * "a91c62ef-8db3-491a-b358-2c5a3fc6315d",…} display_name: "Power_RHEL65_AE"
 * resource_id:"a91c62ef-8db3-491a-b358-2c5a3fc6315d" resource_local: "server"
 * resource_property_key: "rmc_state" resource_property_value: "inactive"
 */
public class HealthStatus
{
    /**
     * 运行状态:ok or warning 
     */
    @JSONField(name = "health_value")
    private String healthValue;

    /**
     * 资源id
     */
    private String id;

    /**
     * 更新日期
     */
    @JSONField(name = "updated_at")
    private String updatedAt;

    /**
     * 原因
     */
    @JSONField(name = "value_reason")
    private ValueReason valueReason;

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getHealthValue()
    {
        return healthValue;
    }

    public void setHealthValue(String healthValue)
    {
        this.healthValue = healthValue;
    }

    public String getUpdatedAt()
    {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt)
    {
        this.updatedAt = updatedAt;
    }

    public ValueReason getValueReason()
    {
        return valueReason;
    }

    public void setValueReason(ValueReason valueReason)
    {
        this.valueReason = valueReason;
    }

    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }

}
