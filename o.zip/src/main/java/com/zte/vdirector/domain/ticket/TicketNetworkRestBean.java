/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月20日      下午2:52:05
*/
package com.zte.vdirector.domain.ticket;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketNetworkRestBean
{

    private String description;//备注

    private String id;//IP地址申请表主键ID

    private String networkfn;//地址用途

    private String serialNo;//工单编号全局唯一

    private String subnet;//子网

    private String type;//网络申请种类

    private String vmName;//服务器名称

    private String vmWork;//服务器功能

    private String orderId;

    public String getOrderId()
    {
        return orderId;
    }

    public void setOrderId(String orderId)
    {
        this.orderId = orderId;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getNetworkfn()
    {
        return networkfn;
    }

    public void setNetworkfn(String networkfn)
    {
        this.networkfn = networkfn;
    }

    public String getSerialNo()
    {
        return serialNo;
    }

    public void setSerialNo(String serialNo)
    {
        this.serialNo = serialNo;
    }

    public String getSubnet()
    {
        return subnet;
    }

    public void setSubnet(String subnet)
    {
        this.subnet = subnet;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getVmName()
    {
        return vmName;
    }

    public void setVmName(String vmName)
    {
        this.vmName = vmName;
    }

    public String getVmWork()
    {
        return vmWork;
    }

    public void setVmWork(String vmWork)
    {
        this.vmWork = vmWork;
    }

}
