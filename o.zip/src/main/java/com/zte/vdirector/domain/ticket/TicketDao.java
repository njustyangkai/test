/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月21日      上午10:21:12
*/
package com.zte.vdirector.domain.ticket;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */
@Repository
public class TicketDao
{

    @Resource
    private JdbcTemplate jdbcTemplate;

    public void addTicketRel(String projectId, String ticketId)
    {
        String sql = "insert into project_ticket_rel(project_id,ticket_id) values (?, ?)";
        jdbcTemplate.update(sql, projectId, ticketId);
    }

    public void updateTicketProcess(String id, String status)
    {
        String sql = "update icmsdb.t_instance_sched  set STATUS = ? where id = ?";
        jdbcTemplate.update(sql, status, id);
    }

    /**
     * 
     * @param id
     * @return e
     */
    public TicketBean getTicketDetail(String id)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from icmsdb.tres_app where APP_ID=?");
        List<TicketBean> list = jdbcTemplate.query(sql.toString(), new TicketRowMapper(), id);

        if (list != null && list.size() > 0)
        {
            return list.get(0);
        }
        return null;
    }

    /**
     * 
     * @param id
     * @return e
     */
    public TicketBean getTicketFlag(String appNumber)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from icmsdb.tres_app where APP_NUMBER=?");
        List<TicketBean> list = jdbcTemplate.query(sql.toString(), new TicketRowMapper(), appNumber);

        if (list != null && list.size() > 0)
        {
            return list.get(0);
        }
        return null;
    }

    /**
     * 
     * @param id
     * @return e
     */
    public List<TicketResourceBean> getTicketResourceList(String appId)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from icmsdb.tdevice_conf where ORDER_ID=?");
        return jdbcTemplate.query(sql.toString(), new TicketResourceRowMapper(), appId);

    }

    /**
     * 
     * @param id
     * @return e
     */
    public List<TicketProgressBean> getTicketProgressList(String appId)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select d.ACTION,s.ID,s.BASE_CODE,s.ORDER_ID,s.STATUS,s.RESOURCE_ID,s.RESOURCE_NAME,s.CODE,s.PARENT_CODE,s.AUTO_TASK,s.NEED_RESOURCE from icmsdb.t_instance_sched s "
                + "left join icmsdb.t_base_sched d on s.BASE_CODE = d.CODE where s.ORDER_ID=? order by s.CODE asc");
        return jdbcTemplate.query(sql.toString(), new TicketProgressRowMapper(), appId);

    }

    /**
     * 
     * @param id
     * @return e
     */
    public List<TicketNetworkBean> getTicketNetworkList(String appId)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from icmsdb.tnet_work where ORDER_ID=?");
        return jdbcTemplate.query(sql.toString(), new TicketNetworkRowMapper(), appId);

    }

    /**
     * 查询该部门的订单信息
     * @return
     */
    public List<TicketBean> listTicketsByOrgId(String orgId)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from icmsdb.tres_app where ORGID =?");

        return jdbcTemplate.query(sql.toString(), new TicketRowMapper(), orgId);
    }

    /**
    * 查询该部门的订单信息
    * @return
    */
    public List<TicketBean> listTickets(String[] projectId)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from icmsdb.tres_app where PROJECT_ID in (");

        if (projectId != null && projectId.length > 0)
        {
            for (int i = 0; i < projectId.length; i++)
            {
                if (i == projectId.length - 1)
                {
                    sql.append("'" + projectId[i] + "'");
                }
                else
                {
                    sql.append("'" + projectId[i] + "',");
                }

            }
            sql.append(")");

        }

        return jdbcTemplate.query(sql.toString(), new TicketRowMapper());
    }

}
