package com.zte.vdirector.domain.subnet;

import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Ports   
 * </p>  
 * <p>  
 * 类描述： 端口列表封装类
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "ports": [
 *         {
 *             "status": "ACTIVE",
 *             "name": "",
 *             "admin_state_up": true,
 *             "network_id": "abe58718-1940-43e9-b119-b716adc886c9",
 *             "tenant_id": "f241a207f7d24dd0a7d45582aa7295e4",
 *             "binding:vif_type": "ovs",
 *             "device_owner": "compute:None",
 *             "binding:capabilities": {
 *                 "port_filter": true
 *             },
 *             "mac_address": "fa:16:3e:70:14:fa",
 *             "fixed_ips": [
 *                 {
 *                     "subnet_id": "8058d556-1d76-454c-9d13-b921c420cf0c",
 *                     "ip_address": "10.10.10.3"
 *                 }
 *             ],
 *             "id": "25738ced-4d4b-47a6-a1ea-f8f006f12397",
 *             "security_groups": [
 *                 "bb2454cd-0c7e-4a2a-bbba-d06e3a9bc95d"
 *             ],
 *             "device_id": "08b183cf-36a8-4820-b316-f15a0ad841d8"
 *         }
 *     ]
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 上午11:03:03 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 上午11:03:03  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Ports implements Iterable<Port>
{
    /**
     * 端口列表
     */
    private List<Port> ports;

    public List<Port> getPorts()
    {
        return ports;
    }

    public void setPorts(List<Port> ports)
    {
        this.ports = ports;
    }

    @Override
    public Iterator<Port> iterator()
    {
        return ports.iterator();
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
