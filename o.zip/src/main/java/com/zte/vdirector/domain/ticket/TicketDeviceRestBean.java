/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月20日      下午2:46:24
*/
package com.zte.vdirector.domain.ticket;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketDeviceRestBean
{

    private String appType;//类型

    private String deviceCode;//设备编号

    private String deviceConfigurationId;//工单编号全局唯一

    private String deviceCpuNew;//CPU 设备需求(新项)

    private String deviceHardDiskNew;//硬盘  设备需求(新项)

    private String deviceMemoryNew;//内存  设备需求(新项)

    private String deviceType;//设备类型

    private String netCn2New;//CN2 网络需求(新项)

    private String netEniNew;//ENI 网络需求(新项)

    private String netInternetNew;//Internet 网络需求(新项)

    private String netbPlaneNew;//B平面  网络需求(新项)

    private String osVersion;//拟装操作系统版本

    private String remark;//备注

    private String serverFunction;//服务器功能

    private String vmName;//服务器名称

    private String orderId;

    public String getOrderId()
    {
        return orderId;
    }

    public void setOrderId(String orderId)
    {
        this.orderId = orderId;
    }

    public String getAppType()
    {
        return appType;
    }

    public void setAppType(String appType)
    {
        this.appType = appType;
    }

    public String getDeviceCode()
    {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode)
    {
        this.deviceCode = deviceCode;
    }

    public String getDeviceConfigurationId()
    {
        return deviceConfigurationId;
    }

    public void setDeviceConfigurationId(String deviceConfigurationId)
    {
        this.deviceConfigurationId = deviceConfigurationId;
    }

    public String getDeviceCpuNew()
    {
        return deviceCpuNew;
    }

    public void setDeviceCpuNew(String deviceCpuNew)
    {
        this.deviceCpuNew = deviceCpuNew;
    }

    public String getDeviceHardDiskNew()
    {
        return deviceHardDiskNew;
    }

    public void setDeviceHardDiskNew(String deviceHardDiskNew)
    {
        this.deviceHardDiskNew = deviceHardDiskNew;
    }

    public String getDeviceMemoryNew()
    {
        return deviceMemoryNew;
    }

    public void setDeviceMemoryNew(String deviceMemoryNew)
    {
        this.deviceMemoryNew = deviceMemoryNew;
    }

    public String getDeviceType()
    {
        return deviceType;
    }

    public void setDeviceType(String deviceType)
    {
        this.deviceType = deviceType;
    }

    public String getNetCn2New()
    {
        return netCn2New;
    }

    public void setNetCn2New(String netCn2New)
    {
        this.netCn2New = netCn2New;
    }

    public String getNetEniNew()
    {
        return netEniNew;
    }

    public void setNetEniNew(String netEniNew)
    {
        this.netEniNew = netEniNew;
    }

    public String getNetInternetNew()
    {
        return netInternetNew;
    }

    public void setNetInternetNew(String netInternetNew)
    {
        this.netInternetNew = netInternetNew;
    }

    public String getNetbPlaneNew()
    {
        return netbPlaneNew;
    }

    public void setNetbPlaneNew(String netbPlaneNew)
    {
        this.netbPlaneNew = netbPlaneNew;
    }

    public String getOsVersion()
    {
        return osVersion;
    }

    public void setOsVersion(String osVersion)
    {
        this.osVersion = osVersion;
    }

    public String getRemark()
    {
        return remark;
    }

    public void setRemark(String remark)
    {
        this.remark = remark;
    }

    public String getServerFunction()
    {
        return serverFunction;
    }

    public void setServerFunction(String serverFunction)
    {
        this.serverFunction = serverFunction;
    }

    public String getVmName()
    {
        return vmName;
    }

    public void setVmName(String vmName)
    {
        this.vmName = vmName;
    }

}
