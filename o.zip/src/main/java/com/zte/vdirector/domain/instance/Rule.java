package com.zte.vdirector.domain.instance;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Rule   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月23日 上午11:08:15 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月23日 上午11:08:15  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Rule
{
    /**
     * 规则ID
     */
    private String id;

    /**
     * 规则名称
     */
    private String name;

    /**
     * 父群组ID
     */
    @JSONField(name = "parent_group_id")
    private String parentGroupId;

    /**
     * 源端口
     */
    @JSONField(name = "from_port")
    private String fromPort;

    /**
     * 目的端口
     */
    @JSONField(name = "to_port")
    private String toPort;

    /**
     * IP协议
     */
    @JSONField(name = "ip_protocol")
    private String ipProtocol;

    /**
     * IP范围
     */
    @JSONField(name = "ip_range")
    private RuleIpRange ipRange = new RuleIpRange();

    /**
     * 规则群组
     */
    private RuleGroup group;

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getParentGroupId()
    {
        return parentGroupId;
    }

    public void setParentGroupId(String parentGroupId)
    {
        this.parentGroupId = parentGroupId;
    }

    public String getFromPort()
    {
        return fromPort;
    }

    public void setFromPort(String fromPort)
    {
        this.fromPort = fromPort;
    }

    public String getToPort()
    {
        return toPort;
    }

    public void setToPort(String toPort)
    {
        this.toPort = toPort;
    }

    public String getIpProtocol()
    {
        return ipProtocol;
    }

    public void setIpProtocol(String ipProtocol)
    {
        this.ipProtocol = ipProtocol;
    }

    public RuleIpRange getIpRange()
    {
        return ipRange;
    }

    public void setIpRange(RuleIpRange ipRange)
    {
        this.ipRange = ipRange;
    }

    public RuleGroup getGroup()
    {
        return group;
    }

    public void setGroup(RuleGroup group)
    {
        this.group = group;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
