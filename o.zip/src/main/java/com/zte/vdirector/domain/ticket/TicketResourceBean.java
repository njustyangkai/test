/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月26日      下午4:21:34
*/
package com.zte.vdirector.domain.ticket;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketResourceBean
{

    /**
     *主键 
     */
    private Integer id;

    /**
     * 设备编号
     */
    private String deviceCode;

    /**
     * 申请类型
     */
    private String appType;

    /**
     * 设备类型
     */
    private String deviceType;

    /**
     * 服务器功能
     */
    private String serverFunction;

    /**
     * 虚机命名
     */
    private String vmName;

    /**
     * CPU 设备需求(新项)
     */
    private String deviceCpuNew;

    /**
     * 内存  设备需求(新项)
     */
    private String deviceMemoryNew;

    /**
     * 硬盘  设备需求(新项)
     */
    private String deviceHardDiskNew;

    /**
     * B平面  网络需求(新项)
     */
    private String netbPlaneNew;

    /**
     * ENI 网络需求(新项)
     */
    private String netEniNew;

    /**
     * Internet 网络需求(新项)
     */
    private String netInternetNew;

    /**
     * CN2 网络需求(新项)
     */
    private String netCn2New;

    /**
     * CPU 设备需求(原项)
     */
    private String deviceCpuOld;

    /**
     * 内存  设备需求(原项)
     */
    private String deviceMemoryOld;

    /**
     * 硬盘  设备需求(原项)
     */
    private String deviceHardDiskOld;

    /**
     * B平面  网络需求(原项)
     */
    private String netbPlaneOld;

    /**
     * ENI 网络需求(原项)
     */
    private String netEniOld;

    /**
     * Internet 网络需求(原项)
     */
    private String netInternetOld;

    /**
     * CN2 网络需求(原项)
     */
    private String netCn2Old;

    /**
     * 拟挂载主机编号
     */
    private String mountHostCode;

    /**
     * NAS存储挂载方式
     */
    private String nasMountMode;

    /**
     * 四层负载均衡设备需求
     */
    private String balanceLoadRequirement;

    /**
     * 均衡负载方向
     */
    private String loadDirection;

    /**
     * 拟装操作系统版本
     */
    private String osVersion;

    /**
     * 内网ip地址
     */
    private String ipAddress;

    /**
     * 备注
     */
    private String remark;

    /**
     * 申请工单id
     */
    private String orderId;

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getDeviceCode()
    {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode)
    {
        this.deviceCode = deviceCode;
    }

    public String getAppType()
    {
        return appType;
    }

    public void setAppType(String appType)
    {
        this.appType = appType;
    }

    public String getDeviceType()
    {
        return deviceType;
    }

    public void setDeviceType(String deviceType)
    {
        this.deviceType = deviceType;
    }

    public String getServerFunction()
    {
        return serverFunction;
    }

    public void setServerFunction(String serverFunction)
    {
        this.serverFunction = serverFunction;
    }

    public String getVmName()
    {
        return vmName;
    }

    public void setVmName(String vmName)
    {
        this.vmName = vmName;
    }

    public String getDeviceCpuNew()
    {
        return deviceCpuNew;
    }

    public void setDeviceCpuNew(String deviceCpuNew)
    {
        this.deviceCpuNew = deviceCpuNew;
    }

    public String getDeviceMemoryNew()
    {
        return deviceMemoryNew;
    }

    public void setDeviceMemoryNew(String deviceMemoryNew)
    {
        this.deviceMemoryNew = deviceMemoryNew;
    }

    public String getDeviceHardDiskNew()
    {
        return deviceHardDiskNew;
    }

    public void setDeviceHardDiskNew(String deviceHardDiskNew)
    {
        this.deviceHardDiskNew = deviceHardDiskNew;
    }

    public String getNetbPlaneNew()
    {
        return netbPlaneNew;
    }

    public void setNetbPlaneNew(String netbPlaneNew)
    {
        this.netbPlaneNew = netbPlaneNew;
    }

    public String getNetEniNew()
    {
        return netEniNew;
    }

    public void setNetEniNew(String netEniNew)
    {
        this.netEniNew = netEniNew;
    }

    public String getNetInternetNew()
    {
        return netInternetNew;
    }

    public void setNetInternetNew(String netInternetNew)
    {
        this.netInternetNew = netInternetNew;
    }

    public String getNetCn2New()
    {
        return netCn2New;
    }

    public void setNetCn2New(String netCn2New)
    {
        this.netCn2New = netCn2New;
    }

    public String getDeviceCpuOld()
    {
        return deviceCpuOld;
    }

    public void setDeviceCpuOld(String deviceCpuOld)
    {
        this.deviceCpuOld = deviceCpuOld;
    }

    public String getDeviceMemoryOld()
    {
        return deviceMemoryOld;
    }

    public void setDeviceMemoryOld(String deviceMemoryOld)
    {
        this.deviceMemoryOld = deviceMemoryOld;
    }

    public String getDeviceHardDiskOld()
    {
        return deviceHardDiskOld;
    }

    public void setDeviceHardDiskOld(String deviceHardDiskOld)
    {
        this.deviceHardDiskOld = deviceHardDiskOld;
    }

    public String getNetbPlaneOld()
    {
        return netbPlaneOld;
    }

    public void setNetbPlaneOld(String netbPlaneOld)
    {
        this.netbPlaneOld = netbPlaneOld;
    }

    public String getNetEniOld()
    {
        return netEniOld;
    }

    public void setNetEniOld(String netEniOld)
    {
        this.netEniOld = netEniOld;
    }

    public String getNetInternetOld()
    {
        return netInternetOld;
    }

    public void setNetInternetOld(String netInternetOld)
    {
        this.netInternetOld = netInternetOld;
    }

    public String getNetCn2Old()
    {
        return netCn2Old;
    }

    public void setNetCn2Old(String netCn2Old)
    {
        this.netCn2Old = netCn2Old;
    }

    public String getMountHostCode()
    {
        return mountHostCode;
    }

    public void setMountHostCode(String mountHostCode)
    {
        this.mountHostCode = mountHostCode;
    }

    public String getNasMountMode()
    {
        return nasMountMode;
    }

    public void setNasMountMode(String nasMountMode)
    {
        this.nasMountMode = nasMountMode;
    }

    public String getBalanceLoadRequirement()
    {
        return balanceLoadRequirement;
    }

    public void setBalanceLoadRequirement(String balanceLoadRequirement)
    {
        this.balanceLoadRequirement = balanceLoadRequirement;
    }

    public String getLoadDirection()
    {
        return loadDirection;
    }

    public void setLoadDirection(String loadDirection)
    {
        this.loadDirection = loadDirection;
    }

    public String getOsVersion()
    {
        return osVersion;
    }

    public void setOsVersion(String osVersion)
    {
        this.osVersion = osVersion;
    }

    public String getIpAddress()
    {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress)
    {
        this.ipAddress = ipAddress;
    }

    public String getRemark()
    {
        return remark;
    }

    public void setRemark(String remark)
    {
        this.remark = remark;
    }

    public String getOrderId()
    {
        return orderId;
    }

    public void setOrderId(String orderId)
    {
        this.orderId = orderId;
    }

}
