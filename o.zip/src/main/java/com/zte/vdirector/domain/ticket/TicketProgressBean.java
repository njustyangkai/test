/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月30日      上午11:22:50
*/
package com.zte.vdirector.domain.ticket;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketProgressBean
{

    private String id;

    private String orderId;

    private String resourceId;

    private String resourceName;

    private String status;

    private String code;

    private String parentCode;

    private String baseCode;

    private String autoTask;

    private String needResource;

    private String action;

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getOrderId()
    {
        return orderId;
    }

    public void setOrderId(String orderId)
    {
        this.orderId = orderId;
    }

    public String getResourceId()
    {
        return resourceId;
    }

    public void setResourceId(String resourceId)
    {
        this.resourceId = resourceId;
    }

    public String getResourceName()
    {
        return resourceName;
    }

    public void setResourceName(String resourceName)
    {
        this.resourceName = resourceName;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getCode()
    {
        return code;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getParentCode()
    {
        return parentCode;
    }

    public void setParentCode(String parentCode)
    {
        this.parentCode = parentCode;
    }

    public String getBaseCode()
    {
        return baseCode;
    }

    public void setBaseCode(String baseCode)
    {
        this.baseCode = baseCode;
    }

    public String getAutoTask()
    {
        return autoTask;
    }

    public void setAutoTask(String autoTask)
    {
        this.autoTask = autoTask;
    }

    public String getNeedResource()
    {
        return needResource;
    }

    public void setNeedResource(String needResource)
    {
        this.needResource = needResource;
    }

    public String getAction()
    {
        return action;
    }

    public void setAction(String action)
    {
        this.action = action;
    }

}
