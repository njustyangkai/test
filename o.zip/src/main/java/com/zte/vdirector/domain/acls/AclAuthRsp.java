package com.zte.vdirector.domain.acls;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate-c  
 * </p>  
 * <p>   
 * 类名称：AclAuthRsp   
 * </p>  
 * <p>  
 * 类描述：
    201
    {
        "acls": {
            "link": "/api/v1.0/iks/acls"
        }
    }
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年11月30日 下午3:38:04 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年11月30日 下午3:38:04  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class AclAuthRsp
{
    private AuthRsp acls;

    public AuthRsp getAcls()
    {
        return acls;
    }

    public void setAcls(AuthRsp acls)
    {
        this.acls = acls;
    }

    public class AuthRsp
    {
        private String link;

        public String getLink()
        {
            return link;
        }

        public void setLink(String link)
        {
            this.link = link;
        }
    }
}
