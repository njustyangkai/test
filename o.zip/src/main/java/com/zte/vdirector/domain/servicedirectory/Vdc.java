package com.zte.vdirector.domain.servicedirectory;

import java.util.List;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：Vdc   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年11月2日 下午6:20:42 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年11月2日 下午6:20:42  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Vdc 
{
 	private String id;
    
	private String name;
    
    private String description;
    
    private List<Object> links;
    
    private Object defaultTenat;
    
    private List<Object> resource_pool;

    private Object quota;
    
    private Object usage;
    
    private Object rental_agreement;
    
    private Object org;
    
	public String getId() 
	{
		return id;
	}

	public void setId(String id) 
	{
		this.id = id;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getDescription() 
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public List<Object> getLinks() {
		return links;
	}

	public void setLinks(List<Object> links) {
		this.links = links;
	}

	public Object getDefaultTenat() {
		return defaultTenat;
	}

	public void setDefaultTenat(Object defaultTenat) {
		this.defaultTenat = defaultTenat;
	}

	public List<Object> getResource_pool() {
		return resource_pool;
	}

	public void setResource_pool(List<Object> resource_pool) {
		this.resource_pool = resource_pool;
	}

	public Object getQuota() {
		return quota;
	}

	public void setQuota(Object quota) {
		this.quota = quota;
	}

	public Object getUsage() {
		return usage;
	}

	public void setUsage(Object usage) {
		this.usage = usage;
	}

	public Object getRental_agreement() {
		return rental_agreement;
	}

	public void setRental_agreement(Object rental_agreement) {
		this.rental_agreement = rental_agreement;
	}

	public Object getOrg() {
		return org;
	}

	public void setOrg(Object org) {
		this.org = org;
	}
    
}
