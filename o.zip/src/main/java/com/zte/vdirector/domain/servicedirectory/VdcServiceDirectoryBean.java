package com.zte.vdirector.domain.servicedirectory;

import java.util.List;

import com.zte.vdirector.domain.serviceprice.ChargeItemBean;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：VdcServiceDirectoryBean   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月29日 下午5:04:16 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月29日 下午5:04:16  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class VdcServiceDirectoryBean extends ServiceDirectoryBean
{
    /**
     * VDCID
     */
    private String vdcId;
    
    private String vdcName;

    private List<ChargeItemBean> chargeItemList;

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    public String getVdcName()
    {
        return vdcName;
    }

    public void setVdcName(String vdcName)
    {
        this.vdcName = vdcName;
    }

    public List<ChargeItemBean> getChargeItemList()
    {
        return chargeItemList;
    }

    public void setChargeItemList(List<ChargeItemBean> chargeItemList)
    {
        this.chargeItemList = chargeItemList;
    }
}
