package com.zte.vdirector.domain.auth;

import java.util.List;
import java.util.Map;

public class Access 
{
    private Token token;

    private List<ServiceCatalog> serviceCatalog;

    private User user;

    private Map<String, Object> metadata;

	public Token getToken() {
		return token;
	}

	public void setToken(Token token) {
		this.token = token;
	}

	public List<ServiceCatalog> getServiceCatalog() {
		return serviceCatalog;
	}

	public void setServiceCatalog(List<ServiceCatalog> serviceCatalog) {
		this.serviceCatalog = serviceCatalog;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Map<String, Object> getMetadata() {
		return metadata;
	}

	public void setMetadata(Map<String, Object> metadata) {
		this.metadata = metadata;
	}
    
    

}
