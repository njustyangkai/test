package com.zte.vdirector.domain.serviceprice;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：ServicePriceRowMapper   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 下午4:21:44 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 下午4:21:44  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class ServicePriceRowMapper implements RowMapper<ChargeItemBean>
{
    @Override
    public ChargeItemBean mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        ChargeItemBean chargeItemBean = new ChargeItemBean();

        chargeItemBean.setId(rs.getString("id"));
        chargeItemBean.setName(rs.getString("name"));
        chargeItemBean.setServiceDirectoryId(rs.getString("service_directory_id"));
        chargeItemBean.setIsleaf(rs.getInt("isleaf"));
        chargeItemBean.setParentId(rs.getString("parent_id"));
        chargeItemBean.setPrice(rs.getString("price"));
        chargeItemBean.setStatus(rs.getInt("status"));
        chargeItemBean.setUnit(rs.getString("unit"));
        chargeItemBean.setDescription(rs.getString("description"));

        return chargeItemBean;
    }
}
