/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月21日      下午5:25:04
*/
package com.zte.vdirector.domain.ticket;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketRowMapper implements RowMapper<TicketBean>
{
    @Override
    public TicketBean mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        TicketBean ticketBean = new TicketBean();

        ticketBean.setAppId(rs.getString("APP_ID"));
        ticketBean.setStatus(rs.getString("STATUS"));
        ticketBean.setApplicant(rs.getString("APPLICANT"));
        ticketBean.setAppCompany(rs.getString("APP_COMPANY"));
        ticketBean.setAppPhoneNum(rs.getString("APP_PHONENUM"));
        ticketBean.setAppEmail(rs.getString("APP_EMAIL"));
        ticketBean.setAppDate(rs.getString("APP_DATE"));
        ticketBean.setAppType(rs.getString("APP_TYPE"));
        ticketBean.setAppNumber(rs.getString("APP_NUMBER"));
        ticketBean.setIsProject(rs.getString("IS_PROJECT"));
        ticketBean.setProNumber(rs.getString("PRO_NUMBER"));
        ticketBean.setGscField(rs.getString("GSC_FIELD"));
        ticketBean.setPlatformCode(rs.getString("PLATFORM_CODE"));
        ticketBean.setPlatformName(rs.getString("PLATFORM_NAME"));
        ticketBean.setMaintainPlatform(rs.getString("MAINTAIN_COMPANY"));
        ticketBean.setContacts(rs.getString("CONTACTS"));
        ticketBean.setContEmail(rs.getString("CONT_EMAIL"));
        ticketBean.setContPhoneNum(rs.getString("CONT_PHONENUM"));
        ticketBean.setServiceProject(rs.getString("SERVICE_PROJECT"));
        ticketBean.setType(rs.getString("TYPE"));
        ticketBean.setStep(rs.getString("STEP"));

        return ticketBean;
    }

}
