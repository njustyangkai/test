package com.zte.vdirector.domain.subnet;

import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Networks   
 * </p>  
 * <p>  
 * 类描述：网络列表封装类   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "networks": [
 *         {
 *             "status": "ACTIVE",
 *             "subnets": [
 *                 "39703064-7c49-4cb5-8b99-681f8e9d8596",
 *                 "495face8-3ed3-4949-984a-833d3abcc94a"
 *             ],
 *             "name": "External",
 *             "provider:physical_network": null,
 *             "admin_state_up": true,
 *             "tenant_id": "f241a207f7d24dd0a7d45582aa7295e4",
 *             "provider:network_type": "gre",
 *             "router:external": true,
 *             "shared": true,
 *             "id": "e49d9cdb-191f-419a-b1a1-a70c067aebfe",
 *             "provider:segmentation_id": 2
 *         }
 *     ]
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 上午10:24:30 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 上午10:24:30  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Networks implements Iterable<Network>
{
    /**
     * 网络列表
     */
    private List<Network> networks;

    public List<Network> getNetworks()
    {
        return networks;
    }

    public void setNetworks(List<Network> networks)
    {
        this.networks = networks;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }

    @Override
    public Iterator<Network> iterator()
    {
        return networks.iterator();
    }
}
