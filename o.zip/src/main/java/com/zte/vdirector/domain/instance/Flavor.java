package com.zte.vdirector.domain.instance;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.auth.Link;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Flavor   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 下午5:26:55 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 下午5:26:55  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Flavor
{
    /**
     * 规格ID
     */
    private String id;

    /**
     * 规格名称
     */
    private String name;

    /**
     * cpu个数
     */
    private Integer vcpus;

    /**
     * 内存大小
     */
    private Integer ram;

    /**
     * 硬盘大小
     */
    private Integer disk;

    /**
     * 
     */
    @JSONField(name = "OS-FLV-EXT-DATA:ephemeral")
    private Integer ephemeral;

    /**
     * 
     */
    private Integer swap;

    /**
     * 
     */
    @JSONField(name = "rxtx_factor")
    private Float rxtxFactor;

    /**
     * 是否禁用
     */
    @JSONField(name = "OS-FLV-DISABLED:disabled")
    private Boolean disabled;

    /**
     * 
     */
    @JSONField(name = "rxtx_quota")
    private Integer rxtxQuota;

    /**
     * 
     */
    @JSONField(name = "rxtx_cap")
    private Integer rxtxCap;

    /**
     * 
     */
    private List<Link> links;

    /**
     * 是否公开
     */
    @JSONField(name = "os-flavor-access:is_public")
    private Boolean isPublic;

    /**
     * @return the id
     */
    public String getId()
    {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the vcpus
     */
    public Integer getVcpus()
    {
        return vcpus;
    }

    /**
     * @param vcpus the vcpus to set
     */
    public void setVcpus(Integer vcpus)
    {
        this.vcpus = vcpus;
    }

    /**
     * @return the ram
     */
    public Integer getRam()
    {
        return ram;
    }

    /**
     * @param ram the ram to set
     */
    public void setRam(Integer ram)
    {
        this.ram = ram;
    }

    /**
     * @return the disk
     */
    public Integer getDisk()
    {
        return disk;
    }

    /**
     * @param disk the disk to set
     */
    public void setDisk(Integer disk)
    {
        this.disk = disk;
    }

    /**
     * @return the ephemeral
     */
    public Integer getEphemeral()
    {
        return ephemeral;
    }

    /**
     * @param ephemeral the ephemeral to set
     */
    public void setEphemeral(Integer ephemeral)
    {
        this.ephemeral = ephemeral;
    }

    /**
     * @return the swap
     */
    public Integer getSwap()
    {
        return swap;
    }

    /**
     * @param swap the swap to set
     */
    public void setSwap(Integer swap)
    {
        this.swap = swap;
    }

    /**
     * @return the disabled
     */
    public Boolean getDisabled()
    {
        return disabled;
    }

    /**
     * @param disabled the disabled to set
     */
    public void setDisabled(Boolean disabled)
    {
        this.disabled = disabled;
    }

    /**
     * @return the links
     */
    public List<Link> getLinks()
    {
        return links;
    }

    /**
     * @param links the links to set
     */
    public void setLinks(List<Link> links)
    {
        this.links = links;
    }

    public Float getRxtxFactor()
    {
        return rxtxFactor;
    }

    public void setRxtxFactor(Float rxtxFactor)
    {
        this.rxtxFactor = rxtxFactor;
    }

    public Integer getRxtxQuota()
    {
        return rxtxQuota;
    }

    public void setRxtxQuota(Integer rxtxQuota)
    {
        this.rxtxQuota = rxtxQuota;
    }

    public Integer getRxtxCap()
    {
        return rxtxCap;
    }

    public void setRxtxCap(Integer rxtxCap)
    {
        this.rxtxCap = rxtxCap;
    }

    public Boolean getIsPublic()
    {
        return isPublic;
    }

    public void setIsPublic(Boolean isPublic)
    {
        this.isPublic = isPublic;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
