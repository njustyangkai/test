package com.zte.vdirector.domain.subnet;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Port   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 上午11:04:56 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 上午11:04:56  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Port
{
    /**
     * 状态
     */
    private String status;

    /**
     * 
     */
    @JSONField(name = "binding:host_id")
    private String bindingHostId;

    /**
     * 名称
     */
    private String name;

    /**
     * 
     */
    @JSONField(name = "allowed_address_pairs")
    private List<Map<String, Object>> allowedAddressPairs;

    /**
     * 
     */
    @JSONField(name = "admin_state_up")
    private boolean adminStateUp;

    /**
     * 网络ID
     */
    @JSONField(name = "network_id")
    private String networkId;

    /**
     * 租户ID
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    /**
     * 
     */
    @JSONField(name = "extra_dhcp_opts")
    private List<String> extraDhcpOpts;

    /**
     * Read-only. The vif type for the specified port.
     */
    @JSONField(name = "binding:vif_type")
    private String bindingVifType;

    /**
     * Read-only. 
     * A dictionary that enables the application to pass information about functions that the Networking API provides. 
     * To enable or disable port filtering features such as security group and anti-MAC/IP spoofing, 
     * specify port_filter: True or port_filter: False
     */
    @JSONField(name = "binding:vif_details")
    private Object bindingVifDetails;

    /**
     * A dictionary the enables the application running on the specified host to pass and receive vif port-specific information to the plug-in.
     */
    @JSONField(name = "binding:profile")
    private Object bindingProfile;

    /**
     * The vnic type that is bound to the neutron port. In POST and PUT operations, 
     * specify a value of normal (virtual nic), direct (pci passthrough), 
     * or macvtap (virtual interface with a tap-like software interface). 
     * These values support SR-IOV PCI passthrough networking. 
     * The ML2 plug-in supports the vnic_type.In GET operations, 
     * the binding:vnic_type extended attribute is visible to only port owners and administrative users.
     * 
     * macvtap：表示要创建一个类型为macvtap的端口
     */
    @JSONField(name = "binding:vnic_type")
    private String bindingVnicType;

    /**
     * 有效值为0或1（配置为1：说明该port是bond端口，在vm里面将看到两个端口，而且要求虚拟机里面对这两个网口进行bond，目前只支持主备模式的bond）
     */
    private String bond;

    /**
     * 
     */
    @JSONField(name = "device_owner")
    private String deviceOwner;

    /**
     * 
     */
    @JSONField(name = "binding:capabilities")
    private Map<String, Object> bindingCapabilities;

    /**
     * MAC地址
     */
    @JSONField(name = "mac_address")
    private String macAddress;

    /**
     * 固定IP列表
     */
    @JSONField(name = "fixed_ips")
    private List<Ip> fixedIps;

    /**
     * 端口ID
     */
    private String id;

    /**
     * 
     */
    @JSONField(name = "security_groups")
    private List<String> securityGroups;

    /**
     * 
     */
    @JSONField(name = "device_id")
    private String deviceId;

    /**
     * For OpenCOS 端口的最大带宽，0表示不限速，默认值为0，单位为MB。范围只有是0和正整数。端口带宽值的优先级大于网络带宽的优先级，如果端口的带宽配置为非0，则以端口的配置值为准。
     */
    private String bandwidth;
    
    /**
     * 端口的CBS，0表示不支持突发，默认值为0，单位为Byte。范围只有是0和正整数。端口CBS的优先级大于网络CBS的优先级，如果端口的CBS配置为非0，则以端口的配置值为准。
     */
    private String cbs;
    
    /**
     * 该值作为端口的DSCP值，默认值为0，有效范围为（0~63）
     */
    @JSONField(name = "dscp")
    private Integer dscp;

    public String getCbs()
    {
        return cbs;
    }

    public void setCbs(String cbs)
    {
        this.cbs = cbs;
    }

    public Integer getDscp()
    {
        return dscp;
    }

    public void setDscp(Integer dscp)
    {
        this.dscp = dscp;
    }

    public String getBandwidth()
    {
        return bandwidth;
    }

    public void setBandwidth(String bandwidth)
    {
        this.bandwidth = bandwidth;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public boolean isAdminStateUp()
    {
        return adminStateUp;
    }

    public void setAdminStateUp(boolean adminStateUp)
    {
        this.adminStateUp = adminStateUp;
    }

    public String getDeviceId()
    {
        return deviceId;
    }

    public void setDeviceId(String deviceId)
    {
        this.deviceId = deviceId;
    }

    public String getDeviceOwner()
    {
        return deviceOwner;
    }

    public void setDeviceOwner(String deviceOwner)
    {
        this.deviceOwner = deviceOwner;
    }

    public List<Ip> getFixedIps()
    {
        return fixedIps;
    }

    public void setFixedIps(List<Ip> fixedIps)
    {
        this.fixedIps = fixedIps;
    }

    public String getMacAddress()
    {
        return macAddress;
    }

    public void setMacAddress(String macAddress)
    {
        this.macAddress = macAddress;
    }

    public String getNetworkId()
    {
        return networkId;
    }

    public void setNetworkId(String networkId)
    {
        this.networkId = networkId;
    }

    public String getTenantId()
    {
        return tenantId;
    }

    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    /**
     * @return the bindingHostId
     */
    public String getBindingHostId()
    {
        return bindingHostId;
    }

    /**
     * @param bindingHostId the bindingHostId to set
     */
    public void setBindingHostId(String bindingHostId)
    {
        this.bindingHostId = bindingHostId;
    }

    /**
     * @return the allowedAddressPairs
     */
    public List<Map<String, Object>> getAllowedAddressPairs()
    {
        return allowedAddressPairs;
    }

    /**
     * @param allowedAddressPairs the allowedAddressPairs to set
     */
    public void setAllowedAddressPairs(List<Map<String, Object>> allowedAddressPairs)
    {
        this.allowedAddressPairs = allowedAddressPairs;
    }

    /**
     * @return the extraDhcpOpts
     */
    public List<String> getExtraDhcpOpts()
    {
        return extraDhcpOpts;
    }

    /**
     * @param extraDhcpOpts the extraDhcpOpts to set
     */
    public void setExtraDhcpOpts(List<String> extraDhcpOpts)
    {
        this.extraDhcpOpts = extraDhcpOpts;
    }

    /**
     * @return the bindingVifType
     */
    public String getBindingVifType()
    {
        return bindingVifType;
    }

    /**
     * @param bindingVifType the bindingVifType to set
     */
    public void setBindingVifType(String bindingVifType)
    {
        this.bindingVifType = bindingVifType;
    }

    public Object getBindingVifDetails()
    {
        return bindingVifDetails;
    }

    public void setBindingVifDetails(Object bindingVifDetails)
    {
        this.bindingVifDetails = bindingVifDetails;
    }

    public Object getBindingProfile()
    {
        return bindingProfile;
    }

    public void setBindingProfile(Object bindingProfile)
    {
        this.bindingProfile = bindingProfile;
    }

    public String getBindingVnicType()
    {
        return bindingVnicType;
    }

    public void setBindingVnicType(String bindingVnicType)
    {
        this.bindingVnicType = bindingVnicType;
    }

    public String getBond()
    {
        return bond;
    }

    public void setBond(String bond)
    {
        this.bond = bond;
    }

    /**
     * @return the bindingCapabilities
     */
    public Map<String, Object> getBindingCapabilities()
    {
        return bindingCapabilities;
    }

    /**
     * @param bindingCapabilities the bindingCapabilities to set
     */
    public void setBindingCapabilities(Map<String, Object> bindingCapabilities)
    {
        this.bindingCapabilities = bindingCapabilities;
    }

    /**
     * @return the securityGroups
     */
    public List<String> getSecurityGroups()
    {
        return securityGroups;
    }

    /**
     * @param securityGroups the securityGroups to set
     */
    public void setSecurityGroups(List<String> securityGroups)
    {
        this.securityGroups = securityGroups;
    }

    public static final class Ip implements Serializable
    {
        /**
         * 序列化ID
         */
        private static final long serialVersionUID = 7355106099208784906L;

        /**
         * IP地址
         */
        @JSONField(name = "ip_address")
        private String ipAddress;

        /**
         * 子网ID
         */
        @JSONField(name = "subnet_id")
        private String subnetId;

        public String getIpAddress()
        {
            return ipAddress;
        }

        public void setIpAddress(String ipAddress)
        {
            this.ipAddress = ipAddress;
        }

        public String getSubnetId()
        {
            return subnetId;
        }

        public void setSubnetId(String subnetId)
        {
            this.subnetId = subnetId;
        }

        /**
         * To string.
         * 
         * @return the string
         */
        @Override
        public String toString()
        {
            return JSON.toJSONString(this);
        }
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
