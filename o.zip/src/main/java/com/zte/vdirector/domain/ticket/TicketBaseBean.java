/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月26日      下午4:17:22
*/
package com.zte.vdirector.domain.ticket;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketBaseBean
{
    /**
     * 申请工单id
     */
    private String appId;

    /**
     * 工单状态
     */
    private String status;

    /**
     * 申请人
     */
    private String applicant;

    /**
     * 申请单位
     */
    private String appCompany;

    /**
     * 申请人电话
     */
    private String appPhoneNum;

    /**
     * 申请人邮件
     */
    private String appEmail;

    /**
     * 申请日期
     */
    private String appDate;

    /**
     * 申请类型
     */
    private String appType;

    /**
     * 申请编号
     */
    private String appNumber;

    /**
     * 是否工程
     */
    private String isProject;

    /**
     * 工程编号
     */
    private String proNumber;

    /**
     * 金银铜域
     */
    private String gscField;

    /**
     * 平台名称
     */
    private String platformName;

    /**
     * 平台代号
     */
    private String platformCode;

    /**
     * 维护单位
     */
    private String maintainCompany;

    /**
     * 联系人员
     */
    private String contacts;

    /**
     * 联系人电话
     */
    private String contPhoneNum;

    /**
     * 联系人邮件
     */
    private String contEmail;

    /**
     * 平台主要服务项目
     */
    private String serviceProject;

    private String step;

    private String type;

    public String getAppId()
    {
        return appId;
    }

    public void setAppId(String appId)
    {
        this.appId = appId;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getApplicant()
    {
        return applicant;
    }

    public void setApplicant(String applicant)
    {
        this.applicant = applicant;
    }

    public String getAppCompany()
    {
        return appCompany;
    }

    public void setAppCompany(String appCompany)
    {
        this.appCompany = appCompany;
    }

    public String getAppPhoneNum()
    {
        return appPhoneNum;
    }

    public void setAppPhoneNum(String appPhoneNum)
    {
        this.appPhoneNum = appPhoneNum;
    }

    public String getAppEmail()
    {
        return appEmail;
    }

    public void setAppEmail(String appEmail)
    {
        this.appEmail = appEmail;
    }

    public String getAppDate()
    {
        return appDate;
    }

    public void setAppDate(String appDate)
    {
        this.appDate = appDate;
    }

    public String getAppType()
    {
        return appType;
    }

    public void setAppType(String appType)
    {
        this.appType = appType;
    }

    public String getAppNumber()
    {
        return appNumber;
    }

    public void setAppNumber(String appNumber)
    {
        this.appNumber = appNumber;
    }

    public String getIsProject()
    {
        return isProject;
    }

    public void setIsProject(String isProject)
    {
        this.isProject = isProject;
    }

    public String getProNumber()
    {
        return proNumber;
    }

    public void setProNumber(String proNumber)
    {
        this.proNumber = proNumber;
    }

    public String getGscField()
    {
        return gscField;
    }

    public void setGscField(String gscField)
    {
        this.gscField = gscField;
    }

    public String getPlatformName()
    {
        return platformName;
    }

    public void setPlatformName(String platformName)
    {
        this.platformName = platformName;
    }

    public String getPlatformCode()
    {
        return platformCode;
    }

    public void setPlatformCode(String platformCode)
    {
        this.platformCode = platformCode;
    }

    public String getMaintainCompany()
    {
        return maintainCompany;
    }

    public void setMaintainCompany(String maintainCompany)
    {
        this.maintainCompany = maintainCompany;
    }

    public String getContacts()
    {
        return contacts;
    }

    public void setContacts(String contacts)
    {
        this.contacts = contacts;
    }

    public String getContPhoneNum()
    {
        return contPhoneNum;
    }

    public void setContPhoneNum(String contPhoneNum)
    {
        this.contPhoneNum = contPhoneNum;
    }

    public String getContEmail()
    {
        return contEmail;
    }

    public void setContEmail(String contEmail)
    {
        this.contEmail = contEmail;
    }

    public String getServiceProject()
    {
        return serviceProject;
    }

    public void setServiceProject(String serviceProject)
    {
        this.serviceProject = serviceProject;
    }

    public String getStep()
    {
        return step;
    }

    public void setStep(String step)
    {
        this.step = step;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

}
