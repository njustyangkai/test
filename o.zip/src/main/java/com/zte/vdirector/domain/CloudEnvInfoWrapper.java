package com.zte.vdirector.domain;

public class CloudEnvInfoWrapper
{
    private CloudEnvInfo cloudEnvInfo;

    public CloudEnvInfo getCloudEnvInfo()
    {
        return cloudEnvInfo;
    }

    public void setCloudEnvInfo(CloudEnvInfo cloudEnvInfo)
    {
        this.cloudEnvInfo = cloudEnvInfo;
    }
}
