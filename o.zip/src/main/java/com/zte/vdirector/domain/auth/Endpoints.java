package com.zte.vdirector.domain.auth;

import java.util.List;

public class Endpoints 
{
	private List<Endpoint> endpoints;

	public List<Endpoint> getEndpoints() 
	{
		return endpoints;
	}

	public void setEndpoints(List<Endpoint> endpoints)
	{
		this.endpoints = endpoints;
	}
	

	
}
