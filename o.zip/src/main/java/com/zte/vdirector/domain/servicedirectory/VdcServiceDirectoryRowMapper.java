package com.zte.vdirector.domain.servicedirectory;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：VdcServiceDirectoryRowMapper   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 下午3:35:58 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 下午3:35:58  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class VdcServiceDirectoryRowMapper implements RowMapper<VdcServiceDirectoryBean>
{
    @Override
    public VdcServiceDirectoryBean mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        VdcServiceDirectoryBean vdcServiceDirectoryBean = new VdcServiceDirectoryBean();

        vdcServiceDirectoryBean.setExtra(rs.getString("extra"));
        vdcServiceDirectoryBean.setVdcId(rs.getString("vdc_id"));

        return vdcServiceDirectoryBean;
    }
}
