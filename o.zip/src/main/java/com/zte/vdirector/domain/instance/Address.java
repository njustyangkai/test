package com.zte.vdirector.domain.instance;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Address   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月23日 下午5:36:33 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月23日 下午5:36:33  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Address
{
    /**
     * MAC地址
     */
    @JSONField(name = "OS-EXT-IPS-MAC:mac_addr")
    private String mac_addr;

    /**
     * 版本
     */
    private String version;

    /**
     * IP地址
     */
    private String addr;

    /**
     * 类型
     */
    @JSONField(name = "OS-EXT-IPS:type")
    private String type;

    public String getMac_addr()
    {
        return mac_addr;
    }

    public void setMac_addr(String mac_addr)
    {
        this.mac_addr = mac_addr;
    }

    public String getVersion()
    {
        return version;
    }

    public void setVersion(String version)
    {
        this.version = version;
    }

    public String getAddr()
    {
        return addr;
    }

    public void setAddr(String addr)
    {
        this.addr = addr;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
