package com.zte.vdirector.domain.loadbalancer;


/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：HealthMonitorWrapper   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "healthmonitor": {
 *         "admin_state_up": true,
 *         "tenant_id": "83657cfcdfe44cd5920adaf26c48ceea",
 *         "delay": 5,
 *         "expected_codes": "200",
 *         "max_retries": 2,
 *         "http_method": "GET",
 *         "timeout": 2,
 *         "url_path": "/",
 *         "type": "HTTP",
 *         "id": "5d4b5228-33b0-4e60-b225-9b727c1a20e7"
 *     }
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 下午3:10:03 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 下午3:10:03  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class HealthMonitorv2Wrapper
{
    /**
     * HealthMonitor信息
     */
    private HealthMonitor healthmonitor;

    public HealthMonitor getHealthmonitor()
    {
        return healthmonitor;
    }

    public void setHealthmonitor(HealthMonitor healthmonitor)
    {
        this.healthmonitor = healthmonitor;
    }
}
