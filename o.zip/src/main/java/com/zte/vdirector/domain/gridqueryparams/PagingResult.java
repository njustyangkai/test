package com.zte.vdirector.domain.gridqueryparams;

import java.util.List;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：PagingResult   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10184649   
 * </p>  
 * <p>  
 * 创建时间：2016年7月28日 下午4:05:18 
 * </p>  
 * <p>    
 * 修改人：10184649  
 * </p>  
 * <p>  
 * 修改时间：2016年7月28日 下午4:05:18  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class PagingResult
{
    private List<?> list;

    private int total;

    public int getTotal()
    {
        return total;
    }

    public void setTotal(int total)
    {
        this.total = total;
    }

    public List<?> getList()
    {
        return list;
    }

    public void setList(List<?> list)
    {
        this.list = list;
    }

    public static PagingResult getResult(List<?> list, int total)
    {
        PagingResult result = new PagingResult();
        result.setList(list);
        result.setTotal(total);
        return result;
    }
}
