package com.zte.vdirector.domain.auth;

import java.util.List;

public class ServiceCatalog 
{
    private String type;

    private String name;
    
    private List<Link> endpoints_links;

    private List<Endpoint> endpoints;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Link> getEndpoints_links() {
		return endpoints_links;
	}

	public void setEndpoints_links(List<Link> endpoints_links) {
		this.endpoints_links = endpoints_links;
	}

	public List<Endpoint> getEndpoints() {
		return endpoints;
	}

	public void setEndpoints(List<Endpoint> endpoints) {
		this.endpoints = endpoints;
	}


    
    

}
