package com.zte.vdirector.domain.loadbalancer;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.CloudEnvInfo;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Member   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年8月28日 下午6:44:08 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年8月28日 下午6:44:08  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class Member
{
    /**
     * Unique identifier for the member.
     */
    private String id;

    /**
     * Owner of the member. Only an admin user can specify a tenant identifier other than its own.
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    /**
     * For 2.0
     */
    @JSONField(name = "subnet_id")
    private String subnetId;

    /**
     * The port on which the application is hosted.
     */
    @JSONField(name = "protocol_port")
    private Integer protocolPort;

    /**
     * The pool that the member belongs to.
     */
    @JSONField(name = "pool_id")
    private String poolId;

    /**
     * 
     */
    @JSONField(name = "status_description")
    private Object statusDescription;

    /**
     * The weight of a member determines the portion of requests or connections it services compared to the other members of the
     */
    private Integer weight;

    /**
     * Administrative state of the member
     */
    @JSONField(name = "admin_state_up")
    private Boolean adminStateUp;

    /**
     * The IP address of the member.
     */
    private String address;

    /**
     * Indicates whether or not a member is currently operational.
     */
    private String status;

    private CloudEnvInfo cloudenv;

    private String vdcId;

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    public CloudEnvInfo getCloudenv()
    {
        return cloudenv;
    }

    public void setCloudenv(CloudEnvInfo cloudenv)
    {
        this.cloudenv = cloudenv;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the subnetId
     */
    public String getSubnetId()
    {
        return subnetId;
    }

    /**
     * @param subnetId the subnetId to set
     */
    public void setSubnetId(String subnetId)
    {
        this.subnetId = subnetId;
    }

    public String getTenantId()
    {
        return tenantId;
    }

    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    public Integer getProtocolPort()
    {
        return protocolPort;
    }

    public void setProtocolPort(Integer protocolPort)
    {
        this.protocolPort = protocolPort;
    }

    public String getPoolId()
    {
        return poolId;
    }

    public void setPoolId(String poolId)
    {
        this.poolId = poolId;
    }

    public Object getStatusDescription()
    {
        return statusDescription;
    }

    public void setStatusDescription(Object statusDescription)
    {
        this.statusDescription = statusDescription;
    }

    public Integer getWeight()
    {
        return weight;
    }

    public void setWeight(Integer weight)
    {
        this.weight = weight;
    }

    public Boolean getAdminStateUp()
    {
        return adminStateUp;
    }

    public void setAdminStateUp(Boolean adminStateUp)
    {
        this.adminStateUp = adminStateUp;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
