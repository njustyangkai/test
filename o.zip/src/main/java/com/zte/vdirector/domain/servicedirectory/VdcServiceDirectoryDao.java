package com.zte.vdirector.domain.servicedirectory;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：VdcServiceDirectoryDao   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月31日 上午10:45:06 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月31日 上午10:45:06  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
@Repository
public class VdcServiceDirectoryDao
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private JdbcTemplate jdbcTemplate;

    public List<VdcServiceDirectoryBean> listVdcServiceDirectorys()
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from vdc_service_directory");
        return jdbcTemplate.query(sql.toString(), new VdcServiceDirectoryRowMapper());
    }

    public VdcServiceDirectoryBean getVdcServiceDirectory(String vdcId)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select * from vdc_service_directory where vdc_id = ?");
        try
        {
            return jdbcTemplate.queryForObject(sql.toString(), new VdcServiceDirectoryRowMapper(), vdcId);
        }
        catch (Exception e)
        {
            logger.error("Fail to get vdc service directory.", e);
            return null;
        }
    }

    public boolean addVdcServiceDirectory(VdcServiceDirectoryBean vdcSerDir)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("insert into vdc_service_directory(vdc_id, extra) values(?, ?)");
        return jdbcTemplate.update(sql.toString(), vdcSerDir.getVdcId(), vdcSerDir.getExtra()) > 0;
    }

    public boolean updateVdcServiceDirectory(VdcServiceDirectoryBean vdcSerDir)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("update vdc_service_directory set extra = ? where vdc_id = ? ");
        return jdbcTemplate.update(sql.toString(), vdcSerDir.getExtra(), vdcSerDir.getVdcId()) > 0;
    }

    public boolean deleteVdcServiceDirectory(String vdcId)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("delete from vdc_service_directory where vdc_id = ? ");
        return jdbcTemplate.update(sql.toString(), vdcId) > 0;
    }
}
