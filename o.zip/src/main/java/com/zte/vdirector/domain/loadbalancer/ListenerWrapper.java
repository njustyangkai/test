package com.zte.vdirector.domain.loadbalancer;

import com.alibaba.fastjson.JSON;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：ListenerWrapper   
 * </p>  
 * <p>  
 * 类描述：防火墙封装类   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月24日 下午4:21:09 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月24日 下午4:21:09  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class ListenerWrapper
{
    /**
     * 防火墙
     */
    private Listener listener;

    /**
     * @return the listener
     */
    public Listener getListener()
    {
        return listener;
    }

    /**
     * @param listener the listener to set
     */
    public void setListener(Listener listener)
    {
        this.listener = listener;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
