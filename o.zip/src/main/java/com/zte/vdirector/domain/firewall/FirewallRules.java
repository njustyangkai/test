package com.zte.vdirector.domain.firewall;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：FirewallRules   
 * </p>  
 * <p>  
 * 类描述：防火墙规则列表封装类   
 * </p> 
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "firewall_rules": [
 *         {
 *             "action": "allow",
 *             "description": "",
 *             "destination_ip_address": null,
 *             "destination_port": "80",
 *             "enabled": true,
 *             "firewall_policy_id": "c69933c1-b472-44f9-8226-30dc4ffd454c",
 *             "id": "8722e0e0-9cc9-4490-9660-8c9a5732fbb0",
 *             "ip_version": 4,
 *             "name": "ALLOW_HTTP",
 *             "position": 1,
 *             "protocol": "tcp",
 *             "shared": false,
 *             "source_ip_address": null,
 *             "source_port": null,
 *             "tenant_id": "45977fa2dbd7482098dd68d0d8970117"
 *         }
 *     ]
 * }
 * </pre></blockquote><p> 
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年5月7日 下午8:24:11 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年5月7日 下午8:24:11  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class FirewallRules
{
    /**
     * 防火墙规则列表
     */
    @JSONField(name = "firewall_rules")
    private List<FirewallRule> firewallRules;

    /**
     * @return the firewallRules
     */
    public List<FirewallRule> getFirewallRules()
    {
        return firewallRules;
    }

    /**
     * @param firewallRules the firewallRules to set
     */
    public void setFirewallRules(List<FirewallRule> firewallRules)
    {
        this.firewallRules = firewallRules;
    }

    /**
     * 将调用每个DC的响应结果聚合为一个
     * 
     * @param wrapperList 响应列表
     * @return 聚合响应
     */
    public FirewallRules combine(ArrayList<FirewallRules> wrapperList)
    {
        FirewallRules finalWrapper = new FirewallRules();
        List<FirewallRule> itemList = new ArrayList<FirewallRule>();
        for (FirewallRules wrapperItem : wrapperList)
        {
            if (null == wrapperItem || null == wrapperItem.getFirewallRules())
            {
                continue;
            }
            itemList.addAll(wrapperItem.getFirewallRules());
        }
        finalWrapper.setFirewallRules(itemList);
        return finalWrapper;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
