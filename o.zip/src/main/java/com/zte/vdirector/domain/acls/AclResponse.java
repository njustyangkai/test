package com.zte.vdirector.domain.acls;

import java.util.List;

public class AclResponse
{
    private List<AclEntity> acls;

    public List<AclEntity> getAcls()
    {
        return acls;
    }

    public void setAcls(List<AclEntity> acls)
    {
        this.acls = acls;
    }
}
