/**
 * 
 */
package com.zte.vdirector.domain.firewall;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Firewalls   
 * </p>  
 * <p>  
 * 类描述：防火墙列表封装类   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "firewalls": [
 *         {
 *             "status": "PENDING_CREATE",
 *             "name": "",
 *             "admin_state_up": true,
 *             "tenant_id": "40bb3ee25d604d219866d08a93150c40",
 *             "firewall_policy_id": "3613ac5d-65db-4170-80a6-d7fdce37d669",
 *             "id": "4ed84817-d856-4795-bac0-0c8c18f89e4c",
 *             "description": ""
 *         }
 *     ]
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月24日 下午4:21:09 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月24日 下午4:21:09  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class Firewalls
{
    /**
     * 防火墙列表
     */
    private List<Firewall> firewalls;

    /**
     * @return the firewalls
     */
    public List<Firewall> getFirewalls()
    {
        return firewalls;
    }

    /**
     * @param firewalls the firewalls to set
     */
    public void setFirewalls(List<Firewall> firewalls)
    {
        this.firewalls = firewalls;
    }

    /**
     * 将调用每个DC的响应结果聚合为一个
     * 
     * @param wrapperList 响应列表
     * @return 聚合响应
     */
    public Firewalls combine(ArrayList<Firewalls> wrapperList)
    {
        Firewalls finalWrapper = new Firewalls();
        List<Firewall> itemList = new ArrayList<Firewall>();
        for (Firewalls wrapperItem : wrapperList)
        {
            if (null == wrapperItem || null == wrapperItem.getFirewalls())
            {
                continue;
            }
            itemList.addAll(wrapperItem.getFirewalls());
        }
        finalWrapper.setFirewalls(itemList);
        return finalWrapper;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
