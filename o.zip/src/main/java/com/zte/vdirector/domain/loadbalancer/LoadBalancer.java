package com.zte.vdirector.domain.loadbalancer;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.CloudEnvInfo;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：04.xx-openstack-api  
 * </p>  
 * <p>   
 * 类名称：LoadBalancer   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016-8-6 下午2:51:55 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016-8-6 下午2:51:55  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class LoadBalancer
{
    private String id;

    private String name;

    private String provider;

    private String description;

    @JSONField(name = "admin_state_up")
    private Boolean adminStateUp;

    @JSONField(name = "tenant_id")
    private String tenantId;

    @JSONField(name = "provisioning_status")
    private String provisioningStatus;

    private List<String> listeners;

    @JSONField(name = "vip_address")
    private String vipAddress;

    @JSONField(name = "vip_subnet_id")
    private String vipSubnetId;

    @JSONField(name = "vip_subnet_name")
    private String vipSubnetName;

    @JSONField(name = "vip_port_id")
    private String vipPortId;

    @JSONField(name = "operating_status")
    private String operatingStatus;

    private CloudEnvInfo cloudenv;

    private String vdcId;

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    public CloudEnvInfo getCloudenv()
    {
        return cloudenv;
    }

    public void setCloudenv(CloudEnvInfo cloudenv)
    {
        this.cloudenv = cloudenv;
    }

    /**
     * @return the id
     */
    public String getId()
    {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return the provider
     */
    public String getProvider()
    {
        return provider;
    }

    /**
     * @param provider the provider to set
     */
    public void setProvider(String provider)
    {
        this.provider = provider;
    }

    /**
     * @return the vipPortId
     */
    public String getVipPortId()
    {
        return vipPortId;
    }

    /**
     * @param vipPortId the vipPortId to set
     */
    public void setVipPortId(String vipPortId)
    {
        this.vipPortId = vipPortId;
    }

    /**
     * @return the adminStateUp
     */
    public Boolean getAdminStateUp()
    {
        return adminStateUp;
    }

    /**
     * @param adminStateUp the adminStateUp to set
     */
    public void setAdminStateUp(Boolean adminStateUp)
    {
        this.adminStateUp = adminStateUp;
    }

    /**
     * @return the tenantId
     */
    public String getTenantId()
    {
        return tenantId;
    }

    /**
     * @param tenantId the tenantId to set
     */
    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    /**
     * @return the provisioningStatus
     */
    public String getProvisioningStatus()
    {
        return provisioningStatus;
    }

    /**
     * @param provisioningStatus the provisioningStatus to set
     */
    public void setProvisioningStatus(String provisioningStatus)
    {
        this.provisioningStatus = provisioningStatus;
    }

    /**
     * @return the listeners
     */
    public List<String> getListeners()
    {
        return listeners;
    }

    /**
     * @param listeners the listeners to set
     */
    public void setListeners(List<String> listeners)
    {
        this.listeners = listeners;
    }

    /**
     * @return the vipAddress
     */
    public String getVipAddress()
    {
        return vipAddress;
    }

    /**
     * @param vipAddress the vipAddress to set
     */
    public void setVipAddress(String vipAddress)
    {
        this.vipAddress = vipAddress;
    }

    /**
     * @return the vipSubnetId
     */
    public String getVipSubnetId()
    {
        return vipSubnetId;
    }

    /**
     * @param vipSubnetId the vipSubnetId to set
     */
    public void setVipSubnetId(String vipSubnetId)
    {
        this.vipSubnetId = vipSubnetId;
    }

    public String getVipSubnetName()
    {
        return vipSubnetName;
    }

    public void setVipSubnetName(String vipSubnetName)
    {
        this.vipSubnetName = vipSubnetName;
    }

    /**
     * @return the operatingStatus
     */
    public String getOperatingStatus()
    {
        return operatingStatus;
    }

    /**
     * @param operatingStatus the operatingStatus to set
     */
    public void setOperatingStatus(String operatingStatus)
    {
        this.operatingStatus = operatingStatus;
    }
}
