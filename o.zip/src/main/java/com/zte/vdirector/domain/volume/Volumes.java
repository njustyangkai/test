package com.zte.vdirector.domain.volume;

import java.util.List;

public class Volumes 
{
	private List<Volume> volumes;

	public List<Volume> getVolumes()
	{
		return volumes;
	}

	public void setVolumes(List<Volume> volumes)
	{
		this.volumes = volumes;
	}
}
