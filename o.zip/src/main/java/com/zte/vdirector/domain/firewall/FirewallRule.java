package com.zte.vdirector.domain.firewall;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.CloudEnvInfo;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：FirewallRule   
 * </p>  
 * <p>  
 * 类描述：防火墙规则信息   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年5月7日 下午8:18:07 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年5月7日 下午8:18:07  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class FirewallRule
{
    /**
     * 动作
     */
    private String action;

    /**
     * 描述
     */
    private String description;

    /**
     * 目的IP
     */
    @JSONField(name = "destination_ip_address")
    private String destinationIpAddress;

    /**
     * 目的端口
     */
    @JSONField(name = "destination_port")
    private String destinationPort;

    /**
     * 是否启用
     */
    private Boolean enabled;

    /**
     * 策略ID
     */
    @JSONField(name = "firewall_policy_id")
    private String firewallPolicyId;

    /**
     * ID
     */
    private String id;

    /**
     * IP版本
     */
    @JSONField(name = "ip_version")
    private Integer ipVersion;

    /**
     * 名称
     */
    private String name;

    /**
     * 位置
     */
    private Integer position;

    /**
     * 协议
     */
    private String protocol;

    /**
     * 是否共享
     */
    private Boolean shared;

    /**
     * 源IP地址
     */
    @JSONField(name = "source_ip_address")
    private String sourceIpAddress;

    /**
     * 源端口
     */
    @JSONField(name = "source_port")
    private String sourcePort;

    /**
     * 租户ID
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    private String vdcId;

    private CloudEnvInfo cloudenv;

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    /**
     * @return the action
     */
    public String getAction()
    {
        return action;
    }

    /**
     * @param action the action to set
     */
    public void setAction(String action)
    {
        this.action = action;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return the enabled
     */
    public Boolean getEnabled()
    {
        return enabled;
    }

    /**
     * @param enabled the enabled to set
     */
    public void setEnabled(Boolean enabled)
    {
        this.enabled = enabled;
    }

    /**
     * @return the id
     */
    public String getId()
    {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the position
     */
    public Integer getPosition()
    {
        return position;
    }

    /**
     * @param position the position to set
     */
    public void setPosition(Integer position)
    {
        this.position = position;
    }

    /**
     * @return the protocol
     */
    public String getProtocol()
    {
        return protocol;
    }

    /**
     * @param protocol the protocol to set
     */
    public void setProtocol(String protocol)
    {
        this.protocol = protocol;
    }

    /**
     * @return the shared
     */
    public Boolean getShared()
    {
        return shared;
    }

    /**
     * @param shared the shared to set
     */
    public void setShared(Boolean shared)
    {
        this.shared = shared;
    }

    /**
     * @return the destinationIpAddress
     */
    public String getDestinationIpAddress()
    {
        return destinationIpAddress;
    }

    /**
     * @param destinationIpAddress the destinationIpAddress to set
     */
    public void setDestinationIpAddress(String destinationIpAddress)
    {
        this.destinationIpAddress = destinationIpAddress;
    }

    /**
     * @return the destinationPort
     */
    public String getDestinationPort()
    {
        return destinationPort;
    }

    /**
     * @param destinationPort the destinationPort to set
     */
    public void setDestinationPort(String destinationPort)
    {
        this.destinationPort = destinationPort;
    }

    /**
     * @return the firewallPolicyId
     */
    public String getFirewallPolicyId()
    {
        return firewallPolicyId;
    }

    /**
     * @param firewallPolicyId the firewallPolicyId to set
     */
    public void setFirewallPolicyId(String firewallPolicyId)
    {
        this.firewallPolicyId = firewallPolicyId;
    }

    /**
     * @return the ipVersion
     */
    public Integer getIpVersion()
    {
        return ipVersion;
    }

    /**
     * @param ipVersion the ipVersion to set
     */
    public void setIpVersion(Integer ipVersion)
    {
        this.ipVersion = ipVersion;
    }

    /**
     * @return the sourceIpAddress
     */
    public String getSourceIpAddress()
    {
        return sourceIpAddress;
    }

    /**
     * @param sourceIpAddress the sourceIpAddress to set
     */
    public void setSourceIpAddress(String sourceIpAddress)
    {
        this.sourceIpAddress = sourceIpAddress;
    }

    /**
     * @return the sourcePort
     */
    public String getSourcePort()
    {
        return sourcePort;
    }

    /**
     * @param sourcePort the sourcePort to set
     */
    public void setSourcePort(String sourcePort)
    {
        this.sourcePort = sourcePort;
    }

    /**
     * @return the tenantId
     */
    public String getTenantId()
    {
        return tenantId;
    }

    /**
     * @param tenantId the tenantId to set
     */
    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    public CloudEnvInfo getCloudenv()
    {
        return cloudenv;
    }

    public void setCloudenv(CloudEnvInfo cloudenv)
    {
        this.cloudenv = cloudenv;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
