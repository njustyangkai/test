package com.zte.vdirector.domain.volume;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.frame.utils.Utils;

public class Volume
{
    private String id;

    private String name;

    private Integer size;

    private String status;

    private String description;

    private String bootable;

    private String vdcId;

    private List<Map<String, String>> attachments;

    private Map<String, String> metadata;

    private Boolean multiattach;

    private Boolean encrypted;

    @JSONField(name = "volume_type")
    private String volumeType;

    @JSONField(name = "availability_zone")
    private String availabilityZone;

    @JSONField(name = "os-vol-host-attr:host")
    private String osVolHostAttrHost;

    @JSONField(name = "source_volid")
    private String sourceVolid;

    @JSONField(name = "snapshot_id")
    private String snapshotId;

    @JSONField(name = "user_id")
    private String userId;

    @JSONField(name = "created_at")
    private String createdAt;

    @JSONField(name = "os-vol-tenant-attr:tenant_id")
    private String tenantId;

    @JSONField(name = "volume_image_metadata")
    private Map<String, String> volumeImageData;

    @JSONField(name = "os-volume-replication:extended_status")
    private String extendedStatus;

    @JSONField(name = "replication_status")
    private String replicationStatus;

    @JSONField(name = "os-vol-mig-status-attr:migstat")
    private String osVolMigStatusAttrMigstat;

    @JSONField(name = "os-volume-replication:driver_data")
    private String driverData;

    @JSONField(name = "consistencygroup_id")
    private String consistencygroupId;

    @JSONField(name = "os-vol-mig-status-attr:name_id")
    private String osVolMigStatusAttrNameId;

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Integer getSize()
    {
        return size;
    }

    public void setSize(Integer size)
    {
        this.size = size;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getBootable()
    {
        return bootable;
    }

    public void setBootable(String bootable)
    {
        this.bootable = bootable;
    }

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    public List<Map<String, String>> getAttachments()
    {
        return attachments;
    }

    public void setAttachments(List<Map<String, String>> attachments)
    {
        this.attachments = attachments;
    }

    public Map<String, String> getMetadata()
    {
        return metadata;
    }

    public void setMetadata(Map<String, String> metadata)
    {
        this.metadata = metadata;
    }

    public Boolean getMultiattach()
    {
        return multiattach;
    }

    public void setMultiattach(Boolean multiattach)
    {
        this.multiattach = multiattach;
    }

    public Boolean getEncrypted()
    {
        return encrypted;
    }

    public void setEncrypted(Boolean encrypted)
    {
        this.encrypted = encrypted;
    }

    public String getVolumeType()
    {
        return volumeType;
    }

    public void setVolumeType(String volumeType)
    {
        this.volumeType = volumeType;
    }

    public String getAvailabilityZone()
    {
        return availabilityZone;
    }

    public void setAvailabilityZone(String availabilityZone)
    {
        this.availabilityZone = availabilityZone;
    }

    public String getOsVolHostAttrHost()
    {
        return osVolHostAttrHost;
    }

    public void setOsVolHostAttrHost(String osVolHostAttrHost)
    {
        this.osVolHostAttrHost = osVolHostAttrHost;
    }

    public String getSourceVolid()
    {
        return sourceVolid;
    }

    public void setSourceVolid(String sourceVolid)
    {
        this.sourceVolid = sourceVolid;
    }

    public String getSnapshotId()
    {
        return snapshotId;
    }

    public void setSnapshotId(String snapshotId)
    {
        this.snapshotId = snapshotId;
    }

    public String getUserId()
    {
        return userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getCreatedAt()
    {
        return createdAt;
    }

    public void setCreatedAt(String createdAt)
    {
        this.createdAt = Utils.convertTimeFormat(createdAt);
    }

    public String getTenantId()
    {
        return tenantId;
    }

    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    public Map<String, String> getVolumeImageData()
    {
        return volumeImageData;
    }

    public void setVolumeImageData(Map<String, String> volumeImageData)
    {
        this.volumeImageData = volumeImageData;
    }

    public String getExtendedStatus()
    {
        return extendedStatus;
    }

    public void setExtendedStatus(String extendedStatus)
    {
        this.extendedStatus = extendedStatus;
    }

    public String getReplicationStatus()
    {
        return replicationStatus;
    }

    public void setReplicationStatus(String replicationStatus)
    {
        this.replicationStatus = replicationStatus;
    }

    public String getOsVolMigStatusAttrMigstat()
    {
        return osVolMigStatusAttrMigstat;
    }

    public void setOsVolMigStatusAttrMigstat(String osVolMigStatusAttrMigstat)
    {
        this.osVolMigStatusAttrMigstat = osVolMigStatusAttrMigstat;
    }

    public String getDriverData()
    {
        return driverData;
    }

    public void setDriverData(String driverData)
    {
        this.driverData = driverData;
    }

    public String getConsistencygroupId()
    {
        return consistencygroupId;
    }

    public void setConsistencygroupId(String consistencygroupId)
    {
        this.consistencygroupId = consistencygroupId;
    }

    public String getOsVolMigStatusAttrNameId()
    {
        return osVolMigStatusAttrNameId;
    }

    public void setOsVolMigStatusAttrNameId(String osVolMigStatusAttrNameId)
    {
        this.osVolMigStatusAttrNameId = osVolMigStatusAttrNameId;
    }
}
