package com.zte.vdirector.domain.gridqueryparams;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：ORG  
 * </p>  
 * <p>   
 * 类名称：GridQueryParams   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10184649   
 * </p>  
 * <p>  
 * 创建时间：2016年7月28日 下午4:05:18 
 * </p>  
 * <p>    
 * 修改人：10184649  
 * </p>  
 * <p>  
 * 修改时间：2016年7月28日 下午4:05:18  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class GridQueryParams 
{
	private Integer limit;//单页数量
    private Integer offset;//本页起始
    private String search;//输入的查询值，模糊查询
    private String sort;//排序的值
    private String order;//排序的类型，asc或desc
    private String filter;
    
	public Integer getLimit() 
	{
		return limit;
	}
	public void setLimit(Integer limit) 
	{
		this.limit = limit;
	}
	public Integer getOffset() 
	{
		return offset;
	}
	public void setOffset(Integer offset)
	{
		this.offset = offset;
	}
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) 
	{
		this.search = search;
	}
	public String getSort() 
	{
		return sort;
	}
	public void setSort(String sort) 
	{
		this.sort = sort;
	}
	public String getOrder()
	{
		return order;
	}
	public void setOrder(String order) 
	{
		this.order = order;
	}
	public String getFilter() 
	{
		return filter;
	}
	public void setFilter(String filter) 
	{
		this.filter = filter;
	}
}
