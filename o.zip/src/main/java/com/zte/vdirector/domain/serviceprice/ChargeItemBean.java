package com.zte.vdirector.domain.serviceprice;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：operate  
 * </p>  
 * <p>   
 * 类名称：ChargeItemBean   
 * </p>  
 * <p>  
 * 类描述：计费项   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2016年10月29日 下午5:04:16 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2016年10月29日 下午5:04:16  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class ChargeItemBean implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 5126624347345086120L;

    /**
     * ID
     */
    private String id;

    /**
     * 名称
     */
    private String name;

    /**
     * 服务目录ID
     */
    private String serviceDirectoryId;

    /**
     * 父计费项ID
     */
    private String parentId;

    /**
     * 价格
     */
    private String price;

    /**
     * 状态 1-可用 2-禁用
     */
    private int status;

    /**
     * 描述
     */
    private String description;

    /**
     * 单位
     */
    private String unit;

    /**
     * 是否叶子节点 0-否；1-是
     */
    private int isleaf;

    private List<ChargeItemBean> children;

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getServiceDirectoryId()
    {
        return serviceDirectoryId;
    }

    public void setServiceDirectoryId(String serviceDirectoryId)
    {
        this.serviceDirectoryId = serviceDirectoryId;
    }

    public String getParentId()
    {
        return parentId;
    }

    public void setParentId(String parentId)
    {
        this.parentId = parentId;
    }

    public String getPrice()
    {
        return price;
    }

    public void setPrice(String price)
    {
        this.price = price;
    }

    public String getUnit()
    {
        return unit;
    }

    public void setUnit(String unit)
    {
        this.unit = unit;
    }

    public int getIsleaf()
    {
        return isleaf;
    }

    public void setIsleaf(int isleaf)
    {
        this.isleaf = isleaf;
    }

    public List<ChargeItemBean> getChildren()
    {
        return children;
    }

    public void setChildren(List<ChargeItemBean> children)
    {
        this.children = children;
    }

    public int getStatus()
    {
        return status;
    }

    public void setStatus(int status)
    {
        this.status = status;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public ChargeItemBean clone()
    {
        ChargeItemBean newSubItem = new ChargeItemBean();
        newSubItem.setId(this.getId());
        newSubItem.setName(this.getName());
        newSubItem.setParentId(this.getParentId());
        newSubItem.setChildren(this.getChildren());
        newSubItem.setDescription(this.getDescription());
        newSubItem.setIsleaf(this.getIsleaf());
        newSubItem.setPrice(this.getPrice());
        newSubItem.setServiceDirectoryId(this.getServiceDirectoryId());
        newSubItem.setStatus(this.getStatus());
        newSubItem.setUnit(this.getUnit());
        return newSubItem;
    }
}
