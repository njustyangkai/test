/*
 * ZTE Corporation, Copyright 2001-2016, All rights reserved.
 * author      date         time      
 * ─────────────────────────────────────────────
 * 10171003     2016年10月21日      下午5:25:04
*/
package com.zte.vdirector.domain.ticket;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * <p>
 * 描述: 
 * </p>
 * <p>
 * 版权所有: 版权所有(C)2001-2016
 * </p>
 * <p>
 * 公 司: 深圳市中兴通讯股份有限公司
 * </p>
 * <p>
 * 版本2.0: 
 * </p> 
 * <p>
 * 版本2.0: 
 * </p>
 * @author 10171003
 * @version 2.0
 */

public class TicketResourceRowMapper implements RowMapper<TicketResourceBean>
{
    public TicketResourceBean mapRow(ResultSet rs, int rowNum) throws SQLException
    {
        TicketResourceBean ticketBean = new TicketResourceBean();

        ticketBean.setAppType(rs.getString("APP_TYPE"));
        ticketBean.setDeviceCode(rs.getString("DEVICE_CODE"));
        ticketBean.setDeviceCpuNew(rs.getString("DEVICE_CPU_NEW"));
        ticketBean.setDeviceHardDiskNew(rs.getString("DEVICE_HARDDISK_NEW"));
        ticketBean.setDeviceMemoryNew(rs.getString("DEVICE_MEMORY_NEW"));
        ticketBean.setDeviceType(rs.getString("DEVICE_TYPE"));
        ticketBean.setNetCn2New(rs.getString("NET_CN2_NEW"));
        ticketBean.setNetEniNew(rs.getString("NET_ENI_NEW"));
        ticketBean.setNetInternetNew(rs.getString("NET_INTERNET_NEW"));
        ticketBean.setNetbPlaneNew(rs.getString("NET_BPLANE_NEW"));
        ticketBean.setOsVersion(rs.getString("OS_VERSION"));
        ticketBean.setRemark(rs.getString("REMARK"));
        ticketBean.setServerFunction(rs.getString("SERVER_FUNCTION"));
        ticketBean.setVmName(rs.getString("VM_NAME"));

        return ticketBean;
    }

}
