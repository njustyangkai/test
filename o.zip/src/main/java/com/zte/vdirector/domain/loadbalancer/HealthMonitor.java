package com.zte.vdirector.domain.loadbalancer;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.annotation.JSONField;
import com.zte.vdirector.domain.CloudEnvInfo;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：HealthMonitor   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年8月28日 下午7:29:19 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年8月28日 下午7:29:19  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class HealthMonitor
{
    /**
     * Unique identifier for the health monitor.
     */
    private String id;

    /**
     * Owner of the health monitor. Only an admin user can specify a tenant identifier other than its own.
     */
    @JSONField(name = "tenant_id")
    private String tenantId;

    @JSONField(name = "pool_id")
    private String poolId;

    /**
     * Administrative state of the health monitor
     */
    @JSONField(name = "admin_state_up")
    private Boolean adminStateUp;

    /**
     * The type of probe send by load balancer to verify member state
     */
    private String type;

    /**
     * The time in seconds between sending probes to members.
     */
    private Integer delay;

    /**
     * Number of allowed connection failures before changing the member's status to INACTIVE.
     */
    @JSONField(name = "max_retries")
    private Integer maxRetries;

    /**
     * The maximum number of seconds for a monitor to wait for a connection to be established before it times out. The value must be less than the delay value.
     */
    private Integer timeout;

    /**
     * The HTTP method used for requests by the monitor.
     */
    @JSONField(name = "http_method")
    private String httpMethod;

    /**
     * The HTTP path of the request sent by the monitor to test a member's health. This must be a string beginning with a / (forwardslash).
     */
    @JSONField(name = "url_path")
    private String urlPath;

    /**
     * The list of HTTP status codes expected in response from the member to declare it healthy.
     */
    @JSONField(name = "expected_codes")
    private String expectedCodes;

    /**
     * Indicates whether a health monitor is currently operational.
     */
    private String status;
    
    private JSONArray pools;

    private CloudEnvInfo cloudenv;

    private String vdcId;

    public String getVdcId()
    {
        return vdcId;
    }

    public void setVdcId(String vdcId)
    {
        this.vdcId = vdcId;
    }

    public CloudEnvInfo getCloudenv()
    {
        return cloudenv;
    }

    public void setCloudenv(CloudEnvInfo cloudenv)
    {
        this.cloudenv = cloudenv;
    }

    /**
     * @return the pools
     */
    public JSONArray getPools()
    {
        return pools;
    }

    /**
     * @param pools the pools to set
     */
    public void setPools(JSONArray pools)
    {
        this.pools = pools;
    }

    /**
     * @return the poolId
     */
    public String getPoolId()
    {
        return poolId;
    }

    /**
     * @param poolId the poolId to set
     */
    public void setPoolId(String poolId)
    {
        this.poolId = poolId;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getTenantId()
    {
        return tenantId;
    }

    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    public Boolean getAdminStateUp()
    {
        return adminStateUp;
    }

    public void setAdminStateUp(Boolean adminStateUp)
    {
        this.adminStateUp = adminStateUp;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public Integer getDelay()
    {
        return delay;
    }

    public void setDelay(Integer delay)
    {
        this.delay = delay;
    }

    public Integer getMaxRetries()
    {
        return maxRetries;
    }

    public void setMaxRetries(Integer maxRetries)
    {
        this.maxRetries = maxRetries;
    }

    public Integer getTimeout()
    {
        return timeout;
    }

    public void setTimeout(Integer timeout)
    {
        this.timeout = timeout;
    }

    public String getHttpMethod()
    {
        return httpMethod;
    }

    public void setHttpMethod(String httpMethod)
    {
        this.httpMethod = httpMethod;
    }

    public String getUrlPath()
    {
        return urlPath;
    }

    public void setUrlPath(String urlPath)
    {
        this.urlPath = urlPath;
    }

    public String getExpectedCodes()
    {
        return expectedCodes;
    }

    public void setExpectedCodes(String expectedCodes)
    {
        this.expectedCodes = expectedCodes;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
