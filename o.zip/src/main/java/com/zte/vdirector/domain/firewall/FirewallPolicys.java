/**
 * 
 */
package com.zte.vdirector.domain.firewall;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

/** 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：FirewallPolicys   
 * </p>  
 * <p>  
 * 类描述：防火墙规则列表封装类   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "firewall_policies": [
 *         {
 *             "name": "test-fxm",
 *             "firewall_rules": [],
 *             "tenant_id": "40bb3ee25d604d219866d08a93150c40",
 *             "audited": false,
 *             "shared": false,
 *             "id": "3613ac5d-65db-4170-80a6-d7fdce37d669",
 *             "description": ""
 *         }
 *     ]
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月24日 下午4:25:32 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月24日 下午4:25:32  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *    
 */
public class FirewallPolicys
{
    /**
     * 防火墙规则列表
     */
    @JSONField(name = "firewall_policies")
    private List<FirewallPolicy> firewallPolicies;

    /**
     * @return the firewallPolicies
     */
    public List<FirewallPolicy> getFirewallPolicies()
    {
        return firewallPolicies;
    }

    /**
     * @param firewallPolicies the firewallPolicies to set
     */
    public void setFirewallPolicies(List<FirewallPolicy> firewallPolicies)
    {
        this.firewallPolicies = firewallPolicies;
    }

    /**
     * 将调用每个DC的响应结果聚合为一个
     * 
     * @param wrapperList 响应列表
     * @return 聚合响应
     */
    public FirewallPolicys combine(ArrayList<FirewallPolicys> wrapperList)
    {
        FirewallPolicys finalWrapper = new FirewallPolicys();
        List<FirewallPolicy> itemList = new ArrayList<FirewallPolicy>();
        for (FirewallPolicys wrapperItem : wrapperList)
        {
            if (null == wrapperItem || null == wrapperItem.getFirewallPolicies())
            {
                continue;
            }
            itemList.addAll(wrapperItem.getFirewallPolicies());
        }
        finalWrapper.setFirewallPolicies(itemList);
        return finalWrapper;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }
}
