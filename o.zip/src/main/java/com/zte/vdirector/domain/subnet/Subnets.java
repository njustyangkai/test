package com.zte.vdirector.domain.subnet;

import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSON;

/**
 * 
 * <p>  
 * 版权所有：中兴通讯股份有限公司   
 * </p>  
 * <p>  
 * 项目名称：openstack-api  
 * </p>  
 * <p>   
 * 类名称：Subnets   
 * </p>  
 * <p>  
 * 类描述：   
 * </p>  
 * <p>Example:
 * <p><blockquote><pre>
 * {
 *     "subnets": [
 *         {
 *             "name": "External-Subnet2",
 *             "enable_dhcp": true,
 *             "network_id": "e49d9cdb-191f-419a-b1a1-a70c067aebfe",
 *             "tenant_id": "f241a207f7d24dd0a7d45582aa7295e4",
 *             "dns_nameservers": [],
 *             "allocation_pools": [
 *                 {
 *                     "start": "192.168.2.2",
 *                     "end": "192.168.2.254"
 *                 }
 *             ],
 *             "host_routes": [],
 *             "ip_version": 4,
 *             "gateway_ip": "192.168.2.1",
 *             "cidr": "192.168.2.0/24",
 *             "id": "39703064-7c49-4cb5-8b99-681f8e9d8596"
 *         }
 *     ]
 * }
 * </pre></blockquote><p>  
 * <p>  
 * 创建人：10155603   
 * </p>  
 * <p>  
 * 创建时间：2014年4月22日 下午3:16:09 
 * </p>  
 * <p>    
 * 修改人：10155603  
 * </p>  
 * <p>  
 * 修改时间：2014年4月22日 下午3:16:09  
 * </p>  
 * <p>   
 * 修改备注： 
 * </p>    
 * @version 1.0   
 *
 */
public class Subnets implements Iterable<Subnet>
{
    /**
     * 子网列表 
     */
    private List<Subnet> subnets;

    public List<Subnet> getSubnets()
    {
        return subnets;
    }

    public void setSubnets(List<Subnet> subnets)
    {
        this.subnets = subnets;
    }

    /**
     * To string.
     * 
     * @return the string
     */
    @Override
    public String toString()
    {
        return JSON.toJSONString(this);
    }

    @Override
    public Iterator<Subnet> iterator()
    {
        return subnets.iterator();
    }
}
